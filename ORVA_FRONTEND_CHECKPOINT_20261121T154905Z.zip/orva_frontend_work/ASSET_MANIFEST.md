# ORVA Android Frontend — Asset Manifest

All referenced showcase imagery and typography are bundled locally. The approved A/B/C font families now resolve from the active Home/About morph region. Variable-font axes are applied on Android API 26+; generated static instances provide typography fallbacks on the project's API 24–25 minimum range. Bengali copy uses Noto Sans Bengali with zero letter spacing. No runtime font CDN or download dependency is used.

The About Scene 07 mosaic is labelled **CONCEPTUAL IMAGE STUDIES** and Scene 08 treats its cover as a **CONCEPT / DOMAIN RULES** study. These generated visual studies are atmospheric editorial artwork, not real pharmacy photography, ORVA interface screenshots or evidence of a deployed workspace. Scene 08 overlays verified domain constraints as editorial annotations; the background image itself is illustrative. The intended final photography swap remains pending local acquisition of the verified Pexels candidates below.

## Bundled Drawable Imagery (`app/src/main/res/drawable/`)

| Local Filename | Origin / Source | Creator / License | Date Added | Planned Use in ORVA | Model / Property / Trademark Notes |
|---|---|---|---|---|---|
| `apothecary_frieze_bw.jpg` | Existing ORVA project asset | ORVA / Rindle Works owned asset | Pre-existing | Shared Home & About closing monochrome scroll frieze (`OrvaScrollFrieze.kt`) | None — original project asset |
| `editorial_architecture_light.jpg` | Studio-generated monochrome architectural photography (offline sandbox) | Generated for Rindle Works × ORVA showcase; replaceable with licensed Pexels ([license](https://www.pexels.com/license/)) or Unsplash ([license](https://unsplash.com/license)) photography | 2026-11-20 | Home H1 Hero background (`HomeScreen.kt`) & About Scene 07 Field Notes tile (`SYSTEM / STRUCTURE`) | Text-free, unbranded architectural geometry; zero identifiable people or trademarks |
| `editorial_apothecary_shelves.jpg` | Studio-generated monochrome apothecary glass shelving (offline sandbox) | Generated for Rindle Works × ORVA showcase; replaceable with licensed Pexels/Unsplash photography | 2026-11-20 | Home H2 Lantern reveal surface (`HomeScreen.kt`), About Scene 02 POV media, Scene 05 Batch & FEFO rail card & Scene 07 Field Notes tile (`BATCH / INVENTORY`) | Text-free, unbranded glass bottles; zero third-party pharmacy branding. Atmospheric artwork only; not a real ORVA shop photograph |
| `editorial_thermal_counter.jpg` | Studio-generated monochrome macro counter paper/hardware (offline sandbox) | Generated for Rindle Works × ORVA showcase; replaceable with licensed Pexels/Unsplash photography | 2026-11-20 | Home H3 Cinematic scroll section (`HomeScreen.kt`), About Scene 05 Counter Billing rail card, Scene 07 Field Notes tile (`BILLING / WORKFLOW`) & Scene 08 conceptual domain-rules plate background | Text-free, unbranded hardware detail; zero trademarks. Atmospheric artwork only; not a real ORVA interface screenshot |
| `editorial_studio_workbench.jpg` | Studio-generated monochrome overhead drafting workbench (offline sandbox) | Generated for Rindle Works × ORVA showcase; replaceable with licensed Pexels/Unsplash photography | 2026-11-20 | About Scene 01 Studio Hero (`AboutUsScreen.kt`), Scene 07 Field Notes tile (`SYSTEM / DETAIL`), Home H4 ORVA case-study cover and About Scene 05 Returns & Ledger rail card | Text-free, unbranded studio tools; zero identifiable people or logos. Atmospheric artwork only; not a real ORVA workspace or product screenshot |

## Bundled Local Fonts (`app/src/main/res/font/`)

| Local Filename | Family | License | Role / Platform Use |
|---|---|---|---|
| `archivo_variable.ttf` | Archivo Variable | SIL OFL 1.1 | Theme A display; `wght` 100–900, `wdth` 62–125 |
| `archivo_display_fallback_regular.ttf` | Archivo | SIL OFL 1.1 | API 24–25 static display fallback, weight 600 / width 86 |
| `archivo_display_fallback_bold.ttf` | Archivo | SIL OFL 1.1 | API 24–25 static display fallback, weight 900 / width 86 |
| `newsreader_variable.ttf` | Newsreader Variable | SIL OFL 1.1 | Theme A reading; `wght` 200–800, `opsz` 6–72 |
| `newsreader_reading_fallback.ttf` | Newsreader | SIL OFL 1.1 | API 24–25 static reading fallback, weight 400 / optical size 18 |
| `space_mono_regular.ttf` | Space Mono Regular | SIL OFL 1.1 | Theme A utility regular |
| `space_mono_bold.ttf` | Space Mono Bold | SIL OFL 1.1 | Theme A utility bold; shares Space Mono's OFL notice |
| `bricolage_grotesque_variable.ttf` | Bricolage Grotesque Variable | SIL OFL 1.1 | Theme B display; `opsz` 12–96, `wdth` 75–100, `wght` 200–800 |
| `bricolage_display_fallback_regular.ttf` | Bricolage Grotesque | SIL OFL 1.1 | API 24–25 static display fallback, weight 600 / width 92 / optical size 96 |
| `bricolage_display_fallback_bold.ttf` | Bricolage Grotesque | SIL OFL 1.1 | API 24–25 static display fallback, weight 800 / width 92 / optical size 96 |
| `source_serif_4_variable.ttf` | Source Serif 4 Variable | SIL OFL 1.1 | Theme B reading; `wght` 200–900, `opsz` 8–60 |
| `source_serif_4_reading_fallback.ttf` | Source Serif 4 | SIL OFL 1.1 | API 24–25 static reading fallback, weight 400 / optical size 20 |
| `martian_mono_variable.ttf` | Martian Mono Variable | SIL OFL 1.1 | Theme B utility; `wght` 100–800; this supplied cut has `wdth` fixed at 112.5 |
| `martian_mono_utility_fallback.ttf` | Martian Mono | SIL OFL 1.1 | API 24–25 static utility fallback, weight 400 / width 112.5 |
| `gloock_regular.ttf` | Gloock Regular | SIL OFL 1.1 | Theme C static display; no variable axes |
| `schibsted_grotesk_variable.ttf` | Schibsted Grotesk Variable | SIL OFL 1.1 | Theme C reading; `wght` 400–900 |
| `schibsted_grotesk_reading_fallback.ttf` | Schibsted Grotesk | SIL OFL 1.1 | API 24–25 static reading fallback, weight 400 |
| `ibm_plex_mono.ttf` | IBM Plex Mono | SIL OFL 1.1 | Existing Theme C utility family |
| `noto_sans_bengali.ttf` | Noto Sans Bengali | SIL OFL 1.1 | Existing Bengali script family for all three themes |

### Approved A/B/C role resolution

| Theme | Display | Reading | Utility |
|---|---|---|---|
| A — The Measured Press | Archivo | Newsreader | Space Mono Regular + Bold |
| B — The Field Specimen | Bricolage Grotesque | Source Serif 4 | Martian Mono |
| C — The Museum Index | Gloock (static) | Schibsted Grotesk | IBM Plex Mono (existing) |

Each Home H1–H6 and About S01–S09 region provides its active `OrvaDesignTheme` to the shared typography resolver. Navigation remains on the default A identity; Home/About content regions use their own live morph theme. No separate user-facing font/theme picker was introduced.

Compose resource-font `FontVariation.Settings` are used only on Android API 26 and above. The eight static fallback instances are generated from the same approved font files for API 24–25; they remain covered by their source families' SIL OFL 1.1 notices. Archivo's `wdth` value is responsive from 86 at 360dp to 125 at 840dp. Bricolage uses the existing theme profile's weight/width/optical-size values; Gloock remains static. Martian Mono's supplied `wdth` axis is fixed at its default/maximum 112.5 and is not animated or fabricated.

The eight newly acquired families have full upstream notices in `third_party/font_licenses/`: Archivo, Newsreader, Space Mono, Bricolage Grotesque, Source Serif 4, Martian Mono, Gloock and Schibsted Grotesk. Separate notices are also retained for the existing IBM Plex Mono and Noto Sans Bengali assets. No old Space Grotesk, Instrument Serif or Plus Jakarta Sans font resources remain in `res/font/` or in the theme role resolver.

`tools/fetch_orva_showcase_fonts.py` remains the fixed-source, dependency-free downloader for the nine upstream TTF files and eight new-family OFL notices. `python tools/fetch_orva_showcase_fonts.py --check-only` validates the allowlisted acquisition manifest without network access. The API 24–25 static fallback instances are checked into `res/font/` and do not require a runtime tool or dependency.

## Verified External Photo Sources — Candidate Bundle Set (21 Nov 2026)

These individual Pexels pages were opened and checked for creator attribution and Pexels' "Free to use" designation. They are selected candidates for Rindle Works' locally bundled portfolio imagery. **They are not yet present in `res/drawable/`**; the current app still references the four existing generated monochrome images until the source files can be placed in the project and optimised. Do not replace local resource references with remote URLs.

| Candidate local filename | Original photo page | Creator | Direct download source | Intended composition | Status |
|---|---|---|---|---|---|
| `pexels_apothecary_shelves.jpg` | https://www.pexels.com/photo/pharmacy-shelves-and-ladder-6074000/ | Eva Bronzini | https://images.pexels.com/photos/6074000/pexels-photo-6074000.jpeg?cs=srgb&dl=pexels-eva-bronzini-6074000.jpg&fm=jpg | Home lantern reveal, About point-of-view scene and field-notes mosaic. Strong dark shelf image; consider monochrome grade and tight crop. | Verified source/licence; binary not bundled |
| `pexels_industrial_corridor.jpg` | https://www.pexels.com/photo/industrial-building-corridor-with-metal-grating-34112019/ | David Nestorov | https://images.pexels.com/photos/34112019/pexels-photo-34112019.jpeg?cs=srgb&dl=pexels-david-nestorov-2153481354-34112019.jpg&fm=jpg | Architectural full-bleed scene / background for Rindle Works hero or scene transition. Tall perspective composition. | Verified source/licence; binary not bundled |
| `pexels_workbench_blueprints.jpg` | https://www.pexels.com/photo/a-laptop-on-a-work-table-5846172/ | Tima Miroshnichenko | https://images.pexels.com/photos/5846172/pexels-photo-5846172.jpeg?cs=srgb&dl=pexels-tima-miroshnichenko-5846172.jpg&fm=jpg | Studio process / engineering field-note image. Crop to remove distracting screen text and colour-grade to the showcase palette. | Verified source/licence; binary not bundled |
| `pexels_pos_thermal_paper.jpg` | https://www.pexels.com/photo/a-pos-terminal-with-thermal-paper-9755391/ | Towfiqu barbhuiya | https://images.pexels.com/photos/9755391/pexels-photo-9755391.jpeg?cs=srgb&dl=pexels-towfiqu-barbhuiya-3440682-9755391.jpg&fm=jpg | ORVA billing/product case-study scene and receipt/transaction detail. Monochrome or restrained grade to remove blue clash. | Verified source/licence; binary not bundled |

Pexels licence: https://www.pexels.com/license/ — Pexels states that photos/videos can be used for free and modified; attribution is not required but is appreciated. It prohibits implying endorsement, redistributing unmodified stock as stock, and using photos as part of a trademark, design mark, trade name, business name or service mark. Keep creator and source attribution in this manifest even though attribution is optional. Avoid implying that any photographed person or brand endorses ORVA.

**Packaging rule:** once files are locally available, resize/crop for their specific layouts, preserve each original creator/source/licence entry, optimise JPEG quality and inspect the resulting crops on 360dp, 390dp and 412dp layouts. Never hotlink these CDN URLs at runtime.
