# Third-Party Notices & Attributions

## 1. CursorSwarm (`cursor-swarm.js`) — MIT License

Multi-agent page-building choreography concepts (role-specialized cursors, idle edge-dimming, blinking typing caret, media scan-line wipe, snap ripples, completion micro-sparks, and HUD controls) in `app/src/main/java/com/rindleworks/orva/ui/about/agentic/` are adapted in native Kotlin / Jetpack Compose with reference to `cursor-swarm.js` by Zheng Lin Lei ([https://github.com/ZhengLinLei/cursor-swarm.js](https://github.com/ZhengLinLei/cursor-swarm.js)).

```text
© 2026 ZhengLinLei <zheng9112003@icloud.com>

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
```

## 2. Visual & Motion Inspiration (No Code or Assets Copied)

- **zll.me** ([https://zll.me/](https://zll.me/)): Editorial portfolio pacing, chapter-scene structure, horizontal rail layout, and asymmetric field-notes gallery inspiration. Zero personal identity, text, or media assets copied.
- **saai.pro** ([https://saai.pro/](https://saai.pro/)): Architectural drafting ruler ticks and telemetry HUD inspiration. Zero branding, text, or assets copied.
- **21st.dev** ([https://21st.dev/@ibelick/components/glow-effect](https://21st.dev/@ibelick/components/glow-effect), [https://21st.dev/@dillionverma/components/border-beam](https://21st.dev/@dillionverma/components/border-beam)): Conceptual reference for controlled specular glow and traveling perimeter border beams, re-engineered natively in Jetpack Compose Canvas (`AgenticOverlayCanvas.kt`). Zero React/Tailwind code copied.
- **ECHO-WEBSITE & Dynamic-Portfolio-Website-**: Visual rhythm inspiration only; zero code, fonts, or media assets copied.

## 3. Bundled Fonts (`app/src/main/res/font/`)

The showcase bundles these locally installed Google Fonts families under the SIL Open Font License 1.1:

- Theme A — Archivo, Newsreader and Space Mono.
- Theme B — Bricolage Grotesque, Source Serif 4 and Martian Mono.
- Theme C — Gloock and Schibsted Grotesk, plus the existing IBM Plex Mono utility family.
- Bengali script — the existing Noto Sans Bengali family across all three themes.

The six variable families used by the theme roles have API 24–25 static fallback instances generated from those same family binaries. They are font instances, not separate third-party typefaces. Their source-family notices cover both variable and fallback files.

Full upstream SIL OFL 1.1 notices are retained as standalone text files in `third_party/font_licenses/`:

- `archivo-OFL.txt`
- `newsreader-OFL.txt`
- `spacemono-OFL.txt`
- `bricolagegrotesque-OFL.txt`
- `sourceserif4-OFL.txt`
- `martianmono-OFL.txt`
- `gloock-OFL.txt`
- `schibstedgrotesk-OFL.txt`
- `ibmplexmono-OFL.txt`
- `notosansbengali-OFL.txt`

Space Mono Regular and Bold share one family notice. The IBM Plex Mono notice preserves its upstream Reserved Font Name statement. No runtime font-download library or remote font service is used.
