# ORVA Android — Source Recovery & Continuity

## Latest implementation state — A/B/C typography integrated (21 November 2026)

- The nine approved upstream TTFs are installed in `app/src/main/res/font/`; the eight new-family OFL notices plus IBM Plex Mono and Noto Sans Bengali notices are in `third_party/font_licenses/`.
- `OrvaShowcaseFonts` resolves display, reading and utility roles from the live region theme. Home H1–H6 and About S01–S09 each provide their active A/B/C identity. Navigation defaults to A. Bengali copy resolves to Noto Sans Bengali and zero tracking.
- API 26+ uses the real supported variable-font axes. Android API 24–25 uses eight static instances generated from the same approved source families. Gloock remains static; Martian Mono's supplied width axis stays at its actual fixed 112.5 value.
- The old Space Grotesk, Instrument Serif and Plus Jakarta Sans font files and mappings have been removed. The existing Agentic Build controller, 16-agent roster, shared frame clock, Home/About regions, H2 lantern sweep and morph scheduling remain in place.
- Verification: pure Kotlin tests **93 passed, 0 failed**; downloader `py_compile` and `--check-only` passed; FontTools confirmed 19 local TTF resources, six variable-font axis tables, eight static fallbacks and ten SIL OFL 1.1 notices; 126 showcase Text calls all specify font families; `git diff --check` passed. A standalone `kotlinc` scan timed out; no parser/compile result is claimed.
- Android/Compose/Robolectric/APK/emulator/physical-device verification remains NOT RUN because this workspace does not have a Gradle wrapper/executable, Android SDK or dependency cache. Variable axes use each theme's terminal display profile; per-frame axis interpolation and visual device review remain pending.
- Remaining visual verification: inspect 360dp, 390dp, 412dp and tablet widths; verify English/Bengali shaping and tracking; confirm that the A/B/C display/reading/utility roles render correctly on API 24–25 and API 26+ devices. No per-frame axis interpolation is claimed; the resolver applies each theme's terminal axis profile and the existing text reveal remains unchanged.


## Why this file exists

Chat conversations and Notion notes do not preserve the actual Android source workspace. The ChatGPT execution workspace may be reset between sessions. The persistent ChatGPT File Library is currently the verified cross-chat source recovery point; Dropbox remains the intended shared mirror when its connected upload route accepts the actual archive file.

## Source of truth

- Current frontend working project: this complete Android project folder.
- Verified persistent recovery location: `/ORVA_FRONTEND_CHECKPOINTS/` in the ChatGPT File Library. A timestamped source ZIP has been uploaded and successfully materialized back into a clean directory; the restored ZIP was byte-for-byte identical. This is the active cross-chat recovery mechanism.
- Intended shared handoff location: `/ORVA-WORKSPACE/04-INTEGRATION/ANDROID-FRONTEND/` in Dropbox. The Dropbox folder currently contains only the old placeholder; no Dropbox source snapshot has been written yet because the connected Dropbox upload action requires a file-parameter object and does not accept the local sandbox path or Library file ID directly. Do not claim a Dropbox upload until verified.
- Notion page: `https://app.notion.com/p/41dbaca0691681a7837cf353c026ac76` — decisions, architecture, change logs and handoff context only. Not a substitute for source files.
- No GitHub remote is required or used. A local Git history is retained inside checkpoint archives for file-level recovery and change comparison.

## Checkpoint policy

1. At the beginning of a new ChatGPT session, list the persistent ChatGPT File Library folder `/ORVA_FRONTEND_CHECKPOINTS/`, materialize the newest `ORVA_FRONTEND_CHECKPOINT_*.zip`, verify it, and restore it into `/mnt/data/orva_frontend_work/`. Use Dropbox as a secondary copy when an upload is available.
2. Verify the archive checksum before extraction when a `.sha256` sidecar is available.
3. Inspect `RECOVERY_AND_CONTINUITY.md`, `BUILD_REPORT.md`, and the latest Notion checkpoint before changing source.
4. Make frontend changes in this working tree only. Keep backend contracts stable and do not change billing, inventory, tax, stock, returns or financial rules without an explicit coordinated task.
5. After each complete implementation topic, create one new timestamped ZIP checkpoint and upload it to `/ORVA_FRONTEND_CHECKPOINTS/` in the persistent ChatGPT File Library. Do not create a separate archive for every small edit or patch. Never overwrite an earlier checkpoint; retain the topic-level history. Mirror it to Dropbox when the connected file-upload path accepts the exact file artifact.
6. Record the checkpoint filename, persistent Library path, Dropbox path if mirrored, changed files, test results and next topic in Notion.
7. If a session is interrupted before its topic is complete and meaningful work has accumulated, create one clearly labelled WIP snapshot to protect that work. Do not create a chain of micro-checkpoints.

## Restore procedure for a new chat

1. List the ChatGPT File Library folder `/ORVA_FRONTEND_CHECKPOINTS/` using the Files tool. This folder is persistent across chats.
2. Select the newest timestamped \`ORVA_FRONTEND_CHECKPOINT_*.zip\`; do not rely solely on chat memory.
3. Materialize the exact Library file ID to the new session's working storage and extract the archive. No user re-upload should be needed.
4. Verify the sidecar SHA-256 when available. (The current ZIP includes the local `.git` repository and complete source tree.)
5. Run `git status`; compare `BUILD_REPORT.md`, `ASSET_MANIFEST.md` and the latest Notion checkpoint.
6. Run `./tools/run_pure_kotlin_tests.sh` for the repeatable scheduler, grapheme and gesture JVM tests. This uses an isolated minimal JUnit-compatible runner and does not run Android, Compose or Robolectric tests.
7. Continue editing the recovered project. Do not reconstruct Kotlin files from summaries if the archive is available.
8. When the Dropbox upload path is available, mirror each accepted source checkpoint to `/ORVA-WORKSPACE/04-INTEGRATION/ANDROID-FRONTEND/` as an additional shared copy.

## Snapshot exclusions

Do not include local signing keys, `.env` files, `local.properties`, machine-specific SDK paths, Gradle caches, or generated build directories in source snapshots. Include source, tests, Gradle configuration, wrapper files when present, assets, manifests, build reports and this recovery guide.

## Current environment verification boundary

A source snapshot is not an APK and is not proof of a successful Android build. Build/test status must be reported separately and only when actually run in an environment with the Android SDK and resolved dependencies.


## Latest verified checkpoint pointer

- Persistent Library folder: `/ORVA_FRONTEND_CHECKPOINTS/`
- Checkpoints use the filename pattern: `ORVA_FRONTEND_CHECKPOINT_YYYYMMDDTHHMMSSZ.zip`.
- Latest snapshot: inspect the Library folder for the newest timestamp; never hardcode this pointer when a newer snapshot may exist.
- The archive contains the source tree, local `.git` commit history, asset/build manifests, tests, and this recovery guide.


## Development checkpoint discipline (user-confirmed)

- Work by complete implementation topic, not by every tiny edit. Finish one coherent topic (for example Agentic Build), run its relevant tests, and checkpoint the whole topic before starting the next.
- If an interruption occurs before the topic is complete, create a clearly labelled WIP checkpoint rather than discard the working tree.
- A completed-topic checkpoint must include the full working tree, uncommitted modifications, source report, ZIP archive and SHA-256. Verify the archive by reopening/testing it before calling it saved.
- Keep Android/Compose/Robolectric verification separate from pure JVM tests. Never label a source-only or parser-only scan as an Android build.

## Latest implementation status — 21 November 2026

- Completed topic 1: Agentic Build bidirectional DISPENSE / RESTOCK. The 16-agent roster and eight concurrent forward workers remain; reverse work is serial, completion-journal ordered, dependency-safe and restricted to content at least 1.5 viewport heights below the reader. Manual takeover, two-second instant restoration, stamp/sweep sequencing, haptic and reduced-motion guards, and the 12ms degradation policy are implemented.
- Completed topic 2: Home/About navigation and appearance boundary. The top bar retains only menu + RINDLE WORKS; the single EN / বাংলা selector is in the drawer; Paper mode state and controls are removed; Home/About use the fixed dark showcase palette. Operational `ui/theme` and business logic were not changed.
- Latest pure JVM verification: 60 passed, 0 failed; `git diff --check` passed. Compose/Robolectric, Gradle, APK, emulator and physical-device checks remain NOT RUN because this workspace has no Gradle wrapper/executable or Android SDK/dependency cache.
- The two new navigation Compose tests are authored but NOT RUN. See `BUILD_REPORT.md` for the exact scope and verification boundary.
- Next topic: local/offline delivery and role mapping for the already-approved Archivo and Space Mono fonts under ORVA Identity Spec v1's no-new-dependency/no-new-family rule.
- Latest completed source snapshot: `ORVA_FRONTEND_CHECKPOINT_20261121T094711Z.zip` in `/ORVA_FRONTEND_CHECKPOINTS/`; its matching `.sha256` sidecar is stored beside it. The verified Dropbox handoff folder is `/ORVA-WORKSPACE/04-INTEGRATION/ANDROID-FRONTEND/`, but this checkpoint has not been uploaded there.

## Latest ORVA Theme Morph milestone — 21 November 2026

- The three approved identities are A — The Measured Press, B — The Field Specimen and C — The Museum Index. They are dynamic design systems, not a user-facing theme toggle.
- About is now wired to the morph engine: random safe section anchor, region-scoped RESTOCK → layout settle → DISPENSE, outward section queue, pause/resume on manual scroll and guided scrolling for automatic mode. Existing Agentic Build cursor roster and single frame clock are reused.
- A/B/C palette, layout grammar, type-size/spacing behaviour and distinct reveal motions are applied in About. HUD/cursor/gauge colours follow the active identity. Normal visitor rewind stays separate.
- Latest pure Kotlin tests: 85 passed, 0 failed. `git diff --check`: passed. Android/Compose/Robolectric/device checks: NOT RUN.
- Still pending: exact font files and true variable axes; Home theme/morph integration and H2 lantern wordmark sweep; Android visual/build verification. See `docs/ORVA_HANDOVER_2026-11-21/11_THEME_MORPH_ENGINE_STATUS_AND_PENDING.md` and `BUILD_REPORT.md`.
- Create a new source ZIP, SHA-256 and updated manifest after committing this milestone; upload all three to `/ORVA_FRONTEND_CHECKPOINTS/`.

## Latest WIP checkpoint — 21 November 2026
- All three A/B/C identities are approved together as a live morph system.
- About morph integration is implemented. Home H1–H6 morph integration is now in progress and preserved as a WIP snapshot.
- The current WIP reuses the same Agentic controller/frame clock, adds Home region wrappers and per-theme layout/type/palette providers, and includes the H2 wordmark lantern sweep.
- Pure Kotlin tests: 86 passed, 0 failed. `git diff --check`: passed. Android/Compose/Robolectric/device checks are NOT RUN.
- Pending work: Android/Compose compile, Home-specific UI tests, EN/BN visual checks on mobile/tablet, exact A/B/C font bundling and axis implementation, and device performance/timing validation.
- The most recent checkpoint in `/ORVA_FRONTEND_CHECKPOINTS/` should be used as the recovery source; this WIP snapshot supersedes the About-only milestone for continuation.

### Latest source milestone — Home A/B/C visual composition pass (21 November 2026)
- Home H1/H2/H4/H5 now express the three approved identities through distinct composition, layout and motion; H2 lantern adapts to each identity and replays when H2 is morphed.
- Home still uses the shared Agentic Build controller, frame clock, 16-agent roster and eight-builder limit. Existing visitor scroll and business actions are preserved.
- Pure JVM tests: **87 passed, 0 failed**; `git diff --check` passed. Android/Compose/Robolectric/APK/device checks remain NOT RUN.
- Pending: bundle exact A/B/C fonts and licences, map them to type roles, implement true variable-axis animation where supported, run Android/Compose/Home UI tests, inspect EN/BN at mobile and tablet widths, and tune device performance/haptics.


## Latest source update — A/B/C typography motion foundation (21 November 2026)

- Theme A now reveals display headlines word by word using the real measured text geometry; the endpoints remain grapheme-safe for Bengali and emoji.
- Theme B fake text `scaleX` expansion was removed. It currently uses grapheme-safe reveal; intended width/weight axis values are modelled separately and checked against official Bricolage metadata. Real variable-font rendering is still pending.
- Archivo width-axis targets are tested from 86 at 360dp to 125 at 840dp. Gloock remains static; no fictional variable axes are attached to it.
- Exact A/B/C display, reading and utility family names and contrast on background + surface are guarded by tests.
- Current pure JVM result: **93 passed, 0 failed**. `git diff --check`: passed.
- IMPORTANT: font TTF binaries and new OFL notices are not yet installed. `OrvaShowcaseFonts` still references legacy Space Grotesk, Instrument Serif and Plus Jakarta Sans. The approved font migration and Android/Compose/visual verification remain incomplete.
- No billing, inventory, GST, FEFO, stock, returns or financial-domain code was changed.


## Latest frontend continuation — approved font acquisition tooling (21 November 2026)

- Added `tools/fetch_orva_showcase_fonts.py`, a no-dependency, fixed-source downloader for the nine approved TTF assets: Archivo variable; Newsreader variable; Space Mono Regular/Bold; Bricolage Grotesque variable; Source Serif 4 variable; Martian Mono variable; Gloock Regular; Schibsted Grotesk variable. IBM Plex Mono remains the existing Theme C utility face; Noto Sans Bengali remains the Bengali script face.
- The script validates the TTF/SFNT header and every SIL Open Font License 1.1 notice before installing files. Targets are `app/src/main/res/font/` and `third_party/font_licenses/`. It has no runtime dependencies and refuses to overwrite existing target fonts unless `--force` is explicit.
- Verification: `python -m py_compile tools/fetch_orva_showcase_fonts.py` passed; `python tools/fetch_orva_showcase_fonts.py --check-only` passed (9 TTF assets, 8 OFL notices). Network download was NOT completed in this workspace, and no font binaries have been installed.
- Next: run the fixed-source downloader from a network-enabled project environment; review the fonts and notices; migrate `OrvaShowcaseFonts` from the legacy Space Grotesk / Instrument Serif / Plus Jakarta Sans mappings to A/B/C theme-specific role families; apply Compose variable-font axis settings; add/run UI tests and visual checks.
- The preceding source commit remains the verified base `a218440`; this continuation must receive its own tests, commit and checkpoint before it is treated as complete.
