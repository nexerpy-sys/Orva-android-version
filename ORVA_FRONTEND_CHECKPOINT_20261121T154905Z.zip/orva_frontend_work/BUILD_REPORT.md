# ORVA Android Frontend — Build & Verification Report

**Date:** 21 November 2026
**Target Package:** `com.rindleworks.orva`  
**Specification:** `RINDLE_WORKS_ORVA_FRONTEND_MASTER_DIRECTIVE.md`

---

## 1. Summary of Changes Implemented

### Priority 1 — Agentic Build Overhaul (`ui/about/agentic/`)
- **Removed Opening ORVA Splash Text & Glow Veil:** normal motion retains the established `ORBITAL_SCAN` intro before `STRUCTURAL_BUILD`, with cursors staged cleanly on the outer viewport rails (`outside` spawn) and zero opening ORVA text/glow overlay. Reduced-motion mode skips the intro immediately.
- **Cursor-Tip-Anchored Optical Specular Glow (`AgenticOverlayCanvas.kt`):** Eliminated the oversized detached overlapping radial clouds. Every active builder now renders a tight two-stage specular halo (`16–21dp` outer radius, `4.5–6dp` inner core) anchored to the **exact arrow-tip coordinate** (`screenPos`) in the same draw pass as the pointer vector.
- **Strictly Dual-Tone Violet & Vermilion Cursor Identities (`OrvaShowcaseTokens.kt` & `AgenticBuildController.kt`):** Locked all 16 deterministic agents to Violet (`#A78BFA` / `#C4B5FD` / `#8B5CF6`) and Vermilion (`#FF604A` / `#FF8370` / `#F45A43`). Idle scouts park quietly along the viewport margins and dim (`alpha = 0.16f`, `glowEnergy = 0f`) so background halos never pile up.
- **21st.dev, cursor-swarm.js & saai.pro Construction Craft:**
  - Added traveling perimeter **Border Beam** comets around active drafting wireframes (`drawDraftingWireframeWithBeam`).
  - Added sleek obsidian-glass agent role tags (`LAYOUT`, `GRID`, `CLONE`, `SYNC`, `TYPE`, `COPY`, `MEDIA`) beside active cursors.
  - Added subtle left-rail drafting ruler ticks (`saai.pro` cue), expanding `1dp` snap ripples, and completion micro-sparks (`cursor-swarm.js` cue).
  - Upgraded `AgenticModifiers.kt` to row-by-row progressive text clipping synced with the blinking I-beam caret, horizontal media scan-line wipes, and matched Violet/Vermilion selection tints (replacing the clashing `FigmaBlueFill`).
  - Upgraded `AgenticHudBar.kt` to display active scene telemetry (`SCENE 01..09`), separate active/total roster counts (`active/16`), real completed/total layer counts, Purple-to-Vermilion hairline progress, and `1× / 2× / 3×` speed cycling.

### Priority 2–4 — Rindle Works Design System, Home Screen & 9-Scene About Us Portfolio
- **`OrvaShowcaseTokens.kt`:** Aligned showcase tokens to `#08090B` obsidian canvas, `#111318` / `#181B21` graphite surfaces, `#F1EFE9` warm chalk ink, `#A1A3AA` muted slate, `#2A2D34` hairlines, `#F45A43` editorial vermilion, and `#9A78F5` secondary violet. Operational billing/inventory theme in `ui/theme/` remains untouched.
- **`OrvaShowcaseCopy.kt`:** Updated English and Bengali display copy to the exact approved Master Directive §3 & §4 text, preserving zero invented claims, zero hardcoded contacts, and honest `IN ACTIVE DEVELOPMENT` status.
- **`HomeScreen.kt`:** Rebuilt with H1 Editorial Hero (`BUILT AROUND THE WORK.`), H2 Darkness-First Neutral Chalk/Violet Lantern Surface, H3 Scroll-Linked Cinematic Image/Type Composition, H4 Flagship ORVA Feature Panel, H5 Three Physical Layered Document Panels (`PRODUCT`, `CRAFT`, `ENGINEERING`), and H6 Shared Monochrome Apothecary Frieze.
- **`AboutUsScreen.kt`:** Rebuilt as the complete 9-scene Rindle Works portfolio (Studio Hero, Point of View, Philosophy Statement, 5 ZLL-style Principle Chapters, Selected Work ORVA Case 001 + Horizontal Rail, Product Concerns & Engineering Commitments Split, Asymmetric Field Notes Image Mosaic, Deep Dive ORVA Row, and Settings-Driven Contact + `RINDLE WORKS` Film-End Closing), with every scene registered in `agenticNode(...)`.
- **`OrvaShowcaseApp.kt` & `HomeAboutShowcaseRobolectricTest.kt`:** Updated top bar brand mark to `RINDLE WORKS` with vermilion dot and updated test headline assertions to match the new approved copy while preserving all existing `testTag`s.

### Priority 6 — Offline Bundled Editorial Assets
- Generated and bundled 4 cohesive monochrome editorial drawables into `app/src/main/res/drawable/` (`editorial_architecture_light.jpg`, `editorial_apothecary_shelves.jpg`, `editorial_thermal_counter.jpg`, `editorial_studio_workbench.jpg`), documented in `ASSET_MANIFEST.md`.

---

## 2. Verification & Honest Test Status

- **Static Code & Resource Audit (Executed in Sandbox):** Passed — verified balanced delimiters across all modified Kotlin files, confirmed all `R.drawable.*` references resolve to real files in `app/src/main/res/drawable/`, confirmed all `HomeAboutShowcaseRobolectricTest` `testTag`s exist in the rebuilt composables, and verified zero opening ORVA splash veil.
- **Gradle Build & Robolectric Execution (Not Run in Offline Sandbox):** The sandbox environment has no Android SDK, no pre-cached Gradle wrapper/Maven artifacts, and no outbound internet access, so `./gradlew testDebugUnitTest` and physical-device screenshot captures could not be executed here.
- **Recommended Next Steps in Android Studio:**
  1. Open the extracted `ORVA_Android_Frontend_Source.zip` project in Android Studio.
  2. Run `./gradlew testDebugUnitTest` to verify `AgentTaskSchedulerTest` and `HomeAboutShowcaseRobolectricTest`.
  3. Inspect Home, About Us, and the Agentic Build cursor glow on 360dp / 390dp / 412dp emulators or a physical Android device.
  4. Upload `ORVA_Android_Frontend_Source.zip` (which includes `THIRD_PARTY_NOTICES.md`, `ASSET_MANIFEST.md`, and `BUILD_REPORT.md`) to `/ORVA-WORKSPACE/04-INTEGRATION/ANDROID-FRONTEND/` in Dropbox.


---

## 3. ChatGPT Frontend Correction Pass — 21 November 2026

Work performed directly against the latest Gemini source baseline in `/mnt/data/orva_frontend_work/`.

### Scheduler integrity
- Fixed the nullable clone-group argument in `AgentTaskScheduler.kt` using a validated non-null group only when a node is a clone.
- Missing parent references and missing clone masters now block all task claims until the graph is complete.
- Added cached dependency-graph validation for missing parents, self-parenting, missing/duplicate clone masters, invalid clone indices and dependency cycles (including parent/master edges). Validation is recomputed only when a node is added or dependency relationships change.
- Added viewport geometry invalidation for width, height and density changes. Active claims are released on geometry changes and old claim generations cannot commit stale bounds.
- `hasEligibleWorkInViewport` and `nextUnbuiltTargetTopY` now respect dependency validity and current geometry generations.
- Updated About's five-principle active display to use stable scheduler node IDs for the single reusable panel/title/description, rather than registering new task IDs every time the selected chapter changes. Selector IDs remain stable and individually registered.
- Removed an unused alternative `PrincipleChapterPanel` implementation so it cannot be mistaken for the active chapter renderer.

### Agentic Build and visual corrections
- Tightened the cursor bloom to an 8.5–11dp outer radius and approximately 2–2.65dp inner core. The glow is drawn around the exact cursor-tip `screenPos` in the same Canvas pass, with the cursor vector drawn above it. Purple and vermilion palette is preserved. Physical-device appearance has not yet been verified.
- Removed the obsolete bitmap luminance sampler and unreferenced `drawKineticOrbitalIntro` renderer from `AgenticOverlayCanvas.kt`; the first real About scene is now the page content under the orbital scan, not a competing intro splash. This also removes a bitmap decode/sampling operation that was no longer used.
- Relabelled the HUD scene state from `INTRO / ORBITAL LOCK` to `ACT I / ORBITAL SCAN`.
- Removed the inert sound control earlier in this correction pass; no sound toggle is presented until audio actually exists.
- Corrected stale comments describing the removed word-by-word chapter re-typing and old introductory splash.

### Home lantern compositing
- The previous correction remains in the working tree: the photograph is drawn on the base layer, while only the darkness veil is drawn into an offscreen Canvas. `DstOut` therefore cuts a hole in the veil and reveals the intact image underneath. Touch drag remains local to the lantern panel.

### External imagery research
- Verified four individual Pexels creator/photo pages and their "Free to use" labels: Eva Bronzini (pharmacy shelves), David Nestorov (industrial corridor), Tima Miroshnichenko (workbench blueprints), and Towfiqu barbhuiya (POS/thermal paper).
- Added original pages, creators and direct image sources to `ASSET_MANIFEST.md`, along with the applicable Pexels licence constraints.
- The remote image binaries could not be transferred into the local source workspace in this runtime. These are documented candidates only; the four existing generated local images remain the resources used by the code. No remote CDN URLs were introduced into the app.

### Verification actually run
- `kotlinc` 1.9.0 successfully compiled the pure Kotlin `AgentTaskScheduler.kt` with a standalone JVM harness.
- Seven scheduler checks passed: missing parent blocks; missing clone master blocks; height/density geometry invalidation releases claims; stale node-bounds claim cannot commit; parent/clone dependency cycles block claims; duplicate clone masters block claims; eight-active-builder cap is enforced.
- Static source registration audit found no missing literal `parentId` references among the 36 Compose `.agenticNode(...)` calls. Parameterised IDs in reusable wrappers remain intentionally dynamic.
- Full Android Gradle build, Compose compilation, Robolectric suite, APK build and physical-device visuals remain unverified because this workspace still has no Gradle wrapper JAR/scripts and no Android SDK. No claim of Android compilation success is made.

### Remaining frontend work
1. Acquire and bundle the four verified Pexels binaries (or user-provided equivalent) and replace generated resource choices only after crop review.
2. Complete a file-by-file UI visual pass of Home and all nine About scenes, including phone-width typography and image crops.
3. Verify cursor bloom/glow, pointer precision, HUD layout and lantern reveal on a real Android build/emulator.
4. Restore a reproducible Gradle wrapper/SDK build path in the actual Android development environment and run the full test suite.
5. Continue preserving billing/inventory/business logic unchanged.

### Exact text-layout / caret integration — 21 November 2026
- Added `rememberAgenticTextLayoutHandler(...)` callbacks to the primary About text layers: hero headline/lead, both point-of-view paragraphs, the two philosophy headline lines and supporting paragraph, active principle title/description, ORVA selected-work headline/body, and deep-dive title.
- `AgenticBuildController.registerTextLayout(...)` now captures actual `TextLayoutResult` line starts/ends, line bounds, paragraph direction and cursor rectangles for each UTF-16 offset. Active I-beam positions therefore use Compose's measured caret geometry rather than estimated line centres for those Text layers.
- Split the philosophy headline group into a stable container with individually measured lead/accent text nodes. Replaced per-scroll-frame `AnnotatedString` rebuilding and per-word colour-alpha updates with stable remembered strings and draw-phase `graphicsLayer` fades. This avoids repeated text construction/layout churn while preserving the scroll reveal.
- Replaced the non-existent/unsupported `isRtlLine` assumption with the public `TextLayoutResult.getParagraphDirection(...)` API and `ResolvedTextDirection.Rtl` check.
- The existing rectangle clip now uses actual Compose line bounds and caret positions for measured Text layers. Composite nodes without a direct Text owner retain the explicitly documented estimate fallback.

### Verification after text-layout integration
- Pure Kotlin scheduler compile/harness re-run: 7/7 checks passed.
- Static Compose scene-registration audit: 37 `.agenticNode(...)` calls, 35 literal IDs, no duplicate literal IDs, and no missing literal parent references.
- Balanced-delimiter scan passed for the five modified Kotlin source files (About screen, Agentic controller, modifiers, scheduler and Home screen).
- Kotlin compiler parser invocation on Compose sources produced no syntax-like diagnostics, but emitted unresolved AndroidX/Compose references because this environment lacks Compose dependencies. This is not a Compose compile result.
- Full Android Gradle build, Robolectric tests, APK build and physical-device render remain unverified: no Android SDK, no Gradle wrapper scripts/JAR and no cached AndroidX dependencies are available in this workspace.

### Portfolio copy / voice refinement — 21 November 2026
- Rewrote the English and Bengali Rindle Works About narrative to use a more distinctive studio/portfolio voice without inventing company history, client work, team details, awards or delivery metrics.
- New hero statement: `THE WORK DOESN'T FIT IN A SCREEN.` Supporting lead focuses on the hand-off, exception, record and next decision behind visible tasks.
- Reframed the Point of View around the gap between the ideal/happy path and actual operational work: interruptions, edge cases, paper trails and decisions that must survive hand-off.
- Replaced the philosophy statement with `THE SCREEN IS SMALL. / THE WORK ISN'T.` and supporting copy about software receding when work flows and details matter in difficult moments.
- Rewrote the five principles in both languages around studying the whole task, clarifying the next move, treating records as promises, designing for the long shift and planning for recovery.
- Revised Deep Dive and Contact headings to `THE DETAILS ARE THE PRODUCT.` and `START WITH THE HARD PART.`
- Standalone Kotlin smoke test compiled `OrvaShowcaseCopy.kt` against a minimal `AppLanguage` enum stub and passed English/Bengali checks for non-empty headline/lead/deep-dive/contact copy and exactly five principles in each language. This is a copy-layer smoke test, not an Android/Compose build.

### Unicode-safe reveal + responsive editorial pass — 21 November 2026

- Extracted text segmentation into `AgenticGraphemeBoundaries.kt`, using `java.text.BreakIterator` plus an Indic virama/conjunct continuation guard. This supports combining marks, Bengali vowel signs, Bengali conjuncts (including ZWJ sequences), and emoji sequences without revealing half of a visible character.
- `LayerRenderState` now maps reveal progress to the same grapheme boundary list for both the I-beam cursor and the `drawWithContent` reveal clip. This prevents cursor/reveal disagreement and avoids splitting Bengali conjuncts or emoji surrogate sequences.
- Added `AgenticGraphemeBoundariesTest.kt` with six cases: combining marks, Bengali vowel sign, Bengali conjunct, ZWJ conjunct, emoji family and progress-to-boundary mapping.
- Increased the five-principle editorial chapter stage from a fixed 360dp to 62% of the viewport height, clamped to 400–560dp, so it reads as an intentional scene instead of a compact card.
- Made the Home hero display size responsive to available width (48/54/62/72sp breakpoints) and the About hero responsive (46/52/60/72sp breakpoints) to avoid awkward title wrapping on compact phones and under-sized typography on larger viewports.
- Updated stale source comments to match the current actual copy and avoid implying a fixed 60/120Hz frame rate.

### Verification for Unicode and responsive changes

- Standalone Kotlin compile of `AgenticGraphemeBoundaries.kt`: passed.
- Standalone grapheme harness passed for combining marks, Bengali vowel signs, Bengali virama conjunct, Bengali ZWJ conjunct, emoji family sequence and progress mapping.
- Scheduler regression harness: 7/7 passed.
- English/Bengali portfolio copy smoke checks: passed.
- Static Kotlin delimiter scan: passed for seven modified frontend sources.
- About scene node audit: 35 literal node registrations, 35 unique IDs, no duplicate literal IDs.
- Controller and draw modifier both use the same grapheme-boundary-to-offset function.
- A parser-oriented `kotlinc` invocation produced no syntax/expecting/unexpected-token diagnostics, but reported 2,159 unresolved AndroidX/Compose references because the Android toolchain/dependencies are unavailable. It exited non-zero and is not a successful Android or Compose compile.

### Image acquisition status (unchanged)

- The four Pexels images remain verified candidate sources with creator and licensing metadata in `ASSET_MANIFEST.md`.
- Attempted to transfer the Pexels image binaries into this local workspace; the local container cannot resolve the Pexels CDN host. The tool could preview the image in the browser, but the image binary did not become a local project file.
- Existing app assets remain in use; no remote CDN hotlinks were inserted. Local photo replacement remains open until the binary files can be acquired through an available file-transfer route.

### Current verification boundary

- Scheduler harness and standalone grapheme helper compile and run locally.
- Copy source compiles against a temporary language enum stub and passes English/Bengali smoke checks.
- Full Android Gradle build, Robolectric test suite (including the new JUnit grapheme tests), APK, emulator and physical-device visual recording remain unverified. No Android SDK, Gradle wrapper scripts/JAR or AndroidX dependency cache is present in this sandbox.


### Image-led Home / Selected Work pass — 21 November 2026

- Rebuilt Home H4 flagship block as a large editorial case-study cover using bundled local workbench artwork, registration-corner marks, `RINDLE WORKS / PRODUCT STUDY` metadata, the ORVA wordmark, and status label. The artwork is explicitly treated as atmosphere, not a representation of the actual ORVA interface. Below the cover, concise product copy and two actions remain real, functional controls. Added stable test tags `home_flagship_explore` and `home_flagship_about`.
- Rebuilt About Scene 05 horizontal ORVA case rail cards as image-led case-study panels. Each card now has its own local image crop, dark legibility gradient, large outlined index, compact project identifier, title, summary and technical tags. Cases map to different bundled resources: billing → thermal detail; FEFO stock → apothecary shelves; returns/ledger → studio workbench; local-first vault → architecture.
- Added `imageResId` to `OrvaCaseRailItem` and assigned distinct local editorial resources in English/Bengali-independent case data.
- Registered each case card, media cover, title and summary with stable Agentic Build IDs and explicit parent dependencies. The agent build can now construct these four card images and text layers, rather than treating the entire horizontal rail as a single visual block.
- Updated `ASSET_MANIFEST.md` with the additional image usages and explicit disclosure that generated artwork is not genuine ORVA product photography/screenshots.

### Verification for image-led pass

- Compiled `OrvaShowcaseCopy.kt` with minimal `AppLanguage` and `R.drawable` stubs. English and Bengali data checks passed: four cards, four distinct positive image resource IDs and non-empty tags for every card.
- Parser-oriented `kotlinc` scan of Home, About and showcase copy exited non-zero due unavailable AndroidX/Compose types, but reported no parser-like diagnostics (`expecting`, unexpected token or unclosed structure). This is not a Compose compile.
- No Gradle/Compose build, Robolectric suite, APK, emulator or physical-device screenshot was possible in this sandbox.
- External Pexels source pages remain verified and documented, but binaries are still not bundled. Existing local generated artwork is being used as an interim offline-safe visual layer; it must be replaced/augmented with the verified Pexels files once binary transfer is possible.

### Source continuity checkpoint implementation — 21 November 2026

- Added `RECOVERY_AND_CONTINUITY.md` to the project. It makes the working source tree, durable snapshots, Notion's role, restore workflow, exclusions, and next-chat recovery procedure explicit.
- Added executable `tools/create_checkpoint.sh`. It creates a local-only Git commit and a timestamped ZIP source snapshot plus SHA-256 sidecar, excluding secrets, local SDK files, Gradle caches and build outputs. No GitHub remote is used.
- Initial local Git commit: `a4a7aa2` (`Recoverable frontend baseline 2026-11-21`).
- Created source archive `ORVA_FRONTEND_CHECKPOINT_20261120T192351Z.zip` (6,805,120 bytes; SHA-256 `e83b75a7db219df4b3808a1ecfd124910a92d5eb39b06effd26cf42a6e0829f8`). Archive integrity verified with `unzip -t`; checksum verified.
- Uploaded that exact archive to the persistent ChatGPT File Library at `/ORVA_FRONTEND_CHECKPOINTS/ORVA_FRONTEND_CHECKPOINT_20261120T192351Z.zip`. Re-materialized it from the Library into a second directory and compared bytes; the round-trip copy is byte-for-byte identical. This proves a future chat can recover the actual project files from the persistent Library, independent of this chat's `/mnt/data` workspace.
- The Dropbox folder `/ORVA-WORKSPACE/04-INTEGRATION/ANDROID-FRONTEND/` was checked; it still contains only the earlier 200-byte placeholder. Dropbox's `upload_file` action could not accept a local sandbox path or Library file ID as its required file-parameter object. No Dropbox upload is falsely claimed. The persistent ChatGPT File Library is currently the verified recovery fallback; Dropbox upload remains a separate handoff path requiring an attached file parameter.


### Focused test rerun after image-led case-study work — 21 November 2026

- Ran the actual pure Kotlin `AgentTaskSchedulerTest.kt` suite with a small local JUnit 4-compatible assertion/annotation shim because JUnit/Gradle artifacts are unavailable in the sandbox: **16/16 tests passed**. The suite covered dependency order, missing parents/masters, clone masters, role preferences, viewport gates, interruption/release, geometry invalidation, stale-claim protection, dependency cycles, duplicate masters, deterministic replay, completion state and concurrency limits. This validates scheduler behavior only; it is not the full Android Gradle test task.
- Ran `AgenticGraphemeBoundariesTest.kt` with the same lightweight local JUnit shim: **6/6 tests passed** (combining mark, Bengali vowel sign, Bengali conjunct, ZWJ conjunct, emoji family and progress boundary mapping).
- Recompiled `OrvaShowcaseCopy.kt` against small `AppLanguage` and `R.drawable` stubs and verified English/Bengali each return four case cards, four distinct positive drawable IDs and non-empty tag sets.
- Home/About source parser scan still reports no parser-like diagnostics. Full AndroidX/Compose type-check and build remain unverified.


### Scene 06 — editorial system contract pass — 21 November 2026

- Rebuilt About Scene 06 from two plain text columns into a more legible editorial spread: a strong bilingual headline and explanatory lead, followed by the product concerns and the engineering commitments as contrasting vermilion/violet tracks.
- Each of the six requirements and six engineering rules now has an individual numbered row with a restrained accent rail and fine divider. The presentation remains text-first and avoids generic cards or invented product telemetry.
- Added bilingual copy for the section eyebrow, editorial headline, introduction and both track captions in `OrvaShowcaseCopy.kt`.
- Registered both track containers, their headers, all 12 rows and all 12 row text elements as individual Agentic Build DAG nodes with stable IDs and explicit parent relationships. This lets the zll.me-inspired construction sequence reveal the section progressively rather than exposing each list as one block.
- Updated `HomeAboutShowcaseRobolectricTest.kt` to correct a stale About hero expectation (`THE WORK DOESN'T FIT IN A SCREEN.`) and assert the new Scene 06 heading, a billing concern and the FEFO engineering rule. These Compose assertions were added but cannot be executed in the current environment.
- Animation provenance clarification: Nexer confirms that the animation patterns used in the Gemini Android project are taken from / based on `https://zll.me/`. Keep zll.me as the confirmed reference for those effects. Continue implementing the behaviour natively in Compose and retain ORVA's own brand, copy and layout; do not transplant unrelated site content or assets. Existing source comments already identify the zll.me-style parallax, drafting grid, scan-line reveal, crosshair and caret timing.

### Verification for Scene 06 pass

- Actual pure Kotlin scheduler suite: **16/16 passed** using a local JUnit-compatible shim.
- Actual grapheme-boundary suite: **6/6 passed** using the same shim.
- `OrvaShowcaseCopy.kt` compiled with minimal `AppLanguage` and `R.drawable` stubs. English and Bengali Scene 06 copy smoke checks passed; both tracks contain six non-empty items.
- Static Agentic registry audit of `AboutUsScreen.kt`: 47 `.agenticNode(...)` registrations; 44 literal IDs, all unique; no unresolved literal parent references. The new Scene 06 generated ID pattern was checked for 12 unique row IDs and 12 unique text IDs with correct row/column parent relationships.
- `git diff --check` and balanced-delimiter checks passed for the changed Kotlin and test files.
- The Compose/Robolectric assertions have not been executed. The Android SDK, Gradle wrapper scripts/JAR and AndroidX dependencies are absent from this workspace. No Android build, APK or device rendering is claimed.

### Next frontend priorities

1. Continue the scene-by-scene visual pass, next reviewing Scene 07's image mosaic and Scene 08's deep-dive book treatment for a stronger relationship between imagery, captions and the actual ORVA product story.
2. Acquire the four licence-checked Pexels image binaries through a supported transfer path and review local offline crops before replacing interim generated artwork.
3. Validate the Agentic Build choreography and the new Scene 06 row sequence in the actual Gemini/Android Studio build, including 360dp, 390dp and 412dp phone layouts.
4. Keep the full Gradle/Robolectric/APK/device verification boundary explicit until run in the real Android toolchain.


### Scene 07 — bilingual field-notes mosaic — 21 November 2026

- Corrected a localization gap: Scene 07 accepted `AppLanguage` but all headings and four image captions were hard-coded in English. The eyebrow, conceptual-image metadata label, editorial headline, supporting sentence and all four captions now have English and Bengali copy.
- Replaced the misleading `PRODUCT / INTERFACE` caption on the abstract architecture image with `SYSTEM / STRUCTURE`, which better describes the actual artwork and avoids implying that it is an ORVA interface screenshot.
- Added a concise editorial statement connecting batches, expiry dates, receipts and records as parts of one pharmacy working day.
- Registered the mosaic eyebrow, metadata, headline, introduction and four captions as individual Agentic Build text nodes. Each caption is a child of its matching image-tile media node.
- Replaced fixed IBM Plex Mono calls with the locale-aware mono font selector in bilingual field-note labels and captions, ensuring Bengali labels use the bundled Noto Sans Bengali family.
- Added English and Bengali Compose test assertions for the headline and image caption. They remain unexecuted because the Android/Compose test environment is unavailable.
- Updated `ASSET_MANIFEST.md` to identify the current mosaic artwork explicitly as conceptual/generated visual studies and correct the architecture tile's usage label. The four Pexels candidate binaries remain unbundled.

### Scene 08 — annotated domain-rules plate — 21 November 2026

- Reworked the Deep Dive artwork from a decorative tilted image into an annotated technical-study plate. The cover now clearly reads `CONCEPT / DOMAIN RULES`; the image remains illustrative rather than a claimed ORVA screen or real product photograph.
- Added four bilingual, source-grounded domain controls: integer paise for money, integer thousandths for quantities, FEFO stock allocation and atomic invoice finalisation.
- The controls are laid out as a compact 2×2 technical specimen grid over a dark editorial field, with fine dividers and restrained mono metadata. This creates an actual link between the Deep Dive headline and the project’s documented engineering rules without changing those rules.
- Kept the perspective transition, but moved it to a clearly labelled, accessible tap target. It toggles between the angled cover and a flat presentation; its visible text and accessibility click label update between “TAP TO FLATTEN” and “TAP TO RESTORE ANGLE” (with Bengali equivalents).
- Registered the plate, hint control, rule grid, each of the four rule cells, and all label/value text layers separately in the Agentic Build dependency graph. Added Agentic nodes for the deep-dive eyebrow, body and Explore action.
- Updated all bilingual metadata and field labels to use locale-aware font families so Bengali copy uses the bundled Bengali font.
- Added English and Bengali Compose assertions for the four controls and the perspective-toggle text. These tests are authored but have not been run under Robolectric in this workspace.
- Updated `ASSET_MANIFEST.md` to clarify that the Scene 08 background is generated conceptual art; only the overlaid domain constraints represent actual project rules.

### Verification for Scenes 06–09 — 21 November 2026

- Actual pure Kotlin `AgentTaskSchedulerTest.kt` source suite, run with a lightweight local JUnit-compatible shim: **16/16 passed**.
- Actual pure Kotlin `AgenticGraphemeBoundariesTest.kt` source suite, run with the same shim: **6/6 passed**. Combined: **22/22 passed**.
- `OrvaShowcaseCopy.kt` compiled against minimal `AppLanguage` and drawable-resource stubs. English and Bengali smoke checks passed for Scene 06's 6+6 rule lists, Scene 07's four captions and all section text, Scene 08's four domain controls, conceptual artwork description and reduced-motion/perspective hint states, plus Scene 09's closing tagline.
- Static Agentic registry audit of `AboutUsScreen.kt`: **82 `.agenticNode(...)` call sites; 64 literal IDs, all unique; no unresolved literal parent references**. Dynamic reusable-component IDs were audited separately: Scene 07 has four distinct media IDs across both responsive branches, each with a caption child; Scene 08 has four distinct spec-cell IDs, each generating its own label/value text children; Scene 09 has six distinct metadata row containers, each generating separate label/value children.
- `git diff --check` and balanced-delimiter scans for About, copy and Robolectric test source passed.
- A parser-oriented `kotlinc` invocation across About, copy and Robolectric test sources emitted **no syntax-like diagnostics**. It exited non-zero with **1,610 unresolved-reference diagnostics** because AndroidX/Compose, test and project dependencies are not installed in this workspace; this is not a successful Compose or Android compile.
- Compose/Robolectric assertions were added but not executed. Full Gradle build, APK build, emulator rendering and physical-device checks remain unverified. The sandbox still has no Android SDK, Gradle wrapper JAR/scripts or AndroidX dependency cache.

### Scene 09 — fully layered contact and studio closing — 21 November 2026

- Changed the Support and Product & Ownership columns from coarse single text blocks into actual containers with independently registered headings, explanatory text, empty-state copy and each metadata row.
- Upgraded `MetadataKeyValueRow` into a reusable Agentic group: each row has a stable container ID and distinct label/value text children. Six Scene 09 row instances are registered: support phone, support email, product, publisher, version and build. Rows merge their semantics so screen readers and Compose tests receive the related label/value as one useful unit while Agentic Build retains independent child layers.
- Registered the Start Billing and Back to Home actions, their labels, and each component of the RINDLE WORKS closing lock-up as explicit Agentic nodes.
- Localized the film-end tagline. The studio brand remains `RINDLE WORKS`; the explanatory line now has English and Bengali copy.
- Added Compose assertions for the support heading and the closing tagline in both languages, alongside the existing configured/empty contact-state assertions. These tests are authored but have not been executed in this environment.

### Reduced-motion and interaction safeguard — Scene 08

- Passed the app's `reducedMotion` setting into the Deep Dive artwork. With reduced motion enabled, the book/spec plate opens in a flat static view and its perspective control is disabled with an explicit `STATIC VIEW / REDUCED MOTION` label (localized in Bengali). With motion enabled, the accessible tap target toggles the perspective and updates its visible/action label.
- Added a dedicated Compose interaction test for the normal-motion toggle and assertions that the reduced-motion mode disables it. Compose tests remain unexecuted due missing Android/Compose test dependencies.

### Next frontend priorities

1. Audit the complete Home-to-About journey and all nine scenes for composition, Agentic Build timing, touch/scroll hand-offs and accessibility.
2. Acquire the licence-checked Pexels image binaries through a supported transfer path and review offline crops before replacing interim generated artwork.
3. Verify the mosaic, technical plate, contact/ownership layout, responsive 360dp/390dp/412dp widths and reduced-motion behaviour in a real Android build environment.
4. Run the complete Gradle/Robolectric/APK/device verification before claiming Android build success.

### Home — bilingual editorial labels and panel interaction/accessibility — 21 November 2026

- Localized the remaining Home scene metadata that had stayed English-only after the main copy translation: the H1 scene index, H2 illumination heading and apothecary caption, the H3 precision label, and the H4 case code and product-study label. Bengali labels now use the language-aware mono font so the bundled Noto Sans Bengali face renders the glyphs rather than relying on IBM Plex Mono fallback.
- Localized the apothecary image's accessible content description to match the selected app language.
- Localized the H5 scene index prefix, keeping section numbers consistent with Bengali numeral rendering used by the earlier Home sections.
- Changed the layered Home panels from a single full-card clickable surface with a nested clickable navigation CTA into two sibling controls: a dedicated expandable/collapsible header and a separate navigation action. This avoids nested button semantics and makes the navigation CTA independent from the disclosure action.
- The panel header exposes a language-aware expanded/collapsed state description to accessibility services. Selecting the active panel a second time now collapses it; selecting another panel transfers the expanded state to that panel.
- Added stable Compose test tags for the localized labels, folder disclosure, and expanded details. Expanded the existing Robolectric/Compose test source to cover both EN/BN labels, panel close/open behaviour and the fact that a child navigation action does not implicitly expand its parent.
- Files changed: `HomeScreen.kt`, `OrvaShowcaseCopy.kt`, `HomeAboutShowcaseRobolectricTest.kt`.

### Verification for this Home pass

- `OrvaShowcaseCopy.kt` compiled with `kotlinc-jvm 1.9.0` against minimal `AppLanguage` and drawable `R` stubs. A small executable harness passed **20 assertions** covering the English/Bengali labels, image descriptions, section indices and expanded/collapsed state descriptions.
- Existing pure Kotlin Agentic Build tests were re-run from the actual source with a local JUnit-compatible shim: **22/22 passed** (scheduler 16/16; grapheme boundaries 6/6).
- Static checks passed: `git diff --check`, balanced delimiters in `HomeScreen.kt`, and targeted assertions for the new disclosure/accessibility wiring.
- New Home/Compose interaction assertions are authored but were not executed. The workspace still lacks Android SDK, Gradle wrapper scripts/JAR and AndroidX/Compose dependencies, so no successful Android/Compose compile or on-device rendering is claimed.
- A fresh parser-oriented `kotlinc` attempt covering `HomeScreen.kt`, `OrvaShowcaseCopy.kt` and `HomeAboutShowcaseRobolectricTest.kt` reported **zero syntax-like diagnostics**. It exited non-zero with **700 unresolved-reference diagnostics** because Compose, AndroidX, test and project classes are not present in this workspace. It is a parser check only, not a Home/Compose compilation.

### About Us — Bengali parity and Agentic Build layer audit — 21 November 2026

- Localized the About hero's scene index, version strip and accessible studio-workbench description. The artwork is explicitly described as conceptual rather than as a real studio/product photograph.
- Localized the Scene 02 apothecary illustration description and figure caption. Replaced `REAL WORKFLOWS` with the more accurate `WORKING CONTEXT` because the current image is conceptual artwork, not evidence of an actual workflow or product screen.
- Localized Scene 03's philosophy eyebrow and backdrop word; the Bengali backdrop uses the bundled Noto Sans Bengali display face and a smaller size to preserve the atmospheric treatment without relying on Latin-font fallback.
- Localized Scene 04 chapter numerals, progress counters and the `PRINCIPLE` label. Bengali chapter numbers use the Bengali display family; chapter/task IDs remain stable and language-independent.
- Localized Scene 05 case-card codes, large indices and tags while keeping the internal English index values for stable Agentic IDs. Bengali tags retain standard technical names where appropriate (FEFO, GST, SQLite).
- Updated Scene 06 row numbers and mono labels to use the locale-aware font family. Updated the Scene 08 section counter to Bengali numerals.
- Localized both zll.me-inspired dual marquee text tracks, retaining RINDLE WORKS / ORVA brand names and standard technical acronyms. Registered each track container and its moving text as separate Agentic Build nodes.
- Added or refined Agentic registrations for the hero metadata/version text, Scene 02 figure caption, Scene 03 backdrop/eyebrow, Scene 04 active label/progress, Scene 05 code/index overlays, Scene 06 row indices and both marquee tracks. No existing scene IDs used by scheduler tests were renamed.
- Expanded `HomeAboutShowcaseRobolectricTest.kt` with English and Bengali assertions covering the hero scene/version labels, conceptual image descriptions, figure caption, both marquee tracks, philosophy marker, chapter progress and label, selected-work code, Scene 06 row index, and the Deep Dive scene marker. These Android UI assertions are authored but not executed in this workspace.

### Verification for this About localization pass

- `OrvaShowcaseCopy.kt` compiled with `kotlinc-jvm 1.9.0` using minimal `AppLanguage` and drawable-resource stubs. An executable temporary harness passed **46 English/Bengali copy assertions**, covering the new About metadata, descriptions, version text, figure label, principle numbering, case-card tags and marquee strings.
- Actual pure Kotlin `AgentTaskSchedulerTest.kt` and `AgenticGraphemeBoundariesTest.kt` sources were recompiled and run with the local JUnit-compatible shim: **22/22 passed** (16 scheduler, 6 grapheme).
- Static Agentic registry audit: **98 node call sites, 77 unique literal IDs, no duplicate literal IDs and no unresolved literal parent references**. Dynamic reusable-component ID families for the four case cards and six Scene 06 rows remain language-independent and parent-linked.
- `git diff --check` and balanced-delimiter scans passed for the changed About screen, copy and Compose test files.
- Parser-oriented `kotlinc` scan found **zero syntax-like diagnostics** but exited non-zero with **1,711 unresolved-reference diagnostics** because AndroidX/Compose, project and test dependencies are absent. This is not a Compose compile.
- The new Robolectric/Compose UI assertions, full Android Gradle build, APK, emulator and physical-device visual checks remain unverified. No Android build success is claimed.
- No billing, inventory, tax, stock, returns or financial logic was changed.

### Next actions

1. Continue reviewing the real Home-to-About scroll and animation experience, especially manual scroll takeover, marquee motion consistency and chapter scrubbing.
2. Acquire the already licence-checked Pexels image binaries through a supported file-transfer route; bundle locally only after inspecting and cropping the images for the actual mobile compositions.
3. Validate English/Bengali typography, 360dp/390dp/412dp layouts, image crops, Agentic Build transitions and accessibility in the full Android toolchain.
4. Run Gradle, Robolectric, APK and device verification before treating the frontend as build-verified.

### Dual-track marquee continuity and reduced-motion refinement — 21 November 2026

- The bilingual marquee now builds each line from two identical copies of a single content cycle. Each Text is measured at unbounded intrinsic width, and its translation is derived from half that measured width. This makes the restart land on the same repeated content instead of jumping an arbitrary 320px.
- The primary ribbon travels left across one cycle in 9 seconds. The outlined secondary ribbon travels in the opposite direction across one cycle in 12 seconds. Its pace is independent of the primary track and is no longer tied to a fixed offset.
- Locale changes and device-width changes update the measured width used by the translation, while the dual-track editorial treatment and Agentic Build node IDs remain stable.
- Reduced-motion mode does not instantiate `rememberInfiniteTransition`; both tracks use a literal zero translation and remain visible as static, localized text. No unused frame-driven marquee timeline is scheduled.
- The existing reduced-motion About Compose test asserts the ribbon text remains present. This is a source-level motion correction; actual visual seam, line measurement and runtime behaviour still require validation in the Android/Compose toolchain.

### Manual-scroll / guided-tour handoff and principle scrub release — 21 November 2026

- Guided About scrolling is now owned by one tracked coroutine job rather than untracked frame-loop launches. A manual vertical gesture cancels an in-flight `animateScrollTo` immediately and disables the TOUR state; the job is also cancelled on pause/background, explicit TOUR-off, Skip/Finish, Replay and meaningful viewport geometry changes.
- Manual-scroll intent is detected after the platform's `viewConfiguration.touchSlop`, once per gesture, rather than using a fixed 18px threshold that varied with device density.
- A manually selected or keyboard-focused principle remains pinned while the reader is stationary. The next actual vertical finger scroll releases that pin, allowing the chapter panel to resume its viewport-position scrub. Chapter selection and the global guided-scroll state remain separate concerns.
- Added a Robolectric/Compose regression test that selects a principle, swipes the About scroll surface, expects HUD state to change from TOUR to FREE, and verifies that chapter progress resumes changing. The UI test is authored but cannot be executed in this workspace because the Android/Compose/Robolectric toolchain is absent.
- No billing, inventory, tax, stock, returns or financial domain logic changed.

### Live Android system reduced-motion preference — 21 November 2026

- Replaced the one-time `remember(context)` snapshot with `rememberSystemReducedMotion(context)`, backed by a lifecycle-scoped `ContentObserver` for Android's global animator-duration, activity-transition and window-animation scales.
- Reduced motion is active if any of those three scales is zero; the observer updates Compose state when system settings change and unregisters on disposal. A fresh read after observer registration closes the initial composition/registration race.
- The existing Home/About motion paths continue to consume one shared `reducedMotion` value. This keeps parallax, reveal pacing, kinetic ribbons, chapter scrub and perspective interactions consistent with the system preference.
- Added a Robolectric/Compose test that starts at normal scale, changes the transition scale to zero while composed, and expects the reduced-motion state to update without passing a new composition parameter. This test is authored but not executed in the current workspace.
- Android's `Settings.Global` API documents zero animator scale as animations ending immediately and zero transition/window scales as disabling those window animations: https://developer.android.com/reference/android/provider/Settings.Global.
- No operational billing, inventory, tax, stock, returns or financial domain logic changed.

### About gesture-axis arbitration — 21 November 2026

- Replaced the About root touch observer's vertical-delta-only detection with a pure Kotlin axis classifier. It waits for the platform touch-slop threshold, then locks only when one axis exceeds the other by a touch-slop-derived dominance margin. Ambiguous diagonal gestures remain undecided, avoiding accidental takeover during the selected-work rail swipe.
- The observer now tracks the original down pointer ID rather than switching to whichever pointer happens to remain pressed. Only a confirmed vertical gesture cancels the in-flight guided-scroll job, changes TOUR to FREE and releases a manually pinned principle chapter.
- Added `AboutGestureClassifier.kt` and six unit tests for sub-slop movement, vertical intent, horizontal intent, exact diagonal movement, ambiguous diagonal movement and negative deltas. Added a Compose/Robolectric integration test which swipes the Selected Work rail horizontally and verifies TOUR remains enabled. The integration test is authored but not executable in the current sandbox.
- Added the stable test tag `about_selected_work_rail` to the actual horizontal work rail.
- The source audit briefly flagged a possible duplicate `reducedMotion` argument in the Scene 03 call; direct inspection of the active source confirms it is present only once, so no change was required there.

### Verification for gesture-axis pass

- Rebuilt the pure Kotlin test suite from the current scheduler, grapheme and gesture source files: **28/28 passed** (16 scheduler, 6 grapheme, 6 gesture classifier).
- Recompiled `OrvaShowcaseCopy.kt` with minimal language/resource stubs and reran the English/Bengali smoke harness: **46 assertions passed**.
- `git diff --check` passed. The Compose pointer-input and Robolectric integration changes still require a full Android/Compose build; no APK, emulator or device test is claimed.
- No billing, inventory, GST, tax, stock, returns, invoice or other financial rules changed.

### External image binary acquisition attempt

- Revisited all four individually licence-checked Pexels photo pages and confirmed the exact image URLs and creator/download paths through page retrieval. However, direct image binary retrieval from `images.pexels.com` failed because the development container could not resolve the CDN hostname (`Could not resolve host: images.pexels.com`).
- No Pexels image files were added, and no remote URLs were introduced into app code. The current locally bundled generated editorial artwork remains in use; the manifest keeps the original page, creator and licence provenance for a future supported binary transfer.

### Agentic controller continuity on live reduced-motion changes — 21 November 2026

- Source review found that `AboutUsScreen` used `remember(reducedMotion)` for `AgenticBuildController`. When Android's system animation preference changed, Compose replaced the entire controller, resetting the 16-agent scheduler, intro phase, active tasks and current build progress. This contradicted the intended live preference update.
- The controller is now remembered for the lifetime of its `ScrollState`. `reducedMotion` is stored as snapshot state inside the controller and updated in place from `SideEffect`; the orchestrator reads the latest policy without replacing its scheduler or visual state.
- Added `agentic_hud_status` as a test locator and a Compose/Robolectric regression that runs the normal-motion intro, changes the preference to reduced motion, and expects the existing build to advance out of INTRO rather than restart at zero. The regression is authored but **NOT RUN** because Android/Compose/Robolectric dependencies are unavailable here.
- Added `tools/run_pure_kotlin_tests.sh` as a rerunnable local test runner. It compiles the actual scheduler, grapheme and gesture-classifier production sources together with their actual pure Kotlin test files. A temporary minimal JUnit API/runner is used because JUnit/Gradle artifacts are unavailable; the shim does not replace or mock production logic. It now rejects an empty test discovery result. It explicitly does not run Android, Compose or Robolectric tests.
- Verification: `./tools/run_pure_kotlin_tests.sh` — **28 passed, 0 failed**; `git diff --check` — passed. No dependencies, lockfiles, business rules, persistence or financial modules were changed.
- Android/Compose type-check and the new controller-preservation regression remain **NOT RUN**. No APK or device validation is claimed.
- Parser-oriented `kotlinc` scan across the changed About screen, controller, HUD and Robolectric test returned **zero syntax-like diagnostics**; compilation exited non-zero with **6,122 unresolved AndroidX/Compose/test/project references** because those dependencies are unavailable. This is not a successful Compose compile.


### Agentic Build — bidirectional DISPENSE / RESTOCK completion — 21 November 2026

- Preserved the existing 16-agent roster, eight concurrent forward builders, role-aware task selection, DAG dependencies, clone/master relationship, viewport-generation invalidation, and the single `withFrameNanos` orchestrator. No new Gradle or runtime dependency was added.
- Completed the two-axis journey policy: `ScrollOwner` (`AUTO` / `MANUAL`) is separate from `AgentActivity` (`BUILD` / `REWIND` / `IDLE`). Manual vertical intent takes scroll ownership, cancels guided movement, and classifies direction only after a real vertical gesture. Starting a new gesture or entering idle clears unfinished direction accumulation.
- Connected direction transitions to controller side effects after policy mutation. The handlers no longer return early merely because the policy already contains the new direction; direction changes therefore cancel or settle the opposite work path instead of mixing DISPENSE and RESTOCK claims.
- Made the scheduler enforce direction exclusivity itself. Forward work cannot start while a reverse claim exists; reverse work cannot start while any forward claim remains. Reverse uses one claim at a time so the completion journal cannot be inverted by racing finishes.
- RESTOCK selects the latest completed eligible node by actual completion sequence, observes the same validated dependency graph, reverses children before parents, reverses clone siblings in completion order before their master, and assigns the matching specialist agent role. Invalid dependency graphs block both reverse availability and claims.
- Applied the 1.5-viewport safety boundary to reverse candidates. A manual upward takeover cancels only unfinished forward tasks already below that protected boundary. Forward tasks at or near the reader are allowed to finish and remain committed; reverse claims wait until those forward claims have cleared.
- Added per-node two-second restoration. A quick direction reversal restores recent reverse transitions to their committed states without replay theatre; older restocked nodes remain hidden and rebuild normally when the reader returns. In-flight reverse claims are settled using their own claim-start timestamp, so they do not receive a fresh grace window accidentally.
- Made inferred scene IDs order-independent for nested Agentic nodes. A child registered before its scene parent now inherits the scene ID when the parent arrives, preserving the correct scene stamp and event ownership.
- Connected scene lifecycle events to the identity presentation: a scene seals once when its last node commits; its stamp appears and its one-shot verify sweep follows. On RESTOCK, the stamp lifts first; the verify state is removed after the 120ms lift; only then does the first layer reverse. A quick restore restores the static committed stamp without replaying haptics or the sweep.
- Haptic calls are skipped in reduced-motion mode, when the view has haptic feedback disabled, or when the device reports no vibrator. The per-scene seal event remains deduplicated by the scheduler.
- Added a pure performance hysteresis policy: three consecutive frames over 12ms advance one degradation level; 90 consecutive frames under 10ms schedule one recovery step, applied only at a scene-seal boundary. The current rendered effects degrade in order: verify sweep, broad Border Beam sheen (crisp core retained), then meniscus curve (solid gauge remains). Stamps and gauge remain available. A non-healthy frame cancels pending recovery.
- Updated the compact HUD so advanced TOUR / speed / FINISH / REPLAY actions are disclosed behind one control. Journey owner/activity are mirrored to Compose snapshot state so status changes render even when layer counts do not change. Its progress line reads the same per-layer progress as the measure gauge through draw-phase clock observation; it drains smoothly without recomposing the entire HUD at frame cadence.
- Added a Compose/Robolectric assertion for the collapsed/expanded HUD disclosure state. This UI test is authored but not run in the present environment.
- No billing, invoice, inventory, stock, FEFO, returns, GST, tax or financial behaviour was changed.

### Verification for Agentic Build bidirectional pass

- `./tools/run_pure_kotlin_tests.sh` — **60 passed, 0 failed**. The suite compiles the actual pure Kotlin scheduler, grapheme, journey-policy, performance-policy and gesture-classifier sources with their actual tests using the local JUnit-compatible runner.
- `git diff --check` — passed.
- Android/Compose type-check, Robolectric, Gradle build, APK build, emulator and physical-device tests remain **NOT RUN**. This workspace has no Android SDK, Gradle executable/wrapper JAR, or AndroidX dependency cache. A parser-only `kotlinc` invocation cannot substitute for those checks.
- The code path for reverse scheduling and progress is source-reviewed; runtime frame pacing, actual haptic hardware response and visual transition timing still require the Gemini/Android Studio build and device validation.

### Home/About navigation and appearance boundary — 21 November 2026

- Reduced the shared showcase top bar to its existing menu button and RINDLE WORKS home/brand action. The language control no longer appears in the top bar.
- Replaced the drawer's one-sided language toggle with one labelled EN / বাংলা segmented selector. Both language states are visible; the active language is exposed through selectable semantics, and each option provides a 48dp minimum touch target. The control still invokes the existing `ShowcaseUiEvent.ToggleLanguage` → `OrvaShowcaseViewModel.toggleLanguage()` path; no second language state was introduced.
- Removed Paper mode from the Home/About shell, drawer and palette contract: no theme state, toggle callback, Paper palette or theme-toggle icons remain. Home/About now consume the fixed dark showcase palette. The Agentic HUD uses the same dark-only accent mapping and retains its build controls.
- Left the operational `ui/theme` implementation, operational settings, billing, inventory, tax, stock, FEFO, returns and financial behaviour unchanged. No dependency or colour value was added.
- Added Compose/Robolectric tests for the two-action top bar, absent top-bar language/theme controls, both drawer language states, toggle behaviour and 48dp option height. These tests are authored but NOT RUN in the current workspace.
- Changed files: `OrvaShowcaseApp.kt`, `OrvaShowcaseTokens.kt`, `OrvaNavIcons.kt`, `AgenticHudBar.kt`, `HomeAboutShowcaseRobolectricTest.kt`.

### Verification for Home/About navigation and appearance boundary

- `./tools/run_pure_kotlin_tests.sh` — **60 passed, 0 failed**. This suite covers pure JVM Agentic scheduling, grapheme boundaries, journey policy, performance policy and gesture classification; it does not execute Compose UI tests.
- `git diff --check` — passed.
- Production-source scan — no remaining Paper-mode state, palette, provider, callback, toggle tag or Paper/Dark switch copy in the Home/About UI source.
- Parser-oriented `kotlinc` scan — no syntax-like diagnostics; the invocation exits non-zero because AndroidX/Compose and project dependencies are unavailable. This is not a successful Kotlin project compile.
- Compose/Robolectric, Gradle, APK, emulator and physical-device validation remain **NOT RUN**. This workspace has no Gradle wrapper, Gradle executable or Android SDK/dependency cache.

### Next frontend topic

- Continue with the Home/About typeface asset and typography phase under the governing ORVA Identity Spec v1: local/offline approved Archivo and Space Mono resources, no new Gradle dependency or typeface family, while preserving the existing Bengali fallback and body families.

## 4. ORVA Theme Morph — About runtime integration (21 November 2026)

### Implemented
- Added the A/B/C identity catalog and morph transaction coordinator in `OrvaThemeMorphEngine.kt`.
- Connected the morph lifecycle to the existing single Agentic Build frame clock. The morph waits until the first build is complete, then selects a randomized, visible, built, measured, stable and non-interactive About section.
- Connected region-scoped reverse/rebuild claims to the existing 16-agent scheduler and eight-builder cap. Independent elements can be worked concurrently while parent/child dependencies remain enforced.
- A region is reverse-built before its target identity is applied; the new Compose layout settles before the same region is dispensed again. The overall identity advances only after the planned wave completes.
- Added pause/resume handling for manual scrolling. Partial work is retained; offscreen regions wait until visible. Automatic scrolling can guide the sequence through longer sections.
- Applied A/B/C palette, layout grammar, hero/body sizing, tracking and distinct display/media reveal styles to About. Reading and utility text roles retain separate reveal behaviour.
- Updated the HUD, cursor labels, cursor outlines, gauge and overlay effects to use active theme colours. Normal visitor RESTOCK behaviour remains separate from theme morphing.
- Added morph-focused scheduler and coordinator tests. The existing Agentic Build and its 16-agent roster remain in place.

### Verification
- `./tools/run_pure_kotlin_tests.sh`: **85 passed, 0 failed**.
- `git diff --check`: passed.
- Android Gradle/Compose compilation, Robolectric tests, APK build and device/emulator verification: **NOT RUN**. This workspace has no Gradle executable, no Gradle wrapper JAR/script and no Android SDK/dependency cache.

### Pending — do not treat as completed
1. Bundle and register the exact A/B/C fonts: Archivo, Newsreader, Space Mono; Bricolage Grotesque, Source Serif 4, Martian Mono; Gloock, Schibsted Grotesk; IBM Plex Mono is already bundled. Add verified licence notices. Noto Sans Bengali remains the Bengali script font.
2. Implement true variable-font axis animation where supported. Current A reveal is a grapheme-safe progressive compile; B's scale settle is a temporary visual approximation, not an actual `wdth`/`opsz` axis interpolation.
3. Extend the same morph architecture and all three visual identities to Home, including the approved H2 lantern wordmark sweep.
4. Run Android/Compose/Robolectric checks and inspect 360dp, 390dp, 412dp and tablet layouts. Validate random anchor suitability, manual scroll takeover, reduced motion, interactions, Bengali rendering and performance on device.

Random morph delays (18–32 seconds initially, then 24–42 seconds) are implementation defaults and still require visual tuning. No new runtime dependency was added.

## 5. ORVA Theme Morph — Home integration WIP (21 November 2026)

### Current source changes
- Reused the existing About morph controller and frame clock on Home; no parallel animation engine was added.
- Wrapped Home H1–H6 as independent morph regions and connected region ownership to the existing scheduler.
- Added A/B/C theme-driven composition grammar, palette, responsive typography sizing and theme-specific motion providers across Home.
- Registered Home content/media nodes and added the H2 ORVA wordmark's one-shot lantern sweep after initial Agentic Build completion. Reduced-motion mode skips the animated sweep.
- Connected Home's manual scroll ownership, lifecycle pause/resume and scene haptic events to the shared controller. Existing Home actions/navigation callbacks were retained.

### Verification
- `./tools/run_pure_kotlin_tests.sh` — **86 passed, 0 failed**. This is pure JVM coverage only.
- `git diff --check` — passed.
- Android/Compose compile, Home Compose/Robolectric tests, APK, emulator and physical-device validation — **NOT RUN**.

### Pending
- Home is still WIP until actual Android/Compose compilation and Home-specific UI tests pass.
- Validate H1–H6 morph registration, A→B→C transitions, safe random anchors, scroll position, manual takeover, lifecycle resume, actions/navigation, reduced motion, haptics and H2 lantern sweep.
- Inspect EN/BN at 360dp, 390dp, 412dp and tablet sizes.
- Bundle the exact A/B/C fonts and licences; implement real variable-axis transitions where supported. Existing font plan is not yet integrated.
- Tune animation timing and performance on physical devices.

### ORVA Theme Morph — Home visual composition pass (21 November 2026)

- Gave Home H1, H2, H4 and H5 distinct A/B/C compositions, not just theme colours. H1 changes between proof baseline, specimen sheet and catalogue ruler; H5 changes between a three-column grid, a two-up + full-width sheet layout, and a catalogue list.
- H2's lantern changes geometry and sweep behaviour with each identity, and replays when H2 is rebuilt into a new identity. Reduced motion settles immediately.
- Replaced the Home H3 secondary Instrument Serif treatment with the display role; no extra typeface family was introduced.
- Added a pure layout-grammar uniqueness test.
- Verification: `./tools/run_pure_kotlin_tests.sh` — **87 passed, 0 failed**; `git diff --check` — passed.
- Android/Compose compilation, Home Compose/Robolectric, APK and device checks: **NOT RUN**; this environment has no Gradle executable, Gradle wrapper JAR/script or Android SDK/dependency cache.
- Pending: exact font files/licences and actual role mapping; true variable-axis animation; Home UI/device visual tests; EN/BN responsive checks; performance and haptic tuning. See `docs/ORVA_HANDOVER_2026-11-21/11_THEME_MORPH_ENGINE_STATUS_AND_PENDING.md`.


## Theme morph typography and word-motion milestone — 21 November 2026

- Theme A display headings now reveal at complete word boundaries, while every reveal endpoint remains aligned to the existing grapheme-safe boundaries. Bengali conjuncts, combining marks and emoji are not split.
- Theme B no longer fakes a font width-axis animation with horizontal `scaleX`; it currently uses the measured grapheme-safe reveal until the actual Bricolage Grotesque variable font is bundled and its axes can be applied to the rendered text.
- The morph catalog now records verified Archivo and Bricolage Grotesque axis ranges and provides tested progress interpolation; the axis values are not yet applied to Compose text. Archivo width is planned to move from 86 at 360dp to 125 at 840dp; no synthetic horizontal scaling is used. Gloock is correctly treated as a static font with no invented axes.
- Identity font names are locked in tests: A Archivo / Newsreader / Space Mono; B Bricolage Grotesque / Source Serif 4 / Martian Mono; C Gloock / Schibsted Grotesk / IBM Plex Mono. Palette body text is tested against both main background and surface tokens.
- Verification: `./tools/run_pure_kotlin_tests.sh` — **93 passed, 0 failed**; `git diff --check` — passed.
- NOT VERIFIED: Android/Compose compilation, Robolectric, APK, emulator and physical-device visual tests remain NOT RUN.
- FONT ASSETS STILL PENDING: the new theme font TTF files and their OFL notices are not in `res/font/`; existing UI font helpers still reference the old Space Grotesk, Instrument Serif and Plus Jakarta Sans assets. Do not call the A/B/C typography migration complete. Runtime `FontVariation.Settings` application is also pending until the real font resources are present.


## Approved font acquisition tool — 21 November 2026

- Added `tools/fetch_orva_showcase_fonts.py` with a fixed allowlist for the exact A/B/C TTF files and corresponding official Google Fonts OFL notices.
- The script validates SFNT font signatures and SIL OFL 1.1 license text before writing anything. It writes locally to `app/src/main/res/font/` and `third_party/font_licenses/`, with no Gradle/runtime dependency and no silent font substitution.
- `python -m py_compile tools/fetch_orva_showcase_fonts.py` — passed.
- `python tools/fetch_orva_showcase_fonts.py --check-only` — passed; 9 font resources and 8 licence notices are listed.
- Actual binary downloads were NOT RUN successfully in this workspace; the environment's file-transfer path did not expose external font bytes to the local source tree. No new font files were added.
- Pending: run the acquisition tool in a network-enabled project environment, inspect the installed font metadata/licences, replace the legacy Latin font mappings with the A/B/C theme-specific families, apply real Compose variable axes, then run Android/Compose and device visual checks.


## Approved A/B/C font integration — 21 November 2026

### Implementation
- Installed all nine approved upstream TTF assets supplied in the font archive and the eight corresponding SIL OFL 1.1 notices. Added separate notices for the two previously bundled families, IBM Plex Mono and Noto Sans Bengali.
- Replaced the legacy Space Grotesk / Instrument Serif / Plus Jakarta Sans mapping with region-aware A/B/C display, reading and utility roles. The live Home H1–H6 and About S01–S09 regions supply their active `OrvaDesignTheme`; no font picker or parallel theme state was added.
- A: Archivo display, Newsreader reading, Space Mono utility. B: Bricolage Grotesque display, Source Serif 4 reading, Martian Mono utility. C: static Gloock display, Schibsted Grotesk reading, existing IBM Plex Mono utility. Noto Sans Bengali is selected for Bengali copy across all roles.
- Applied Compose `FontVariation.Settings` using the real supported `wght`, `wdth` and `opsz` axes. Archivo width uses the existing responsive 86-at-360dp to 125-at-840dp function. Bricolage uses the existing profile values; Gloock remains static. The supplied Martian Mono width axis is fixed at 112.5 and is not fabricated.
- Added eight static font instances for API 24–25, where Android variable-font support is unavailable. API 26+ uses the variable resources directly. Removed the three obsolete Latin font resources and updated tracking resolution so Bengali copy uses zero letter spacing.

### Asset evidence
- `ttf.zip`: ZIP integrity passed; exactly nine expected TTF files were present.
- FontTools inspection confirmed the actual `fvar` axis ranges documented in `ASSET_MANIFEST.md`; the supplied Newsreader weight minimum is 200, and the Martian Mono width axis is fixed at 112.5.
- Every one of the eight acquired OFL notices contains the SIL Open Font License 1.1 text. Separate official notices are also present for IBM Plex Mono and Noto Sans Bengali.
- All variable resources and static fallbacks were inspected directly; fallback files contain no `fvar` table.

### Verification
- `bash tools/run_pure_kotlin_tests.sh` — **93 passed, 0 failed**. Pure JVM tests only.
- `python -m py_compile tools/fetch_orva_showcase_fonts.py` — passed.
- `python tools/fetch_orva_showcase_fonts.py --check-only` — passed; fixed manifest lists 9 TTF sources and 8 new-family OFL notices.
- FontTools asset audit — passed; all 19 local TTF resources parse, all six variable families expose the documented axis tuples, all eight API 24–25 fallback instances have no `fvar` table, and all 10 standalone notices contain SIL OFL 1.1. The uploaded `ttf.zip` contains exactly the nine approved upstream TTFs.
- Standalone `kotlinc` scan without an Android/Compose classpath — timed out; no parser or compilation result is claimed.
- `git diff --check` — passed.
- Android/Compose compilation, Robolectric, APK, emulator and physical-device checks — **NOT RUN**. This workspace has no Gradle executable, Gradle wrapper JAR/script or Android SDK/dependency cache.

### Remaining limitations
- Variable axes are applied at the active theme's terminal display profile and responsive viewport width; the existing reveal/region morph animation still owns the text reveal. Per-frame optical-axis interpolation is not claimed.
- The runtime appearance on 360dp, 390dp, 412dp and tablet widths, and Bengali shaping on physical devices, remain NOT VERIFIED until an Android toolchain/device is available.
