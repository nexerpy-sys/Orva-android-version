#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CHECKPOINT_DIR="${1:-$(dirname "$ROOT")/ORVA_CHECKPOINTS}"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
NAME="ORVA_FRONTEND_CHECKPOINT_${STAMP}"
mkdir -p "$CHECKPOINT_DIR"

# The repository is local-only. No remote is configured or required.
if [ ! -d "$ROOT/.git" ]; then
  git -C "$ROOT" init
fi
if ! git -C "$ROOT" config user.name >/dev/null; then
  git -C "$ROOT" config user.name "ORVA Frontend Checkpoint"
fi
if ! git -C "$ROOT" config user.email >/dev/null; then
  git -C "$ROOT" config user.email "orva-checkpoint@local.invalid"
fi

git -C "$ROOT" add -A
if ! git -C "$ROOT" diff --cached --quiet; then
  git -C "$ROOT" commit -m "Frontend checkpoint ${STAMP}"
fi

ARCHIVE="$CHECKPOINT_DIR/${NAME}.zip"
(
  cd "$ROOT"
  zip -qr "$ARCHIVE" . \
    -x './.gradle/*' './**/.gradle/*' './build/*' './**/build/*' \
       './local.properties' './.env' './.env.*.local' './debug.keystore' \
       './rindle_keys/*' './**/rindle_keys/*' './*.iml' './.idea/*' \
       './**/.DS_Store'
)

(
  cd "$CHECKPOINT_DIR"
  sha256sum "${NAME}.zip" > "${NAME}.zip.sha256"
)
printf 'Created: %s\n' "$ARCHIVE"
printf 'Checksum: %s/%s.zip.sha256\n' "$CHECKPOINT_DIR" "$NAME"
