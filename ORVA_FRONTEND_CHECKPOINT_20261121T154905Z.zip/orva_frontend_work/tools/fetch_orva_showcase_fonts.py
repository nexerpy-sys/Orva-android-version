#!/usr/bin/env python3
"""Fetch the approved ORVA showcase TTFs and their SIL OFL notices."""

from __future__ import annotations

import argparse
import hashlib
import sys
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FONT_DIR = ROOT / "app/src/main/res/font"
LICENSE_DIR = ROOT / "third_party/font_licenses"
BASE_URL = "https://raw.githubusercontent.com/google/fonts/main/ofl"
SFNT_SIGNATURES = (b"\x00\x01\x00\x00", b"OTTO", b"true", b"typ1")


@dataclass(frozen=True)
class FontAsset:
    family: str
    resource_name: str
    source_path: str


FONTS = (
    FontAsset("Archivo", "archivo_variable.ttf", "archivo/Archivo[wdth,wght].ttf"),
    FontAsset("Newsreader", "newsreader_variable.ttf", "newsreader/Newsreader[opsz,wght].ttf"),
    FontAsset("Space Mono", "space_mono_regular.ttf", "spacemono/SpaceMono-Regular.ttf"),
    FontAsset("Space Mono", "space_mono_bold.ttf", "spacemono/SpaceMono-Bold.ttf"),
    FontAsset(
        "Bricolage Grotesque",
        "bricolage_grotesque_variable.ttf",
        "bricolagegrotesque/BricolageGrotesque[opsz,wdth,wght].ttf",
    ),
    FontAsset(
        "Source Serif 4",
        "source_serif_4_variable.ttf",
        "sourceserif4/SourceSerif4[opsz,wght].ttf",
    ),
    FontAsset("Martian Mono", "martian_mono_variable.ttf", "martianmono/MartianMono[wdth,wght].ttf"),
    FontAsset("Gloock", "gloock_regular.ttf", "gloock/Gloock-Regular.ttf"),
    FontAsset(
        "Schibsted Grotesk",
        "schibsted_grotesk_variable.ttf",
        "schibstedgrotesk/SchibstedGrotesk[wght].ttf",
    ),
)

FAMILIES = (
    ("archivo", "Archivo"),
    ("newsreader", "Newsreader"),
    ("spacemono", "Space Mono"),
    ("bricolagegrotesque", "Bricolage Grotesque"),
    ("sourceserif4", "Source Serif 4"),
    ("martianmono", "Martian Mono"),
    ("gloock", "Gloock"),
    ("schibstedgrotesk", "Schibsted Grotesk"),
)


def validate_manifest() -> None:
    names = [font.resource_name for font in FONTS]
    if len(names) != len(set(names)):
        raise ValueError("Font resource names must be unique.")
    approved_slugs = {slug for slug, _ in FAMILIES}
    for font in FONTS:
        parts = Path(font.source_path).parts
        if len(parts) != 2 or parts[0] not in approved_slugs or ".." in parts:
            raise ValueError(f"Invalid Google Fonts source path: {font.source_path}")
    print(f"Manifest valid: {len(FONTS)} TTF files, {len(FAMILIES)} OFL notices.")


def read_url(url: str) -> bytes:
    request = urllib.request.Request(
        url,
        headers={"User-Agent": "ORVA-Showcase-Font-Bundler/1.0"},
    )
    with urllib.request.urlopen(request, timeout=45) as response:
        if response.status != 200:
            raise RuntimeError(f"Unexpected HTTP status {response.status} for {url}")
        return response.read()


def validate_font(data: bytes, family: str) -> None:
    if len(data) < 8 or data[:4] not in SFNT_SIGNATURES:
        raise ValueError(f"Downloaded {family} file is not a valid SFNT/TTF font.")


def validate_license(data: bytes, family: str) -> None:
    text = data.decode("utf-8", errors="strict")
    if "SIL OPEN FONT LICENSE" not in text or "Version 1.1" not in text:
        raise ValueError(f"The official OFL 1.1 notice was not verified for {family}.")


def write_atomic(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".part")
    temporary.write_bytes(data)
    temporary.replace(path)


def fetch_all() -> tuple[dict[str, bytes], dict[str, bytes]]:
    fonts: dict[str, bytes] = {}
    licenses: dict[str, bytes] = {}
    for font in FONTS:
        encoded_path = urllib.parse.quote(font.source_path, safe="/")
        url = f"{BASE_URL}/{encoded_path}"
        data = read_url(url)
        validate_font(data, font.family)
        fonts[font.resource_name] = data
        digest = hashlib.sha256(data).hexdigest()
        print(f"Verified {font.family}: {len(data):,} bytes, SHA-256 {digest}")
    for slug, family in FAMILIES:
        url = f"{BASE_URL}/{slug}/OFL.txt"
        data = read_url(url)
        validate_license(data, family)
        licenses[f"{slug}-OFL.txt"] = data
        digest = hashlib.sha256(data).hexdigest()
        print(f"Verified {family} SIL OFL 1.1 notice, SHA-256 {digest}")
    return fonts, licenses


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--check-only",
        action="store_true",
        help="validate the fixed source manifest without downloading files",
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="replace existing files after all downloads validate successfully",
    )
    args = parser.parse_args()

    try:
        validate_manifest()
        if args.check_only:
            return 0
        existing = [FONT_DIR / font.resource_name for font in FONTS]
        if not args.force:
            conflicts = [path for path in existing if path.exists()]
            if conflicts:
                names = ", ".join(path.name for path in conflicts)
                raise FileExistsError(f"Refusing to overwrite existing fonts: {names}. Use --force only after review.")

        fonts, licenses = fetch_all()
        for name, data in fonts.items():
            write_atomic(FONT_DIR / name, data)
        for name, data in licenses.items():
            write_atomic(LICENSE_DIR / name, data)
        print(f"Installed {len(fonts)} fonts in {FONT_DIR.relative_to(ROOT)}.")
        print(f"Installed {len(licenses)} OFL notices in {LICENSE_DIR.relative_to(ROOT)}.")
        return 0
    except (OSError, urllib.error.URLError, RuntimeError, ValueError) as error:
        print(f"Font acquisition failed: {error}", file=sys.stderr)
        print("No font resources were written before all downloads passed validation.", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
