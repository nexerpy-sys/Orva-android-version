package com.rindleworks.orva

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.rindleworks.orva.domain.common.OrvaDateTimeFormatters
import java.time.Instant
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class OrvaAppFoundationRobolectricTest {

  @Test
  fun `application identity and Java time desugaring are configured`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    assertEquals("ORVA", context.getString(R.string.app_name))
    assertEquals("com.rindleworks.orva", BuildConfig.APPLICATION_ID)
    assertEquals(
      "2026-04-01T00:00:00.0000000Z",
      OrvaDateTimeFormatters.formatUtcRoundTrip(Instant.parse("2026-04-01T00:00:00Z")),
    )
  }
}
