package com.rindleworks.orva.ui.about.agentic

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class AgentTaskSchedulerMorphTest {
  private fun bounds(top: Float) = SceneBounds(24f, top, 820f, top + 120f)

  @Test
  fun `home scene IDs receive independent home morph regions and inherit them`() {
    val scheduler = AgentTaskScheduler()
    scheduler.registerOrUpdateNode(
      id = "home_h2_backplate",
      kind = LayerKind.CONTAINER,
      bounds = bounds(100f),
    )
    scheduler.registerOrUpdateNode(
      id = "home_lantern_wordmark",
      kind = LayerKind.TEXT,
      parentId = "home_h2_backplate",
      bounds = bounds(140f),
    )

    assertEquals(2, scheduler.getNode("home_h2_backplate")?.sceneIndex)
    assertEquals("home-scene-02", scheduler.getNode("home_h2_backplate")?.morphRegionId)
    assertEquals(2, scheduler.getNode("home_lantern_wordmark")?.sceneIndex)
    assertEquals("home-scene-02", scheduler.getNode("home_lantern_wordmark")?.morphRegionId)
    assertEquals(setOf(2), scheduler.sceneIndicesSnapshot())
  }

  @Test
  fun `forward claims can be restricted to one morph region`() {
    val scheduler = AgentTaskScheduler()
    scheduler.registerOrUpdateNode(
      id = "region_a_root",
      kind = LayerKind.CONTAINER,
      bounds = bounds(100f),
      sceneIndex = 1,
      morphRegionId = "region-a",
    )
    scheduler.registerOrUpdateNode(
      id = "region_b_root",
      kind = LayerKind.CONTAINER,
      bounds = bounds(300f),
      sceneIndex = 2,
      morphRegionId = "region-b",
    )

    val claim = scheduler.tryClaimNextTask(
      agentId = 0,
      role = AgentRole.LAYOUT_ARCHITECT,
      viewportTopPx = 0f,
      viewportBottomPx = 600f,
      morphRegionIdFilter = "region-b",
    )

    assertEquals("region_b_root", claim?.nodeId)
    assertTrue(scheduler.completeTask(0, "region_b_root"))
    assertNull(
      scheduler.tryClaimNextTask(1, AgentRole.LAYOUT_ARCHITECT, 0f, 600f, morphRegionIdFilter = "region-b"),
    )
    assertEquals(LayerPhase.HIDDEN, scheduler.getNode("region_a_root")?.phase)
  }

  @Test
  fun `a composition supplied region owns every child regardless of node naming`() {
    val scheduler = AgentTaskScheduler()
    scheduler.registerOrUpdateNode(
      id = "about_scene_06_wrapper",
      kind = LayerKind.CONTAINER,
      bounds = bounds(100f),
      morphRegionId = "about-scene-06",
    )
    scheduler.registerOrUpdateNode(
      id = "about_ownership_block",
      kind = LayerKind.CONTAINER,
      parentId = "about_scene_06_wrapper",
      bounds = bounds(140f),
      morphRegionId = "about-scene-06",
    )

    assertEquals("about-scene-06", scheduler.getNode("about_ownership_block")?.morphRegionId)
    assertEquals("about-scene-06", scheduler.getNode("about_scene_06_wrapper")?.morphRegionId)
  }

  @Test
  fun `morph reverse can dismantle independent leaves with multiple agents`() {
    val scheduler = AgentTaskScheduler(totalAgents = 16, maxConcurrentBuilders = 8)
    scheduler.registerOrUpdateNode(
      id = "morph_root",
      kind = LayerKind.CONTAINER,
      bounds = bounds(100f),
      sceneIndex = 1,
      morphRegionId = "region-a",
    )
    scheduler.registerOrUpdateNode(
      id = "morph_text",
      kind = LayerKind.TEXT,
      parentId = "morph_root",
      bounds = bounds(140f),
      sceneIndex = 1,
      morphRegionId = "region-a",
    )
    scheduler.registerOrUpdateNode(
      id = "morph_media",
      kind = LayerKind.MEDIA,
      parentId = "morph_root",
      bounds = bounds(180f),
      sceneIndex = 1,
      morphRegionId = "region-a",
    )

    val root = scheduler.tryClaimNextTask(0, AgentRole.LAYOUT_ARCHITECT, 0f, 600f)
    assertEquals("morph_root", root?.nodeId)
    assertTrue(scheduler.completeTask(0, "morph_root"))

    val text = scheduler.tryClaimNextTask(1, AgentRole.TYPOGRAPHER, 0f, 600f)
    val media = scheduler.tryClaimNextTask(2, AgentRole.ART_DIRECTOR, 0f, 600f)
    assertEquals("morph_text", text?.nodeId)
    assertEquals("morph_media", media?.nodeId)
    assertTrue(scheduler.completeTask(1, "morph_text"))
    assertTrue(scheduler.completeTask(2, "morph_media"))
    assertTrue(scheduler.isMorphRegionFullyDispensed("region-a"))

    val firstReverse = scheduler.tryClaimNextMorphReverseTask(3, AgentRole.ART_DIRECTOR, "region-a", 0f, 600f)
    val secondReverse = scheduler.tryClaimNextMorphReverseTask(4, AgentRole.TYPOGRAPHER, "region-a", 0f, 600f)
    assertNotNull(firstReverse)
    assertNotNull(secondReverse)
    assertEquals("morph_media", firstReverse?.nodeId)
    assertEquals("morph_text", secondReverse?.nodeId)
    assertEquals(2, scheduler.activeBuilderCount())

    assertNull(scheduler.tryClaimNextMorphReverseTask(5, AgentRole.LAYOUT_ARCHITECT, "region-b", 0f, 600f))
    assertNull(scheduler.tryClaimNextMorphReverseTask(5, AgentRole.LAYOUT_ARCHITECT, "region-a", 0f, 600f))

    assertTrue(scheduler.completeTask(3, "morph_media", nowMs = 100L))
    assertTrue(scheduler.completeTask(4, "morph_text", nowMs = 100L))
    val rootReverse = scheduler.tryClaimNextMorphReverseTask(5, AgentRole.LAYOUT_ARCHITECT, "region-a", 0f, 600f)
    assertEquals("morph_root", rootReverse?.nodeId)
    assertTrue(scheduler.completeTask(5, "morph_root", nowMs = 200L))
    assertTrue(scheduler.isMorphRegionFullyRestocked("region-a"))
  }

  @Test
  fun `morph work exposes the next offscreen restock target without widening the visible work gate`() {
    val scheduler = AgentTaskScheduler(prefetchMarginPx = 0f)
    scheduler.registerOrUpdateNode(
      id = "near_item",
      kind = LayerKind.TEXT,
      bounds = bounds(100f),
      morphRegionId = "region-a",
    )
    scheduler.registerOrUpdateNode(
      id = "far_item",
      kind = LayerKind.TEXT,
      bounds = bounds(1000f),
      morphRegionId = "region-a",
    )
    val farBuild = scheduler.tryClaimNextTask(0, AgentRole.TYPOGRAPHER, 900f, 1400f)
    assertEquals("far_item", farBuild?.nodeId)
    assertTrue(scheduler.completeTask(0, "far_item"))
    val nearBuild = scheduler.tryClaimNextTask(1, AgentRole.TYPOGRAPHER, 0f, 600f)
    assertEquals("near_item", nearBuild?.nodeId)
    assertTrue(scheduler.completeTask(1, "near_item"))
    assertTrue(scheduler.hasEligibleMorphRestockWork("region-a", 0f, 600f))

    val nearReverse = scheduler.tryClaimNextMorphReverseTask(2, AgentRole.TYPOGRAPHER, "region-a", 0f, 600f)
    assertEquals("near_item", nearReverse?.nodeId)
    assertTrue(scheduler.completeTask(2, "near_item", nowMs = 200L))
    assertFalse(scheduler.hasEligibleMorphRestockWork("region-a", 0f, 600f))
    assertEquals(1060f, scheduler.nextMorphRestockTargetY("region-a"))
  }

  @Test
  fun `morph dispense work exposes offscreen target while keeping viewport claims scoped`() {
    val scheduler = AgentTaskScheduler(prefetchMarginPx = 0f)
    scheduler.registerOrUpdateNode(
      id = "near_item",
      kind = LayerKind.TEXT,
      bounds = bounds(100f),
      morphRegionId = "region-a",
    )
    scheduler.registerOrUpdateNode(
      id = "far_item",
      kind = LayerKind.TEXT,
      bounds = bounds(1000f),
      morphRegionId = "region-a",
    )
    val nearBuild = scheduler.tryClaimNextTask(0, AgentRole.TYPOGRAPHER, 0f, 600f)
    assertEquals("near_item", nearBuild?.nodeId)
    assertTrue(scheduler.completeTask(0, "near_item"))
    assertFalse(scheduler.hasEligibleMorphDispenseWork("region-a", 0f, 600f))
    assertEquals(1060f, scheduler.nextMorphDispenseTargetY("region-a"))
  }

  @Test
  fun `regular visitor rewind remains serialized and keeps its reading boundary`() {
    val scheduler = AgentTaskScheduler(prefetchMarginPx = 0f)
    scheduler.registerOrUpdateNode(id = "rewind_root", kind = LayerKind.CONTAINER, bounds = bounds(0f))
    val build = scheduler.tryClaimNextTask(0, AgentRole.LAYOUT_ARCHITECT, 0f, 1000f)
    assertNotNull(build)
    assertTrue(scheduler.completeTask(0, "rewind_root"))

    val first = scheduler.tryClaimNextReverseTask(1, AgentRole.LAYOUT_ARCHITECT, 0f, 1000f, rewindScreens = 1.5f)
    assertNull(first)
    assertEquals(LayerPhase.REVEALED, scheduler.getNode("rewind_root")?.phase)
    assertFalse(scheduler.isMorphRegionFullyRestocked("about-scene-01"))
  }
}
