package com.rindleworks.orva.ui.about.agentic

import org.junit.Assert.assertEquals
import org.junit.Test

class AgenticPerformancePolicyTest {
  @Test fun `three consecutive frames over twelve milliseconds drop one effect level`() {
    val policy = AgenticPerformancePolicy()
    repeat(2) { assertEquals(0, policy.onFrame(12.1f)) }
    assertEquals(1, policy.onFrame(12.1f))
  }

  @Test fun `degradation advances in order and is capped at three levels`() {
    val policy = AgenticPerformancePolicy()
    repeat(9) { policy.onFrame(12.5f) }
    assertEquals(3, policy.level)
    repeat(30) { policy.onFrame(16f) }
    assertEquals(3, policy.level)
  }

  @Test fun `exactly twelve milliseconds does not count as a slow frame`() {
    val policy = AgenticPerformancePolicy()
    repeat(10) { policy.onFrame(12f) }
    assertEquals(0, policy.level)
  }

  @Test fun `moderate frames break both degradation and recovery streaks`() {
    val policy = AgenticPerformancePolicy()
    repeat(2) { policy.onFrame(13f) }
    policy.onFrame(11f)
    assertEquals(0, policy.onFrame(13f))

    repeat(90) { policy.onFrame(9f) }
    assertEquals(0, policy.onFrame(11f))
    assertEquals(0, policy.onSceneSealed())
  }

  @Test fun `recovery waits for ninety healthy frames and a scene boundary`() {
    val policy = AgenticPerformancePolicy()
    repeat(3) { repeat(3) { policy.onFrame(13f) } }
    assertEquals(3, policy.level)

    repeat(89) { policy.onFrame(9f) }
    assertEquals(3, policy.level)
    assertEquals(3, policy.onSceneSealed())

    policy.onFrame(9f)
    assertEquals(2, policy.onSceneSealed())
  }

  @Test fun `a non-healthy frame cancels pending recovery before the scene boundary`() {
    val policy = AgenticPerformancePolicy()
    repeat(9) { repeat(3) { policy.onFrame(13f) } }
    assertEquals(3, policy.level)
    repeat(90) { policy.onFrame(9f) }
    policy.onFrame(11f)
    assertEquals(3, policy.onSceneSealed())

    repeat(90) { policy.onFrame(9f) }
    policy.onFrame(13f)
    assertEquals(3, policy.onSceneSealed())
  }

  @Test fun `reset clears level and hysteresis state`() {
    val policy = AgenticPerformancePolicy()
    repeat(3) { policy.onFrame(13f) }
    assertEquals(1, policy.level)
    assertEquals(0, policy.reset())
    repeat(2) { assertEquals(0, policy.onFrame(13f)) }
    assertEquals(1, policy.onFrame(13f))
  }
}
