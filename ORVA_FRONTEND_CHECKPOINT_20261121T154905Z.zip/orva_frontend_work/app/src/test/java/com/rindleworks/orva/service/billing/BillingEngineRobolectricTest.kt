package com.rindleworks.orva.service.billing

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.rindleworks.orva.data.local.OrvaDatabaseProvider
import com.rindleworks.orva.data.local.OrvaTransactionRunner
import com.rindleworks.orva.data.local.entity.MedicineEntity
import com.rindleworks.orva.data.local.entity.StockBatchEntity
import com.rindleworks.orva.data.repository.RoomShopRepository
import com.rindleworks.orva.data.repository.RoomTaxSettingsRepository
import com.rindleworks.orva.data.repository.StockSnapshotState
import com.rindleworks.orva.domain.billing.BillingIssueCodes
import com.rindleworks.orva.domain.billing.InvoiceCustomerDraft
import com.rindleworks.orva.domain.billing.InvoiceDraft
import com.rindleworks.orva.domain.billing.InvoiceItemDraft
import com.rindleworks.orva.domain.billing.InvoicePaymentMethod
import com.rindleworks.orva.domain.billing.PaymentTenderDraft
import com.rindleworks.orva.domain.engine.BillingInstant
import com.rindleworks.orva.domain.engine.FixedBillingClock
import com.rindleworks.orva.domain.engine.GstinValidator
import com.rindleworks.orva.domain.settings.RoundOffMode
import com.rindleworks.orva.domain.settings.ShopProfile
import com.rindleworks.orva.domain.settings.SupplyType
import com.rindleworks.orva.domain.settings.TaxPricingMode
import java.io.File
import java.time.Instant
import java.time.LocalDateTime
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class BillingEngineRobolectricTest {

  private fun appContext(): Context = ApplicationProvider.getApplicationContext()

  private class BillingHarness(
    context: Context,
    initialClock: FixedBillingClock = FixedBillingClock(
      utcNow = Instant.parse("2026-04-15T10:00:00Z"),
      localOffsetMinutes = 330,
    ),
    snapshotRefresher: (suspend () -> Result<Boolean>)? = null,
  ) {
    val dbFile =
      File(File(context.cacheDir, "billing_test_${System.nanoTime()}").apply { mkdirs() }, "orva.sqlite")
    val provider = OrvaDatabaseProvider(context, dbFile, allowMainThreadQueries = true)
    val txRunner = OrvaTransactionRunner(provider, Dispatchers.IO)
    val clock = initialClock
    val shopRepo = RoomShopRepository(provider, txRunner, clock)
    val taxRepo = RoomTaxSettingsRepository(provider, txRunner, clock)
    val billingService = DefaultBillingService(txRunner, clock, snapshotRefresher = snapshotRefresher)

    suspend fun seedDefaultShopAndTax(
      pricingMode: TaxPricingMode = TaxPricingMode.TaxInclusive,
      defaultSupplyType: SupplyType = SupplyType.IntraState,
      roundOffMode: RoundOffMode = RoundOffMode.None,
      stateCode: String? = "19",
    ) {
      shopRepo.saveProfileWithAudit(
        ShopProfile(
          shopId = "shop-1",
          shopName = "Rindle Pharmacy",
          stateCode = stateCode,
          invoicePrefix = "INV",
          financialYearStartMonth = 4,
        )
      ).getOrThrow()
      taxRepo.saveTaxSettings(true, pricingMode, defaultSupplyType, roundOffMode).getOrThrow()
    }

    suspend fun seedMedicineAndBatches(
      medId: String = "med-1",
      name: String = "Dolo 650",
      gstBps: Int = 1200,
      gstConfigured: Boolean = true,
      hsn: String? = "3004",
      batches: List<StockBatchEntity>,
    ) {
      val now = "2026-04-01T00:00:00.0000000Z"
      txRunner.runWriteTransaction { db ->
        db.medicineDao()
          .insert(
            MedicineEntity(
              medicineId = medId,
              displayName = name,
              normalizedName = name.lowercase(),
              stockUnitName = "strip",
              hsnCode = hsn,
              gstRateBasisPoints = gstBps,
              gstRateConfigured = if (gstConfigured) 1 else 0,
              createdAtUtc = now,
              updatedAtUtc = now,
            )
          )
        for (b in batches) {
          db.stockBatchDao().insert(b)
        }
      }
    }

    fun close() = provider.closeCurrent()
  }

  private fun batch(
    id: String,
    medId: String = "med-1",
    num: String,
    exp: Int,
    mrp: Long,
    qty: Long,
    status: String = "ACTIVE",
  ) =
    StockBatchEntity(
      batchId = id,
      medicineId = medId,
      batchNumber = num,
      expiryYyyyMm = exp,
      stockUnitName = "strip",
      mrpPaise = mrp,
      latestPurchasePricePaise = mrp / 2,
      quantityMilli = qty,
      batchStatus = status,
      createdAtUtc = "2026-04-01T00:00:00.0000000Z",
      updatedAtUtc = "2026-04-01T00:00:00.0000000Z",
    )

  @Test
  fun previewAndFinalize_blocksUnconfiguredShopTaxAndMedicineGst() = runBlocking {
    val h = BillingHarness(appContext())
    try {
      h.seedMedicineAndBatches(
        gstConfigured = false,
        batches = listOf(batch("b1", num = "B1", exp = 202705, mrp = 3000L, qty = 5000L)),
      )
      val preview =
        h.billingService.previewInvoice(
          InvoiceDraft(items = listOf(InvoiceItemDraft("med-1", 1000L)))
        )
      assertFalse(preview.canFinalize)
      val codes = preview.issues.map { it.code }.toSet()
      assertTrue(BillingIssueCodes.SHOP_PROFILE_MISSING in codes)
      assertTrue(BillingIssueCodes.TAX_CONFIG_MISSING in codes)
      assertTrue(BillingIssueCodes.MEDICINE_TAX_NOT_CONFIGURED in codes)
    } finally {
      h.close()
    }
  }

  @Test
  fun finalizeInvoice_splitsAcrossFefoBatches_mergesDuplicateItems_andReconcilesSplitTenders() =
    runBlocking {
      val h = BillingHarness(appContext())
      try {
        h.seedDefaultShopAndTax()
        h.seedMedicineAndBatches(
          batches =
            listOf(
              // Expired -> excluded
              batch("b-exp", num = "B0", exp = 202603, mrp = 1000L, qty = 10_000L),
              // Earliest active -> 2 strips @ ₹30.00
              batch("b-early", num = "B1", exp = 202606, mrp = 3000L, qty = 2_000L),
              // Next active -> 5 strips @ ₹35.00
              batch("b-late", num = "B2", exp = 202612, mrp = 3500L, qty = 5_000L),
            )
        )

        // Two separate draft entries for med-1 (2 + 1 = 3 strips total -> 2 from B1 + 1 from B2 = 6000 + 3500 = 9500 paise)
        val draftShort =
          InvoiceDraft(
            items = listOf(InvoiceItemDraft("med-1", 2000L), InvoiceItemDraft("med-1", 1000L)),
            tenders = listOf(PaymentTenderDraft(InvoicePaymentMethod.Cash, 9000L)),
          )
        val previewShort = h.billingService.previewInvoice(draftShort)
        assertTrue(previewShort.isDraftValid)
        assertFalse(previewShort.canFinalize)
        assertEquals(9500L, previewShort.grandTotalPaise)
        assertEquals(500L, previewShort.amountRemainingPaise)
        assertTrue(previewShort.issues.any { it.code == BillingIssueCodes.PAYMENT_SHORT })

        val draftOverpaid =
          draftShort.copy(tenders = listOf(PaymentTenderDraft(InvoicePaymentMethod.Cash, 9600L)))
        val previewOver = h.billingService.previewInvoice(draftOverpaid)
        assertFalse(previewOver.canFinalize)
        assertTrue(previewOver.issues.any { it.code == BillingIssueCodes.PAYMENT_OVERPAID })

        val draftExact =
          draftShort.copy(
            tenders =
              listOf(
                PaymentTenderDraft(InvoicePaymentMethod.Cash, 5000L),
                PaymentTenderDraft(InvoicePaymentMethod.Upi, 4500L, "UPI-REF-99"),
              )
          )
        val result = h.billingService.finalizeInvoice(draftExact)
        assertTrue("Expected success, got ${result.issues}", result.succeeded)
        assertEquals("INV/26-27/000001", result.invoiceNumber)
        assertEquals(9500L, result.grandTotalPaise)

        // Verify database state: batches deducted, 2 invoice lines, 2 movements, 2 payments, audit, snapshot dirty
        h.txRunner.runRead { db ->
          assertEquals(0L, db.stockBatchDao().getById("b-early")?.quantityMilli)
          assertEquals(4_000L, db.stockBatchDao().getById("b-late")?.quantityMilli)
          assertEquals(10_000L, db.stockBatchDao().getById("b-exp")?.quantityMilli)

          val lines = db.invoiceDao().getLinesForInvoice(result.invoiceId!!)
          assertEquals(2, lines.size)
          assertEquals("B1", lines[0].batchNumberSnapshot)
          assertEquals("3004", lines[0].hsnCodeSnapshot)
          assertEquals("B2", lines[1].batchNumberSnapshot)

          val payments = db.invoiceDao().getPaymentsForInvoice(result.invoiceId)
          assertEquals(2, payments.size)
          assertEquals(9500L, payments.sumOf { it.amountPaise })

          val movements = db.ledgerDao().getMovementsForReference("INVOICE", result.invoiceId)
          assertEquals(2, movements.size)
          assertEquals(-3_000L, movements.sumOf { it.quantityDeltaMilli })

          assertTrue(StockSnapshotState.isDirty(db))
          assertEquals(1L, StockSnapshotState.readGeneration(db))
        }
      } finally {
        h.close()
      }
    }

  @Test
  fun placeOfSupply_blocksMissingShopState_andFailsSafelyOnOutOfStateCustomerGstin() = runBlocking {
    val h = BillingHarness(appContext())
    try {
      // 1. Missing shop state code MUST block even B2C invoices with SHOP_STATE_CODE_MISSING
      h.seedDefaultShopAndTax(pricingMode = TaxPricingMode.TaxExclusive, stateCode = null)
      h.seedMedicineAndBatches(
        gstBps = 1200,
        batches = listOf(batch("b1", num = "B1", exp = 202705, mrp = 10_000L, qty = 5000L)),
      )
      val missingStatePreview =
        h.billingService.previewInvoice(
          InvoiceDraft(
            items = listOf(InvoiceItemDraft("med-1", 1000L)),
            tenders = listOf(PaymentTenderDraft(InvoicePaymentMethod.Cash, 11_200L)),
          )
        )
      assertFalse(missingStatePreview.canFinalize)
      assertTrue(
        missingStatePreview.issues.any { it.code == BillingIssueCodes.SHOP_STATE_CODE_MISSING }
      )

      // 2. Configure West Bengal ("19"): out-of-state customer GSTIN ("27") MUST block for review
      h.seedDefaultShopAndTax(pricingMode = TaxPricingMode.TaxExclusive, stateCode = "19")
      val mhPrefix = "27ABCDE1234F1Z"
      val mhGstin = mhPrefix + GstinValidator.computeChecksumCharacter(mhPrefix)

      val outOfStatePreview =
        h.billingService.previewInvoice(
          InvoiceDraft(
            items = listOf(InvoiceItemDraft("med-1", 1000L)),
            customer = InvoiceCustomerDraft(name = "Mumbai Clinic", gstin = mhGstin),
            tenders = listOf(PaymentTenderDraft(InvoicePaymentMethod.Upi, 11_200L)),
          )
        )
      assertFalse(outOfStatePreview.canFinalize)
      assertTrue(
        outOfStatePreview.issues.any {
          it.code == BillingIssueCodes.PLACE_OF_SUPPLY_REQUIRES_REVIEW
        }
      )

      // 3. Same-state customer GSTIN ("19") succeeds as Intra-State (CGST + SGST)
      val wbPrefix = "19ABCDE1234F1Z"
      val wbGstin = wbPrefix + GstinValidator.computeChecksumCharacter(wbPrefix)
      val intraB2bPreview =
        h.billingService.previewInvoice(
          InvoiceDraft(
            items = listOf(InvoiceItemDraft("med-1", 1000L)),
            customer = InvoiceCustomerDraft(name = "Kolkata Clinic", gstin = wbGstin),
            tenders = listOf(PaymentTenderDraft(InvoicePaymentMethod.Upi, 11_200L)),
          )
        )
      assertTrue(intraB2bPreview.canFinalize)
      assertEquals(600L, intraB2bPreview.cgstPaise)
      assertEquals(600L, intraB2bPreview.sgstPaise)
      assertEquals(0L, intraB2bPreview.igstPaise)
      assertEquals(11_200L, intraB2bPreview.grandTotalPaise)

      // 4. B2C with shop defaultSupplyType = InterState uses IGST cleanly
      h.seedDefaultShopAndTax(
        pricingMode = TaxPricingMode.TaxExclusive,
        defaultSupplyType = SupplyType.InterState,
        stateCode = "19",
      )
      val interB2cPreview =
        h.billingService.previewInvoice(
          InvoiceDraft(
            items = listOf(InvoiceItemDraft("med-1", 1000L)),
            tenders = listOf(PaymentTenderDraft(InvoicePaymentMethod.Cash, 11_200L)),
          )
        )
      assertTrue(interB2cPreview.canFinalize)
      assertEquals(0L, interB2cPreview.cgstPaise)
      assertEquals(0L, interB2cPreview.sgstPaise)
      assertEquals(1200L, interB2cPreview.igstPaise)
      assertEquals(11_200L, interB2cPreview.grandTotalPaise)
    } finally {
      h.close()
    }
  }

  @Test
  fun searchActiveMedicines_escapesSqlLikeWildcardsLiterally() = runBlocking {
    val h = BillingHarness(appContext())
    try {
      h.seedDefaultShopAndTax()
      h.seedMedicineAndBatches(
        medId = "med-dex-pct",
        name = "Dextrose 50%",
        batches = listOf(batch("b-pct", medId = "med-dex-pct", num = "D1", exp = 202705, mrp = 5000L, qty = 5000L)),
      )
      h.seedMedicineAndBatches(
        medId = "med-dex-500",
        name = "Dextrose 500mg",
        batches = listOf(batch("b-500", medId = "med-dex-500", num = "D2", exp = 202705, mrp = 5000L, qty = 5000L)),
      )
      h.seedMedicineAndBatches(
        medId = "med-vit-us",
        name = "Vitamin A_B",
        batches = listOf(batch("b-us", medId = "med-vit-us", num = "V1", exp = 202705, mrp = 5000L, qty = 5000L)),
      )
      h.seedMedicineAndBatches(
        medId = "med-vit-1",
        name = "Vitamin A1B",
        batches = listOf(batch("b-v1", medId = "med-vit-1", num = "V2", exp = 202705, mrp = 5000L, qty = 5000L)),
      )

      val pctMatches = h.billingService.searchMedicines("50%")
      assertEquals(listOf("Dextrose 50%"), pctMatches.map { it.displayName })

      val underscoreMatches = h.billingService.searchMedicines("A_B")
      assertEquals(listOf("Vitamin A_B"), underscoreMatches.map { it.displayName })
    } finally {
      h.close()
    }
  }

  @Test
  fun financialYearBoundary_resetsSequenceCleanly() = runBlocking {
    val clock =
      FixedBillingClock(
        utcNow = Instant.parse("2026-03-31T18:00:00Z"),
        localOffsetMinutes = 330,
      )
    val h = BillingHarness(appContext(), initialClock = clock)
    try {
      h.seedDefaultShopAndTax()
      h.seedMedicineAndBatches(
        batches = listOf(batch("b1", num = "B1", exp = 202705, mrp = 1000L, qty = 10_000L))
      )
      val draft =
        InvoiceDraft(
          items = listOf(InvoiceItemDraft("med-1", 1000L)),
          tenders = listOf(PaymentTenderDraft(InvoicePaymentMethod.Cash, 1000L)),
        )
      val r1 = h.billingService.finalizeInvoice(draft)
      assertTrue(r1.succeeded)
      assertEquals("INV/25-26/000001", r1.invoiceNumber)

      // Advance across April 1 FY boundary
      clock.utcNow = Instant.parse("2026-04-01T04:00:00Z")
      val r2 = h.billingService.finalizeInvoice(draft)
      assertTrue(r2.succeeded)
      assertEquals("INV/26-27/000001", r2.invoiceNumber)
    } finally {
      h.close()
    }
  }

  @Test
  fun postCommitSnapshotRefreshFailure_attachesWarningWithoutRollingBackInvoice() = runBlocking {
    val h =
      BillingHarness(
        appContext(),
        snapshotRefresher = { Result.failure(IllegalStateException("Disk temporarily read-only")) },
      )
    try {
      h.seedDefaultShopAndTax()
      h.seedMedicineAndBatches(
        batches = listOf(batch("b1", num = "B1", exp = 202705, mrp = 2000L, qty = 5_000L))
      )
      val res =
        h.billingService.finalizeInvoice(
          InvoiceDraft(
            items = listOf(InvoiceItemDraft("med-1", 1000L)),
            tenders = listOf(PaymentTenderDraft(InvoicePaymentMethod.Cash, 2000L)),
          )
        )
      assertTrue(res.succeeded)
      assertEquals(1, res.warnings.size)
      assertTrue(res.warnings[0].contains("StockData.json"))
      h.txRunner.runRead { db ->
        assertEquals(1, db.invoiceDao().countInvoices())
        assertEquals(4_000L, db.stockBatchDao().getById("b1")?.quantityMilli)
      }
    } finally {
      h.close()
    }
  }

  /**
   * T19: Verifies atomic SQLite rollback at ALL EIGHT failure-injection checkpoints.
   * Zero partial invoice, sequence, line, batch deduction, movement, payment, audit, or
   * snapshot generation mutations may survive a failure at any checkpoint.
   */
  @Test
  fun t19_allEightCheckpoints_rollBackCompletelyOnFailure() = runBlocking {
    assertEquals(8, BillingCommitCheckpoint.entries.size)
    for (checkpoint in BillingCommitCheckpoint.entries) {
      val h = BillingHarness(appContext())
      try {
        h.seedDefaultShopAndTax()
        h.seedMedicineAndBatches(
          batches = listOf(batch("b1", num = "B1", exp = 202705, mrp = 2500L, qty = 10_000L))
        )

        val baselineAuditCount = h.txRunner.runRead { it.ledgerDao().getRecentAuditLogs(500).size }
        val baselineGen = h.txRunner.runRead { StockSnapshotState.readGeneration(it) }

        h.billingService.failureInjectionHook = { cp ->
          if (cp == checkpoint) {
            throw RuntimeException("Injected T19 failure at $cp")
          }
        }

        try {
          h.billingService.finalizeInvoice(
            InvoiceDraft(
              items = listOf(InvoiceItemDraft("med-1", 2000L)),
              tenders = listOf(PaymentTenderDraft(InvoicePaymentMethod.Cash, 5000L)),
            )
          )
          fail("Expected injected failure at checkpoint $checkpoint")
        } catch (ex: RuntimeException) {
          assertTrue(ex.message!!.contains(checkpoint.name))
        }

        // Verify zero side effects persisted!
        h.txRunner.runRead { db ->
          assertEquals("[$checkpoint] sequence leaked", null, db.invoiceDao().getSequence("26-27"))
          assertEquals("[$checkpoint] invoice leaked", 0, db.invoiceDao().countInvoices())
          assertEquals(
            "[$checkpoint] stock batch deducted",
            10_000L,
            db.stockBatchDao().getById("b1")?.quantityMilli,
          )
          assertEquals(
            "[$checkpoint] stock movement leaked",
            0,
            db.ledgerDao().getMovementsForBatch("b1").size,
          )
          assertEquals(
            "[$checkpoint] audit log leaked",
            baselineAuditCount,
            db.ledgerDao().getRecentAuditLogs(500).size,
          )
          assertEquals(
            "[$checkpoint] snapshot generation leaked",
            baselineGen,
            StockSnapshotState.readGeneration(db),
          )
        }
      } finally {
        h.close()
      }
    }
  }

  /**
   * Concurrent oversell race test: 10 concurrent coroutines each attempt to buy 2 strips
   * from a single batch containing 10 strips. Exactly 5 MUST succeed with unique sequential
   * invoice numbers, 5 MUST fail with INSUFFICIENT_STOCK, and final stock MUST be exactly 0.
   */
  @Test
  fun concurrentFinalizations_neverOversellOrDuplicateInvoiceNumbers() = runBlocking {
    val h = BillingHarness(appContext())
    try {
      h.seedDefaultShopAndTax()
      h.seedMedicineAndBatches(
        batches = listOf(batch("b1", num = "B1", exp = 202705, mrp = 1500L, qty = 10_000L))
      )

      val draft =
        InvoiceDraft(
          items = listOf(InvoiceItemDraft("med-1", 2_000L)),
          tenders = listOf(PaymentTenderDraft(InvoicePaymentMethod.Cash, 3_000L)),
        )

      val results =
        (1..10).map { async(Dispatchers.Default) { h.billingService.finalizeInvoice(draft) } }.awaitAll()

      val succeeded = results.filter { it.succeeded }
      val failed = results.filterNot { it.succeeded }

      assertEquals(5, succeeded.size)
      assertEquals(5, failed.size)
      assertTrue(
        failed.all { res -> res.issues.any { it.code == BillingIssueCodes.INSUFFICIENT_STOCK } }
      )

      val invoiceNumbers = succeeded.mapNotNull { it.invoiceNumber }.sorted()
      assertEquals(
        listOf(
          "INV/26-27/000001",
          "INV/26-27/000002",
          "INV/26-27/000003",
          "INV/26-27/000004",
          "INV/26-27/000005",
        ),
        invoiceNumbers,
      )

      h.txRunner.runRead { db ->
        assertEquals(0L, db.stockBatchDao().getById("b1")?.quantityMilli)
        assertEquals(5, db.invoiceDao().countInvoices())
        assertEquals(5L, db.invoiceDao().getSequence("26-27")?.lastNumber)
      }
    } finally {
      h.close()
    }
  }
}
