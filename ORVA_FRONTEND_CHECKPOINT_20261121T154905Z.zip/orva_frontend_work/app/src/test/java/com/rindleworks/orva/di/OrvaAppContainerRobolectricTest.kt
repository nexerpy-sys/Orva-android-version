package com.rindleworks.orva.di

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.rindleworks.orva.OrvaApplication
import com.rindleworks.orva.domain.billing.InvoiceCustomerDraft
import com.rindleworks.orva.domain.billing.InvoiceDraft
import com.rindleworks.orva.domain.billing.InvoiceItemDraft
import com.rindleworks.orva.domain.billing.InvoicePaymentMethod
import com.rindleworks.orva.domain.billing.PaymentTenderDraft
import com.rindleworks.orva.domain.common.OrvaSettingKeys
import com.rindleworks.orva.domain.engine.FixedBillingClock
import com.rindleworks.orva.domain.engine.GstinValidator
import com.rindleworks.orva.domain.inventory.PurchaseDocumentType
import com.rindleworks.orva.domain.inventory.StockEntryInput
import com.rindleworks.orva.domain.records.ExportFormat
import com.rindleworks.orva.domain.records.InvoiceStatusFilter
import com.rindleworks.orva.domain.records.RegisterDateFilter
import com.rindleworks.orva.domain.records.ReportType
import com.rindleworks.orva.domain.settings.RoundOffMode
import com.rindleworks.orva.domain.settings.ShopProfile
import com.rindleworks.orva.domain.settings.SupplyType
import com.rindleworks.orva.domain.settings.TaxPricingMode
import java.io.ByteArrayOutputStream
import java.io.File
import java.time.Instant
import java.util.UUID
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class OrvaAppContainerRobolectricTest {

  private lateinit var context: Context
  private lateinit var rootDir: File
  private lateinit var container: OrvaAppContainer

  @Before
  fun setUp() {
    context = ApplicationProvider.getApplicationContext()
    rootDir = File(context.cacheDir, "orva-container-${UUID.randomUUID()}").apply { mkdirs() }
    val clock = FixedBillingClock(Instant.parse("2026-06-15T05:30:00Z"), localOffsetMinutes = 330)
    container =
      OrvaAppContainer(
        context = context,
        rootDirectory = rootDir,
        clock = clock,
        allowMainThreadQueries = true,
      )
  }

  @After
  fun tearDown() {
    container.close()
    rootDir.deleteRecursively()
  }

  @Test
  fun applicationExposesOrvaApplicationInstance() {
    assertTrue(context is OrvaApplication)
  }

  @Test
  fun endToEndProductionContainerJourneyWiresSnapshotRefreshBillingReportingAndBackup() = runTest {
    // 1. Setup shop & tax
    assertTrue(
      container.shopRepository
        .saveProfileWithAudit(
          ShopProfile(
            shopId = "shop-e2e",
            shopName = "Rindle Pharmacy",
            stateName = "West Bengal",
            stateCode = "19",
            gstin = "19AAACA1234A1Z" + GstinValidator.computeChecksumCharacter("19AAACA1234A1Z"),
            invoicePrefix = "INV",
          )
        )
        .isSuccess
    )
    assertTrue(
      container.taxSettingsRepository
        .saveTaxSettings(
          taxConfigured = true,
          pricingMode = TaxPricingMode.TaxInclusive,
          defaultSupplyType = SupplyType.IntraState,
          roundOffMode = RoundOffMode.None,
        )
        .isSuccess
    )

    // 2. Receive stock -> automatically refreshes StockData.json via container hook
    val stockRes =
      container.stockEntryService.receiveStock(
        StockEntryInput(
          medicineName = "Azithromycin 500mg",
          stockUnitName = "strip",
          batchNumber = "AZ500",
          expiryYearMonth = 202712,
          quantityMilli = 10_000L,
          mrpPaise = 11_200L,
          purchasePricePaise = 8_000L,
          supplierName = "MedSupply",
          documentType = PurchaseDocumentType.TaxInvoice,
          documentReference = "MS-101",
        )
      )
    assertTrue(stockRes.succeeded)
    assertTrue(stockRes.snapshotUpdated)
    val snapshotFile = File(container.snapshotsDirectory, "StockData.json")
    assertTrue("StockData.json should be auto-written after stock entry", snapshotFile.exists())
    assertEquals("0", container.appSettingsRepository.get(OrvaSettingKeys.SNAPSHOT_DIRTY, "1"))

    val medId = container.taxSettingsRepository.getMedicinesForTaxConfig("Azithromycin").single().medicineId
    assertTrue(container.taxSettingsRepository.updateMedicineTaxConfig(medId, "30042099", 1200, true).isSuccess)

    // 3. Finalize invoice -> auto-refreshes StockData.json again
    val inv =
      container.billingService.finalizeInvoice(
        InvoiceDraft(
          items = listOf(InvoiceItemDraft(medId, 2_000L)),
          customer = InvoiceCustomerDraft(name = "Ananya Sen"),
          tenders = listOf(PaymentTenderDraft(InvoicePaymentMethod.Cash, 22_400L)),
        )
      )
    assertTrue(inv.succeeded)
    assertEquals("INV/26-27/000001", inv.invoiceNumber)
    assertEquals("0", container.appSettingsRepository.get(OrvaSettingKeys.SNAPSHOT_DIRTY, "1"))

    // 4. Verify reporting & export via container
    val filter = RegisterDateFilter("2026-06-15", "2026-06-15")
    val register =
      container.reportingService.getSalesRegister(filter, InvoiceStatusFilter.Issued, null)
    assertEquals(1, register.size)
    assertEquals(22_400L, register.single().grandTotalPaise)

    val pdfBytes = ByteArrayOutputStream()
    assertTrue(
      container.reportingService
        .exportReport(ReportType.SalesRegister, ExportFormat.Pdf, pdfBytes, filter)
        .isSuccess
    )
    assertTrue(pdfBytes.size() > 200)

    // 5. Run local .shopbackup via container
    val backup = container.backupRestoreService.runBackupNow()
    assertTrue("Backup failed: ${backup.errorMessage}", backup.succeeded)
    val manifest = backup.manifest
    assertNotNull(manifest)
    assertEquals(1L, manifest!!.invoiceCount)
    assertEquals(1L, manifest.medicineCount)
    assertTrue(File(backup.backupPathOrUri!!).exists())
  }
}
