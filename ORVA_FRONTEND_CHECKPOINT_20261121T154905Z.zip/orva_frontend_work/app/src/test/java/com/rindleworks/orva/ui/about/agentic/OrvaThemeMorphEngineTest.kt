package com.rindleworks.orva.ui.about.agentic

import kotlin.random.Random
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class OrvaThemeMorphEngineTest {
  private fun candidate(
    id: String,
    order: Int,
    top: Float = 100f,
    bottom: Float = 700f,
    visible: Float = 1f,
    fullyBuilt: Boolean = true,
    interaction: Boolean = false,
    focus: Boolean = false,
    protected: Boolean = false,
  ) = MorphRegionCandidate(
    id = id,
    sceneIndex = order + 1,
    documentOrder = order,
    bounds = SceneBounds(0f, top, 1000f, bottom),
    visibleFraction = visible,
    isFullyBuilt = fullyBuilt,
    hasActiveInteraction = interaction,
    hasAccessibilityFocus = focus,
    isPinnedOrProtected = protected,
  )

  @Test fun `approved identities cycle A to B to C and back to A`() {
    assertEquals(OrvaDesignTheme.FIELD_SPECIMEN, OrvaDesignTheme.MEASURED_PRESS.next())
    assertEquals(OrvaDesignTheme.MUSEUM_INDEX, OrvaDesignTheme.FIELD_SPECIMEN.next())
    assertEquals(OrvaDesignTheme.MEASURED_PRESS, OrvaDesignTheme.MUSEUM_INDEX.next())
    assertEquals(3, OrvaThemeCatalog.all.size)
  }

  @Test fun `every theme body text meets WCAG AA on both main surfaces`() {
    OrvaThemeCatalog.all.forEach { theme ->
      assertTrue(
        "${theme.name} background contrast was below 4.5:1",
        contrastRatio(theme.colours.text, theme.colours.background) >= 4.5,
      )
      assertTrue(
        "${theme.name} surface contrast was below 4.5:1",
        contrastRatio(theme.colours.text, theme.colours.surface) >= 4.5,
      )
    }
  }

  @Test fun `each identity keeps its approved display reading and utility families`() {
    val press = OrvaThemeCatalog.get(OrvaDesignTheme.MEASURED_PRESS).type
    assertEquals("Archivo", press.display)
    assertEquals("Newsreader", press.reading)
    assertEquals("Space Mono", press.utility)

    val specimen = OrvaThemeCatalog.get(OrvaDesignTheme.FIELD_SPECIMEN).type
    assertEquals("Bricolage Grotesque", specimen.display)
    assertEquals("Source Serif 4", specimen.reading)
    assertEquals("Martian Mono", specimen.utility)

    val museum = OrvaThemeCatalog.get(OrvaDesignTheme.MUSEUM_INDEX).type
    assertEquals("Gloock", museum.display)
    assertEquals("Schibsted Grotesk", museum.reading)
    assertEquals("IBM Plex Mono", museum.utility)
  }

  @Test fun `each approved identity owns a distinct headline motion language`() {
    assertEquals(ThemeHeadlineMotion.WORD_BY_WORD_REVEAL, OrvaThemeCatalog.get(OrvaDesignTheme.MEASURED_PRESS).headlineMotion)
    assertEquals(ThemeHeadlineMotion.GRAPHEME_REVEAL, OrvaThemeCatalog.get(OrvaDesignTheme.FIELD_SPECIMEN).headlineMotion)
    assertEquals(ThemeHeadlineMotion.SERIF_LINE_MASK, OrvaThemeCatalog.get(OrvaDesignTheme.MUSEUM_INDEX).headlineMotion)
  }

  @Test fun `Archivo uses a responsive real width axis instead of horizontal scaling`() {
    val narrow = archivoWidthForViewport(360)
    val medium = archivoWidthForViewport(600)
    val tablet = archivoWidthForViewport(840)
    assertTrue(narrow < medium)
    assertTrue(medium < tablet)
    assertEquals(86f, narrow)
    assertEquals(125f, tablet)
    assertTrue(narrow in 62f..125f)
    assertTrue(tablet in 62f..125f)
  }

  @Test fun `Archivo and Bricolage axis animation stays within verified font ranges`() {
    val archivoStart = requireNotNull(displayAxesAtProgress(OrvaDesignTheme.MEASURED_PRESS, 0f, 360))
    val archivoEnd = requireNotNull(displayAxesAtProgress(OrvaDesignTheme.MEASURED_PRESS, 1f, 840))
    assertEquals(680f, archivoStart.weight)
    assertEquals(900f, archivoEnd.weight)
    assertEquals(125f, archivoEnd.width)
    val archivoHalf = requireNotNull(displayAxesAtProgress(OrvaDesignTheme.MEASURED_PRESS, 0.5f, 360))
    assertEquals(79f, archivoHalf.width)
    assertEquals(790f, archivoHalf.weight)

    val bricolageStart = requireNotNull(displayAxesAtProgress(OrvaDesignTheme.FIELD_SPECIMEN, 0f, 360))
    val bricolageEnd = requireNotNull(displayAxesAtProgress(OrvaDesignTheme.FIELD_SPECIMEN, 1f, 840))
    assertEquals(620f, bricolageStart.weight)
    assertEquals(800f, bricolageEnd.weight)
    assertEquals(78f, bricolageStart.width)
    assertEquals(92f, bricolageEnd.width)
    assertEquals(96f, bricolageEnd.opticalSize)
    val bricolageHalf = requireNotNull(displayAxesAtProgress(OrvaDesignTheme.FIELD_SPECIMEN, 0.5f, 412))
    assertEquals(710f, bricolageHalf.weight)
    assertEquals(85f, bricolageHalf.width)
    assertEquals(80f, bricolageHalf.opticalSize)
  }

  @Test fun `Gloock uses its static cut and has no fabricated variable axes`() {
    assertNull(displayAxesAtProgress(OrvaDesignTheme.MUSEUM_INDEX, 0.5f, 840))
  }

  @Test fun `each approved identity owns a distinct media motion language`() {
    assertEquals(ThemeMediaMotion.HORIZONTAL_SCAN, OrvaThemeCatalog.get(OrvaDesignTheme.MEASURED_PRESS).mediaMotion)
    assertEquals(ThemeMediaMotion.FOIL_PRESS, OrvaThemeCatalog.get(OrvaDesignTheme.FIELD_SPECIMEN).mediaMotion)
    assertEquals(ThemeMediaMotion.CATALOGUE_LIFT, OrvaThemeCatalog.get(OrvaDesignTheme.MUSEUM_INDEX).mediaMotion)
  }

  @Test fun `each approved identity owns a distinct layout grammar`() {
    assertEquals(
      3,
      OrvaThemeCatalog.all.map { it.layoutGrammar }.toSet().size,
    )
  }

  @Test fun `accent and signal are distinct roles in every theme`() {
    OrvaThemeCatalog.all.forEach { theme ->
      assertFalse(theme.name, theme.colours.accent.equals(theme.colours.signal, ignoreCase = true))
    }
  }

  @Test fun `first morph chooses a random safe visible anchor and neighbours`() {
    val policy = OrvaThemeMorphPolicy(random = Random(7), firstDelayRangeMs = 0L..0L)
    policy.beginSession(nowMs = 0L)
    val candidates = listOf(
      candidate("scene_01", 0),
      candidate("scene_02", 1, top = 1100f, bottom = 1700f, visible = 0f),
      candidate("scene_03", 2),
    )

    val plan = policy.choosePlan(
      nowMs = 1L,
      viewport = MorphViewport(topPx = 0f, bottomPx = 800f),
      candidates = candidates,
    )

    assertTrue(plan != null)
    assertEquals(OrvaDesignTheme.MEASURED_PRESS, plan?.fromTheme)
    assertEquals(OrvaDesignTheme.FIELD_SPECIMEN, plan?.toTheme)
    assertEquals(plan?.anchorRegionId, plan?.regionIds?.first())
    assertEquals(3, plan?.regionIds?.size)
    assertTrue(policy.choosePlan(2L, MorphViewport(0f, 800f), candidates) == null)
  }

  @Test fun `focused interacting incomplete protected and hidden regions cannot be anchors`() {
    val policy = OrvaThemeMorphPolicy(random = Random(1), firstDelayRangeMs = 0L..0L)
    policy.beginSession(0L)
    val candidates = listOf(
      candidate("focused", 0, focus = true),
      candidate("interacting", 1, interaction = true),
      candidate("incomplete", 2, fullyBuilt = false),
      candidate("protected", 3, protected = true),
      candidate("hidden", 4, top = 1200f, bottom = 1700f),
      candidate("partial", 5, visible = 0.1f),
    )

    assertNull(
      policy.choosePlan(
        nowMs = 1L,
        viewport = MorphViewport(topPx = 0f, bottomPx = 800f),
        candidates = candidates,
      ),
    )
  }

  @Test fun `partially morphed region can resume when it returns safely to view`() {
    val policy = OrvaThemeMorphPolicy(random = Random(9))
    val partial = candidate("scene_04", 3, top = 100f, bottom = 700f, visible = 0.8f)
      .copy(isFullyBuilt = false)
    val viewport = MorphViewport(0f, 800f)

    assertFalse(policy.isSafeToStartRegion(partial, viewport))
    assertTrue(policy.isSafeToResumeRegion(partial, viewport))
    assertFalse(policy.isSafeToResumeRegion(partial, viewport.copy(pointerIsDown = true)))
  }

  @Test fun `invalid visible fraction cannot be selected as a morph anchor`() {
    val policy = OrvaThemeMorphPolicy(random = Random(9), firstDelayRangeMs = 0L..0L)
    policy.beginSession(0L)
    val invalid = candidate("invalid-visible-ratio", 0, visible = 1.2f)

    assertNull(policy.choosePlan(1L, MorphViewport(0f, 800f), listOf(invalid)))
  }

  @Test fun `morph waits for safe page state and randomized deadline`() {
    val policy = OrvaThemeMorphPolicy(random = Random(11), firstDelayRangeMs = 500L..500L)
    policy.beginSession(100L)
    val candidates = listOf(candidate("scene_01", 0))
    val safe = MorphViewport(0f, 800f)

    assertNull(policy.choosePlan(599L, safe, candidates))
    assertNull(policy.choosePlan(600L, safe.copy(pointerIsDown = true), candidates))
    assertNull(policy.choosePlan(600L, safe.copy(agentWorkIsBusy = true), candidates))
    assertNull(policy.choosePlan(600L, safe.copy(pageIsVisible = false), candidates))
    assertTrue(policy.choosePlan(600L, safe, candidates) != null)
  }

  @Test fun `offscreen regions stay in the wave queue but cannot start until visible`() {
    val policy = OrvaThemeMorphPolicy(random = Random(2), firstDelayRangeMs = 0L..0L)
    policy.beginSession(0L)
    val visible = candidate("scene_02", 1)
    val offscreen = candidate("scene_08", 7, top = 1400f, bottom = 1900f, visible = 0f)
    val plan = policy.choosePlan(1L, MorphViewport(0f, 800f), listOf(visible, offscreen))

    assertEquals(listOf("scene_02", "scene_08"), plan?.regionIds)
    assertFalse(policy.isSafeToStartRegion(offscreen, MorphViewport(0f, 800f)))
    assertTrue(
      policy.isSafeToStartRegion(offscreen.copy(visibleFraction = 1f), MorphViewport(1200f, 2000f)),
    )
  }

  @Test fun `coordinator restocks old region before revealing its target identity`() {
    val coordinator = OrvaThemeMorphCoordinator()
    val plan = ThemeMorphPlan(
      fromTheme = OrvaDesignTheme.MEASURED_PRESS,
      toTheme = OrvaDesignTheme.FIELD_SPECIMEN,
      anchorRegionId = "scene_04",
      regionIds = listOf("scene_04", "scene_05"),
      startedAtMs = 100L,
    )

    assertTrue(coordinator.begin(plan))
    assertEquals(OrvaDesignTheme.MEASURED_PRESS, coordinator.themeForRegion("scene_04"))
    assertTrue(coordinator.onRegionRestocked("scene_04"))
    assertEquals(OrvaDesignTheme.FIELD_SPECIMEN, coordinator.themeForRegion("scene_04"))
    assertEquals(OrvaDesignTheme.MEASURED_PRESS, coordinator.themeForRegion("scene_05"))
  }

  @Test fun `wrong region or out of order phase cannot advance morph`() {
    val coordinator = OrvaThemeMorphCoordinator()
    assertTrue(coordinator.begin(plan("scene_02", listOf("scene_02", "scene_03"))))

    assertFalse(coordinator.onRegionRestocked("scene_03"))
    assertFalse(coordinator.onRegionDispensed("scene_02"))
    assertTrue(coordinator.onRegionRestocked("scene_02"))
    assertFalse(coordinator.onRegionRestocked("scene_02"))
    assertFalse(coordinator.onRegionDispensed("scene_02"))
    assertTrue(coordinator.onRegionLayoutSettled("scene_02"))
    assertFalse(coordinator.onRegionLayoutSettled("scene_02"))
  }

  @Test fun `theme commits only when every planned region is rebuilt`() {
    val coordinator = OrvaThemeMorphCoordinator()
    assertTrue(coordinator.begin(plan("scene_02", listOf("scene_02", "scene_03"))))

    assertTrue(coordinator.onRegionRestocked("scene_02"))
    assertEquals(OrvaDesignTheme.FIELD_SPECIMEN, coordinator.themeForRegion("scene_02"))
    assertEquals(MorphRegionPhase.LAYOUT_SETTLING, coordinator.snapshot.activeRegionPhase)
    assertTrue(coordinator.onRegionLayoutSettled("scene_02"))
    assertTrue(coordinator.onRegionDispensed("scene_02"))
    assertEquals(MorphEnginePhase.ACTIVE, coordinator.snapshot.phase)
    assertEquals(OrvaDesignTheme.MEASURED_PRESS, coordinator.snapshot.committedTheme)
    assertEquals("scene_03", coordinator.snapshot.activeRegionId)

    assertTrue(coordinator.onRegionRestocked("scene_03"))
    assertTrue(coordinator.onRegionLayoutSettled("scene_03"))
    assertTrue(coordinator.onRegionDispensed("scene_03"))
    assertEquals(MorphEnginePhase.IDLE, coordinator.snapshot.phase)
    assertEquals(OrvaDesignTheme.FIELD_SPECIMEN, coordinator.snapshot.committedTheme)
  }

  @Test fun `manual interaction requests pause only at a completed region boundary`() {
    val coordinator = OrvaThemeMorphCoordinator()
    assertTrue(coordinator.begin(plan("scene_02", listOf("scene_02", "scene_03"))))
    assertTrue(coordinator.requestPause())
    assertEquals(MorphEnginePhase.ACTIVE, coordinator.snapshot.phase)

    assertTrue(coordinator.onRegionRestocked("scene_02"))
    assertEquals(OrvaDesignTheme.FIELD_SPECIMEN, coordinator.themeForRegion("scene_02"))
    assertEquals(MorphRegionPhase.LAYOUT_SETTLING, coordinator.snapshot.activeRegionPhase)
    assertTrue(coordinator.onRegionLayoutSettled("scene_02"))
    assertTrue(coordinator.onRegionDispensed("scene_02"))
    assertEquals(MorphEnginePhase.PAUSED, coordinator.snapshot.phase)
    assertTrue(coordinator.resume())
    assertEquals("scene_03", coordinator.snapshot.activeRegionId)
  }


  @Test fun `untouched next region pauses cleanly and resumes without losing progress`() {
    val coordinator = OrvaThemeMorphCoordinator()
    assertTrue(coordinator.begin(plan("scene_02", listOf("scene_02", "scene_03"))))
    assertTrue(coordinator.onRegionRestocked("scene_02"))
    assertTrue(coordinator.onRegionLayoutSettled("scene_02"))
    assertTrue(coordinator.onRegionDispensed("scene_02"))
    assertEquals("scene_03", coordinator.snapshot.activeRegionId)
    assertTrue(coordinator.pauseAtRegionBoundary())
    assertEquals(MorphEnginePhase.PAUSED, coordinator.snapshot.phase)
    assertTrue(coordinator.resume())
    assertEquals("scene_03", coordinator.snapshot.activeRegionId)
    assertEquals(MorphRegionPhase.RESTOCKING, coordinator.snapshot.activeRegionPhase)
  }

  @Test fun `partial region pause retains its exact phase and resumes in place`() {
    val coordinator = OrvaThemeMorphCoordinator()
    assertTrue(coordinator.begin(plan("scene_02", listOf("scene_02", "scene_03"))))
    assertTrue(coordinator.onRegionRestocked("scene_02"))
    assertTrue(coordinator.onRegionLayoutSettled("scene_02"))

    assertTrue(coordinator.pauseAtRegionBoundary())
    assertEquals(MorphEnginePhase.PAUSED, coordinator.snapshot.phase)
    assertEquals("scene_02", coordinator.snapshot.activeRegionId)
    assertEquals(MorphRegionPhase.DISPENSING, coordinator.snapshot.activeRegionPhase)
    assertEquals(OrvaDesignTheme.FIELD_SPECIMEN, coordinator.themeForRegion("scene_02"))

    assertTrue(coordinator.resume())
    assertEquals("scene_02", coordinator.snapshot.activeRegionId)
    assertEquals(MorphRegionPhase.DISPENSING, coordinator.snapshot.activeRegionPhase)
  }

  @Test fun `coordinator reset discards partial morph and restores one committed identity`() {
    val coordinator = OrvaThemeMorphCoordinator()
    assertTrue(coordinator.begin(plan("scene_02", listOf("scene_02", "scene_03"))))
    assertTrue(coordinator.onRegionRestocked("scene_02"))
    coordinator.reset(OrvaDesignTheme.MUSEUM_INDEX)
    assertEquals(OrvaDesignTheme.MUSEUM_INDEX, coordinator.snapshot.committedTheme)
    assertEquals(MorphEnginePhase.IDLE, coordinator.snapshot.phase)
    assertEquals(OrvaDesignTheme.MUSEUM_INDEX, coordinator.themeForRegion("scene_02"))
  }

  @Test fun `policy advances its scheduling window only after successful morph completion`() {
    val policy = OrvaThemeMorphPolicy(
      random = Random(3),
      firstDelayRangeMs = 10L..10L,
      repeatDelayRangeMs = 100L..100L,
    )
    policy.beginSession(0L)
    assertEquals(10L, policy.nextEligibleAtMs)
    val plan = policy.choosePlan(
      10L,
      MorphViewport(0f, 800f),
      listOf(candidate("scene_01", 0)),
    )
    assertTrue(plan != null)
    policy.completeMorph(50L, OrvaDesignTheme.FIELD_SPECIMEN)
    assertEquals(150L, policy.nextEligibleAtMs)
    assertEquals(OrvaDesignTheme.FIELD_SPECIMEN, policy.currentTheme)
    assertEquals(1, policy.morphCount)
  }

  private fun plan(anchor: String, regions: List<String>) = ThemeMorphPlan(
    fromTheme = OrvaDesignTheme.MEASURED_PRESS,
    toTheme = OrvaDesignTheme.FIELD_SPECIMEN,
    anchorRegionId = anchor,
    regionIds = regions,
    startedAtMs = 0L,
  )
}
