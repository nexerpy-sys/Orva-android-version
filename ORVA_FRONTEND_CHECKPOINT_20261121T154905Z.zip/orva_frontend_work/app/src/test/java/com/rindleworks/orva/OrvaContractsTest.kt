package com.rindleworks.orva

import com.rindleworks.orva.domain.billing.BillingIssueCodes
import com.rindleworks.orva.domain.billing.InvoiceDraft
import com.rindleworks.orva.domain.billing.InvoiceItemDraft
import com.rindleworks.orva.domain.billing.InvoicePaperFormat
import com.rindleworks.orva.domain.billing.InvoicePaymentMethod
import com.rindleworks.orva.domain.billing.PaymentTenderDraft
import com.rindleworks.orva.domain.common.InvoiceStatus
import com.rindleworks.orva.domain.common.OrvaDateTimeFormatters
import com.rindleworks.orva.domain.common.OrvaFormatters
import com.rindleworks.orva.domain.common.StockMovementType
import com.rindleworks.orva.domain.inventory.BatchStatus
import com.rindleworks.orva.domain.inventory.InventoryFilterMode
import com.rindleworks.orva.domain.inventory.PurchaseDocumentType
import com.rindleworks.orva.domain.inventory.StockEntryInput
import com.rindleworks.orva.domain.records.ExportFormat
import com.rindleworks.orva.domain.records.InvoiceStatusFilter
import com.rindleworks.orva.domain.records.RegisterDateFilter
import com.rindleworks.orva.domain.records.ReportType
import com.rindleworks.orva.domain.returns.ResaleDisposition
import com.rindleworks.orva.domain.returns.SalesRefundMethod
import com.rindleworks.orva.domain.returns.SalesReturnLineRequest
import com.rindleworks.orva.domain.returns.SalesReturnRequest
import com.rindleworks.orva.domain.settings.AppLanguage
import com.rindleworks.orva.domain.settings.RoundOffMode
import com.rindleworks.orva.domain.settings.SupplyType
import com.rindleworks.orva.domain.settings.TaxPricingMode
import com.rindleworks.orva.fake.FakeOrvaServiceRegistry
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.time.Instant
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class OrvaContractsTest {

  @Test
  fun `persisted enum mappings match exact WPF values`() {
    assertEquals(
      listOf("Thermal58", "Thermal80", "A4", "A5"),
      InvoicePaperFormat.entries.map { it.persistedKey },
    )
    assertEquals(InvoicePaperFormat.Thermal80, InvoicePaperFormat.fromPersistedKey("unknown"))

    assertEquals(
      listOf("CASH", "UPI", "DEBIT_CARD", "CREDIT_CARD"),
      InvoicePaymentMethod.entries.map { it.dbValue },
    )
    assertEquals(
      listOf("CASH", "UPI", "DEBIT_CARD", "CREDIT_CARD", "ADJUSTMENT"),
      SalesRefundMethod.entries.map { it.dbValue },
    )
    assertEquals(
      listOf("QUARANTINE", "RESTOCK", "DAMAGED", "EXPIRED"),
      ResaleDisposition.entries.map { it.dbValue },
    )
    assertEquals(
      listOf("ACTIVE", "QUARANTINED", "EXPIRED", "BLOCKED"),
      BatchStatus.entries.map { it.dbValue },
    )
    assertEquals(
      listOf("ISSUED", "CANCELLED", "CREDIT_NOTE_ISSUED"),
      InvoiceStatus.entries.map { it.dbValue },
    )
    assertEquals(
      listOf("TAX_INVOICE", "CASH_CREDIT_MEMO", "NO_DOCUMENT", "OTHER"),
      PurchaseDocumentType.entries.map { it.dbValue },
    )
    assertEquals(
      listOf(
        "OPENING",
        "PURCHASE",
        "SALE",
        "SALE_RETURN_RESTOCK",
        "DAMAGE",
        "EXPIRY_WRITE_OFF",
        "ADJUSTMENT",
        "IMPORT",
      ),
      StockMovementType.entries.map { it.dbValue },
    )
    assertEquals(listOf("INCLUSIVE", "EXCLUSIVE"), TaxPricingMode.entries.map { it.dbValue })
    assertEquals(listOf("INTRA_STATE", "INTER_STATE"), SupplyType.entries.map { it.dbValue })
    assertEquals(listOf("NONE", "NEAREST_RUPEE"), RoundOffMode.entries.map { it.dbValue })
    assertEquals(listOf("en", "bn"), AppLanguage.entries.map { it.code })
    assertEquals(
      listOf("ALL", "LOW_STOCK", "EXPIRING", "EXPIRED"),
      InventoryFilterMode.entries.map { it.dbValue },
    )
    assertEquals(
      listOf("ALL", "ISSUED", "CANCELLED", "CREDIT_NOTE_ISSUED"),
      InvoiceStatusFilter.entries.map { it.dbValue },
    )
  }

  @Test
  fun `billing issue codes preserve all 19 exact WPF identifiers`() {
    val codes =
      setOf(
        BillingIssueCodes.DRAFT_EMPTY,
        BillingIssueCodes.INVALID_ITEM,
        BillingIssueCodes.INVALID_QUANTITY,
        BillingIssueCodes.QUANTITY_OVERFLOW,
        BillingIssueCodes.MEDICINE_NOT_FOUND,
        BillingIssueCodes.MEDICINE_INACTIVE,
        BillingIssueCodes.INSUFFICIENT_STOCK,
        BillingIssueCodes.SHOP_PROFILE_MISSING,
        BillingIssueCodes.TAX_CONFIG_MISSING,
        BillingIssueCodes.MEDICINE_TAX_NOT_CONFIGURED,
        BillingIssueCodes.CUSTOMER_GSTIN_INVALID,
        BillingIssueCodes.INVALID_PAYMENT_METHOD,
        BillingIssueCodes.INVALID_PAYMENT_AMOUNT,
        BillingIssueCodes.PAYMENT_SHORT,
        BillingIssueCodes.PAYMENT_OVERPAID,
        BillingIssueCodes.CALCULATION_OVERFLOW,
        BillingIssueCodes.SHOP_STATE_CODE_MISSING,
        BillingIssueCodes.PLACE_OF_SUPPLY_REQUIRES_REVIEW,
        BillingIssueCodes.INVOICE_PREFIX_INVALID,
      )
    assertEquals(19, codes.size)
  }

  @Test
  fun `formatters and UTC serializer preserve integer base-10 and WPF 7-digit round-trip rules`() {
    assertEquals("1,25,050.05", OrvaFormatters.formatRupees(12_505_005L))
    assertEquals("0.00", OrvaFormatters.formatRupees(0L))
    assertEquals("-12.50", OrvaFormatters.formatRupees(-1_250L))
    assertEquals("2.5", OrvaFormatters.formatQuantity(2_500L))
    assertEquals("3", OrvaFormatters.formatQuantity(3_000L))
    assertEquals("2028-03", OrvaFormatters.formatExpiry(202803))
    assertEquals("12%", OrvaFormatters.formatGstPercent(1_200))
    assertEquals("5.5%", OrvaFormatters.formatGstPercent(550))

    assertEquals(125_050L, OrvaFormatters.parseRupeesToPaise("1,250.50"))
    assertNull(OrvaFormatters.parseRupeesToPaise("12.345"))
    assertNull(OrvaFormatters.parseRupeesToPaise("-5"))
    assertEquals(1_250L, OrvaFormatters.parseQuantityToMilli("1.25"))
    assertNull(OrvaFormatters.parseQuantityToMilli("1.2345"))

    val instant = Instant.parse("2026-04-01T10:15:30.123456700Z")
    val formatted = OrvaDateTimeFormatters.formatUtcRoundTrip(instant)
    assertEquals("2026-04-01T10:15:30.1234567Z", formatted)
    assertEquals(instant, OrvaDateTimeFormatters.parseUtcInstant(formatted))
  }

  @Test
  fun `fake service registry supports end-to-end frontend development flows`() = runTest {
    val registry = FakeOrvaServiceRegistry()

    val hits = registry.billingService.searchMedicines("Paracetamol", 10)
    assertEquals(1, hits.size)
    assertTrue(hits.first().canSell)

    val unpaidDraft =
      InvoiceDraft(items = listOf(InvoiceItemDraft(hits.first().medicineId, 2_000L)))
    val unpaidPreview = registry.billingService.previewInvoice(unpaidDraft)
    assertTrue(unpaidPreview.isDraftValid)
    assertFalse(unpaidPreview.canFinalize)
    assertEquals(6_400L, unpaidPreview.grandTotalPaise)

    val paidDraft =
      unpaidDraft.copy(
        tenders = listOf(PaymentTenderDraft(InvoicePaymentMethod.Cash, unpaidPreview.grandTotalPaise))
      )
    val committed = registry.billingService.finalizeInvoice(paidDraft)
    assertTrue(committed.succeeded)
    assertEquals("INV/26-27/000001", committed.invoiceNumber)

    val entry =
      registry.stockEntryService.receiveStock(
        StockEntryInput(
          medicineName = "Cetirizine 10mg",
          stockUnitName = "strip",
          batchNumber = "CET01",
          expiryYearMonth = 202812,
          quantityMilli = 10_000L,
          purchasePricePaise = 1_200L,
          mrpPaise = 2_000L,
        )
      )
    assertTrue(entry.succeeded)
    assertEquals(3, registry.inventoryRepository.observeInventoryRows("", InventoryFilterMode.All).first().size)

    val returnResult =
      registry.salesReturnService.finalizeReturn(
        SalesReturnRequest(
          invoiceId = "fake-inv-1",
          reason = "Damaged strip",
          refundMethod = SalesRefundMethod.Cash,
          lines = listOf(SalesReturnLineRequest("fake-inv-line-1", 1_000L)),
        )
      )
    assertTrue(returnResult.succeeded)
    val cancelBlocked = registry.invoiceCancellationService.cancelInvoice("fake-inv-1", "Mistake")
    assertFalse(cancelBlocked.succeeded)

    val exportOut = ByteArrayOutputStream()
    val exportRes =
      registry.reportingService.exportReport(
        reportType = ReportType.SalesRegister,
        format = ExportFormat.Csv,
        output = exportOut,
        filter = RegisterDateFilter(),
      )
    assertTrue(exportRes.isSuccess)
    assertTrue(exportOut.size() > 0)

    assertEquals(0L, registry.databaseGeneration.value)
    val restoreRes =
      registry.backupRestoreService.executeRestore(ByteArrayInputStream(ByteArray(0)), "demo.shopbackup")
    assertTrue(restoreRes.succeeded)
    assertEquals(1L, registry.databaseGeneration.value)
    assertNotNull(registry.shopRepository.getProfile())
  }
}
