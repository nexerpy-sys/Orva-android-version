package com.rindleworks.orva.domain.engine

import com.rindleworks.orva.domain.inventory.ExpiryAlertLevel
import com.rindleworks.orva.domain.settings.RoundOffMode
import com.rindleworks.orva.domain.settings.SupplyType
import com.rindleworks.orva.domain.settings.TaxPricingMode
import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class OrvaDomainEnginesTest {

  private val fefoAllocator = FefoAllocator()
  private val invoiceCalculator = InvoiceCalculator()

  @Test
  fun fefoAllocator_sortsDeterministically_andExcludesIneligibleBatches() {
    val batches =
      listOf(
        // Expired
        BillingBatchRecord("b-exp", "m1", "A0", 202603, "strip", 1000L, 5000L, "ACTIVE"),
        // Quarantined
        BillingBatchRecord("b-q", "m1", "A1", 202605, "strip", 1000L, 5000L, "QUARANTINED"),
        // Blocked
        BillingBatchRecord("b-blk", "m1", "A2", 202605, "strip", 1000L, 5000L, "BLOCKED"),
        // Zero qty
        BillingBatchRecord("b-zero", "m1", "A3", 202605, "strip", 1000L, 0L, "ACTIVE"),
        // Eligible: later expiry
        BillingBatchRecord("b-late", "m1", "A1", 202608, "strip", 1200L, 3000L, "ACTIVE"),
        // Eligible: same earliest expiry, higher normalized batch number
        BillingBatchRecord("b-early-2", "m1", " b-02 ", 202605, "strip", 1100L, 2000L, "ACTIVE"),
        // Eligible: same earliest expiry, lower normalized batch number
        BillingBatchRecord("b-early-1", "m1", "B-01", 202605, "strip", 1000L, 2000L, "ACTIVE"),
      )

    val outcome =
      fefoAllocator.allocate(
        candidateBatches = batches,
        requestedQuantityMilli = 5000L,
        currentExpiryYearMonth = 202604,
      )

    assertTrue(outcome.succeeded)
    assertEquals(7000L, outcome.availableQuantityMilli)
    assertEquals(3, outcome.allocations.size)
    assertEquals("b-early-1", outcome.allocations[0].batchId)
    assertEquals(2000L, outcome.allocations[0].quantityMilli)
    assertEquals("b-early-2", outcome.allocations[1].batchId)
    assertEquals(2000L, outcome.allocations[1].quantityMilli)
    assertEquals("b-late", outcome.allocations[2].batchId)
    assertEquals(1000L, outcome.allocations[2].quantityMilli)
  }

  @Test
  fun invoiceCalculator_inclusiveIntraState_alternatesOddPaiseBetweenCgstAndSgst() {
    val med =
      BillingMedicineRecord(
        medicineId = "m1",
        displayName = "Paracetamol 500",
        stockUnitName = "strip",
        hsnCode = "3004",
        gstRateBasisPoints = 1200, // 12%
        gstRateConfigured = true,
      )
    // 1 strip at ₹1.00 = 100 paise inclusive at 12%:
    // taxable = round(100 * 10000 / 11200) = round(89.2857) = 89 paise; tax = 11 paise (odd!)
    val alloc1 = FefoBatchAllocation("b1", "B1", 202701, 1000L, 100L, "strip", 5000L)
    val alloc2 = FefoBatchAllocation("b2", "B2", 202702, 1000L, 100L, "strip", 5000L)

    val calc =
      invoiceCalculator.calculate(
        lineInputs = listOf(InvoiceLineCalculationInput(med, 2000L, listOf(alloc1, alloc2))),
        taxPolicy =
          ResolvedTaxPolicy(
            pricingMode = TaxPricingMode.TaxInclusive,
            supplyType = SupplyType.IntraState,
            roundOffMode = RoundOffMode.None,
            placeOfSupplyStateCode = "19",
          ),
      )

    val bl1 = calc.lines[0].batchLines[0]
    val bl2 = calc.lines[0].batchLines[1]
    assertEquals(89L, bl1.taxableValuePaise)
    assertEquals(6L, bl1.cgstPaise) // first odd paise -> CGST
    assertEquals(5L, bl1.sgstPaise)
    assertEquals(0L, bl1.igstPaise)

    assertEquals(89L, bl2.taxableValuePaise)
    assertEquals(5L, bl2.cgstPaise)
    assertEquals(6L, bl2.sgstPaise) // second odd paise -> SGST
    assertEquals(0L, bl2.igstPaise)

    // Balanced totals!
    assertEquals(11L, calc.cgstPaise)
    assertEquals(11L, calc.sgstPaise)
    assertEquals(200L, calc.grandTotalPaise)
  }

  @Test
  fun invoiceCalculator_exclusiveInterState_andNearestRupeeRoundOff() {
    val med =
      BillingMedicineRecord(
        medicineId = "m1",
        displayName = "Syrup",
        stockUnitName = "bottle",
        hsnCode = "3004",
        gstRateBasisPoints = 500, // 5%
        gstRateConfigured = true,
      )
    // 1 bottle at ₹10.90 = 1090 paise exclusive + 5% = 55 paise IGST -> raw total 1145 -> rounds to 1100 (-45)
    val alloc = FefoBatchAllocation("b1", "B1", 202701, 1000L, 1090L, "bottle", 5000L)

    val calc =
      invoiceCalculator.calculate(
        lineInputs = listOf(InvoiceLineCalculationInput(med, 1000L, listOf(alloc))),
        taxPolicy =
          ResolvedTaxPolicy(
            pricingMode = TaxPricingMode.TaxExclusive,
            supplyType = SupplyType.InterState,
            roundOffMode = RoundOffMode.NearestRupee,
            placeOfSupplyStateCode = "27",
          ),
      )

    assertEquals(1090L, calc.taxableValuePaise)
    assertEquals(0L, calc.cgstPaise)
    assertEquals(0L, calc.sgstPaise)
    assertEquals(55L, calc.igstPaise)
    assertEquals(-45L, calc.roundOffPaise)
    assertEquals(1100L, calc.grandTotalPaise)
  }

  @Test
  fun invoiceCalculator_financialYear_andGstRule46NumberFormatting() {
    assertEquals("25-26", InvoiceCalculator.getFinancialYearLabel(LocalDate.of(2026, 3, 31), 4))
    assertEquals("26-27", InvoiceCalculator.getFinancialYearLabel(LocalDate.of(2026, 4, 1), 4))
    assertEquals("2026", InvoiceCalculator.getFinancialYearLabel(LocalDate.of(2026, 1, 15), 1))

    val num = InvoiceCalculator.formatInvoiceNumber("inv", "26-27", 42L)
    assertEquals("INV/26-27/000042", num)
    assertTrue(num.length <= 16)
    assertTrue(InvoiceCalculator.isValidInvoicePrefix("INV"))
    assertFalse(InvoiceCalculator.isValidInvoicePrefix("ABCD"))
  }

  @Test
  fun gstinValidator_validatesOfficialMod36Checksum() {
    val prefix14 = "19ABCDE1234F1Z"
    val checksum = GstinValidator.computeChecksumCharacter(prefix14)
    val validGstin = prefix14 + checksum

    val ok = GstinValidator.validate(validGstin.lowercase())
    assertTrue(ok.isValid)
    assertEquals(validGstin, ok.normalizedGstin)
    assertEquals("19", ok.stateCode)

    val badChar = if (checksum == '0') '1' else '0'
    val bad = GstinValidator.validate(prefix14 + badChar)
    assertFalse(bad.isValid)

    val badState = GstinValidator.validate("98ABCDE1234F1Z0")
    assertFalse(badState.isValid)
  }

  @Test
  fun inventoryAlertCalculator_handlesLeapYearAndExactBoundaries() {
    assertEquals(LocalDate.of(2028, 2, 29), InventoryAlertCalculator.getMonthEndExpiryDate(202802))
    assertEquals(LocalDate.of(2026, 2, 28), InventoryAlertCalculator.getMonthEndExpiryDate(202602))

    // Expiry 2026-06-30
    assertEquals(
      ExpiryAlertLevel.Expired,
      InventoryAlertCalculator.classifyExpiry("ACTIVE", 202606, LocalDate.of(2026, 7, 1)),
    )
    assertEquals(
      ExpiryAlertLevel.UrgentWarning30Days,
      InventoryAlertCalculator.classifyExpiry("ACTIVE", 202606, LocalDate.of(2026, 5, 31)), // 30 days
    )
    assertEquals(
      ExpiryAlertLevel.Warning60Days,
      InventoryAlertCalculator.classifyExpiry("ACTIVE", 202606, LocalDate.of(2026, 5, 30)), // 31 days
    )
    assertEquals(
      ExpiryAlertLevel.EarlyWarning90Days,
      InventoryAlertCalculator.classifyExpiry("ACTIVE", 202606, LocalDate.of(2026, 4, 1)), // 90 days
    )
    assertEquals(
      ExpiryAlertLevel.None,
      InventoryAlertCalculator.classifyExpiry("ACTIVE", 202606, LocalDate.of(2026, 3, 31)), // 91 days
    )
  }
}
