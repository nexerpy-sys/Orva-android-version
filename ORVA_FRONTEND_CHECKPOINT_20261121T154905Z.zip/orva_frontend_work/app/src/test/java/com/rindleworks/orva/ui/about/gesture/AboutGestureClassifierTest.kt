package com.rindleworks.orva.ui.about.gesture

import org.junit.Assert.assertEquals
import org.junit.Test

class AboutGestureClassifierTest {
  @Test
  fun `movement below touch slop remains undecided`() {
    assertEquals(AboutGestureAxis.UNDECIDED, classifyAboutGestureAxis(3f, 4f, 8f))
  }

  @Test
  fun `dominant vertical movement is classified as page scroll`() {
    assertEquals(AboutGestureAxis.VERTICAL, classifyAboutGestureAxis(4f, 14f, 8f))
  }

  @Test
  fun `dominant horizontal movement is classified as work rail swipe`() {
    assertEquals(AboutGestureAxis.HORIZONTAL, classifyAboutGestureAxis(18f, 5f, 8f))
  }

  @Test
  fun `exact diagonal remains undecided until the gesture has a clear direction`() {
    assertEquals(AboutGestureAxis.UNDECIDED, classifyAboutGestureAxis(10f, 10f, 8f))
  }

  @Test
  fun `small diagonal bias remains undecided until intent is clearer`() {
    assertEquals(AboutGestureAxis.UNDECIDED, classifyAboutGestureAxis(18f, 15f, 8f))
  }

  @Test
  fun `negative movement uses the same dominant axis`() {
    assertEquals(AboutGestureAxis.VERTICAL, classifyAboutGestureAxis(-4f, -14f, 8f))
  }
}
