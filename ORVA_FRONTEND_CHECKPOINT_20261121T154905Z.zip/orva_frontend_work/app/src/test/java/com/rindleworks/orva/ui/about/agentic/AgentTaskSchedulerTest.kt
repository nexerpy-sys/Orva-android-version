package com.rindleworks.orva.ui.about.agentic

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class AgentTaskSchedulerTest {

  private fun rect(top: Float, height: Float = 120f, left: Float = 24f, width: Float = 800f) =
    SceneBounds(left = left, top = top, right = left + width, bottom = top + height)

  @Test
  fun `parent must be revealed before child can be claimed`() {
    val scheduler = AgentTaskScheduler()
    scheduler.registerOrUpdateNode(id = "hero_container", kind = LayerKind.CONTAINER, bounds = rect(100f))
    scheduler.registerOrUpdateNode(
      id = "hero_headline",
      kind = LayerKind.TEXT,
      parentId = "hero_container",
      bounds = rect(140f),
    )

    // Even a TYPOGRAPHER cannot claim hero_headline while hero_container is HIDDEN or BUILDING
    val first = scheduler.tryClaimNextTask(0, AgentRole.TYPOGRAPHER, 0f, 1000f)
    assertNotNull(first)
    assertEquals("hero_container", first!!.nodeId)

    // While hero_container is still BUILDING, no other agent can claim hero_headline
    val blocked = scheduler.tryClaimNextTask(1, AgentRole.TYPOGRAPHER, 0f, 1000f)
    assertNull(blocked)

    // Once parent completes, child unlocks immediately
    assertTrue(scheduler.completeTask(0, "hero_container"))
    val childClaim = scheduler.tryClaimNextTask(1, AgentRole.TYPOGRAPHER, 0f, 4000f)
    assertNotNull(childClaim)
    assertEquals("hero_headline", childClaim!!.nodeId)
  }

  @Test
  fun `master node must complete before clone siblings can be claimed`() {
    val scheduler = AgentTaskScheduler()
    scheduler.registerOrUpdateNode(
      id = "principle_1",
      kind = LayerKind.CONTAINER,
      cloneGroupId = "principles",
      cloneIndex = 0,
      bounds = rect(200f),
    )
    scheduler.registerOrUpdateNode(
      id = "principle_2",
      kind = LayerKind.CONTAINER,
      cloneGroupId = "principles",
      cloneIndex = 1,
      bounds = rect(360f),
    )
    scheduler.registerOrUpdateNode(
      id = "principle_3",
      kind = LayerKind.CONTAINER,
      cloneGroupId = "principles",
      cloneIndex = 2,
      bounds = rect(520f),
    )

    val masterClaim = scheduler.tryClaimNextTask(3, AgentRole.COMPONENT_DUPLICATOR, 0f, 1200f)
    assertNotNull(masterClaim)
    assertEquals("principle_1", masterClaim!!.nodeId)
    assertFalse(masterClaim.isCloneFromMaster)
    assertNull(masterClaim.masterNodeId)

    // Clones remain blocked while master is BUILDING
    assertNull(scheduler.tryClaimNextTask(4, AgentRole.COMPONENT_DUPLICATOR, 0f, 1200f))

    // Complete master -> clones unlock in parallel referencing masterNodeId
    assertTrue(scheduler.completeTask(3, "principle_1"))
    val clone2 = scheduler.tryClaimNextTask(4, AgentRole.COMPONENT_DUPLICATOR, 0f, 1200f)
    val clone3 = scheduler.tryClaimNextTask(5, AgentRole.COMPONENT_DUPLICATOR, 0f, 1200f)
    assertNotNull(clone2)
    assertNotNull(clone3)
    assertEquals("principle_2", clone2!!.nodeId)
    assertTrue(clone2.isCloneFromMaster)
    assertEquals("principle_1", clone2.masterNodeId)
    assertEquals("principle_3", clone3!!.nodeId)
    assertTrue(clone3.isCloneFromMaster)
    assertEquals("principle_1", clone3.masterNodeId)
  }

  @Test
  fun `max concurrent builders cap is strictly enforced at 8 and IDLE_SCOUT never claims`() {
    val scheduler = AgentTaskScheduler(totalAgents = 16, maxConcurrentBuilders = 8)
    for (i in 0 until 12) {
      scheduler.registerOrUpdateNode(id = "node_$i", kind = LayerKind.CONTAINER, bounds = rect(100f + i * 60f))
    }

    // IDLE_SCOUT can never claim build tasks
    assertNull(scheduler.tryClaimNextTask(12, AgentRole.IDLE_SCOUT, 0f, 2000f))

    // First 8 builder agents succeed
    for (agentId in 0 until 8) {
      val claim = scheduler.tryClaimNextTask(agentId, AgentRole.LAYOUT_ARCHITECT, 0f, 2000f)
      assertNotNull("Agent $agentId should claim a task", claim)
    }
    assertEquals(8, scheduler.activeBuilderCount())

    // 9th builder is rejected by concurrency cap
    assertNull(scheduler.tryClaimNextTask(8, AgentRole.LAYOUT_ARCHITECT, 0f, 2000f))

    // Completing one slot allows the 9th builder to claim immediately
    val node0 = scheduler.allNodesSnapshot().first { it.claimedByAgentId == 0 }.id
    assertTrue(scheduler.completeTask(0, node0))
    assertEquals(7, scheduler.activeBuilderCount())
    assertNotNull(scheduler.tryClaimNextTask(8, AgentRole.LAYOUT_ARCHITECT, 0f, 2000f))
    assertEquals(8, scheduler.activeBuilderCount())
  }

  @Test
  fun `viewport and prefetch margin gate off-screen nodes until scrolled into range`() {
    val scheduler = AgentTaskScheduler(prefetchMarginPx = 200f)
    scheduler.registerOrUpdateNode(id = "top_hero", kind = LayerKind.CONTAINER, bounds = rect(100f))
    scheduler.registerOrUpdateNode(id = "deep_footer", kind = LayerKind.CONTAINER, bounds = rect(2400f))

    // Viewport [0..800], prefetch reaches 1000 -> top_hero eligible, deep_footer blocked
    val first = scheduler.tryClaimNextTask(0, AgentRole.LAYOUT_ARCHITECT, 0f, 800f)
    assertEquals("top_hero", first?.nodeId)
    assertNull(scheduler.tryClaimNextTask(1, AgentRole.LAYOUT_ARCHITECT, 0f, 800f))

    // Move viewport down to [1600..2300], prefetch reaches 2500 -> deep_footer now eligible
    val second = scheduler.tryClaimNextTask(1, AgentRole.LAYOUT_ARCHITECT, 1600f, 2300f)
    assertEquals("deep_footer", second?.nodeId)
  }

  @Test
  fun `releaseClaim restores interrupted task cleanly without stranding`() {
    val scheduler = AgentTaskScheduler()
    scheduler.registerOrUpdateNode(id = "story_block", kind = LayerKind.CONTAINER, bounds = rect(200f))

    val claim = scheduler.tryClaimNextTask(0, AgentRole.LAYOUT_ARCHITECT, 0f, 1000f)
    assertNotNull(claim)
    assertEquals(LayerPhase.BUILDING, scheduler.getNode("story_block")?.phase)
    assertEquals(1, scheduler.activeBuilderCount())

    // Simulate coroutine cancellation -> finally releases claim
    scheduler.releaseClaim(0, "story_block")
    assertEquals(0, scheduler.activeBuilderCount())
    assertEquals(LayerPhase.HIDDEN, scheduler.getNode("story_block")?.phase)
    assertNull(scheduler.getNode("story_block")?.claimedByAgentId)

    // Another agent can safely claim and complete it
    val retryClaim = scheduler.tryClaimNextTask(1, AgentRole.LAYOUT_ARCHITECT, 0f, 1000f)
    assertEquals("story_block", retryClaim?.nodeId)
    assertTrue(scheduler.completeTask(1, "story_block"))
    assertEquals(LayerPhase.REVEALED, scheduler.getNode("story_block")?.phase)
  }

  @Test
  fun `responsive viewport width resize releases in-flight claims and advances bounds generation`() {
    val scheduler = AgentTaskScheduler()
    scheduler.onViewportWidthChanged(1080f)
    scheduler.registerOrUpdateNode(id = "meta_panel", kind = LayerKind.CONTAINER, bounds = rect(300f))

    val claim1 = scheduler.tryClaimNextTask(0, AgentRole.LAYOUT_ARCHITECT, 0f, 1200f)
    assertNotNull(claim1)
    val initialGen = claim1!!.boundsGeneration

    // Small noise (< 8px) does not invalidate
    assertFalse(scheduler.onViewportWidthChanged(1083f))
    assertEquals(1, scheduler.activeBuilderCount())

    // Real orientation / foldable width change invalidates claims & bumps generation
    assertTrue(scheduler.onViewportWidthChanged(2200f))
    assertEquals(0, scheduler.activeBuilderCount())
    assertEquals(LayerPhase.HIDDEN, scheduler.getNode("meta_panel")?.phase)

    scheduler.registerOrUpdateNode(id = "meta_panel", kind = LayerKind.CONTAINER, bounds = rect(300f, width = 1800f))
    val claim2 = scheduler.tryClaimNextTask(0, AgentRole.LAYOUT_ARCHITECT, 0f, 1200f)
    assertNotNull(claim2)
    assertTrue(claim2!!.boundsGeneration > initialGen)
  }

  @Test
  fun `role preference prioritizes matching kind with graceful assist fallback`() {
    val scheduler = AgentTaskScheduler()
    scheduler.registerOrUpdateNode(id = "media_frieze", kind = LayerKind.MEDIA, bounds = rect(100f))
    scheduler.registerOrUpdateNode(id = "headline_text", kind = LayerKind.TEXT, bounds = rect(100f))

    // TYPOGRAPHER prefers TEXT even though MEDIA has lower priorityRank
    val typoClaim = scheduler.tryClaimNextTask(6, AgentRole.TYPOGRAPHER, 0f, 1000f)
    assertEquals("headline_text", typoClaim?.nodeId)

    // ART_DIRECTOR claims MEDIA
    val artClaim = scheduler.tryClaimNextTask(10, AgentRole.ART_DIRECTOR, 0f, 1000f)
    assertEquals("media_frieze", artClaim?.nodeId)

    // If only MEDIA remains, TYPOGRAPHER gracefully assists rather than stalling
    scheduler.registerOrUpdateNode(id = "extra_media", kind = LayerKind.MEDIA, bounds = rect(300f))
    val assistClaim = scheduler.tryClaimNextTask(7, AgentRole.TYPOGRAPHER, 0f, 1000f)
    assertEquals("extra_media", assistClaim?.nodeId)
  }

  @Test
  fun `resetForReplay reproduces deterministic claim sequence and convergence waits for all nodes`() {
    val scheduler = AgentTaskScheduler()
    scheduler.registerOrUpdateNode(id = "a_container", kind = LayerKind.CONTAINER, bounds = rect(100f))
    scheduler.registerOrUpdateNode(id = "b_rule", kind = LayerKind.LINE, parentId = "a_container", bounds = rect(180f))
    scheduler.registerOrUpdateNode(id = "c_text", kind = LayerKind.TEXT, parentId = "a_container", bounds = rect(240f))

    fun drainSequence(): List<String> {
      val order = mutableListOf<String>()
      while (!scheduler.isAllCompleted()) {
        val c = scheduler.tryClaimNextTask(0, AgentRole.LAYOUT_ARCHITECT, 0f, 1000f) ?: break
        order += c.nodeId
        assertFalse(scheduler.isAllCompleted())
        assertTrue(scheduler.completeTask(0, c.nodeId))
      }
      return order
    }

    val run1 = drainSequence()
    assertEquals(listOf("a_container", "b_rule", "c_text"), run1)
    assertTrue(scheduler.isAllCompleted())
    assertEquals(3, scheduler.completedCount())

    scheduler.resetForReplay()
    assertFalse(scheduler.isAllCompleted())
    assertEquals(0, scheduler.completedCount())

    val run2 = drainSequence()
    assertEquals(run1, run2)
    assertTrue(scheduler.isAllCompleted())
  }

  @Test
  fun `empty scheduler never falsely reports completed`() {
    val scheduler = AgentTaskScheduler()
    assertFalse(scheduler.isAllCompleted())
    assertEquals(0, scheduler.totalCount())
    assertEquals(0, scheduler.completedCount())
  }
  @Test
  fun `missing parent blocks child until parent is registered and revealed`() {
    val scheduler = AgentTaskScheduler()
    scheduler.registerOrUpdateNode(
      id = "child_text",
      kind = LayerKind.TEXT,
      parentId = "late_parent",
      bounds = rect(180f),
    )

    assertNull(scheduler.tryClaimNextTask(0, AgentRole.TYPOGRAPHER, 0f, 1000f))

    scheduler.registerOrUpdateNode(
      id = "late_parent",
      kind = LayerKind.CONTAINER,
      bounds = rect(100f),
    )
    val parentClaim = scheduler.tryClaimNextTask(1, AgentRole.LAYOUT_ARCHITECT, 0f, 1000f)
    assertEquals("late_parent", parentClaim?.nodeId)
    assertTrue(scheduler.completeTask(1, "late_parent"))

    val childClaim = scheduler.tryClaimNextTask(0, AgentRole.TYPOGRAPHER, 0f, 1000f)
    assertEquals("child_text", childClaim?.nodeId)
  }

  @Test
  fun `missing clone master blocks clone rather than building it independently`() {
    val scheduler = AgentTaskScheduler()
    scheduler.registerOrUpdateNode(
      id = "principle_clone",
      kind = LayerKind.CONTAINER,
      cloneGroupId = "principles",
      cloneIndex = 1,
      bounds = rect(220f),
    )
    assertNull(scheduler.tryClaimNextTask(0, AgentRole.COMPONENT_DUPLICATOR, 0f, 1000f))

    scheduler.registerOrUpdateNode(
      id = "principle_master",
      kind = LayerKind.CONTAINER,
      cloneGroupId = "principles",
      cloneIndex = 0,
      bounds = rect(100f),
    )
    val masterClaim = scheduler.tryClaimNextTask(1, AgentRole.COMPONENT_DUPLICATOR, 0f, 1000f)
    assertEquals("principle_master", masterClaim?.nodeId)
    assertTrue(scheduler.completeTask(1, "principle_master"))

    val cloneClaim = scheduler.tryClaimNextTask(0, AgentRole.COMPONENT_DUPLICATOR, 0f, 1000f)
    assertEquals("principle_clone", cloneClaim?.nodeId)
    assertEquals("principle_master", cloneClaim?.masterNodeId)
  }

  @Test
  fun `height and density changes invalidate in-flight claims`() {
    val scheduler = AgentTaskScheduler()
    assertFalse(scheduler.onViewportGeometryChanged(1080f, 1920f, 2.75f)) // initial baseline
    scheduler.registerOrUpdateNode(id = "viewport_node", kind = LayerKind.CONTAINER, bounds = rect(100f))

    val first = scheduler.tryClaimNextTask(0, AgentRole.LAYOUT_ARCHITECT, 0f, 1000f)
    assertNotNull(first)
    assertTrue(scheduler.onViewportGeometryChanged(1080f, 2200f, 2.75f))
    assertEquals(0, scheduler.activeBuilderCount())
    assertEquals(LayerPhase.HIDDEN, scheduler.getNode("viewport_node")?.phase)

    // Same measured bounds still receive the new geometry epoch on re-registration.
    scheduler.registerOrUpdateNode(id = "viewport_node", kind = LayerKind.CONTAINER, bounds = rect(100f))
    val second = scheduler.tryClaimNextTask(0, AgentRole.LAYOUT_ARCHITECT, 0f, 1200f)
    assertNotNull(second)

    assertTrue(scheduler.onViewportGeometryChanged(1080f, 2200f, 3.0f))
    assertEquals(0, scheduler.activeBuilderCount())
    assertEquals(LayerPhase.HIDDEN, scheduler.getNode("viewport_node")?.phase)
  }

  @Test
  fun `viewport work query ignores nodes whose dependencies are blocked`() {
    val scheduler = AgentTaskScheduler(prefetchMarginPx = 200f)
    scheduler.registerOrUpdateNode(
      id = "orphan_child",
      kind = LayerKind.TEXT,
      parentId = "missing_parent",
      bounds = rect(100f),
    )
    assertFalse(scheduler.hasEligibleWorkInViewport(0f, 800f))
  }

  @Test
  fun `significant node remeasurement invalidates its old active claim`() {
    val scheduler = AgentTaskScheduler()
    scheduler.registerOrUpdateNode(id = "moving_panel", kind = LayerKind.CONTAINER, bounds = rect(100f))

    val oldClaim = scheduler.tryClaimNextTask(0, AgentRole.LAYOUT_ARCHITECT, 0f, 1000f)
    assertNotNull(oldClaim)
    scheduler.registerOrUpdateNode(id = "moving_panel", kind = LayerKind.CONTAINER, bounds = rect(180f))

    // The old worker can no longer commit work positioned against the previous bounds.
    assertFalse(scheduler.completeTask(0, "moving_panel"))
    assertEquals(LayerPhase.HIDDEN, scheduler.getNode("moving_panel")?.phase)
    val newClaim = scheduler.tryClaimNextTask(1, AgentRole.LAYOUT_ARCHITECT, 0f, 1000f)
    assertNotNull(newClaim)
    assertTrue(newClaim!!.boundsGeneration > oldClaim!!.boundsGeneration)
  }


  @Test
  fun `dependency cycle is reported and blocks all claims`() {
    val scheduler = AgentTaskScheduler()
    scheduler.registerOrUpdateNode("a", LayerKind.CONTAINER, parentId = "b", bounds = rect(100f))
    scheduler.registerOrUpdateNode("b", LayerKind.CONTAINER, parentId = "a", bounds = rect(240f))

    val issues = scheduler.validateSceneGraph()
    assertTrue(issues.any { it.contains("Dependency cycle") })
    assertNull(scheduler.tryClaimNextTask(0, AgentRole.LAYOUT_ARCHITECT, 0f, 1000f))
    assertFalse(scheduler.hasEligibleWorkInViewport(0f, 1000f))
  }

  @Test
  fun `clone group with duplicate masters is invalid`() {
    val scheduler = AgentTaskScheduler()
    scheduler.registerOrUpdateNode("master_a", LayerKind.CONTAINER, cloneGroupId = "cards", cloneIndex = 0, bounds = rect(100f))
    scheduler.registerOrUpdateNode("master_b", LayerKind.CONTAINER, cloneGroupId = "cards", cloneIndex = 0, bounds = rect(240f))
    scheduler.registerOrUpdateNode("clone", LayerKind.CONTAINER, cloneGroupId = "cards", cloneIndex = 1, bounds = rect(360f))

    assertTrue(scheduler.validateSceneGraph().any { it.contains("multiple masters") })
    assertNull(scheduler.tryClaimNextTask(0, AgentRole.COMPONENT_DUPLICATOR, 0f, 1000f))
  }

  @Test
  fun `reverse claim only reaches content at least one and a half screens below reader`() {
    val scheduler = AgentTaskScheduler(prefetchMarginPx = 200f)
    scheduler.registerOrUpdateNode("near_reader", LayerKind.CONTAINER, bounds = rect(2499f))
    scheduler.registerOrUpdateNode("eligible_far", LayerKind.CONTAINER, bounds = rect(2500f))
    listOf("near_reader", "eligible_far").forEach { id ->
      val claim = scheduler.tryClaimNextTask(0, AgentRole.LAYOUT_ARCHITECT, 0f, 4000f)
      assertEquals(id, claim?.nodeId)
      assertTrue(scheduler.completeTask(0, id))
    }

    val reverse = scheduler.tryClaimNextReverseTask(1, AgentRole.LAYOUT_ARCHITECT, 0f, 1000f)
    assertEquals("eligible_far", reverse?.nodeId)
    assertEquals(TaskDirection.RESTOCK, reverse?.direction)
    assertNull(scheduler.tryClaimNextReverseTask(2, AgentRole.LAYOUT_ARCHITECT, 0f, 1000f))
  }

  @Test
  fun `reverse honours child before parent even when parent completed later`() {
    val scheduler = AgentTaskScheduler()
    scheduler.registerOrUpdateNode("scene_parent", LayerKind.CONTAINER, bounds = rect(3000f))
    scheduler.registerOrUpdateNode("scene_child", LayerKind.TEXT, parentId = "scene_parent", bounds = rect(3200f))
    val parentClaim = scheduler.tryClaimNextTask(0, AgentRole.LAYOUT_ARCHITECT, 0f, 4000f)
    assertEquals("scene_parent", parentClaim?.nodeId)
    assertTrue(scheduler.completeTask(0, "scene_parent"))
    val childClaim = scheduler.tryClaimNextTask(1, AgentRole.TYPOGRAPHER, 0f, 4000f)
    assertEquals("scene_child", childClaim?.nodeId)
    assertTrue(scheduler.completeTask(1, "scene_child"))

    val firstReverse = scheduler.tryClaimNextReverseTask(2, AgentRole.TYPOGRAPHER, 0f, 1000f)
    assertEquals("scene_child", firstReverse?.nodeId)
    assertNull(scheduler.tryClaimNextReverseTask(3, AgentRole.LAYOUT_ARCHITECT, 0f, 1000f))
    assertTrue(scheduler.completeTask(2, "scene_child", nowMs = 1000L))
    val secondReverse = scheduler.tryClaimNextReverseTask(3, AgentRole.LAYOUT_ARCHITECT, 0f, 1000f)
    assertEquals("scene_parent", secondReverse?.nodeId)
  }

  @Test
  fun `reverse journal uses actual completion order across independent nodes`() {
    val scheduler = AgentTaskScheduler()
    scheduler.registerOrUpdateNode("gamma", LayerKind.CONTAINER, bounds = rect(3000f))
    scheduler.registerOrUpdateNode("alpha", LayerKind.CONTAINER, bounds = rect(3150f))
    scheduler.registerOrUpdateNode("beta", LayerKind.CONTAINER, bounds = rect(3300f))
    listOf("gamma", "alpha", "beta").forEachIndexed { agent, wantedId ->
      val next = scheduler.tryClaimNextTask(agent, AgentRole.LAYOUT_ARCHITECT, 0f, 4000f)
      assertEquals(wantedId, next?.nodeId)
      assertTrue(scheduler.completeTask(agent, wantedId))
    }
    val reverseOrder = mutableListOf<String>()
    repeat(3) { index ->
      val claim = scheduler.tryClaimNextReverseTask(index, AgentRole.LAYOUT_ARCHITECT, 0f, 1000f)
      assertNotNull(claim)
      val claimed = claim!!
      reverseOrder += claimed.nodeId
      assertTrue(scheduler.completeTask(index, claimed.nodeId, nowMs = 2000L + index))
    }
    assertEquals(listOf("beta", "alpha", "gamma"), reverseOrder)
  }

  @Test
  fun `reverse interruption restores committed content without losing journal`() {
    val scheduler = AgentTaskScheduler()
    scheduler.registerOrUpdateNode("stable", LayerKind.CONTAINER, bounds = rect(3000f))
    val forward = scheduler.tryClaimNextTask(0, AgentRole.LAYOUT_ARCHITECT, 0f, 4000f)
    assertTrue(scheduler.completeTask(0, forward!!.nodeId))
    val originalSequence = scheduler.completionJournal().single().first
    assertNotNull(scheduler.tryClaimNextReverseTask(1, AgentRole.LAYOUT_ARCHITECT, 0f, 1000f, nowMs = 100L))

    val settled = scheduler.settleReverseClaimsByGrace(nowMs = 500L, graceWindowMs = 2_000L)
    assertEquals(listOf("stable"), settled.restoredNodeIds)
    assertEquals(LayerPhase.REVEALED, scheduler.getNode("stable")?.phase)
    assertEquals(originalSequence, scheduler.completionJournal().single().first)
    assertEquals(0, scheduler.activeBuilderCount())
  }

  @Test
  fun `completed restock can be restored only inside its own grace window`() {
    val scheduler = AgentTaskScheduler()
    scheduler.registerOrUpdateNode("recent", LayerKind.CONTAINER, bounds = rect(3000f))
    val forward = scheduler.tryClaimNextTask(0, AgentRole.LAYOUT_ARCHITECT, 0f, 4000f)
    assertTrue(scheduler.completeTask(0, forward!!.nodeId))
    assertNotNull(scheduler.tryClaimNextReverseTask(1, AgentRole.LAYOUT_ARCHITECT, 0f, 1000f))
    assertTrue(scheduler.completeTask(1, "recent", nowMs = 1000L))

    assertEquals(listOf("recent"), scheduler.restoreRecentlyReversed(nowMs = 2500L, graceWindowMs = 2000L))
    assertEquals(LayerPhase.REVEALED, scheduler.getNode("recent")?.phase)
    assertEquals(1, scheduler.completionJournal().size)
  }

  @Test
  fun `expired restock is not falsely restored`() {
    val scheduler = AgentTaskScheduler()
    scheduler.registerOrUpdateNode("old", LayerKind.CONTAINER, bounds = rect(3000f))
    val forward = scheduler.tryClaimNextTask(0, AgentRole.LAYOUT_ARCHITECT, 0f, 4000f)
    assertTrue(scheduler.completeTask(0, forward!!.nodeId))
    assertNotNull(scheduler.tryClaimNextReverseTask(1, AgentRole.LAYOUT_ARCHITECT, 0f, 1000f))
    assertTrue(scheduler.completeTask(1, "old", nowMs = 1000L))

    assertTrue(scheduler.restoreRecentlyReversed(nowMs = 3001L, graceWindowMs = 2000L).isEmpty())
    assertEquals(LayerPhase.HIDDEN, scheduler.getNode("old")?.phase)
  }

  @Test
  fun `scene unseals before first reverse claim and restores without duplicate seal`() {
    val scheduler = AgentTaskScheduler()
    scheduler.registerOrUpdateNode("about_hero_container", LayerKind.CONTAINER, bounds = rect(3000f), sceneIndex = 1)
    scheduler.registerOrUpdateNode("about_hero_text", LayerKind.TEXT, parentId = "about_hero_container", bounds = rect(3200f), sceneIndex = 1)
    val parent = scheduler.tryClaimNextTask(0, AgentRole.LAYOUT_ARCHITECT, 0f, 4000f)
    assertTrue(scheduler.completeTask(0, parent!!.nodeId))
    val child = scheduler.tryClaimNextTask(1, AgentRole.TYPOGRAPHER, 0f, 4000f)
    assertTrue(scheduler.completeTask(1, child!!.nodeId))
    assertEquals(listOf(SceneBuildEvent.Sealed(1)), scheduler.drainSceneEvents())

    assertNotNull(scheduler.tryClaimNextReverseTask(2, AgentRole.TYPOGRAPHER, 0f, 1000f))
    assertEquals(listOf(SceneBuildEvent.Unsealed(1)), scheduler.drainSceneEvents())
    assertTrue(scheduler.completeTask(2, "about_hero_text", nowMs = 1000L))
    val parentReverse = scheduler.tryClaimNextReverseTask(3, AgentRole.LAYOUT_ARCHITECT, 0f, 1000f)
    assertEquals("about_hero_container", parentReverse?.nodeId)
    assertTrue(scheduler.completeTask(3, "about_hero_container", nowMs = 1100L))
    assertEquals(emptyList<SceneBuildEvent>(), scheduler.drainSceneEvents())

    assertEquals(2, scheduler.restoreRecentlyReversed(nowMs = 1500L).size)
    assertEquals(listOf(SceneBuildEvent.Restored(1)), scheduler.drainSceneEvents())
  }

  @Test
  fun `reverse journal has one owner at a time so completion order cannot invert`() {
    val scheduler = AgentTaskScheduler(maxConcurrentBuilders = 8)
    repeat(4) { index ->
      val id = "node_$index"
      scheduler.registerOrUpdateNode(id, LayerKind.CONTAINER, bounds = rect(3000f + index * 100f))
      val forward = scheduler.tryClaimNextTask(index, AgentRole.LAYOUT_ARCHITECT, 0f, 4000f)
      assertEquals(id, forward?.nodeId)
      assertTrue(scheduler.completeTask(index, id))
    }

    val first = scheduler.tryClaimNextReverseTask(8, AgentRole.LAYOUT_ARCHITECT, 0f, 1000f, nowMs = 500L)
    assertNotNull(first)
    assertEquals(1, scheduler.activeBuilderCount())
    assertNull(scheduler.tryClaimNextReverseTask(9, AgentRole.LAYOUT_ARCHITECT, 0f, 1000f, nowMs = 500L))
    assertNull(scheduler.tryClaimNextTask(8, AgentRole.LAYOUT_ARCHITECT, 0f, 4000f))
    assertTrue(scheduler.completeTask(8, first!!.nodeId, nowMs = 900L))
    assertNotNull(scheduler.tryClaimNextReverseTask(9, AgentRole.LAYOUT_ARCHITECT, 0f, 1000f, nowMs = 901L))
  }

  @Test
  fun `clone siblings restock in reverse completion order before their master`() {
    val scheduler = AgentTaskScheduler()
    scheduler.registerOrUpdateNode("card_master", LayerKind.CONTAINER, cloneGroupId = "cards", cloneIndex = 0, bounds = rect(3000f))
    scheduler.registerOrUpdateNode("card_left", LayerKind.CONTAINER, cloneGroupId = "cards", cloneIndex = 1, bounds = rect(3200f))
    scheduler.registerOrUpdateNode("card_right", LayerKind.CONTAINER, cloneGroupId = "cards", cloneIndex = 2, bounds = rect(3400f))

    val master = scheduler.tryClaimNextTask(0, AgentRole.COMPONENT_DUPLICATOR, 0f, 4000f)
    assertEquals("card_master", master?.nodeId)
    assertTrue(scheduler.completeTask(0, "card_master"))
    val left = scheduler.tryClaimNextTask(1, AgentRole.COMPONENT_DUPLICATOR, 0f, 4000f)
    assertEquals("card_left", left?.nodeId)
    assertTrue(scheduler.completeTask(1, "card_left"))
    val right = scheduler.tryClaimNextTask(2, AgentRole.COMPONENT_DUPLICATOR, 0f, 4000f)
    assertEquals("card_right", right?.nodeId)
    assertTrue(scheduler.completeTask(2, "card_right"))

    val reverseIds = mutableListOf<String>()
    repeat(3) { agentId ->
      val claim = scheduler.tryClaimNextReverseTask(agentId + 3, AgentRole.COMPONENT_DUPLICATOR, 0f, 1000f)
      assertNotNull(claim)
      val actualClaim = claim!!
      reverseIds += actualClaim.nodeId
      assertTrue(scheduler.completeTask(agentId + 3, actualClaim.nodeId, nowMs = 1000L + agentId))
    }
    assertEquals(listOf("card_right", "card_left", "card_master"), reverseIds)
  }

  @Test
  fun `scene indices propagate to descendants registered before their parent`() {
    val scheduler = AgentTaskScheduler()
    scheduler.registerOrUpdateNode(
      "support_phone_value",
      LayerKind.TEXT,
      parentId = "support_phone_row",
      bounds = rect(3000f),
    )
    scheduler.registerOrUpdateNode(
      "support_phone_row",
      LayerKind.CONTAINER,
      parentId = "about_meta_container",
      bounds = rect(2900f),
    )
    assertNull(scheduler.getNode("support_phone_value")?.sceneIndex)

    scheduler.registerOrUpdateNode("about_meta_container", LayerKind.CONTAINER, bounds = rect(2800f))

    assertEquals(9, scheduler.getNode("support_phone_row")?.sceneIndex)
    assertEquals(9, scheduler.getNode("support_phone_value")?.sceneIndex)
  }

  @Test
  fun `reverse availability respects invalid scene graphs`() {
    val scheduler = AgentTaskScheduler()
    scheduler.registerOrUpdateNode("cycle_a", LayerKind.CONTAINER, parentId = "cycle_b", bounds = rect(3000f))
    scheduler.registerOrUpdateNode("cycle_b", LayerKind.CONTAINER, parentId = "cycle_a", bounds = rect(3200f))
    scheduler.markAllRevealed()

    assertFalse(scheduler.hasEligibleReverseWork(0f, 1000f, rewindScreens = 1.5f))
    assertNull(scheduler.tryClaimNextReverseTask(0, AgentRole.LAYOUT_ARCHITECT, 0f, 1000f))
  }

  @Test
  fun `restock only reaches content at least one and a half screens below the viewport`() {
    val scheduler = AgentTaskScheduler()
    scheduler.registerOrUpdateNode("near_reader", LayerKind.CONTAINER, bounds = rect(2_000f))
    scheduler.registerOrUpdateNode("far_below", LayerKind.CONTAINER, bounds = rect(2_600f))
    scheduler.markAllRevealed()

    val first = scheduler.tryClaimNextReverseTask(
      agentId = 0,
      role = AgentRole.LAYOUT_ARCHITECT,
      viewportTopPx = 0f,
      viewportBottomPx = 1_000f,
      rewindScreens = 1.5f,
      nowMs = 100L,
    )
    assertEquals("far_below", first?.nodeId)
    assertTrue(scheduler.completeTask(0, "far_below", nowMs = 300L))
    assertFalse(scheduler.hasEligibleReverseWork(0f, 1_000f, rewindScreens = 1.5f))
  }

  @Test
  fun `reverse work is claimed by the matching specialist role`() {
    val scheduler = AgentTaskScheduler()
    scheduler.registerOrUpdateNode("media", LayerKind.MEDIA, bounds = rect(3000f))
    val forward = scheduler.tryClaimNextTask(0, AgentRole.ART_DIRECTOR, 0f, 4000f)
    assertEquals("media", forward?.nodeId)
    assertTrue(scheduler.completeTask(0, "media"))

    assertNull(scheduler.tryClaimNextReverseTask(1, AgentRole.LAYOUT_ARCHITECT, 0f, 1000f))
    val reverse = scheduler.tryClaimNextReverseTask(2, AgentRole.ART_DIRECTOR, 0f, 1000f)
    assertEquals("media", reverse?.nodeId)
  }

  @Test
  fun `scheduler never holds forward and reverse claims at the same time`() {
    val scheduler = AgentTaskScheduler(maxConcurrentBuilders = 8)
    scheduler.registerOrUpdateNode("forward", LayerKind.CONTAINER, bounds = rect(3000f))
    scheduler.registerOrUpdateNode("committed", LayerKind.CONTAINER, bounds = rect(3200f))
    val committed = scheduler.tryClaimNextTask(0, AgentRole.LAYOUT_ARCHITECT, 0f, 4000f)
    assertEquals("forward", committed?.nodeId)
    assertTrue(scheduler.completeTask(0, "forward"))
    val other = scheduler.tryClaimNextTask(1, AgentRole.LAYOUT_ARCHITECT, 0f, 4000f)
    assertEquals("committed", other?.nodeId)
    assertTrue(scheduler.completeTask(1, "committed"))

    val reverse = scheduler.tryClaimNextReverseTask(2, AgentRole.LAYOUT_ARCHITECT, 0f, 1000f, nowMs = 100L)
    assertNotNull(reverse)
    assertNull(scheduler.tryClaimNextTask(3, AgentRole.LAYOUT_ARCHITECT, 0f, 4000f))
    assertTrue(scheduler.completeTask(2, reverse!!.nodeId, nowMs = 500L))
    assertNotNull(scheduler.tryClaimNextTask(3, AgentRole.LAYOUT_ARCHITECT, 0f, 4000f))
  }

  @Test
  fun `expired in-flight reverse claim does not receive an accidental fresh grace window`() {
    val scheduler = AgentTaskScheduler()
    scheduler.registerOrUpdateNode("slow_reverse", LayerKind.CONTAINER, bounds = rect(3000f))
    val forward = scheduler.tryClaimNextTask(0, AgentRole.LAYOUT_ARCHITECT, 0f, 4000f)
    assertTrue(scheduler.completeTask(0, forward!!.nodeId))
    assertNotNull(scheduler.tryClaimNextReverseTask(1, AgentRole.LAYOUT_ARCHITECT, 0f, 1000f, nowMs = 100L))

    val settled = scheduler.settleReverseClaimsByGrace(nowMs = 2501L, graceWindowMs = 2000L)
    assertEquals(listOf("slow_reverse"), settled.restockedNodeIds)
    assertTrue(scheduler.restoreRecentlyReversed(
      nowMs = 2501L,
      graceWindowMs = 2000L,
      excludeNodeIds = settled.restockedNodeIds.toSet(),
    ).isEmpty())
    assertEquals(LayerPhase.HIDDEN, scheduler.getNode("slow_reverse")?.phase)
  }

}
