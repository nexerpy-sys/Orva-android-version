package com.rindleworks.orva.data.local

import android.content.Context
import android.database.sqlite.SQLiteConstraintException
import android.database.sqlite.SQLiteDatabase
import androidx.test.core.app.ApplicationProvider
import com.rindleworks.orva.data.local.entity.MedicineEntity
import com.rindleworks.orva.data.local.entity.StockBatchEntity
import com.rindleworks.orva.domain.common.OrvaSchemaInteropContract
import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

/**
 * Verifies Stage 2 Room <-> ORVA WPF Schema v3 bidirectional interoperability:
 * - Room cleanly opens pure WPF 001->002->003 SQLite databases (no room_master_table).
 * - All 18 tables, 15 indexes (including expression unique index ux_batch_normalized_identity),
 *   and SQLite CHECK constraints remain intact and enforced.
 * - Non-destructive v1 -> v3 migration preserves existing data.
 * - Future schema version (v4) fails loudly without modifying the database.
 * - Portable export strips room_master_table and passes standalone validation.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class OrvaSchemaInteropRobolectricTest {

  private fun appContext(): Context = ApplicationProvider.getApplicationContext()

  private fun readAssetSql(fileName: String): String =
    appContext().assets.open("db/$fileName").bufferedReader(Charsets.UTF_8).use { it.readText() }

  private fun newTempDbFile(name: String): File {
    val dir = File(appContext().cacheDir, "interop_tests_${System.nanoTime()}").apply { mkdirs() }
    return File(dir, name)
  }

  @Test
  fun freshBootstrap_opensCleanlyInRoom_preservesCheckConstraintsAndExpressionIndex() {
    val dbFile = newTempDbFile("fresh_orva.sqlite")
    val provider = OrvaDatabaseProvider(appContext(), dbFile, allowMainThreadQueries = true)
    try {
      val db = provider.current()
      val sqlite = db.openHelper.writableDatabase

      // Verify schema_version and user_version
      assertEquals("3", db.appMetaDao().getValue("schema_version"))
      sqlite.query("PRAGMA user_version;").use { c ->
        assertTrue(c.moveToFirst())
        assertEquals(3, c.getInt(0))
      }

      // Verify all 18 tables exist
      val tables = mutableSetOf<String>()
      sqlite.query(
          "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' AND name NOT IN ('room_master_table', 'android_metadata');"
        )
        .use { c ->
          while (c.moveToNext()) tables.add(c.getString(0))
        }
      assertEquals(OrvaSchemaBootstrapper.REQUIRED_TABLES, tables)

      // Verify expression unique index ux_batch_normalized_identity exists
      var hasExprIndex = false
      sqlite.query("SELECT name FROM sqlite_master WHERE type='index' AND name='ux_batch_normalized_identity';")
        .use { c -> hasExprIndex = c.moveToFirst() }
      assertTrue("ux_batch_normalized_identity must exist", hasExprIndex)

      // Insert a medicine and batch via Room DAO
      val now = "2026-04-15T10:00:00.0000000Z"
      db.medicineDao()
        .insert(
          MedicineEntity(
            medicineId = "med-1",
            displayName = "Dolo 650",
            normalizedName = "dolo 650",
            stockUnitName = "strip",
            gstRateBasisPoints = 1200,
            gstRateConfigured = 1,
            createdAtUtc = now,
            updatedAtUtc = now,
          )
        )
      db.stockBatchDao()
        .insert(
          StockBatchEntity(
            batchId = "batch-1",
            medicineId = "med-1",
            batchNumber = "B-101",
            expiryYyyyMm = 202705,
            stockUnitName = "strip",
            mrpPaise = 3000L,
            latestPurchasePricePaise = 2100L,
            quantityMilli = 5000L,
            batchStatus = "ACTIVE",
            createdAtUtc = now,
            updatedAtUtc = now,
          )
        )

      // Expression unique index must block whitespace/case-variant duplicate batch!
      try {
        db.stockBatchDao()
          .insert(
            StockBatchEntity(
              batchId = "batch-dup",
              medicineId = "med-1",
              batchNumber = "  b-101 ",
              expiryYyyyMm = 202705,
              stockUnitName = "strip",
              mrpPaise = 3000L,
              latestPurchasePricePaise = 2100L,
              quantityMilli = 1000L,
              batchStatus = "ACTIVE",
              createdAtUtc = now,
              updatedAtUtc = now,
            )
          )
        fail("Expected SQLiteConstraintException from ux_batch_normalized_identity")
      } catch (_: SQLiteConstraintException) {
        // Expected
      }

      // SQLite CHECK constraint must block negative quantity_milli!
      try {
        db.stockBatchDao()
          .insert(
            StockBatchEntity(
              batchId = "batch-neg",
              medicineId = "med-1",
              batchNumber = "B-NEG",
              expiryYyyyMm = 202705,
              stockUnitName = "strip",
              mrpPaise = 3000L,
              latestPurchasePricePaise = 2100L,
              quantityMilli = -100L,
              batchStatus = "ACTIVE",
              createdAtUtc = now,
              updatedAtUtc = now,
            )
          )
        fail("Expected SQLiteConstraintException from CHECK (quantity_milli >= 0)")
      } catch (_: SQLiteConstraintException) {
        // Expected
      }

      // SQLite CHECK constraint must block invalid batch_status!
      try {
        db.stockBatchDao()
          .insert(
            StockBatchEntity(
              batchId = "batch-badstatus",
              medicineId = "med-1",
              batchNumber = "B-BAD",
              expiryYyyyMm = 202705,
              stockUnitName = "strip",
              mrpPaise = 3000L,
              latestPurchasePricePaise = 2100L,
              quantityMilli = 1000L,
              batchStatus = "UNKNOWN_STATUS",
              createdAtUtc = now,
              updatedAtUtc = now,
            )
          )
        fail("Expected SQLiteConstraintException from CHECK (batch_status IN ...)")
      } catch (_: SQLiteConstraintException) {
        // Expected
      }
    } finally {
      provider.closeCurrent()
    }
  }

  @Test
  fun wpfCreatedSchemaV3Database_withoutRoomMasterTable_opensCleanlyInRoom_andExportsBackCleanly() {
    val wpfDbFile = newTempDbFile("wpf_origin.sqlite")

    // Simulate a pure WPF-created v3 database using raw SQLite (no Room, no room_master_table)
    val raw = SQLiteDatabase.openOrCreateDatabase(wpfDbFile, null)
    try {
      raw.execSQL("PRAGMA foreign_keys = ON;")
      for (file in listOf("001_InitialSchema.sql", "002_BillingTaxConfig.sql", "003_PerformanceIndexes.sql")) {
        for (stmt in OrvaSchemaBootstrapper.splitSqlStatements(readAssetSql(file))) {
          if (!stmt.startsWith("PRAGMA ", ignoreCase = true)) {
            raw.execSQL(stmt)
          }
        }
      }
      raw.execSQL("INSERT OR REPLACE INTO app_meta(meta_key, meta_value) VALUES ('schema_version', '3');")
      raw.execSQL("PRAGMA user_version = 3;")
      raw.execSQL(
        """
        INSERT INTO shop_profile(profile_id, shop_id, shop_name, invoice_prefix, financial_year_start_month, created_at_utc, updated_at_utc)
        VALUES (1, 'shop-wpf-001', 'Bengal Medicos', 'BM', 4, '2026-04-01T00:00:00.0000000Z', '2026-04-01T00:00:00.0000000Z');
        """
      )
      raw.execSQL(
        """
        INSERT INTO medicine(medicine_id, display_name, normalized_name, stock_unit_name, gst_rate_basis_points, gst_rate_configured, created_at_utc, updated_at_utc)
        VALUES ('m-wpf', 'Azithral 500', 'azithral 500', 'strip', 1200, 1, '2026-04-01T00:00:00.0000000Z', '2026-04-01T00:00:00.0000000Z');
        """
      )
    } finally {
      raw.close()
    }

    // Open directly in Room via OrvaDatabaseProvider
    val provider = OrvaDatabaseProvider(appContext(), wpfDbFile, allowMainThreadQueries = true)
    try {
      val db = provider.current()
      val profile = db.shopProfileDao().getProfile()
      assertNotNull(profile)
      assertEquals("shop-wpf-001", profile?.shopId)
      assertEquals("Bengal Medicos", profile?.shopName)

      val med = db.medicineDao().getById("m-wpf")
      assertNotNull(med)
      assertEquals("Azithral 500", med?.displayName)
      assertEquals(1, med?.gstRateConfigured)
    } finally {
      provider.closeCurrent()
    }

    // Export a portable staged copy and strip Room metadata for WPF import
    val stagedCopy = newTempDbFile("portable_export.sqlite")
    wpfDbFile.copyTo(stagedCopy, overwrite = true)
    OrvaSchemaBootstrapper.prepareStagedCopyForPortableExport(stagedCopy)

    val report = OrvaSchemaBootstrapper.validateStandaloneSqliteFile(stagedCopy)
    assertTrue("Staged portable backup must pass validation: ${report.errors}", report.isValid)
    assertEquals(3, report.schemaVersion)
    assertEquals("shop-wpf-001", report.shopId)
    assertEquals(1L, report.medicineCount)

    // Confirm room_master_table was removed on staged copy
    val verifyDb = SQLiteDatabase.openDatabase(stagedCopy.absolutePath, null, SQLiteDatabase.OPEN_READONLY)
    try {
      verifyDb.rawQuery(
          "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?;",
          arrayOf(OrvaSchemaInteropContract.ROOM_MASTER_TABLE),
        )
        .use { c -> assertFalse("room_master_table must be stripped from portable copy", c.moveToFirst()) }
    } finally {
      verifyDb.close()
    }
  }

  @Test
  fun v1Database_upgradesNonDestructivelyToV3_andPreservesExistingRows() {
    val v1File = newTempDbFile("wpf_v1.sqlite")
    val raw = SQLiteDatabase.openOrCreateDatabase(v1File, null)
    try {
      raw.execSQL("PRAGMA foreign_keys = ON;")
      for (stmt in OrvaSchemaBootstrapper.splitSqlStatements(readAssetSql("001_InitialSchema.sql"))) {
        if (!stmt.startsWith("PRAGMA ", ignoreCase = true)) {
          raw.execSQL(stmt)
        }
      }
      raw.execSQL("PRAGMA user_version = 1;")
      raw.execSQL(
        """
        INSERT INTO medicine(medicine_id, display_name, normalized_name, stock_unit_name, gst_rate_basis_points, created_at_utc, updated_at_utc)
        VALUES ('m-legacy', 'Crocin Advance', 'crocin advance', 'strip', 500, '2025-12-01T00:00:00.0000000Z', '2025-12-01T00:00:00.0000000Z');
        """
      )
    } finally {
      raw.close()
    }

    val provider = OrvaDatabaseProvider(appContext(), v1File, allowMainThreadQueries = true)
    try {
      val db = provider.current()
      assertEquals("3", db.appMetaDao().getValue("schema_version"))
      val med = db.medicineDao().getById("m-legacy")
      assertNotNull("Existing v1 medicine row must survive non-destructive upgrade", med)
      assertEquals("Crocin Advance", med?.displayName)
      assertEquals(0, med?.gstRateConfigured) // default 0 from migration 002
    } finally {
      provider.closeCurrent()
    }
  }

  @Test
  fun futureSchemaV4Database_isRejectedLoudlyWithoutModification() {
    val v4File = newTempDbFile("future_v4.sqlite")
    val raw = SQLiteDatabase.openOrCreateDatabase(v4File, null)
    try {
      raw.execSQL("CREATE TABLE app_meta (meta_key TEXT PRIMARY KEY, meta_value TEXT NOT NULL);")
      raw.execSQL("INSERT INTO app_meta VALUES ('schema_version', '4');")
      raw.execSQL("PRAGMA user_version = 4;")
    } finally {
      raw.close()
    }

    try {
      OrvaSchemaBootstrapper.bootstrapOrMigrate(appContext(), v4File)
      fail("Expected UnsupportedSchemaVersionException for schema version 4")
    } catch (ex: UnsupportedSchemaVersionException) {
      assertEquals(4, ex.foundVersion)
    }
  }
}
