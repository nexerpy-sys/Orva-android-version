package com.rindleworks.orva.ui.about.agentic

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class AgenticJourneyPolicyTest {
  @Test fun `automatic tour starts with automatic build`() {
    val policy = AgenticJourneyPolicy()
    assertEquals(ScrollOwner.AUTO, policy.scrollOwner)
    assertEquals(AgentActivity.BUILD, policy.activity)
  }

  @Test fun `manual vertical gesture takes scroll ownership immediately`() {
    val policy = AgenticJourneyPolicy()
    policy.onManualVerticalGesture()
    assertEquals(ScrollOwner.MANUAL, policy.scrollOwner)
  }

  @Test fun `auto tour can never enter rewind`() {
    val policy = AgenticJourneyPolicy()
    policy.markRewind()
    assertEquals(ScrollOwner.AUTO, policy.scrollOwner)
    assertEquals(AgentActivity.BUILD, policy.activity)
  }

  @Test fun `small deltas accumulate before direction changes`() {
    val policy = AgenticJourneyPolicy(directionThresholdPx = 18f)
    policy.onManualVerticalGesture()
    assertNull(policy.observeManualScrollDelta(-7f))
    assertNull(policy.observeManualScrollDelta(-7f))
    val change = policy.observeManualScrollDelta(-6f)
    assertEquals(ManualScrollDirection.UP, change?.direction)
    assertEquals(AgentActivity.REWIND, policy.activity)
  }

  @Test fun `a new manual gesture cannot reuse an unfinished direction threshold`() {
    val policy = AgenticJourneyPolicy(directionThresholdPx = 18f)
    policy.onManualVerticalGesture()
    assertNull(policy.observeManualScrollDelta(-10f))

    policy.onManualVerticalGesture()
    assertNull(policy.observeManualScrollDelta(-10f))
    assertEquals(AgentActivity.BUILD, policy.activity)
    assertEquals(ManualScrollDirection.UP, policy.observeManualScrollDelta(-8f)?.direction)
  }

  @Test fun `idle reader state clears an unfinished direction threshold`() {
    val policy = AgenticJourneyPolicy(directionThresholdPx = 18f)
    policy.onManualVerticalGesture()
    assertNull(policy.observeManualScrollDelta(-10f))
    policy.markIdle()
    assertNull(policy.observeManualScrollDelta(-10f))
    assertEquals(AgentActivity.IDLE, policy.activity)
    assertEquals(ManualScrollDirection.UP, policy.observeManualScrollDelta(-8f)?.direction)
  }

  @Test fun `a new gesture interrupts rewind classification until its direction is known`() {
    val policy = AgenticJourneyPolicy(directionThresholdPx = 1f)
    policy.onManualVerticalGesture()
    policy.observeManualScrollDelta(-2f)
    assertEquals(AgentActivity.REWIND, policy.activity)

    policy.onManualVerticalGesture()
    assertEquals(AgentActivity.IDLE, policy.activity)
    assertNull(policy.observeManualScrollDelta(0.5f))
    assertEquals(ManualScrollDirection.DOWN, policy.observeManualScrollDelta(1f)?.direction)
  }

  @Test fun `upward movement restocks and downward movement builds`() {
    val policy = AgenticJourneyPolicy(directionThresholdPx = 1f)
    policy.onManualVerticalGesture()
    assertEquals(AgentActivity.REWIND, policy.observeManualScrollDelta(-2f)?.nextActivity)
    assertEquals(AgentActivity.BUILD, policy.observeManualScrollDelta(2f)?.nextActivity)
  }

  @Test fun `horizontal rail cannot change journey policy`() {
    val policy = AgenticJourneyPolicy(directionThresholdPx = 1f)
    assertNull(policy.observeManualScrollDelta(100f))
    assertEquals(ScrollOwner.AUTO, policy.scrollOwner)
    assertEquals(AgentActivity.BUILD, policy.activity)
  }

  @Test fun `disabling and enabling tour updates both legal axes`() {
    val policy = AgenticJourneyPolicy()
    policy.disableTour()
    assertEquals(ScrollOwner.MANUAL, policy.scrollOwner)
    policy.markIdle()
    assertEquals(AgentActivity.IDLE, policy.activity)
    policy.enableTour()
    assertEquals(ScrollOwner.AUTO, policy.scrollOwner)
    assertEquals(AgentActivity.BUILD, policy.activity)
  }
}
