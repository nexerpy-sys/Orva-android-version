package com.rindleworks.orva.service.export

import java.io.ByteArrayOutputStream
import java.io.OutputStream
import java.math.BigDecimal
import java.util.Locale
import java.util.zip.Deflater
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * CSV export helper with exact ORVA WPF parity:
 * - UTF-8 with BOM (EF BB BF) for Excel compatibility.
 * - Spreadsheet formula neutralization: prefixes `'` on leading `=`, `+`, `@`, `\t`, `\r`,
 *   and on leading `-` ONLY when the trimmed text is NOT parseable as a decimal number.
 */
object CsvExportHelper {

  fun neutralizeFormulaCell(raw: String?): String {
    val value = raw.orEmpty()
    if (value.isEmpty()) return ""
    val first = value[0]
    val needsPrefix =
      when (first) {
        '=', '+', '@', '\t', '\r' -> true
        '-' -> !isPlainDecimalNumber(value.trim())
        else -> false
      }
    return if (needsPrefix) "'$value" else value
  }

  private fun isPlainDecimalNumber(trimmed: String): Boolean {
    if (trimmed.length <= 1) return false
    // Must match optional leading '-' followed strictly by digits and optional single decimal point.
    var sawDigit = false
    var sawDot = false
    for (i in 1 until trimmed.length) {
      val c = trimmed[i]
      when {
        c in '0'..'9' -> sawDigit = true
        c == '.' && !sawDot -> sawDot = true
        else -> return false
      }
    }
    if (!sawDigit) return false
    return runCatching { BigDecimal(trimmed) }.isSuccess
  }

  fun escapeCsvField(raw: String?): String {
    val neutralized = neutralizeFormulaCell(raw)
    val needsQuotes =
      neutralized.indexOf(',') >= 0 ||
        neutralized.indexOf('"') >= 0 ||
        neutralized.indexOf('\n') >= 0 ||
        neutralized.indexOf('\r') >= 0
    return if (!needsQuotes) {
      neutralized
    } else {
      "\"${neutralized.replace("\"", "\"\"")}\""
    }
  }

  fun writeCsv(output: OutputStream, headers: List<String>, rows: List<List<String>>) {
    // Write UTF-8 BOM
    output.write(byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()))
    val sb = StringBuilder()
    sb.append(headers.joinToString(",") { escapeCsvField(it) }).append("\r\n")
    for (row in rows) {
      sb.append(row.joinToString(",") { escapeCsvField(it) }).append("\r\n")
    }
    output.write(sb.toString().toByteArray(Charsets.UTF_8))
    output.flush()
  }
}

sealed interface XlsxCell {
  data class Text(val value: String) : XlsxCell
  data class Number(val numericText: String) : XlsxCell
}

/**
 * Zero-dependency minimal valid OOXML (.xlsx) writer producing typed string & numeric worksheets
 * compatible with Microsoft Excel, LibreOffice Calc, and Google Sheets.
 */
object SpreadsheetExportHelper {

  fun writeXlsx(
    output: OutputStream,
    sheetName: String,
    headers: List<String>,
    rows: List<List<XlsxCell>>,
  ) {
    val safeSheetName =
      sheetName.replace(Regex("[\\\\/?*\\[\\]:]"), " ").trim().take(31).ifEmpty { "Report" }

    val sheetXml = buildWorksheetXml(headers, rows)

    ZipOutputStream(output).use { zos ->
      zos.setLevel(Deflater.DEFAULT_COMPRESSION)
      writeEntry(zos, "[Content_Types].xml", CONTENT_TYPES_XML)
      writeEntry(zos, "_rels/.rels", ROOT_RELS_XML)
      writeEntry(zos, "xl/workbook.xml", workbookXml(safeSheetName))
      writeEntry(zos, "xl/_rels/workbook.xml.rels", WORKBOOK_RELS_XML)
      writeEntry(zos, "xl/styles.xml", STYLES_XML)
      writeEntry(zos, "xl/worksheets/sheet1.xml", sheetXml)
      zos.finish()
    }
  }

  private fun buildWorksheetXml(headers: List<String>, rows: List<List<XlsxCell>>): String {
    val sb = StringBuilder(4096)
    sb.append(
      """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<sheetData>
"""
    )

    // Row 1: bold header row (style s="1")
    sb.append("""<row r="1">""")
    headers.forEachIndexed { colIdx, h ->
      val ref = "${colLetters(colIdx)}1"
      val safe = xmlEscape(CsvExportHelper.neutralizeFormulaCell(h))
      sb.append("""<c r="$ref" t="inlineStr" s="1"><is><t>$safe</t></is></c>""")
    }
    sb.append("</row>\n")

    // Data rows starting at row 2
    rows.forEachIndexed { rIdx, row ->
      val excelRow = rIdx + 2
      sb.append("""<row r="$excelRow">""")
      row.forEachIndexed { colIdx, cell ->
        val ref = "${colLetters(colIdx)}$excelRow"
        when (cell) {
          is XlsxCell.Number -> {
            val cleanNum = cell.numericText.trim()
            if (runCatching { BigDecimal(cleanNum) }.isSuccess) {
              sb.append("""<c r="$ref" t="n"><v>$cleanNum</v></c>""")
            } else {
              val safe = xmlEscape(CsvExportHelper.neutralizeFormulaCell(cleanNum))
              sb.append("""<c r="$ref" t="inlineStr"><is><t>$safe</t></is></c>""")
            }
          }
          is XlsxCell.Text -> {
            val safe = xmlEscape(CsvExportHelper.neutralizeFormulaCell(cell.value))
            sb.append("""<c r="$ref" t="inlineStr"><is><t>$safe</t></is></c>""")
          }
        }
      }
      sb.append("</row>\n")
    }

    sb.append("</sheetData>\n</worksheet>")
    return sb.toString()
  }

  private fun colLetters(zeroBasedIndex: Int): String {
    var n = zeroBasedIndex + 1
    val sb = StringBuilder()
    while (n > 0) {
      val rem = (n - 1) % 26
      sb.append(('A'.code + rem).toChar())
      n = (n - 1) / 26
    }
    return sb.reverse().toString()
  }

  private fun xmlEscape(text: String): String {
    val sb = StringBuilder(text.length + 16)
    for (ch in text) {
      when (ch) {
        '&' -> sb.append("&amp;")
        '<' -> sb.append("&lt;")
        '>' -> sb.append("&gt;")
        '"' -> sb.append("&quot;")
        '\'' -> sb.append("&apos;")
        else -> if (ch.code >= 0x20 || ch == '\t' || ch == '\n' || ch == '\r') sb.append(ch)
      }
    }
    return sb.toString()
  }

  private fun writeEntry(zos: ZipOutputStream, name: String, content: String) {
    zos.putNextEntry(ZipEntry(name))
    zos.write(content.toByteArray(Charsets.UTF_8))
    zos.closeEntry()
  }

  private fun workbookXml(sheetName: String): String =
    """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
<sheets><sheet name="${xmlEscape(sheetName)}" sheetId="1" r:id="rId1"/></sheets>
</workbook>"""

  private const val CONTENT_TYPES_XML =
    """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
</Types>"""

  private const val ROOT_RELS_XML =
    """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>"""

  private const val WORKBOOK_RELS_XML =
    """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>"""

  private const val STYLES_XML =
    """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><name val="Calibri"/></font></fonts>
<fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills>
<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>
<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
<cellXfs count="2"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/></cellXfs>
</styleSheet>"""
}

/**
 * Pure, deterministic PDF 1.4 table and document writer with exact xref offsets.
 * Uses standard Type1 Helvetica & Helvetica-Bold fonts so output is 100% portable and
 * verifiable in both Android runtime and JVM/Robolectric tests.
 */
object PdfExportHelper {

  fun writeTabularReportPdf(
    output: OutputStream,
    title: String,
    subtitle: String?,
    headers: List<String>,
    rows: List<List<String>>,
    landscape: Boolean = true,
  ) {
    val pageWidth = if (landscape) 842 else 595
    val pageHeight = if (landscape) 595 else 842
    val margin = 32
    val usableWidth = pageWidth - margin * 2
    val colCount = headers.size.coerceAtLeast(1)
    val colWidth = usableWidth / colCount
    val maxCharsPerCell = (colWidth / 4).coerceAtLeast(10)

    val pageStreams = mutableListOf<String>()
    val rowsPerPage = ((pageHeight - 130) / 16).coerceAtLeast(10)
    val chunks = if (rows.isEmpty()) listOf(emptyList()) else rows.chunked(rowsPerPage)

    chunks.forEachIndexed { pageIdx, chunk ->
      val cs = StringBuilder()
      var y = pageHeight - 38

      // Title
      cs.append(drawText(margin, y, 14, bold = true, text = title))
      y -= 18
      if (!subtitle.isNullOrBlank()) {
        cs.append(drawText(margin, y, 9, bold = false, text = subtitle))
        y -= 14
      }
      cs.append(drawLine(margin, y, pageWidth - margin, y))
      y -= 16

      // Table headers
      headers.forEachIndexed { i, h ->
        val x = margin + i * colWidth
        cs.append(drawText(x, y, 8, bold = true, text = truncate(h, maxCharsPerCell)))
      }
      y -= 6
      cs.append(drawLine(margin, y, pageWidth - margin, y))
      y -= 14

      if (chunk.isEmpty()) {
        cs.append(drawText(margin, y, 9, bold = false, text = "No records found for the selected filter."))
      } else {
        for (row in chunk) {
          row.forEachIndexed { i, cell ->
            val x = margin + i * colWidth
            cs.append(drawText(x, y, 8, bold = false, text = truncate(cell, maxCharsPerCell)))
          }
          y -= 16
        }
      }

      // Page footer
      cs.append(
        drawText(
          margin,
          18,
          8,
          bold = false,
          text = "ORVA by Rindle Works  |  Page ${pageIdx + 1} of ${chunks.size}",
        )
      )
      pageStreams += cs.toString()
    }

    writePdfDocument(output, pageWidth, pageHeight, pageStreams)
  }

  fun writeLinesDocumentPdf(
    output: OutputStream,
    pageWidthPt: Int,
    pageHeightPt: Int,
    lines: List<PdfTextLine>,
    marginPt: Int = 24,
  ) {
    val pageStreams = mutableListOf<String>()
    var cs = StringBuilder()
    var y = pageHeightPt - marginPt - 12

    for (line in lines) {
      val lineStep = (line.fontSizePt + 5).coerceAtLeast(10)
      if (y < marginPt + 16) {
        pageStreams += cs.toString()
        cs = StringBuilder()
        y = pageHeightPt - marginPt - 12
      }
      if (line.isRule) {
        cs.append(drawLine(marginPt, y + 3, pageWidthPt - marginPt, y + 3))
      } else {
        cs.append(drawText(marginPt, y, line.fontSizePt, line.bold, line.text))
      }
      y -= lineStep
    }
    pageStreams += cs.toString()
    writePdfDocument(output, pageWidthPt, pageHeightPt, pageStreams)
  }

  data class PdfTextLine(
    val text: String,
    val fontSizePt: Int = 9,
    val bold: Boolean = false,
    val isRule: Boolean = false,
  )

  private fun writePdfDocument(
    output: OutputStream,
    pageWidth: Int,
    pageHeight: Int,
    pageStreams: List<String>,
  ) {
    val baos = ByteArrayOutputStream()
    val offsets = mutableListOf<Int>()

    fun writeRaw(s: String) = baos.write(s.toByteArray(Charsets.ISO_8859_1))

    writeRaw("%PDF-1.4\n")

    // Obj 1: Catalog, Obj 2: Pages, Obj 3: Helvetica, Obj 4: Helvetica-Bold
    // Page objects start at 5: each page uses 2 objects (Page, ContentStream)
    val pageCount = pageStreams.size
    val pageObjectIds = (0 until pageCount).map { 5 + it * 2 }

    fun beginObj(id: Int) {
      offsets += baos.size()
      writeRaw("$id 0 obj\n")
    }

    beginObj(1)
    writeRaw("<< /Type /Catalog /Pages 2 0 R >>\nendobj\n")

    beginObj(2)
    val kids = pageObjectIds.joinToString(" ") { "$it 0 R" }
    writeRaw("<< /Type /Pages /Kids [ $kids ] /Count $pageCount >>\nendobj\n")

    beginObj(3)
    writeRaw("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>\nendobj\n")

    beginObj(4)
    writeRaw("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>\nendobj\n")

    pageStreams.forEachIndexed { idx, streamContent ->
      val pageObjId = 5 + idx * 2
      val contentObjId = pageObjId + 1
      val streamBytes = streamContent.toByteArray(Charsets.ISO_8859_1)

      beginObj(pageObjId)
      writeRaw(
        "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 $pageWidth $pageHeight] " +
          "/Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents $contentObjId 0 R >>\nendobj\n"
      )

      beginObj(contentObjId)
      writeRaw("<< /Length ${streamBytes.size} >>\nstream\n")
      baos.write(streamBytes)
      writeRaw("\nendstream\nendobj\n")
    }

    val xrefOffset = baos.size()
    val totalObjects = offsets.size + 1
    writeRaw("xref\n0 $totalObjects\n")
    writeRaw("0000000000 65535 f \n")
    for (off in offsets) {
      writeRaw(String.format(Locale.ROOT, "%010d 00000 n \n", off))
    }
    writeRaw("trailer\n<< /Size $totalObjects /Root 1 0 R >>\nstartxref\n$xrefOffset\n%%EOF\n")

    output.write(baos.toByteArray())
    output.flush()
  }

  private fun drawText(x: Int, y: Int, fontSize: Int, bold: Boolean, text: String): String {
    val fontKey = if (bold) "F2" else "F1"
    val escaped = sanitizePdfAscii(text)
    return "BT /$fontKey $fontSize Tf 1 0 0 1 $x $y Tm ($escaped) Tj ET\n"
  }

  private fun drawLine(x1: Int, y1: Int, x2: Int, y2: Int): String =
    "0.5 w $x1 $y1 m $x2 $y2 l S\n"

  private fun truncate(text: String, maxChars: Int): String =
    if (text.length <= maxChars) text else text.take((maxChars - 2).coerceAtLeast(1)) + ".."

  private fun sanitizePdfAscii(raw: String): String {
    val normalized = raw.replace("₹", "Rs.")
    val sb = StringBuilder(normalized.length + 8)
    for (ch in normalized) {
      val safeChar = if (ch.code in 32..126) ch else '?'
      when (safeChar) {
        '\\' -> sb.append("\\\\")
        '(' -> sb.append("\\(")
        ')' -> sb.append("\\)")
        else -> sb.append(safeChar)
      }
    }
    return sb.toString()
  }
}
