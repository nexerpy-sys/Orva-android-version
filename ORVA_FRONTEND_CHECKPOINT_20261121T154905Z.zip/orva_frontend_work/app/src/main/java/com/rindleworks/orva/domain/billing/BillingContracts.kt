package com.rindleworks.orva.domain.billing

import com.rindleworks.orva.domain.settings.ShopProfile
import java.io.OutputStream

// Shared, frozen boundary between the ORVA billing engine and the Compose billing UI.
// Preserves exact WPF BillingContracts.cs & InvoicePaperFormat.cs wire/persisted mappings.

enum class InvoicePaymentMethod(val wireValue: Int, val dbValue: String) {
  Cash(1, "CASH"),
  Upi(2, "UPI"),
  DebitCard(3, "DEBIT_CARD"),
  CreditCard(4, "CREDIT_CARD");

  companion object {
    fun fromDbValue(raw: String?): InvoicePaymentMethod? =
      entries.firstOrNull { it.dbValue.equals(raw?.trim(), ignoreCase = true) }
  }
}

enum class BillingIssueSeverity(val wireValue: Int) {
  Information(1),
  Warning(2),
  Blocking(3),
}

enum class InvoicePaperFormat(val wireValue: Int, val persistedKey: String) {
  Thermal58(1, "Thermal58"),
  Thermal80(2, "Thermal80"),
  A4(3, "A4"),
  A5(4, "A5");

  companion object {
    fun fromPersistedKey(raw: String?): InvoicePaperFormat =
      entries.firstOrNull { it.persistedKey.equals(raw?.trim(), ignoreCase = true) }
        ?: Thermal80
  }
}

object BillingIssueCodes {
  const val DRAFT_EMPTY = "DRAFT_EMPTY"
  const val INVALID_ITEM = "INVALID_ITEM"
  const val INVALID_QUANTITY = "INVALID_QUANTITY"
  const val QUANTITY_OVERFLOW = "QUANTITY_OVERFLOW"
  const val MEDICINE_NOT_FOUND = "MEDICINE_NOT_FOUND"
  const val MEDICINE_INACTIVE = "MEDICINE_INACTIVE"
  const val INSUFFICIENT_STOCK = "INSUFFICIENT_STOCK"
  const val SHOP_PROFILE_MISSING = "SHOP_PROFILE_MISSING"
  const val TAX_CONFIG_MISSING = "TAX_CONFIG_MISSING"
  const val MEDICINE_TAX_NOT_CONFIGURED = "MEDICINE_TAX_NOT_CONFIGURED"
  const val CUSTOMER_GSTIN_INVALID = "CUSTOMER_GSTIN_INVALID"
  const val INVALID_PAYMENT_METHOD = "INVALID_PAYMENT_METHOD"
  const val INVALID_PAYMENT_AMOUNT = "INVALID_PAYMENT_AMOUNT"
  const val PAYMENT_SHORT = "PAYMENT_SHORT"
  const val PAYMENT_OVERPAID = "PAYMENT_OVERPAID"
  const val CALCULATION_OVERFLOW = "CALCULATION_OVERFLOW"
  const val SHOP_STATE_CODE_MISSING = "SHOP_STATE_CODE_MISSING"
  const val PLACE_OF_SUPPLY_REQUIRES_REVIEW = "PLACE_OF_SUPPLY_REQUIRES_REVIEW"
  const val INVOICE_PREFIX_INVALID = "INVOICE_PREFIX_INVALID"
}

data class InvoiceDraft(
  val items: List<InvoiceItemDraft> = emptyList(),
  val tenders: List<PaymentTenderDraft> = emptyList(),
  val customer: InvoiceCustomerDraft = InvoiceCustomerDraft(),
)

data class InvoiceItemDraft(
  val medicineId: String,
  val quantityMilli: Long,
)

data class PaymentTenderDraft(
  val method: InvoicePaymentMethod,
  val amountPaise: Long,
  val referenceText: String? = null,
)

data class InvoiceCustomerDraft(
  val name: String? = null,
  val phone: String? = null,
  val address: String? = null,
  val gstin: String? = null,
)

data class MedicineLookupResult(
  val medicineId: String,
  val displayName: String,
  val genericName: String?,
  val brandName: String?,
  val strength: String?,
  val dosageForm: String?,
  val stockUnitName: String,
  val availableQuantityMilli: Long,
  val lowStockThresholdMilli: Long,
  val isLowStock: Boolean,
  val canSell: Boolean,
  val availabilityMessage: String,
)

data class BatchAllocationPreview(
  val batchNumber: String,
  val expiryYyyyMm: Int,
  val quantityMilli: Long,
  val unitPricePaise: Long,
  val subtotalPaise: Long,
  val taxableValuePaise: Long,
  val cgstPaise: Long,
  val sgstPaise: Long,
  val igstPaise: Long,
  val lineTotalPaise: Long,
)

data class InvoiceLinePreview(
  val medicineId: String,
  val medicineName: String,
  val quantityMilli: Long,
  val stockUnitName: String,
  val batchAllocations: List<BatchAllocationPreview>,
  val subtotalPaise: Long,
  val taxableValuePaise: Long,
  val cgstPaise: Long,
  val sgstPaise: Long,
  val igstPaise: Long,
  val lineTotalPaise: Long,
)

data class BillingIssue(
  val severity: BillingIssueSeverity,
  val code: String,
  val message: String,
  val medicineId: String? = null,
)

data class InvoicePreviewResult(
  val isDraftValid: Boolean,
  val canFinalize: Boolean,
  val lines: List<InvoiceLinePreview> = emptyList(),
  val issues: List<BillingIssue> = emptyList(),
  val subtotalPaise: Long = 0L,
  val discountPaise: Long = 0L, // Always 0L in V1
  val taxableValuePaise: Long = 0L,
  val cgstPaise: Long = 0L,
  val sgstPaise: Long = 0L,
  val igstPaise: Long = 0L,
  val roundOffPaise: Long = 0L,
  val grandTotalPaise: Long = 0L,
  val tenderTotalPaise: Long = 0L,
  val amountRemainingPaise: Long = 0L,
  val isFullyPaid: Boolean = false,
)

data class InvoiceResult(
  val succeeded: Boolean,
  val invoiceId: String? = null,
  val invoiceNumber: String? = null,
  val issuedAtUtc: String? = null,
  val issuedLocalOffsetMinutes: Int = 0,
  val grandTotalPaise: Long = 0L,
  val issues: List<BillingIssue> = emptyList(),
  val warnings: List<String> = emptyList(),
)

data class InvoicePrintRequest(
  val committedInvoice: InvoiceResult,
  val preview: InvoicePreviewResult,
  val shopProfile: ShopProfile,
  val customer: InvoiceCustomerDraft,
  val tenders: List<PaymentTenderDraft>,
  val paperFormat: InvoicePaperFormat,
)

data class InvoicePrintResult(
  val printed: Boolean,
  val cancelledByUser: Boolean = false,
  val printerName: String? = null,
  val errorMessage: String? = null,
)

/**
 * Hardware-agnostic ESC/POS byte transport implemented in Stage 6 for Bluetooth SPP
 * and USB-OTG thermal printers (58mm / 80mm).
 */
interface ThermalPrinterTransport {
  val displayName: String
  suspend fun write(bytes: ByteArray): Result<Unit>
}

interface BillingService {
  suspend fun searchMedicines(query: String, maximumResults: Int = 25): List<MedicineLookupResult>
  suspend fun previewInvoice(draft: InvoiceDraft): InvoicePreviewResult
  suspend fun finalizeInvoice(draft: InvoiceDraft): InvoiceResult
}

interface InvoicePrintService {
  suspend fun getDefaultPaperFormat(): InvoicePaperFormat
  suspend fun setDefaultPaperFormat(format: InvoicePaperFormat)
  suspend fun getLastPrinterName(): String
  suspend fun renderInvoicePdf(request: InvoicePrintRequest, output: OutputStream)
  suspend fun printViaThermalTransport(
    request: InvoicePrintRequest,
    transport: ThermalPrinterTransport,
  ): InvoicePrintResult
}
