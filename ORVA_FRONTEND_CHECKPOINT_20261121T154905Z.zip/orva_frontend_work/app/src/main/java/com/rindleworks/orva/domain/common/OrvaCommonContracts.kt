package com.rindleworks.orva.domain.common

import java.math.BigDecimal
import java.math.RoundingMode
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.time.Instant
import java.time.LocalDateTime
import java.time.OffsetDateTime
import java.time.ZoneId
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlinx.coroutines.flow.StateFlow

/**
 * Shared schema & interoperability contract constants for Stage 2 Room adoption.
 *
 * Stage 2 Room Expression-Index & Interop Plan:
 * 1. Fresh Android DBs are bootstrapped from verbatim WPF SQL migrations (001 -> 002 -> 003)
 *    via OrvaSchemaBootstrapper before Room opens, preserving all 18 tables, 30+ CHECK constraints,
 *    15 indexes (including expression unique index ux_batch_normalized_identity), PRAGMA user_version = 3,
 *    and app_meta.schema_version = '3'.
 * 2. Room entities declare exact WPF column types, nullability, foreign keys, defaultValue literals,
 *    and all 14 standard indexes + stock_batch composite unique index so Room's onValidateSchema(db)
 *    succeeds cleanly on WPF-created v3 databases where room_master_table is absent.
 * 3. Expression index ux_batch_normalized_identity (medicine_id, UPPER(TRIM(batch_number)), expiry_yyyymm)
 *    is created/verified by OrvaSchemaBootstrapper; SQLite PRAGMA index_xinfo reports cid=-2/name=null
 *    for expression columns, which Room TableInfo.readIndex skips during validation without error.
 * 4. Destructive migrations are forbidden. On .shopbackup export, room_master_table is dropped on
 *    the staged backup copy only (never on the live Room DB) for pure Android -> WPF compatibility.
 */
object OrvaSchemaInteropContract {
  const val CURRENT_SCHEMA_VERSION: Int = 3
  const val EXPRESSION_BATCH_UNIQUE_INDEX: String = "ux_batch_normalized_identity"
  const val ROOM_MASTER_TABLE: String = "room_master_table"
  const val BACKUP_FORMAT_NAME: String = "ORVA_SHOP_BACKUP"
  const val BACKUP_FORMAT_VERSION: Int = 1
  const val STOCK_DATA_FORMAT_NAME: String = "ORVA_STOCK_DATA"
  const val STOCK_DATA_FORMAT_VERSION: Int = 2
}

/** Exact persisted app_setting keys matching ORVA WPF Stage 5.6.0. */
object OrvaSettingKeys {
  // Billing / Tax
  const val TAX_CONFIGURED = "billing.tax_configured"
  const val TAX_PRICING_MODE = "billing.tax_pricing_mode"
  const val DEFAULT_SUPPLY_TYPE = "billing.default_supply_type"
  const val ROUND_OFF_MODE = "billing.round_off_mode"

  // Stock Snapshot
  const val SNAPSHOT_DIRTY = "stock_snapshot_dirty"
  const val SNAPSHOT_GENERATION = "stock_snapshot_generation"
  const val SNAPSHOT_LAST_WRITTEN_UTC = "stock_snapshot_last_written_at_utc"

  // Sales Return Sequence Prefix (suffixed with Financial Year label, e.g. return_seq_26-27)
  const val RETURN_SEQUENCE_PREFIX = "return_seq_"

  // Backup
  const val BACKUP_LAST_SUCCESS_UTC = "backup.last_success_utc"
  const val BACKUP_LAST_SUCCESS_LOCAL_DATE = "backup.last_success_local_date"
  const val BACKUP_LAST_PATH = "backup.last_path"
  const val BACKUP_LAST_ERROR = "backup.last_error"
  const val BACKUP_RETENTION_DAYS = "backup.retention_days"

  // Printing & Localization
  const val DEFAULT_PAPER_FORMAT = "printing.default_paper_format"
  const val LAST_PRINTER_NAME = "printing.last_printer_name"
  const val DISPLAY_LANGUAGE = "display_language"

  // Subscription & Support (zero hardcoded commercial prices)
  const val SUBSCRIPTION_REGISTRY_URL = "subscription.registry_csv_url"
  const val SUBSCRIPTION_USERNAME = "subscription.username"
  const val SUBSCRIPTION_ACTIVATION_CODE = "subscription.activation_code"
  const val SUBSCRIPTION_CACHED_PLAN = "subscription.cached_plan"
  const val SUBSCRIPTION_CACHED_START = "subscription.cached_start"
  const val SUBSCRIPTION_CACHED_EXPIRY = "subscription.cached_expiry"
  const val SUBSCRIPTION_CACHED_STATUS = "subscription.cached_status"
  const val SUBSCRIPTION_LAST_VERIFIED_UTC = "subscription.last_verified_utc"
  const val SUBSCRIPTION_LAST_SEEN_UTC = "subscription.last_seen_utc"
  const val SUPPORT_PHONES = "subscription.support_phones"
  const val SUPPORT_WHATSAPP = "subscription.support_whatsapp"
  const val SUPPORT_EMAIL = "support.email"
  const val UPI_ID = "subscription.upi_id"
  const val UPI_PAYEE_NAME = "subscription.upi_payee_name"
  const val PRICE_MONTHLY = "subscription.price_monthly"
  const val PRICE_QUARTERLY = "subscription.price_quarterly"
  const val PRICE_ANNUAL = "subscription.price_annual"
  const val PRICE_ONETIME = "subscription.price_onetime"
}

enum class InvoiceStatus(val dbValue: String) {
  Issued("ISSUED"),
  Cancelled("CANCELLED"),
  CreditNoteIssued("CREDIT_NOTE_ISSUED");

  companion object {
    fun fromDbValue(raw: String?): InvoiceStatus? =
      entries.firstOrNull { it.dbValue.equals(raw?.trim(), ignoreCase = true) }
  }
}

enum class StockMovementType(val dbValue: String) {
  Opening("OPENING"),
  Purchase("PURCHASE"),
  Sale("SALE"),
  SaleReturnRestock("SALE_RETURN_RESTOCK"),
  Damage("DAMAGE"),
  ExpiryWriteOff("EXPIRY_WRITE_OFF"),
  Adjustment("ADJUSTMENT"),
  Import("IMPORT");

  companion object {
    fun fromDbValue(raw: String?): StockMovementType? =
      entries.firstOrNull { it.dbValue.equals(raw?.trim(), ignoreCase = true) }
  }
}

/** Read-only metadata exposed to independent frontend screens (e.g. Home / About Us). */
data class AppVersionInfo(
  val applicationName: String = "ORVA",
  val publisherName: String = "Rindle Works",
  val versionName: String,
  val versionCode: Int,
  val databaseSchemaVersion: Int = OrvaSchemaInteropContract.CURRENT_SCHEMA_VERSION,
)

/** Emits monotonic increments whenever the active database is replaced (e.g. after restore). */
interface OrvaDatabaseSignal {
  val databaseGeneration: StateFlow<Long>
}

/**
 * Exact WPF-compatible date/time serialization helpers using desugared java.time.
 * UTC timestamps use fixed 7-digit fractional seconds (.NET round-trip "o" format)
 * so SQLite lexicographical range filters behave identically across WPF and Android.
 */
object OrvaDateTimeFormatters {
  private val utcRoundTripFormatter: DateTimeFormatter =
    DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSSSSS'Z'", Locale.ROOT)
      .withZone(ZoneOffset.UTC)

  private val localLogFormatter: DateTimeFormatter =
    DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss", Locale.ROOT)

  private val registerDisplayFormatter: DateTimeFormatter =
    DateTimeFormatter.ofPattern("dd MMM yyyy, hh:mm a", Locale.ENGLISH)

  fun formatUtcRoundTrip(instant: Instant): String = utcRoundTripFormatter.format(instant)

  fun formatLocalLogText(localDateTime: LocalDateTime): String =
    localLogFormatter.format(localDateTime)

  fun parseUtcInstant(raw: String?): Instant? {
    val trimmed = raw?.trim().orEmpty()
    if (trimmed.isEmpty()) return null
    return runCatching { Instant.parse(trimmed) }
      .recoverCatching { OffsetDateTime.parse(trimmed).toInstant() }
      .getOrNull()
  }

  fun formatUtcToLocalDisplay(utcIso: String?, zoneId: ZoneId = ZoneId.systemDefault()): String {
    val instant = parseUtcInstant(utcIso) ?: return utcIso.orEmpty()
    return registerDisplayFormatter.format(instant.atZone(zoneId))
  }
}

/** Pure base-10 integer-unit formatting and parsing helpers (zero binary floating-point). */
object OrvaFormatters {
  const val PAISE_PER_RUPEE: Long = 100L
  const val QUANTITY_SCALE: Long = 1000L
  const val BASIS_POINTS_PER_PERCENT: Long = 100L

  private val rupeeDivisor = BigDecimal.valueOf(PAISE_PER_RUPEE)
  private val quantityDivisor = BigDecimal.valueOf(QUANTITY_SCALE)
  private val percentDivisor = BigDecimal.valueOf(BASIS_POINTS_PER_PERCENT)

  fun formatRupees(paise: Long): String {
    val negative = paise < 0L
    val absPaise = if (paise == Long.MIN_VALUE) {
      BigDecimal.valueOf(paise).abs()
    } else {
      BigDecimal.valueOf(kotlin.math.abs(paise))
    }
    val majorMinor = absPaise.divideAndRemainder(rupeeDivisor)
    val whole = majorMinor[0].toPlainString()
    val fractional = majorMinor[1].toInt().toString().padStart(2, '0')
    val groupedWhole = formatIndianGrouping(whole)
    return if (negative) "-$groupedWhole.$fractional" else "$groupedWhole.$fractional"
  }

  fun formatQuantity(quantityMilli: Long): String {
    val value = BigDecimal.valueOf(quantityMilli)
      .divide(quantityDivisor, 3, RoundingMode.UNNECESSARY)
      .stripTrailingZeros()
    return if (value.compareTo(BigDecimal.ZERO) == 0) "0" else value.toPlainString()
  }

  fun formatExpiry(expiryYyyyMm: Int): String {
    val year = expiryYyyyMm / 100
    val month = kotlin.math.abs(expiryYyyyMm % 100)
    return String.format(Locale.ROOT, "%04d-%02d", year, month)
  }

  fun formatGstPercent(basisPoints: Int): String {
    val percent = BigDecimal.valueOf(basisPoints.toLong())
      .divide(percentDivisor, 2, RoundingMode.UNNECESSARY)
      .stripTrailingZeros()
    val text = if (percent.compareTo(BigDecimal.ZERO) == 0) "0" else percent.toPlainString()
    return "$text%"
  }

  fun parseRupeesToPaise(input: String): Long? {
    val cleaned = input.trim().replace(",", "")
    if (cleaned.isEmpty()) return null
    val decimal = runCatching { BigDecimal(cleaned) }.getOrNull() ?: return null
    if (decimal < BigDecimal.ZERO) return null
    val scaled = decimal.multiply(rupeeDivisor)
    if (scaled.stripTrailingZeros().scale() > 0) return null
    return runCatching { scaled.longValueExact() }.getOrNull()
  }

  fun parseQuantityToMilli(input: String): Long? {
    val cleaned = input.trim().replace(",", "")
    if (cleaned.isEmpty()) return null
    val decimal = runCatching { BigDecimal(cleaned) }.getOrNull() ?: return null
    if (decimal < BigDecimal.ZERO) return null
    val scaled = decimal.multiply(quantityDivisor)
    if (scaled.stripTrailingZeros().scale() > 0) return null
    return runCatching { scaled.longValueExact() }.getOrNull()
  }

  private fun formatIndianGrouping(digits: String): String {
    if (digits.length <= 3) return digits
    val lastThree = digits.takeLast(3)
    val prefix = digits.dropLast(3)
    val sb = StringBuilder(digits.length + digits.length / 2)
    val rem = prefix.length % 2
    if (rem > 0) {
      sb.append(prefix.substring(0, rem))
      if (prefix.length > rem) sb.append(',')
    }
    var i = rem
    while (i < prefix.length) {
      if (i > rem) sb.append(',')
      sb.append(prefix.substring(i, i + 2))
      i += 2
    }
    sb.append(',').append(lastThree)
    return sb.toString()
  }

  @Suppress("unused")
  private fun invariantSymbols(): DecimalFormatSymbols = DecimalFormatSymbols(Locale.ROOT)

  @Suppress("unused")
  private fun invariantDecimalFormat(pattern: String): DecimalFormat =
    DecimalFormat(pattern, invariantSymbols())
}
