package com.rindleworks.orva.domain.returns

import com.rindleworks.orva.domain.inventory.BatchStatus

enum class SalesRefundMethod(val dbValue: String) {
  Cash("CASH"),
  Upi("UPI"),
  DebitCard("DEBIT_CARD"),
  CreditCard("CREDIT_CARD"),
  Adjustment("ADJUSTMENT");

  companion object {
    fun fromDbValue(raw: String?): SalesRefundMethod? =
      entries.firstOrNull { it.dbValue.equals(raw?.trim(), ignoreCase = true) }
  }
}

enum class ResaleDisposition(val dbValue: String) {
  Quarantine("QUARANTINE"), // Default — never silently re-enters sellable FEFO stock
  Restock("RESTOCK"),
  Damaged("DAMAGED"),
  Expired("EXPIRED");

  companion object {
    fun fromDbValue(raw: String?): ResaleDisposition? =
      entries.firstOrNull { it.dbValue.equals(raw?.trim(), ignoreCase = true) }
  }
}

data class ReturnableInvoiceSummary(
  val invoiceId: String,
  val invoiceNumber: String,
  val issuedAtUtc: String,
  val issuedDateText: String,
  val customerName: String,
  val grandTotalPaise: Long,
  val status: String,
)

data class ReturnableInvoiceLine(
  val invoiceLineId: String,
  val medicineId: String,
  val batchId: String,
  val medicineName: String,
  val batchNumber: String,
  val expiryYyyyMm: Int,
  val stockUnitName: String,
  val originalQuantityMilli: Long,
  val alreadyReturnedMilli: Long,
  val remainingReturnableMilli: Long,
  val unitPricePaise: Long,
  val originalLineTotalPaise: Long,
  val alreadyRefundedPaise: Long,
  val remainingRefundablePaise: Long,
  val batchStatus: BatchStatus,
  val gstRateBasisPoints: Int,
  val hsnCode: String?,
)

data class SalesReturnLineRequest(
  val invoiceLineId: String,
  val returnQuantityMilli: Long,
  val resaleDisposition: ResaleDisposition = ResaleDisposition.Quarantine,
)

data class SalesReturnRequest(
  val invoiceId: String,
  val reason: String,
  val refundMethod: SalesRefundMethod,
  val lines: List<SalesReturnLineRequest>,
)

data class SalesReturnPreviewResult(
  val canFinalize: Boolean,
  val totalRefundPaise: Long = 0L,
  val quarantinedLineCount: Int = 0,
  val restockedLineCount: Int = 0,
  val errors: List<String> = emptyList(),
)

data class SalesReturnResult(
  val succeeded: Boolean,
  val returnId: String? = null,
  val returnNumber: String? = null,
  val refundAmountPaise: Long = 0L,
  val returnedAtUtc: String? = null,
  val snapshotRefreshed: Boolean = false,
  val snapshotWarning: String? = null,
  val errorMessage: String? = null,
)

data class InvoiceCancellationResult(
  val succeeded: Boolean,
  val invoiceNumber: String? = null,
  val stockRestored: Boolean = false,
  val snapshotRefreshed: Boolean = false,
  val snapshotWarning: String? = null,
  val stockWarning: String? = null,
  val errorMessage: String? = null,
)

interface SalesReturnService {
  suspend fun searchReturnableInvoices(query: String, limit: Int = 30): List<ReturnableInvoiceSummary>
  suspend fun getReturnableLines(invoiceId: String): List<ReturnableInvoiceLine>
  suspend fun previewReturn(request: SalesReturnRequest): SalesReturnPreviewResult
  suspend fun finalizeReturn(request: SalesReturnRequest): SalesReturnResult
}

interface InvoiceCancellationService {
  suspend fun cancelInvoice(
    invoiceId: String,
    reason: String,
    restoreStock: Boolean = true,
  ): InvoiceCancellationResult
}
