package com.rindleworks.orva.ui.about.agentic

import kotlin.math.abs

/**
 * Five specialized roles across the 16-agent About Us construction roster.
 */
enum class AgentRole {
  LAYOUT_ARCHITECT,
  COMPONENT_DUPLICATOR,
  TYPOGRAPHER,
  ART_DIRECTOR,
  IDLE_SCOUT,
}

enum class LayerKind {
  CONTAINER,
  MEDIA,
  TEXT,
  LINE,
}

enum class LayerPhase {
  HIDDEN,
  BUILDING,
  CLONED_MASTER_TEXT,
  REVEALED,
  REVERSING,
}

enum class TaskDirection { DISPENSE, RESTOCK }

sealed interface SceneBuildEvent {
  data class Sealed(val sceneIndex: Int) : SceneBuildEvent
  data class Unsealed(val sceneIndex: Int) : SceneBuildEvent
  /** A grace-window restore: restore the stamp without replaying its entrance or haptic. */
  data class Restored(val sceneIndex: Int) : SceneBuildEvent
}

enum class BuildAct {
  ORBITAL_SCAN,
  STRUCTURAL_BUILD,
  SCROLL_ASSEMBLY,
  CONVERGENCE,
  COMPLETED,
}

/** Platform-independent rectangle in unified root/content coordinates (pixels). */
data class SceneBounds(
  val left: Float,
  val top: Float,
  val right: Float,
  val bottom: Float,
) {
  val width: Float get() = (right - left).coerceAtLeast(0f)
  val height: Float get() = (bottom - top).coerceAtLeast(0f)
  val centerX: Float get() = (left + right) * 0.5f
  val centerY: Float get() = (top + bottom) * 0.5f
  val isValid: Boolean get() = width > 0.5f && height > 0.5f

  fun intersectsVerticalWindow(windowTop: Float, windowBottom: Float): Boolean =
    isValid && bottom >= windowTop && top <= windowBottom

  companion object {
    val Empty = SceneBounds(0f, 0f, 0f, 0f)
  }
}

/**
 * Node registered by an actual Compose composable inside the About Us component tree.
 */
data class RegisteredSceneNode(
  val id: String,
  val kind: LayerKind,
  val orderIndex: Int,
  val parentId: String? = null,
  val cloneGroupId: String? = null,
  val cloneIndex: Int = 0, // 0 = Master, >0 = Alt-Drag Clone sibling
  val bounds: SceneBounds = SceneBounds.Empty,
  val phase: LayerPhase = LayerPhase.HIDDEN,
  val claimedByAgentId: Int? = null,
  val boundsGeneration: Int = 0,
  val sceneIndex: Int? = null,
  /** Optional visual-morph scope; defaults to the containing About scene. */
  val morphRegionId: String? = null,
  val completionSequence: Long? = null,
  val reversedAtMs: Long? = null,
  val reversedCompletionSequence: Long? = null,
)

data class AgentTaskClaim(
  val agentId: Int,
  val role: AgentRole,
  val nodeId: String,
  val kind: LayerKind,
  val isCloneFromMaster: Boolean,
  val masterNodeId: String?,
  val boundsGeneration: Int,
  val direction: TaskDirection = TaskDirection.DISPENSE,
  val claimedAtMs: Long = 0L,
)

/**
 * Pure-Kotlin deterministic DAG task scheduler for ORVA's About Us Agentic Build experience.
 *
 * Enforced invariants:
 * 1. Parent-before-child ordering (`parentId` MUST be `REVEALED` before any child is eligible).
 * 2. Master-before-clone ordering (`cloneIndex == 0` MUST be `REVEALED` before `cloneIndex > 0` in the same `cloneGroupId`).
 * 3. Bounded concurrency: maximum [maxConcurrentBuilders] (default 8) active builders out of [totalAgents] (default 16).
 * 4. Viewport + prefetch gating so off-screen sections wait until scrolled/toured into range.
 * 5. Atomic claim / commit / release semantics so cancellation restores tasks cleanly without stranding.
 * 6. Responsive layout resize invalidation clears stale geometry and pending claims safely.
 * 7. Deterministic ordering (top-to-bottom + registration `orderIndex`) so Replay reproduces the same choreography.
 */
class AgentTaskScheduler(
  val totalAgents: Int = 16,
  val maxConcurrentBuilders: Int = 8,
  val prefetchMarginPx: Float = 260f,
) {
  private val nodes = LinkedHashMap<String, RegisteredSceneNode>()
  private val activeClaimsByAgent = LinkedHashMap<Int, AgentTaskClaim>()
  private var nextOrderCounter = 0
  private var currentBoundsGeneration = 0
  private var lastViewportWidthPx: Float = -1f
  private var lastViewportHeightPx: Float = -1f
  private var lastDensityScale: Float = -1f
  private var dependencyGraphVersion = 0L
  private var validatedGraphVersion = -1L
  private var cachedGraphIssues: List<String> = emptyList()
  private var completionSequence = 0L
  private val sealedScenes = linkedSetOf<Int>()
  private val pendingSceneEvents = mutableListOf<SceneBuildEvent>()

  @Synchronized
  fun registerOrUpdateNode(
    id: String,
    kind: LayerKind,
    parentId: String? = null,
    cloneGroupId: String? = null,
    cloneIndex: Int = 0,
    bounds: SceneBounds,
    sceneIndex: Int? = null,
    morphRegionId: String? = null,
  ) {
    val existing = nodes[id]
    val parentChanged = existing != null && existing.parentId != parentId
    val resolvedSceneIndex = sceneIndex ?: inferSceneIndex(id) ?: parentId?.let { nodes[it]?.sceneIndex }
    val resolvedMorphRegionId = morphRegionId ?: inferMorphRegionId(id)
      ?: parentId?.let { nodes[it]?.morphRegionId }
      ?: resolvedSceneIndex?.let(::defaultMorphRegionId)
    if (existing == null) {
      dependencyGraphVersion++
      nodes[id] =
        RegisteredSceneNode(
          id = id,
          kind = kind,
          orderIndex = nextOrderCounter++,
          parentId = parentId,
          cloneGroupId = cloneGroupId,
          cloneIndex = cloneIndex,
          bounds = bounds,
          phase = LayerPhase.HIDDEN,
          claimedByAgentId = null,
          boundsGeneration = currentBoundsGeneration,
          completionSequence = null,
          reversedAtMs = null,
          reversedCompletionSequence = null,
          sceneIndex = resolvedSceneIndex,
          morphRegionId = resolvedMorphRegionId,
        )
    } else {
      if (existing.parentId != parentId ||
        existing.cloneGroupId != cloneGroupId ||
        existing.cloneIndex != cloneIndex ||
        existing.morphRegionId != resolvedMorphRegionId
      ) {
        dependencyGraphVersion++
      }
      val movedSignificantly =
        abs(existing.bounds.left - bounds.left) > 4f ||
          abs(existing.bounds.top - bounds.top) > 4f ||
          abs(existing.bounds.width - bounds.width) > 4f ||
          abs(existing.bounds.height - bounds.height) > 4f
      nodes[id] =
        existing.copy(
          parentId = parentId,
          cloneGroupId = cloneGroupId,
          cloneIndex = cloneIndex,
          bounds = bounds,
          sceneIndex = resolvedSceneIndex ?: if (parentChanged) null else existing.sceneIndex,
          morphRegionId = resolvedMorphRegionId ?: if (parentChanged) null else existing.morphRegionId,
          // Node-local version: a significant re-measure invalidates only this node's old claim.
          // A viewport epoch also forces stale nodes to adopt the new global baseline.
          boundsGeneration =
            when {
              existing.boundsGeneration < currentBoundsGeneration -> currentBoundsGeneration
              movedSignificantly -> existing.boundsGeneration + 1
              else -> existing.boundsGeneration
            },
        )
    }
    if (existing == null || parentChanged || sceneIndex != null || morphRegionId != null) {
      propagateInheritedSceneIndices()
      propagateInheritedMorphRegionIds()
    }
  }

  /** Fills scene IDs that were missing only because Compose registered descendants first. */
  private fun propagateInheritedSceneIndices() {
    var changed: Boolean
    do {
      changed = false
      nodes.values.toList().forEach { node ->
        if (node.sceneIndex == null) {
          val inherited = node.parentId?.let { nodes[it]?.sceneIndex }
          if (inherited != null) {
            nodes[node.id] = node.copy(sceneIndex = inherited)
            changed = true
          }
        }
      }
    } while (changed)
  }

  /** Fills morph-region IDs for descendants registered before their parent. */
  private fun propagateInheritedMorphRegionIds() {
    var changed: Boolean
    do {
      changed = false
      nodes.values.toList().forEach { node ->
        if (node.morphRegionId == null) {
          val inherited = node.parentId?.let { nodes[it]?.morphRegionId }
            ?: node.sceneIndex?.let(::defaultMorphRegionId)
          if (inherited != null) {
            nodes[node.id] = node.copy(morphRegionId = inherited)
            changed = true
          }
        }
      }
    } while (changed)
  }

  /**
   * Invalidates geometry when the usable viewport or display density changes. Width alone is not
   * sufficient: height/insets can move the scroll frontier, while density changes every px bound.
   */
  @Synchronized
  fun onViewportGeometryChanged(
    newWidthPx: Float,
    newHeightPx: Float,
    newDensityScale: Float,
  ): Boolean {
    if (newWidthPx <= 0f || newHeightPx <= 0f || newDensityScale <= 0f) return false

    val widthChanged = lastViewportWidthPx > 0f && abs(newWidthPx - lastViewportWidthPx) >= 8f
    val heightChanged = lastViewportHeightPx > 0f && abs(newHeightPx - lastViewportHeightPx) >= 8f
    val densityChanged = lastDensityScale > 0f && abs(newDensityScale - lastDensityScale) >= 0.01f
    val hasBaseline = lastViewportWidthPx > 0f && lastViewportHeightPx > 0f && lastDensityScale > 0f

    lastViewportWidthPx = newWidthPx
    lastViewportHeightPx = newHeightPx
    lastDensityScale = newDensityScale
    if (hasBaseline && !widthChanged && !heightChanged && !densityChanged) return false

    currentBoundsGeneration++
    // Release in-flight work. Existing bounds remain available until Compose publishes its next
    // LayoutCoordinates; each re-registration advances that node into the new geometry epoch.
    val claimList = activeClaimsByAgent.values.toList()
    for (claim in claimList) releaseClaim(claim.agentId, claim.nodeId)
    restoreSceneSealsWithEvents()
    return hasBaseline
  }

  /** Compatibility helper retained for the standalone scheduler tests and older callers. */
  @Synchronized
  fun onViewportWidthChanged(newWidthPx: Float): Boolean {
    val h = if (lastViewportHeightPx > 0f) lastViewportHeightPx else 1f
    val d = if (lastDensityScale > 0f) lastDensityScale else 1f
    return onViewportGeometryChanged(newWidthPx, h, d)
  }

  @Synchronized
  fun resetForReplay() {
    activeClaimsByAgent.clear()
    currentBoundsGeneration++
    completionSequence = 0L
    sealedScenes.clear()
    pendingSceneEvents.clear()
    val updated = LinkedHashMap<String, RegisteredSceneNode>(nodes.size)
    for ((id, node) in nodes) {
      updated[id] =
        node.copy(
          phase = LayerPhase.HIDDEN,
          claimedByAgentId = null,
          boundsGeneration = currentBoundsGeneration,
          completionSequence = null,
          reversedAtMs = null,
          reversedCompletionSequence = null,
        )
    }
    nodes.clear()
    nodes.putAll(updated)
  }

  @Synchronized
  fun markAllRevealed() {
    activeClaimsByAgent.clear()
    val updated = LinkedHashMap<String, RegisteredSceneNode>(nodes.size)
    for ((id, node) in nodes) {
      updated[id] = node.copy(
        phase = LayerPhase.REVEALED,
        claimedByAgentId = null,
        completionSequence = node.completionSequence ?: ++completionSequence,
        reversedAtMs = null,
        reversedCompletionSequence = null,
      )
    }
    nodes.clear()
    nodes.putAll(updated)
    restoreSceneSealsSilently()
  }

  @Synchronized
  fun getNode(id: String): RegisteredSceneNode? = nodes[id]

  @Synchronized
  fun allNodesSnapshot(): List<RegisteredSceneNode> = nodes.values.toList()

  @Synchronized
  fun totalCount(): Int = nodes.size

  /**
   * Validates the registered construction graph. Missing dependencies and cycles are reported
   * explicitly instead of leaving a scene that can never finish. Results are cached until a node
   * is added or one of its dependency relationships changes.
   */
  @Synchronized
  fun validateSceneGraph(): List<String> {
    if (validatedGraphVersion == dependencyGraphVersion) return cachedGraphIssues

    val issues = linkedSetOf<String>()
    val mastersByGroup = nodes.values
      .filter { it.cloneGroupId != null && it.cloneIndex == 0 }
      .groupBy { it.cloneGroupId!! }

    for (node in nodes.values) {
      node.parentId?.let { parentId ->
        if (parentId == node.id) {
          issues += "Node '${node.id}' cannot be its own parent."
        } else if (parentId !in nodes) {
          issues += "Node '${node.id}' references missing parent '$parentId'."
        }
      }
      if (node.cloneGroupId == null && node.cloneIndex != 0) {
        issues += "Node '${node.id}' has cloneIndex ${node.cloneIndex} without a cloneGroupId."
      }
      if (node.cloneIndex < 0) {
        issues += "Node '${node.id}' has a negative cloneIndex."
      }
      node.cloneGroupId?.let { group ->
        if (node.cloneIndex > 0 && mastersByGroup[group].isNullOrEmpty()) {
          issues += "Clone '${node.id}' has no master in group '$group'."
        }
      }
    }
    mastersByGroup.filterValues { it.size > 1 }.forEach { (group, masters) ->
      issues += "Clone group '$group' has multiple masters: ${masters.joinToString { it.id }}."
    }

    // Directed edges point from a task to the prerequisite that must finish before it.
    // A grey/black DFS detects cycles across both parent and clone-master relationships.
    val visitState = HashMap<String, Int>()
    val stack = ArrayList<String>()
    fun visit(nodeId: String) {
      when (visitState[nodeId]) {
        1 -> {
          val start = stack.indexOf(nodeId).coerceAtLeast(0)
          issues += "Dependency cycle: ${(stack.subList(start, stack.size) + nodeId).joinToString(" -> ")}."
          return
        }
        2 -> return
      }
      visitState[nodeId] = 1
      stack += nodeId
      val node = nodes[nodeId]
      if (node != null) {
        node.parentId?.takeIf { it in nodes }?.let(::visit)
        val group = node.cloneGroupId
        if (group != null && node.cloneIndex > 0) {
          mastersByGroup[group]?.singleOrNull()?.id?.let(::visit)
        }
      }
      stack.removeAt(stack.lastIndex)
      visitState[nodeId] = 2
    }
    nodes.keys.forEach(::visit)

    cachedGraphIssues = issues.toList()
    validatedGraphVersion = dependencyGraphVersion
    return cachedGraphIssues
  }

  @Synchronized
  fun completedCount(): Int = nodes.values.count { it.phase == LayerPhase.REVEALED }

  @Synchronized
  fun activeBuilderCount(): Int = activeClaimsByAgent.size

  @Synchronized
  fun isAllCompleted(): Boolean = nodes.isNotEmpty() && completedCount() == nodes.size

  /**
   * Atomically claims the next eligible task for [agentId] with [role] inside the current
   * visible viewport `[viewportTopPx, viewportBottomPx]` (expanded by [prefetchMarginPx]).
   */
  @Synchronized
  fun tryClaimNextTask(
    agentId: Int,
    role: AgentRole,
    viewportTopPx: Float,
    viewportBottomPx: Float,
    ignoreViewportGate: Boolean = false,
    morphRegionIdFilter: String? = null,
  ): AgentTaskClaim? {
    if (role == AgentRole.IDLE_SCOUT) return null
    if (validateSceneGraph().isNotEmpty()) return null
    if (activeClaimsByAgent.containsKey(agentId)) return null
    if (activeClaimsByAgent.values.any { it.direction == TaskDirection.RESTOCK }) return null
    if (activeClaimsByAgent.size >= maxConcurrentBuilders) return null

    val windowTop = viewportTopPx - prefetchMarginPx
    val windowBottom = viewportBottomPx + prefetchMarginPx

    val allReady =
      nodes.values
        .asSequence()
        .filter { node ->
          (morphRegionIdFilter == null || node.morphRegionId == morphRegionIdFilter) &&
            node.phase == LayerPhase.HIDDEN &&
            node.claimedByAgentId == null &&
            node.bounds.isValid &&
            node.boundsGeneration >= currentBoundsGeneration &&
            (ignoreViewportGate || node.bounds.intersectsVerticalWindow(windowTop, windowBottom)) &&
            isParentSatisfied(node) &&
            isCloneMasterSatisfied(node)
        }
        .sortedWith(
          compareBy<RegisteredSceneNode>(
            { if (isRoleCompatible(role, it)) 0 else 1 },
            { it.kind.priorityRank() },
            { it.bounds.top },
            { it.orderIndex },
          )
        )
        .toList()

    val chosen = allReady.firstOrNull() ?: return null
    val cloneGroup = chosen.cloneGroupId
    val isClone = cloneGroup != null && chosen.cloneIndex > 0
    val masterId = if (isClone) findMasterNodeId(requireNotNull(cloneGroup)) else null

    nodes[chosen.id] =
      chosen.copy(
        phase = LayerPhase.BUILDING,
        claimedByAgentId = agentId,
      )

    val claim =
      AgentTaskClaim(
        agentId = agentId,
        role = role,
        nodeId = chosen.id,
        kind = chosen.kind,
        isCloneFromMaster = isClone,
        masterNodeId = masterId,
        boundsGeneration = chosen.boundsGeneration,
        direction = TaskDirection.DISPENSE,
      )
    activeClaimsByAgent[agentId] = claim
    return claim
  }

  @Synchronized
  fun markCloneMasterTextVisible(nodeId: String) {
    val existing = nodes[nodeId] ?: return
    if (existing.phase == LayerPhase.BUILDING) {
      nodes[nodeId] = existing.copy(phase = LayerPhase.CLONED_MASTER_TEXT)
    }
  }

  /** Atomically completes a DISPENSE or RESTOCK claim and releases the agent's active slot. */
  @Synchronized
  fun completeTask(agentId: Int, nodeId: String, nowMs: Long = 0L): Boolean {
    val claim = activeClaimsByAgent[agentId]
    if (claim == null || claim.nodeId != nodeId) return false
    activeClaimsByAgent.remove(agentId)
    val node = nodes[nodeId] ?: return false

    // A task measured against an old layout must never reveal or hide content at stale coordinates.
    if (claim.boundsGeneration != node.boundsGeneration) {
      nodes[nodeId] = node.copy(
        phase = if (claim.direction == TaskDirection.RESTOCK) LayerPhase.REVEALED else LayerPhase.HIDDEN,
        claimedByAgentId = null,
      )
      if (claim.direction == TaskDirection.RESTOCK) restoreSceneSealsWithEvents()
      return false
    }

    when (claim.direction) {
      TaskDirection.DISPENSE -> {
        nodes[nodeId] = node.copy(
          phase = LayerPhase.REVEALED,
          claimedByAgentId = null,
          completionSequence = ++completionSequence,
          reversedAtMs = null,
          reversedCompletionSequence = null,
        )
        refreshSceneSealEvents()
      }
      TaskDirection.RESTOCK -> {
        nodes[nodeId] = node.copy(
          phase = LayerPhase.HIDDEN,
          claimedByAgentId = null,
          completionSequence = null,
          reversedAtMs = nowMs,
          reversedCompletionSequence = node.completionSequence,
        )
        refreshSceneSealEvents()
      }
    }
    return true
  }

  /**
   * Claims the latest completed, dependency-unblocked layer at least 1.5 viewport heights
   * below the reading viewport. This preserves the active reading area while restocking.
   */
  @Synchronized
  fun tryClaimNextReverseTask(
    agentId: Int,
    role: AgentRole,
    viewportTopPx: Float,
    viewportBottomPx: Float,
    rewindScreens: Float = 1.5f,
    nowMs: Long = 0L,
  ): AgentTaskClaim? {
    if (role == AgentRole.IDLE_SCOUT) return null
    if (validateSceneGraph().isNotEmpty()) return null
    if (activeClaimsByAgent.containsKey(agentId)) return null
    // RESTOCK follows the journal one committed layer at a time; parallel reverse claims could
    // finish out of order and contradict the authoritative completion sequence.
    if (activeClaimsByAgent.values.any { it.direction == TaskDirection.DISPENSE }) return null
    if (activeClaimsByAgent.values.any { it.direction == TaskDirection.RESTOCK }) return null
    if (activeClaimsByAgent.size >= maxConcurrentBuilders) return null
    val viewportHeight = (viewportBottomPx - viewportTopPx).coerceAtLeast(1f)
    val protectedBottom = viewportBottomPx + viewportHeight * rewindScreens.coerceAtLeast(0f)

    val candidate = nodes.values.asSequence()
      .filter { node ->
        node.phase == LayerPhase.REVEALED &&
          node.claimedByAgentId == null &&
          node.completionSequence != null &&
          node.bounds.isValid &&
          node.boundsGeneration >= currentBoundsGeneration &&
          node.bounds.top >= protectedBottom &&
          dependentsAreHidden(node)
      }
      .sortedWith(
        compareByDescending<RegisteredSceneNode> { it.completionSequence ?: Long.MIN_VALUE }
          .thenByDescending { it.orderIndex },
      )
      .firstOrNull() ?: return null
    if (!isRoleCompatible(role, candidate)) return null

    val cloneGroup = candidate.cloneGroupId
    val isClone = cloneGroup != null && candidate.cloneIndex > 0
    val masterId = if (isClone) findMasterNodeId(requireNotNull(cloneGroup)) else null
    val reversing = candidate.copy(phase = LayerPhase.REVERSING, claimedByAgentId = agentId)
    nodes[candidate.id] = reversing
    val claim = AgentTaskClaim(
      agentId = agentId,
      role = role,
      nodeId = candidate.id,
      kind = candidate.kind,
      isCloneFromMaster = isClone,
      masterNodeId = masterId,
      boundsGeneration = candidate.boundsGeneration,
      direction = TaskDirection.RESTOCK,
      claimedAtMs = nowMs,
    )
    activeClaimsByAgent[agentId] = claim
    beginSceneUnseal(candidate.sceneIndex)
    return claim
  }

  /**
   * Theme morph restock is scoped to one visual region. Unlike visitor rewind, it intentionally
   * does not use the 1.5-screen protection horizon: the morph policy has already selected a safe,
   * visible region. Normal visitor rewind continues to use [tryClaimNextReverseTask] unchanged.
   */
  @Synchronized
  fun tryClaimNextMorphReverseTask(
    agentId: Int,
    role: AgentRole,
    morphRegionId: String,
    viewportTopPx: Float,
    viewportBottomPx: Float,
    nowMs: Long = 0L,
  ): AgentTaskClaim? {
    if (morphRegionId.isBlank() || role == AgentRole.IDLE_SCOUT) return null
    if (validateSceneGraph().isNotEmpty() || activeClaimsByAgent.containsKey(agentId)) return null
    if (activeClaimsByAgent.values.any { it.direction == TaskDirection.DISPENSE }) return null
    if (activeClaimsByAgent.size >= maxConcurrentBuilders) return null

    val windowTop = viewportTopPx - prefetchMarginPx
    val windowBottom = viewportBottomPx + prefetchMarginPx
    val candidate = nodes.values.asSequence()
      .filter { node ->
        node.morphRegionId == morphRegionId &&
          node.phase == LayerPhase.REVEALED &&
          node.claimedByAgentId == null &&
          node.completionSequence != null &&
          node.bounds.isValid &&
          node.boundsGeneration >= currentBoundsGeneration &&
          node.bounds.intersectsVerticalWindow(windowTop, windowBottom) &&
          dependentsAreHidden(node)
      }
      .sortedWith(
        compareByDescending<RegisteredSceneNode> { it.completionSequence ?: Long.MIN_VALUE }
          .thenByDescending { it.orderIndex },
      )
      .firstOrNull() ?: return null
    if (!isRoleCompatible(role, candidate)) return null

    val cloneGroup = candidate.cloneGroupId
    val isClone = cloneGroup != null && candidate.cloneIndex > 0
    val masterId = if (isClone) findMasterNodeId(requireNotNull(cloneGroup)) else null
    nodes[candidate.id] = candidate.copy(phase = LayerPhase.REVERSING, claimedByAgentId = agentId)
    val claim = AgentTaskClaim(
      agentId = agentId,
      role = role,
      nodeId = candidate.id,
      kind = candidate.kind,
      isCloneFromMaster = isClone,
      masterNodeId = masterId,
      boundsGeneration = candidate.boundsGeneration,
      direction = TaskDirection.RESTOCK,
      claimedAtMs = nowMs,
    )
    activeClaimsByAgent[agentId] = claim
    beginSceneUnseal(candidate.sceneIndex)
    return claim
  }

  @Synchronized
  fun isMorphRegionFullyRestocked(morphRegionId: String): Boolean {
    val regionNodes = nodes.values.filter { it.morphRegionId == morphRegionId }
    return regionNodes.isNotEmpty() && regionNodes.all {
      it.phase == LayerPhase.HIDDEN && it.claimedByAgentId == null
    }
  }

  @Synchronized
  fun isMorphRegionFullyDispensed(morphRegionId: String): Boolean {
    val regionNodes = nodes.values.filter { it.morphRegionId == morphRegionId }
    return regionNodes.isNotEmpty() && regionNodes.all {
      it.phase == LayerPhase.REVEALED && it.claimedByAgentId == null
    }
  }

  @Synchronized
  fun hasEligibleMorphRestockWork(
    morphRegionId: String,
    viewportTopPx: Float,
    viewportBottomPx: Float,
  ): Boolean {
    if (validateSceneGraph().isNotEmpty()) return false
    val windowTop = viewportTopPx - prefetchMarginPx
    val windowBottom = viewportBottomPx + prefetchMarginPx
    return nodes.values.any { node ->
      node.morphRegionId == morphRegionId &&
        node.phase == LayerPhase.REVEALED &&
        node.claimedByAgentId == null &&
        node.completionSequence != null &&
        node.bounds.isValid &&
        node.boundsGeneration >= currentBoundsGeneration &&
        node.bounds.intersectsVerticalWindow(windowTop, windowBottom) &&
        dependentsAreHidden(node)
    }
  }

  @Synchronized
  fun hasEligibleMorphDispenseWork(
    morphRegionId: String,
    viewportTopPx: Float,
    viewportBottomPx: Float,
  ): Boolean {
    if (validateSceneGraph().isNotEmpty()) return false
    val windowTop = viewportTopPx - prefetchMarginPx
    val windowBottom = viewportBottomPx + prefetchMarginPx
    return nodes.values.any { node ->
      node.morphRegionId == morphRegionId &&
        node.phase == LayerPhase.HIDDEN &&
        node.claimedByAgentId == null &&
        node.bounds.isValid &&
        node.boundsGeneration >= currentBoundsGeneration &&
        node.bounds.intersectsVerticalWindow(windowTop, windowBottom) &&
        isParentSatisfied(node) &&
        isCloneMasterSatisfied(node)
    }
  }

  @Synchronized
  fun nextMorphRestockTargetY(morphRegionId: String): Float? = nodes.values.asSequence()
    .filter { node ->
      node.morphRegionId == morphRegionId &&
        node.phase == LayerPhase.REVEALED &&
        node.claimedByAgentId == null &&
        node.completionSequence != null &&
        node.bounds.isValid &&
        node.boundsGeneration >= currentBoundsGeneration &&
        dependentsAreHidden(node)
    }
    .sortedByDescending { it.completionSequence ?: Long.MIN_VALUE }
    .firstOrNull()?.bounds?.centerY

  @Synchronized
  fun nextMorphDispenseTargetY(morphRegionId: String): Float? = nodes.values.asSequence()
    .filter { node ->
      node.morphRegionId == morphRegionId &&
        node.phase == LayerPhase.HIDDEN &&
        node.claimedByAgentId == null &&
        node.bounds.isValid &&
        node.boundsGeneration >= currentBoundsGeneration &&
        isParentSatisfied(node) &&
        isCloneMasterSatisfied(node)
    }
    .sortedWith(
      compareBy<RegisteredSceneNode>(
        { it.kind.priorityRank() },
        { it.bounds.top },
        { it.orderIndex },
      ),
    )
    .firstOrNull()?.bounds?.centerY

  /** Restores only completed reverse transitions still inside their own two-second grace window. */
  @Synchronized
  fun restoreRecentlyReversed(
    nowMs: Long,
    graceWindowMs: Long = 2_000L,
    excludeNodeIds: Set<String> = emptySet(),
  ): List<String> {
    val restored = nodes.values.filter { node ->
      node.id !in excludeNodeIds &&
      node.phase == LayerPhase.HIDDEN &&
        node.reversedAtMs != null &&
        nowMs >= node.reversedAtMs &&
        nowMs - node.reversedAtMs <= graceWindowMs &&
        node.reversedCompletionSequence != null
    }
    if (restored.isEmpty()) return emptyList()

    restored.forEach { node ->
      nodes[node.id] = node.copy(
        phase = LayerPhase.REVEALED,
        claimedByAgentId = null,
        completionSequence = node.reversedCompletionSequence,
        reversedAtMs = null,
        reversedCompletionSequence = null,
      )
    }
    val restoredScenes = restored.mapNotNull { it.sceneIndex }.toSet()
    restoredScenes.forEach { sceneIndex ->
      if (isSceneFullyRevealed(sceneIndex) && sealedScenes.add(sceneIndex)) {
        pendingSceneEvents.add(SceneBuildEvent.Restored(sceneIndex))
      }
    }
    return restored.map { it.id }
  }

  data class ReverseClaimSettlement(
    val restoredNodeIds: List<String>,
    val restockedNodeIds: List<String>,
  )

  /** Resolve in-flight reverse claims using each claim's own start time and the two-second grace. */
  @Synchronized
  fun settleReverseClaimsByGrace(nowMs: Long, graceWindowMs: Long = 2_000L): ReverseClaimSettlement {
    val reverseClaims = activeClaimsByAgent.values.filter { it.direction == TaskDirection.RESTOCK }
    if (reverseClaims.isEmpty()) return ReverseClaimSettlement(emptyList(), emptyList())
    val restored = mutableListOf<String>()
    val restocked = mutableListOf<String>()
    reverseClaims.forEach { claim ->
      activeClaimsByAgent.remove(claim.agentId)
      val node = nodes[claim.nodeId] ?: return@forEach
      val withinGrace = nowMs >= claim.claimedAtMs && nowMs - claim.claimedAtMs <= graceWindowMs
      if (withinGrace) {
        nodes[claim.nodeId] = node.copy(
          phase = LayerPhase.REVEALED,
          claimedByAgentId = null,
          reversedAtMs = null,
          reversedCompletionSequence = null,
        )
        restored += claim.nodeId
      } else {
        nodes[claim.nodeId] = node.copy(
          phase = LayerPhase.HIDDEN,
          claimedByAgentId = null,
          completionSequence = null,
          reversedAtMs = nowMs,
          reversedCompletionSequence = node.completionSequence,
        )
        restocked += claim.nodeId
      }
    }
    if (restored.isNotEmpty()) restoreSceneSealsWithEvents()
    if (restocked.isNotEmpty()) refreshSceneSealEvents()
    return ReverseClaimSettlement(restored, restocked)
  }

  /** Scene stamp and verification state are withdrawn before the first child layer reverses. */
  private fun beginSceneUnseal(sceneIndex: Int?) {
    if (sceneIndex != null && sealedScenes.remove(sceneIndex)) {
      pendingSceneEvents.add(SceneBuildEvent.Unsealed(sceneIndex))
    }
  }

  @Synchronized
  fun drainSceneEvents(): List<SceneBuildEvent> {
    if (pendingSceneEvents.isEmpty()) return emptyList()
    val events = pendingSceneEvents.toList()
    pendingSceneEvents.clear()
    return events
  }

  @Synchronized
  fun sealedSceneIndices(): Set<Int> = sealedScenes.toSet()

  @Synchronized
  fun sceneRootBounds(sceneIndex: Int): SceneBounds? = nodes.values.firstOrNull {
    it.sceneIndex == sceneIndex && it.kind == LayerKind.CONTAINER && it.parentId == null && it.bounds.isValid
  }?.bounds

  @Synchronized
  fun completionJournal(): List<Pair<Long, String>> = nodes.values
    .mapNotNull { node -> node.completionSequence?.let { it to node.id } }
    .sortedBy { it.first }

  /**
   * Releases a cancelled claim. Forward work returns to HIDDEN; interrupted reverse work returns
   * to REVEALED, so cancellation never falsely removes committed content.
   */
  @Synchronized
  fun releaseClaim(agentId: Int, nodeId: String) {
    val claim = activeClaimsByAgent[agentId]
    if (claim != null && claim.nodeId == nodeId) activeClaimsByAgent.remove(agentId)
    val node = nodes[nodeId] ?: return
    if (node.claimedByAgentId == agentId && node.phase != LayerPhase.REVEALED) {
      nodes[nodeId] = node.copy(
        phase = if (claim?.direction == TaskDirection.RESTOCK) LayerPhase.REVEALED else LayerPhase.HIDDEN,
        claimedByAgentId = null,
      )
      if (claim?.direction == TaskDirection.RESTOCK) restoreSceneSealsWithEvents()
    }
  }

  private fun dependentsAreHidden(node: RegisteredSceneNode): Boolean {
    return nodes.values.asSequence()
      .filter { dependent ->
        dependent.id != node.id && (
          dependent.parentId == node.id ||
            (node.cloneIndex == 0 && node.cloneGroupId != null &&
              dependent.cloneGroupId == node.cloneGroupId && dependent.cloneIndex > 0)
          )
      }
      .all { it.phase == LayerPhase.HIDDEN }
  }

  private fun refreshSceneSealEvents() {
    val sceneIndices = nodes.values.mapNotNull { it.sceneIndex }.toSet()
    sceneIndices.forEach { sceneIndex ->
      val fullyRevealed = isSceneFullyRevealed(sceneIndex)
      if (fullyRevealed && sealedScenes.add(sceneIndex)) {
        pendingSceneEvents.add(SceneBuildEvent.Sealed(sceneIndex))
      } else if (!fullyRevealed && sealedScenes.remove(sceneIndex)) {
        pendingSceneEvents.add(SceneBuildEvent.Unsealed(sceneIndex))
      }
    }
  }

  private fun restoreSceneSealsWithEvents() {
    val sceneIndices = nodes.values.mapNotNull { it.sceneIndex }.toSet()
    sceneIndices.forEach { sceneIndex ->
      if (isSceneFullyRevealed(sceneIndex) && sealedScenes.add(sceneIndex)) {
        pendingSceneEvents.add(SceneBuildEvent.Restored(sceneIndex))
      } else if (!isSceneFullyRevealed(sceneIndex)) {
        sealedScenes.remove(sceneIndex)
      }
    }
  }

  private fun restoreSceneSealsSilently() {
    val sceneIndices = nodes.values.mapNotNull { it.sceneIndex }.toSet()
    sceneIndices.forEach { sceneIndex ->
      if (isSceneFullyRevealed(sceneIndex)) sealedScenes.add(sceneIndex)
      else sealedScenes.remove(sceneIndex)
    }
  }

  private fun isSceneFullyRevealed(sceneIndex: Int): Boolean {
    val sceneNodes = nodes.values.filter { it.sceneIndex == sceneIndex }
    return sceneNodes.isNotEmpty() && sceneNodes.all { it.phase == LayerPhase.REVEALED }
  }

  private fun inferMorphRegionId(id: String): String? {
    val sceneIndex = inferSceneIndex(id) ?: return null
    val prefix = if (id.lowercase().startsWith("home_")) "home" else "about"
    return "$prefix-scene-%02d".format(sceneIndex)
  }

  private fun defaultMorphRegionId(sceneIndex: Int): String = "about-scene-%02d".format(sceneIndex)

  @Synchronized
  fun sceneIndicesSnapshot(): Set<Int> = nodes.values.mapNotNull { it.sceneIndex }.toSet()

  private fun inferSceneIndex(id: String): Int? {
    val normalized = id.lowercase()
    return when {
      normalized.startsWith("home_h1") -> 1
      normalized.startsWith("home_h2") -> 2
      normalized.startsWith("home_h3") -> 3
      normalized.startsWith("home_h4") -> 4
      normalized.startsWith("home_h5") -> 5
      normalized.startsWith("home_h6") -> 6
      normalized.startsWith("about_hero") -> 1
      normalized.startsWith("about_pov") -> 2
      normalized.startsWith("about_marquee") || normalized.startsWith("about_philosophy") -> 3
      normalized.startsWith("about_principle") -> 4
      normalized.startsWith("about_selected") -> 5
      normalized.startsWith("about_commitment") -> 6
      normalized.startsWith("about_mosaic") -> 7
      normalized.startsWith("about_deep_dive") -> 8
      normalized.startsWith("about_meta") || normalized.startsWith("about_film_end") || normalized.startsWith("about_frieze") -> 9
      else -> null
    }
  }

  /** Returns the lowest `top` coordinate of the next unbuilt node below the viewport for guided Touring. */
  @Synchronized
  fun nextUnbuiltTargetTopY(afterY: Float): Float? {
    if (validateSceneGraph().isNotEmpty()) return null
    return nodes.values
      .asSequence()
      .filter {
        it.phase == LayerPhase.HIDDEN &&
          it.claimedByAgentId == null &&
          it.bounds.isValid &&
          it.boundsGeneration >= currentBoundsGeneration &&
          it.bounds.top >= afterY &&
          isParentSatisfied(it) &&
          isCloneMasterSatisfied(it)
      }
      .minByOrNull { it.bounds.top }
      ?.bounds
      ?.top
  }

  @Synchronized
  fun hasEligibleWorkInViewport(viewportTopPx: Float, viewportBottomPx: Float): Boolean {
    if (validateSceneGraph().isNotEmpty()) return false
    val windowTop = viewportTopPx - prefetchMarginPx
    val windowBottom = viewportBottomPx + prefetchMarginPx
    return nodes.values.any { node ->
      node.phase == LayerPhase.HIDDEN &&
        node.claimedByAgentId == null &&
        node.bounds.isValid &&
        node.boundsGeneration >= currentBoundsGeneration &&
        node.bounds.intersectsVerticalWindow(windowTop, windowBottom) &&
        isParentSatisfied(node) &&
        isCloneMasterSatisfied(node)
    }
  }

  @Synchronized
  fun hasEligibleReverseWork(viewportTopPx: Float, viewportBottomPx: Float, rewindScreens: Float = 1.5f): Boolean {
    if (validateSceneGraph().isNotEmpty()) return false
    val viewportHeight = (viewportBottomPx - viewportTopPx).coerceAtLeast(1f)
    val protectedBottom = viewportBottomPx + viewportHeight * rewindScreens.coerceAtLeast(0f)
    return nodes.values.any { node ->
      node.phase == LayerPhase.REVEALED &&
        node.claimedByAgentId == null &&
        node.completionSequence != null &&
        node.bounds.isValid &&
        node.boundsGeneration >= currentBoundsGeneration &&
        node.bounds.top >= protectedBottom &&
        dependentsAreHidden(node)
    }
  }

  private fun isParentSatisfied(node: RegisteredSceneNode): Boolean {
    val pid = node.parentId ?: return true
    // A missing parent is a broken scene graph, not permission to skip the dependency.
    val parent = nodes[pid] ?: return false
    return parent.phase == LayerPhase.REVEALED
  }

  private fun isCloneMasterSatisfied(node: RegisteredSceneNode): Boolean {
    val group = node.cloneGroupId ?: return true
    if (node.cloneIndex == 0) return true
    // A clone without a registered master remains locked rather than being silently built alone.
    val master =
      nodes.values.firstOrNull { it.cloneGroupId == group && it.cloneIndex == 0 } ?: return false
    return master.phase == LayerPhase.REVEALED
  }

  private fun findMasterNodeId(groupId: String): String? =
    nodes.values.firstOrNull { it.cloneGroupId == groupId && it.cloneIndex == 0 }?.id

  private fun isRoleCompatible(role: AgentRole, node: RegisteredSceneNode): Boolean {
    val isClone = node.cloneGroupId != null && node.cloneIndex > 0
    return when (role) {
      AgentRole.LAYOUT_ARCHITECT ->
        !isClone && (node.kind == LayerKind.CONTAINER || node.kind == LayerKind.LINE)
      AgentRole.COMPONENT_DUPLICATOR ->
        isClone || node.kind == LayerKind.CONTAINER
      AgentRole.TYPOGRAPHER ->
        node.kind == LayerKind.TEXT
      AgentRole.ART_DIRECTOR ->
        node.kind == LayerKind.MEDIA || node.kind == LayerKind.LINE
      AgentRole.IDLE_SCOUT -> false
    }
  }

  private fun LayerKind.priorityRank(): Int =
    when (this) {
      LayerKind.CONTAINER -> 0
      LayerKind.LINE -> 1
      LayerKind.MEDIA -> 2
      LayerKind.TEXT -> 3
    }
}
