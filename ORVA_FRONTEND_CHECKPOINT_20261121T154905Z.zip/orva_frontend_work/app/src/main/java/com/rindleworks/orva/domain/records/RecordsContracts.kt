package com.rindleworks.orva.domain.records

import com.rindleworks.orva.domain.billing.InvoiceCustomerDraft
import com.rindleworks.orva.domain.billing.InvoicePaymentMethod
import com.rindleworks.orva.domain.billing.InvoicePreviewResult
import com.rindleworks.orva.domain.billing.InvoiceResult
import com.rindleworks.orva.domain.billing.PaymentTenderDraft
import java.io.OutputStream

enum class InvoiceStatusFilter(val dbValue: String) {
  All("ALL"),
  Issued("ISSUED"),
  Cancelled("CANCELLED"),
  CreditNoteIssued("CREDIT_NOTE_ISSUED");

  companion object {
    fun fromDbValue(raw: String?): InvoiceStatusFilter =
      entries.firstOrNull { it.dbValue.equals(raw?.trim(), ignoreCase = true) } ?: All
  }
}

enum class ReportType {
  SalesRegister,
  PurchaseRegister,
  GstSummary,
  StockValuation,
  SalesReturnsRegister,
  Expenses,
}

enum class ExportFormat {
  Csv,
  Xlsx,
  Pdf,
}

data class RegisterDateFilter(
  val fromLocalDateIso: String? = null, // "YYYY-MM-DD" (inclusive start of local day -> UTC)
  val toLocalDateIso: String? = null, // "YYYY-MM-DD" (inclusive end of local day -> UTC)
)

data class SalesRegisterRow(
  val invoiceId: String,
  val invoiceNumber: String,
  val issuedAtUtc: String,
  val issuedDateText: String,
  val customerName: String,
  val customerGstin: String,
  val taxableValuePaise: Long,
  val cgstPaise: Long,
  val sgstPaise: Long,
  val igstPaise: Long,
  val roundOffPaise: Long,
  val grandTotalPaise: Long,
  val paidTotalPaise: Long,
  val status: String,
  val cancellationReason: String,
)

data class PurchaseRegisterRow(
  val purchaseId: String,
  val receivedAtUtc: String,
  val receivedDateText: String,
  val supplierName: String,
  val documentType: String,
  val documentReference: String,
  val totalPaise: Long,
  val isDocumentedForReview: Boolean,
)

data class GstSummaryRow(
  val hsnCode: String,
  val gstRateBasisPoints: Int,
  val taxableValuePaise: Long,
  val cgstPaise: Long,
  val sgstPaise: Long,
  val igstPaise: Long,
  val totalValuePaise: Long,
)

data class StockValuationRow(
  val medicineId: String,
  val medicineName: String,
  val stockUnitName: String,
  val usableQuantityMilli: Long,
  val lowStockThresholdMilli: Long,
  val isLowStock: Boolean,
  val purchaseCostValuePaise: Long,
  val mrpValuePaise: Long,
)

data class SalesReturnRegisterRow(
  val returnId: String,
  val returnNumber: String,
  val invoiceNumber: String,
  val returnedAtUtc: String,
  val returnedDateText: String,
  val reason: String,
  val refundMethod: String,
  val refundAmountPaise: Long,
  val status: String,
)

data class ExpenseRow(
  val expenseId: String,
  val expenseDateUtc: String,
  val expenseDateText: String,
  val category: String,
  val description: String,
  val amountPaise: Long,
  val paymentMethod: String,
  val documentReference: String,
)

data class ExpenseInput(
  val category: String,
  val description: String?,
  val amountPaise: Long,
  val paymentMethod: InvoicePaymentMethod?,
  val documentReference: String?,
)

data class HistoricalInvoiceRecord(
  val committedInvoice: InvoiceResult,
  val preview: InvoicePreviewResult,
  val customer: InvoiceCustomerDraft,
  val tenders: List<PaymentTenderDraft>,
)

interface ReportingService {
  suspend fun getSalesRegister(
    filter: RegisterDateFilter,
    statusFilter: InvoiceStatusFilter = InvoiceStatusFilter.All,
    search: String? = null,
  ): List<SalesRegisterRow>

  suspend fun getPurchaseRegister(
    filter: RegisterDateFilter,
    supplierSearch: String? = null,
  ): List<PurchaseRegisterRow>

  suspend fun getGstSummary(filter: RegisterDateFilter): List<GstSummaryRow>
  suspend fun getStockValuation(): List<StockValuationRow>

  suspend fun getSalesReturnsRegister(
    filter: RegisterDateFilter,
    search: String? = null,
  ): List<SalesReturnRegisterRow>

  suspend fun getExpenses(filter: RegisterDateFilter): List<ExpenseRow>
  suspend fun addExpense(input: ExpenseInput): Result<Unit>
  suspend fun getInvoiceForReprint(invoiceId: String): HistoricalInvoiceRecord?

  suspend fun exportReport(
    reportType: ReportType,
    format: ExportFormat,
    output: OutputStream,
    filter: RegisterDateFilter,
    statusFilter: InvoiceStatusFilter = InvoiceStatusFilter.All,
    search: String? = null,
    subtitle: String? = null,
  ): Result<Unit>
}
