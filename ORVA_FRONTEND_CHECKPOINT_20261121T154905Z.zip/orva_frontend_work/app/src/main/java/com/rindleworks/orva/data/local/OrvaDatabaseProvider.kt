package com.rindleworks.orva.data.local

import android.content.Context
import androidx.room.Room
import androidx.room.RoomDatabase
import com.rindleworks.orva.domain.common.OrvaDatabaseSignal
import java.io.File
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/**
 * Replaceable Room database holder required for safe live `.shopbackup` restore.
 *
 * Before opening Room, [OrvaSchemaBootstrapper.bootstrapOrMigrate] always runs on [databaseFile]
 * so fresh databases use verbatim WPF SQL (001 -> 002 -> 003) and v1/v2 databases upgrade
 * non-destructively without ever invoking destructive migrations.
 *
 * When a restore replaces the SQLite file on disk, [reopen] bumps [databaseGeneration] so any
 * reactive observers re-subscribe cleanly to the fresh Room instance.
 */
class OrvaDatabaseProvider(
  private val context: Context,
  val databaseFile: File = File(context.filesDir, "orva/${OrvaDatabase.DEFAULT_DB_NAME}"),
  private val sqlLoader: (String) -> String = { fileName ->
    context.assets.open("db/$fileName").bufferedReader(Charsets.UTF_8).use { it.readText() }
  },
  private val allowMainThreadQueries: Boolean = false,
) : OrvaDatabaseSignal {

  private val lock = Any()
  private var activeDatabase: OrvaDatabase? = null

  private val _databaseGeneration = MutableStateFlow(0L)
  override val databaseGeneration: StateFlow<Long> = _databaseGeneration.asStateFlow()

  fun current(): OrvaDatabase =
    synchronized(lock) {
      activeDatabase ?: openInternal().also { activeDatabase = it }
    }

  fun closeCurrent() {
    synchronized(lock) {
      activeDatabase?.close()
      activeDatabase = null
    }
  }

  /**
   * Re-bootstraps/migrates [databaseFile], opens a fresh Room instance, validates connectivity,
   * and monotonically increments [databaseGeneration].
   */
  fun reopen(): OrvaDatabase {
    val db =
      synchronized(lock) {
        activeDatabase?.close()
        activeDatabase = null
        openInternal().also { activeDatabase = it }
      }
    _databaseGeneration.update { it + 1L }
    return db
  }

  private fun openInternal(): OrvaDatabase {
    val builder =
      Room.databaseBuilder(
          context.applicationContext,
          OrvaDatabase::class.java,
          databaseFile.absolutePath,
        )
        .setJournalMode(RoomDatabase.JournalMode.WRITE_AHEAD_LOGGING)
        .addCallback(OrvaDatabase.pragmaCallback())
    if (allowMainThreadQueries) {
      builder.allowMainThreadQueries()
    }
    val db = builder.build()
    OrvaSchemaBootstrapper.bootstrapOrMigrate(
      dbFile = databaseFile,
      sqlLoader = sqlLoader,
      roomIdentityHash = db.compiledIdentityHash(),
    )
    // Force immediate open & identity verification so any schema/corruption error fails fast here.
    db.openHelper.writableDatabase
    return db
  }
}
