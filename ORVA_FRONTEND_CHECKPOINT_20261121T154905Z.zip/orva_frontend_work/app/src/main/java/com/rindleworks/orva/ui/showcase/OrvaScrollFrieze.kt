package com.rindleworks.orva.ui.showcase

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rindleworks.orva.R
import com.rindleworks.orva.domain.settings.AppLanguage

/**
 * Shared closing bar (`#101218`) + chalk-white (`#F0F0EC`) scroll-controlled monochrome
 * apothecary frieze with counter-gliding giant ghosted `ORVA.` lettering.
 *
 * Vertical scroll smoothly scrubs the oversized monochrome illustration horizontally from left to
 * right while `ORVA.` counter-glides in the opposite direction. When [reducedMotion] is enabled,
 * both layers stay cleanly centered at `0f`.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun OrvaClosingFriezeSection(
  appVersion: String,
  language: AppLanguage,
  isAboutScreen: Boolean,
  reducedMotion: Boolean,
  viewportHeightPx: Float,
  onStartBilling: () -> Unit,
  onSecondaryNav: () -> Unit,
  onBackToTop: () -> Unit,
  modifier: Modifier = Modifier,
  friezeModifier: Modifier = Modifier,
) {
  var bandTopInWindow by remember { mutableFloatStateOf(viewportHeightPx) }
  var bandHeightPx by remember { mutableFloatStateOf(420f) }

  // Scroll progress [0f..1f] as the frieze band travels across the viewport.
  val rawProgress =
    if (reducedMotion || viewportHeightPx <= 1f) {
      0.5f
    } else {
      val travelSpan = viewportHeightPx + bandHeightPx
      ((viewportHeightPx - bandTopInWindow) / travelSpan).coerceIn(0f, 1f)
    }
  val centeredSigned = (rawProgress - 0.5f) * 2f // [-1f..+1f]
  val density = LocalDensity.current

  Column(
    modifier = modifier
      .fillMaxWidth()
      .background(OrvaShowcaseColors.CanvasSecondary)
  ) {
    HorizontalDivider(thickness = 1.dp, color = OrvaShowcaseColors.Hairline)

    // Anchored dark closing header bar
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 24.dp, vertical = 28.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
      Text(
        text = OrvaShowcaseCopy.closingLine(language),
        fontFamily = OrvaShowcaseFonts.body(language),
        fontSize = 26.sp,
        lineHeight = 32.sp,
        color = OrvaShowcaseColors.InkPrimary,
      )

      FlowRow(
        horizontalArrangement = Arrangement.spacedBy(20.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
      ) {
        FooterActionLink(
          label = OrvaShowcaseCopy.linkStartBilling(language),
          accent = true,
          testTag = "frieze_start_billing",
          onClick = onStartBilling,
        )
        FooterActionLink(
          label =
            if (isAboutScreen) OrvaShowcaseCopy.linkBackToHome(language)
            else OrvaShowcaseCopy.linkAboutUs(language),
          accent = false,
          testTag = if (isAboutScreen) "frieze_back_home" else "frieze_about_us",
          onClick = onSecondaryNav,
        )
        FooterActionLink(
          label = OrvaShowcaseCopy.linkBackToTop(language),
          accent = false,
          testTag = "frieze_back_to_top",
          onClick = onBackToTop,
        )
      }

      Text(
        text = "RINDLE WORKS · ORVA v$appVersion",
        fontFamily = OrvaShowcaseFonts.mono(language),
        fontSize = 11.sp,
        letterSpacing = OrvaShowcaseFonts.tracking(1.4.sp),
        color = OrvaShowcaseColors.InkMuted,
      )
    }

    // Chalk-white monochrome apothecary frieze stage
    Box(
      modifier =
        friezeModifier
          .fillMaxWidth()
          .height(228.dp)
          .background(OrvaShowcaseColors.PaperSheetFront)
          .clipToBounds()
          .onGloballyPositioned { coords ->
            bandTopInWindow = coords.positionInWindow().y
            bandHeightPx = coords.size.height.toFloat().coerceAtLeast(1f)
          },
      contentAlignment = Alignment.Center,
    ) {
      // Layer 1 (Back): Giant low-contrast ghosted ORVA. lettering counter-gliding
      val ghostShiftPx = with(density) { (centeredSigned * -44.dp.toPx()) }
      Text(
        text = "ORVA.",
        fontFamily = OrvaShowcaseFonts.display(AppLanguage.English),
        fontWeight = FontWeight.Bold,
        fontSize = 132.sp,
        letterSpacing = OrvaShowcaseFonts.tracking(AppLanguage.English, (-4).sp),
        maxLines = 1,
        softWrap = false,
        overflow = TextOverflow.Visible,
        color = Color(0x1408090D), // ~8% obsidian ink on chalk
        modifier =
          Modifier
            .wrapContentWidth(unbounded = true)
            .graphicsLayer {
              translationX = ghostShiftPx
            },
      )

      // Layer 2 (Front): Authentic monochrome apothecary_frieze_bw.jpg scrubbed horizontally
      val friezeShiftPx = with(density) { (centeredSigned * 36.dp.toPx()) }
      Image(
        painter = painterResource(id = R.drawable.apothecary_frieze_bw),
        contentDescription =
          if (language == AppLanguage.Bengali) "ORVA ফার্মেসি কাউন্টারের সাদা-কালো অলঙ্করণ"
          else "Monochrome Indian apothecary counter frieze illustration",
        contentScale = ContentScale.Crop,
        colorFilter = ColorFilter.tint(OrvaShowcaseColors.PaperSheetFront, BlendMode.Multiply),
        modifier =
          Modifier
            .fillMaxSize()
            .graphicsLayer {
              scaleX = 1.26f
              scaleY = 1.06f
              translationX = friezeShiftPx
              alpha = 0.92f
            },
      )
    }
  }
}

@Composable
private fun FooterActionLink(
  label: String,
  accent: Boolean,
  testTag: String,
  onClick: () -> Unit,
) {
  Row(
    modifier =
      Modifier
        .minimumInteractiveComponentSize()
        .testTag(testTag)
        .clickable(role = Role.Button, onClick = onClick)
        .padding(vertical = 8.dp),
    verticalAlignment = Alignment.CenterVertically,
  ) {
    Text(
      text = label,
      fontFamily = OrvaShowcaseFonts.body(language),
      fontWeight = FontWeight.Medium,
      fontSize = 14.sp,
      color = if (accent) OrvaShowcaseColors.AccentVioletSoft else OrvaShowcaseColors.InkSecondary,
    )
  }
}
