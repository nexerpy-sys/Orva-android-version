package com.rindleworks.orva.ui.home

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rindleworks.orva.R
import com.rindleworks.orva.domain.settings.AppLanguage
import com.rindleworks.orva.ui.about.agentic.AgenticBuildController
import com.rindleworks.orva.ui.about.agentic.BuildAct
import com.rindleworks.orva.ui.about.agentic.AgenticHudBar
import com.rindleworks.orva.ui.about.agentic.AgenticOverlayCanvas
import com.rindleworks.orva.ui.about.agentic.AgenticTextRole
import com.rindleworks.orva.ui.about.agentic.LayerKind
import com.rindleworks.orva.ui.about.agentic.LocalAgenticController
import com.rindleworks.orva.ui.about.agentic.LocalAgenticMorphRegionId
import com.rindleworks.orva.ui.about.agentic.LocalAgenticThemeMediaMotion
import com.rindleworks.orva.ui.about.agentic.LocalAgenticThemeMotion
import com.rindleworks.orva.ui.about.agentic.OrvaDesignTheme
import com.rindleworks.orva.ui.about.agentic.OrvaThemeCatalog
import com.rindleworks.orva.ui.about.agentic.OrvaThemeSpec
import com.rindleworks.orva.ui.about.agentic.ThemeLayoutGrammar
import com.rindleworks.orva.ui.about.agentic.ThemeMediaMotion
import com.rindleworks.orva.ui.about.agentic.agenticNode
import com.rindleworks.orva.ui.about.agentic.rememberAgenticTextLayoutHandler
import com.rindleworks.orva.ui.showcase.LocalShowcasePalette
import com.rindleworks.orva.ui.showcase.ShowcasePalette
import com.rindleworks.orva.ui.showcase.FolderCopy
import com.rindleworks.orva.ui.showcase.HomeShowcaseUiState
import com.rindleworks.orva.ui.showcase.OrvaClosingFriezeSection
import com.rindleworks.orva.ui.showcase.OrvaShowcaseCopy
import com.rindleworks.orva.ui.showcase.OrvaShowcaseFonts
import com.rindleworks.orva.ui.showcase.LocalOrvaShowcaseLanguage
import com.rindleworks.orva.ui.showcase.LocalOrvaShowcaseTheme
import com.rindleworks.orva.ui.showcase.ShowcaseUiEvent
import com.rindleworks.orva.ui.showcase.currentShowcasePalette
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.collect
import android.content.Context
import android.os.Vibrator

/**
 * Rindle Works × ORVA Home Screen (Master Frontend Build Directive §3).
 *
 * Art-directed dark editorial entry:
 * - H1: Near-fullscreen Rindle Works hero (`BUILT AROUND THE WORK.`) with monochrome architecture
 *   and quiet local readiness strip.
 * - H2: Darkness-first neutral chalk/violet touch lantern over monochrome apothecary shelving.
 * - H3: Scroll-linked cinematic image crop/scale + oversized integrated typography.
 * - H4: Flagship ORVA product panel (`IN ACTIVE DEVELOPMENT`, honest scope).
 * - H5: Three layered editorial document panels (`PRODUCT`, `CRAFT`, `ENGINEERING`).
 * - H6: Shared monochrome apothecary frieze & closing navigation.
 */
private val LocalHomeThemeSpec = compositionLocalOf {
  OrvaThemeCatalog.get(OrvaDesignTheme.MEASURED_PRESS)
}

@Composable
fun HomeScreen(
  state: HomeShowcaseUiState,
  reducedMotion: Boolean,
  onEvent: (ShowcaseUiEvent) -> Unit,
  modifier: Modifier = Modifier,
) {
  val scrollState = rememberScrollState()
  val scope = rememberCoroutineScope()
  val density = LocalDensity.current
  val lifecycleOwner = LocalLifecycleOwner.current
  val controller = remember(scrollState) {
    AgenticBuildController(scrollState = scrollState, reducedMotion = reducedMotion)
  }
  SideEffect { controller.updateReducedMotion(reducedMotion) }

  var viewportHeightPx by remember { mutableFloatStateOf(1600f) }
  var lastSealHapticCount by remember(controller) { mutableIntStateOf(0) }

  DisposableEffect(lifecycleOwner, controller) {
    controller.onLifecyclePaused(!lifecycleOwner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED))
    val observer = LifecycleEventObserver { _, event ->
      when (event) {
        Lifecycle.Event.ON_PAUSE, Lifecycle.Event.ON_STOP -> controller.onLifecyclePaused(true)
        Lifecycle.Event.ON_RESUME -> controller.onLifecyclePaused(false)
        else -> Unit
      }
    }
    lifecycleOwner.lifecycle.addObserver(observer)
    onDispose {
      controller.onLifecyclePaused(true)
      lifecycleOwner.lifecycle.removeObserver(observer)
    }
  }

  LaunchedEffect(controller) { controller.runOrchestrator(this) }
  LaunchedEffect(controller, scrollState) {
    snapshotFlow { scrollState.value }.collect(controller::onObservedScrollPosition)
  }

  val hapticFeedback = LocalHapticFeedback.current
  val context = LocalContext.current
  val localView = LocalView.current
  val vibrator = remember(context) { context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator }
  val hapticsAvailable = localView.isHapticFeedbackEnabled && vibrator?.hasVibrator() == true
  LaunchedEffect(controller, controller.sceneSealHapticTickCount, reducedMotion, hapticsAvailable) {
    val pendingTicks = (controller.sceneSealHapticTickCount - lastSealHapticCount).coerceAtLeast(0)
    if (!reducedMotion && hapticsAvailable) repeat(pendingTicks.coerceAtMost(6)) {
      hapticFeedback.performHapticFeedback(HapticFeedbackType.TextHandleMove)
    }
    lastSealHapticCount = controller.sceneSealHapticTickCount
  }

  val scrollProgress = if (scrollState.maxValue > 0) {
    (scrollState.value.toFloat() / scrollState.maxValue.toFloat()).coerceIn(0f, 1f)
  } else 0f
  val committedThemeSpec = remember(controller.themeMorphSnapshot.committedTheme) {
    OrvaThemeCatalog.get(controller.themeMorphSnapshot.committedTheme)
  }
  val palette = remember(committedThemeSpec) { homePaletteForTheme(committedThemeSpec) }

  CompositionLocalProvider(
    LocalAgenticController provides controller,
    LocalShowcasePalette provides palette,
    LocalHomeThemeSpec provides committedThemeSpec,
    LocalOrvaShowcaseTheme provides committedThemeSpec.id,
    LocalOrvaShowcaseLanguage provides state.language,
  ) {
    Box(
      modifier = modifier
        .fillMaxSize()
        .background(palette.canvasDeep)
        .onGloballyPositioned { controller.stageRootTopInRootPx = it.positionInRoot().y }
        .onSizeChanged {
          viewportHeightPx = it.height.toFloat().coerceAtLeast(1f)
          controller.onViewportSized(it.width.toFloat(), viewportHeightPx, density.density)
        }
        .pointerInput(controller) {
          awaitEachGesture {
            val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
            var manualOwnershipGranted = false
            while (true) {
              val event = awaitPointerEvent(pass = PointerEventPass.Initial)
              val change = event.changes.firstOrNull { it.id == down.id }
              if (change == null || !change.pressed) break
              val dx = change.position.x - down.position.x
              val dy = change.position.y - down.position.y
              if (!manualOwnershipGranted && kotlin.math.abs(dy) > viewConfiguration.touchSlop &&
                kotlin.math.abs(dy) > kotlin.math.abs(dx)
              ) {
                controller.onUserManualScroll()
                manualOwnershipGranted = true
              }
            }
          }
        },
    ) {
      Column(
        modifier = Modifier.fillMaxSize().verticalScroll(scrollState).padding(bottom = 104.dp).testTag("home_scroll_container"),
      ) {
        HomeThemeRegion(sceneIndex = 1) {
          HomeEditorialHeroSection(
            state = state,
            scrollPxProvider = { scrollState.value.toFloat() },
            reducedMotion = reducedMotion,
            onExploreOrva = { onEvent(ShowcaseUiEvent.StartBilling) },
            onOpenStudio = { onEvent(ShowcaseUiEvent.OpenAboutUs) },
            onAddStock = { onEvent(ShowcaseUiEvent.AddStock) },
          )
        }
        HomeThemeRegion(sceneIndex = 2) {
          HomeLanternSurfaceSection(language = state.language, reducedMotion = reducedMotion)
        }
        HomeThemeRegion(sceneIndex = 3) {
          HomeCinematicScrollSection(
            language = state.language,
            reducedMotion = reducedMotion,
            viewportHeightPx = viewportHeightPx,
          )
        }
        HomeThemeRegion(sceneIndex = 4) {
          HomeFlagshipOrvaSection(
            state = state,
            onExploreProduct = { onEvent(ShowcaseUiEvent.StartBilling) },
            onOpenStudio = { onEvent(ShowcaseUiEvent.OpenAboutUs) },
          )
        }
        HomeThemeRegion(sceneIndex = 5) {
          HomeLayeredPanelsSection(
            state = state,
            reducedMotion = reducedMotion,
            onPanelAction = { id ->
              when (id) {
                "quick_billing" -> onEvent(ShowcaseUiEvent.StartBilling)
                "expiry_stock" -> onEvent(ShowcaseUiEvent.OpenInventory)
                "about_orva" -> onEvent(ShowcaseUiEvent.OpenAboutUs)
              }
            },
          )
        }
        HomeThemeRegion(sceneIndex = 6) {
          OrvaClosingFriezeSection(
            appVersion = state.appVersion,
            language = state.language,
            isAboutScreen = false,
            reducedMotion = reducedMotion,
            viewportHeightPx = viewportHeightPx,
            onStartBilling = { onEvent(ShowcaseUiEvent.StartBilling) },
            onSecondaryNav = { onEvent(ShowcaseUiEvent.OpenAboutUs) },
            onBackToTop = {
              controller.onUserManualScroll()
              scope.launch {
                if (reducedMotion) scrollState.scrollTo(0)
                else scrollState.animateScrollTo(0, tween(520, easing = FastOutSlowInEasing))
              }
            },
            friezeModifier = Modifier.agenticNode(id = "home_h6_frieze_media", kind = LayerKind.MEDIA),
          )
        }
      }

      Box(
        modifier = Modifier.align(Alignment.TopStart)
          .fillMaxWidth(scrollProgress)
          .height(1.5.dp)
          .background(Brush.horizontalGradient(listOf(palette.accent, palette.signal))),
      )
      AgenticOverlayCanvas(controller = controller, modifier = Modifier.matchParentSize())
      AgenticHudBar(controller = controller, language = state.language, modifier = Modifier.align(Alignment.BottomCenter))
    }
  }
}

@Composable
private fun HomeThemeRegion(sceneIndex: Int, content: @Composable () -> Unit) {
  val controller = LocalAgenticController.current
  val regionId = "home-scene-%02d".format(sceneIndex)
  val theme = controller?.themeForRegion(regionId) ?: OrvaDesignTheme.MEASURED_PRESS
  val spec = remember(theme) { OrvaThemeCatalog.get(theme) }
  val palette = remember(spec) { homePaletteForTheme(spec) }
  val backplateId = "home_h${sceneIndex}_backplate"
  val contentId = "home_h${sceneIndex}_content"
  val frame = when (spec.layoutGrammar) {
    ThemeLayoutGrammar.PROOF_PRESS -> Modifier.drawBehind {
      val mark = 7.dp.toPx()
      drawLine(palette.hairline, Offset.Zero, Offset(size.width, 0f), 1.dp.toPx())
      drawLine(palette.accent, Offset.Zero, Offset(mark, 0f), 1.dp.toPx())
      drawLine(palette.accent, Offset.Zero, Offset(0f, mark), 1.dp.toPx())
    }
    ThemeLayoutGrammar.SPECIMEN_FIELD -> Modifier.drawBehind {
      drawRect(palette.hairline, style = Stroke(1.dp.toPx()))
      drawLine(palette.accent, Offset.Zero, Offset(8.dp.toPx(), 0f), 1.dp.toPx())
    }
    ThemeLayoutGrammar.MUSEUM_CATALOGUE -> Modifier.drawBehind {
      val x = 14.dp.toPx()
      drawLine(palette.hairline, Offset(x, 0f), Offset(x, size.height), 1.dp.toPx())
      var y = 0f
      while (y <= size.height) {
        drawLine(palette.accent.copy(alpha = 0.72f), Offset(x - 6.dp.toPx(), y), Offset(x + 2.dp.toPx(), y), 0.8.dp.toPx())
        y += 48.dp.toPx()
      }
    }
  }
  val inset = when (spec.layoutGrammar) {
    ThemeLayoutGrammar.PROOF_PRESS -> Modifier
    ThemeLayoutGrammar.SPECIMEN_FIELD -> Modifier.padding(horizontal = 18.dp, vertical = 12.dp)
    ThemeLayoutGrammar.MUSEUM_CATALOGUE -> Modifier.padding(start = 30.dp)
  }
  CompositionLocalProvider(
    LocalHomeThemeSpec provides spec,
    LocalOrvaShowcaseTheme provides spec.id,
    LocalShowcasePalette provides palette,
    LocalAgenticThemeMotion provides spec.headlineMotion,
    LocalAgenticThemeMediaMotion provides spec.mediaMotion,
    LocalAgenticMorphRegionId provides regionId,
  ) {
    Box(Modifier.fillMaxWidth().then(frame)) {
      Box(
        Modifier.matchParentSize().background(palette.canvasDeep)
          .agenticNode(id = backplateId, kind = LayerKind.CONTAINER),
      )
      val contentTreatment = when (spec.layoutGrammar) {
        ThemeLayoutGrammar.PROOF_PRESS -> Modifier
        ThemeLayoutGrammar.SPECIMEN_FIELD -> Modifier
          .background(palette.canvasSecondary)
          .drawBehind {
            val edge = 5.dp.toPx()
            drawLine(palette.accent, Offset.Zero, Offset(edge, 0f), 1.2.dp.toPx())
            drawLine(palette.accent, Offset.Zero, Offset(0f, edge), 1.2.dp.toPx())
          }
        ThemeLayoutGrammar.MUSEUM_CATALOGUE -> Modifier.drawBehind {
          val insetX = 10.dp.toPx()
          drawLine(palette.hairline, Offset(insetX, 0f), Offset(insetX, size.height), 1.dp.toPx())
          var y = 0f
          while (y < size.height) {
            drawLine(palette.signal, Offset(insetX - 3.dp.toPx(), y), Offset(insetX + 3.dp.toPx(), y), 0.8.dp.toPx())
            y += 32.dp.toPx()
          }
        }
      }
      Box(
        Modifier.fillMaxWidth().then(inset).then(contentTreatment)
          .agenticNode(id = contentId, kind = LayerKind.CONTAINER, parentId = backplateId),
      ) { content() }
    }
  }
}

private fun homePaletteForTheme(spec: OrvaThemeSpec): ShowcasePalette {
  fun colour(hex: String) = Color(android.graphics.Color.parseColor(hex))
  val text = colour(spec.colours.text)
  val surface = colour(spec.colours.surface)
  return ShowcasePalette(
    canvasDeep = colour(spec.colours.background),
    canvasSecondary = surface,
    surfaceRaised = surface,
    inkPrimary = text,
    inkSecondary = text.copy(alpha = 0.82f),
    inkMuted = text.copy(alpha = 0.72f),
    hairline = text.copy(alpha = 0.20f),
    agentTagSurface = surface.copy(alpha = 0.94f),
    accent = colour(spec.colours.accent),
    signal = colour(spec.colours.signal),
  )
}

@Composable
private fun currentHomeThemeSpec(): OrvaThemeSpec = LocalHomeThemeSpec.current

@Composable
private fun homeDisplaySize(baseSp: Float) =
  (baseSp * currentHomeThemeSpec().type.scaleRatio / 1.333f).sp

@Composable
private fun homeBodySize() = currentHomeThemeSpec().type.bodySp.sp

@Composable
private fun homeBodyLineHeight() = currentHomeThemeSpec().type.bodyLineHeightSp.sp

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun HomeEditorialHeroSection(
  state: HomeShowcaseUiState,
  scrollPxProvider: () -> Float,
  reducedMotion: Boolean,
  onExploreOrva: () -> Unit,
  onOpenStudio: () -> Unit,
  onAddStock: () -> Unit,
) {
  val palette = currentShowcasePalette()
  BoxWithConstraints(
    modifier =
      Modifier
        .fillMaxWidth()
        .background(palette.canvasDeep)
        .clipToBounds(),
  ) {
    // Scale the display face to the actual phone width; the hero must not force awkward
    // mid-word wrapping on compact devices or look undersized on larger screens.
    val heroTitleSize =
      when {
        maxWidth < 380.dp -> currentHomeThemeSpec().type.heroCompactSp.sp
        maxWidth < 640.dp -> currentHomeThemeSpec().type.heroStandardSp.sp
        else -> currentHomeThemeSpec().type.heroTabletSp.sp
      }
    // Monochrome architectural hero photography with subtle scroll scale/parallax
    Image(
      painter = painterResource(id = R.drawable.editorial_architecture_light),
      contentDescription = null,
      contentScale = ContentScale.Crop,
      alpha = 0.34f,
      modifier =
        Modifier
          .matchParentSize()
          .graphicsLayer {
            val scroll = if (reducedMotion) 0f else scrollPxProvider().coerceIn(0f, 800f)
            val p = scroll / 800f
            scaleX = 1.04f + p * 0.12f
            scaleY = 1.04f + p * 0.12f
            translationY = scroll * 0.22f
          }
          .agenticNode(id = "home_h1_architecture_media", kind = LayerKind.MEDIA, parentId = "home_h1_content"),
    )

    // Editorial bottom-heavy dark vignette for razor-sharp type legibility
    Box(
      modifier =
        Modifier
          .matchParentSize()
          .background(
            Brush.verticalGradient(
              0.0f to palette.canvasDeep.copy(alpha = 0.48f),
              0.55f to palette.canvasDeep.copy(alpha = 0.72f),
              1.0f to palette.canvasDeep,
            )
          ),
    )

    val heroFrame = when (currentHomeThemeSpec().layoutGrammar) {
      ThemeLayoutGrammar.PROOF_PRESS -> Modifier
        .padding(horizontal = 24.dp, vertical = 44.dp)
        .drawBehind {
          val x = 0f
          val y = size.height - 1.dp.toPx()
          drawLine(palette.hairline, Offset(x, y), Offset(size.width, y), 1.dp.toPx())
          drawLine(palette.accent, Offset(x, y), Offset(44.dp.toPx(), y), 1.dp.toPx())
        }
      ThemeLayoutGrammar.SPECIMEN_FIELD -> Modifier
        .padding(horizontal = 18.dp, vertical = 30.dp)
        .background(palette.canvasSecondary)
        .border(1.dp, palette.hairline)
        .padding(horizontal = 22.dp, vertical = 22.dp)
      ThemeLayoutGrammar.MUSEUM_CATALOGUE -> Modifier
        .padding(start = 42.dp, end = 20.dp, top = 48.dp, bottom = 48.dp)
        .drawBehind {
          val x = 9.dp.toPx()
          drawLine(palette.hairline, Offset(x, 0f), Offset(x, size.height), 1.dp.toPx())
          var y = 0f
          while (y < size.height) {
            drawLine(palette.accent, Offset(x - 4.dp.toPx(), y), Offset(x + 4.dp.toPx(), y), 0.8.dp.toPx())
            y += 24.dp.toPx()
          }
        }
    }
    val heroSpacing = when (currentHomeThemeSpec().layoutGrammar) {
      ThemeLayoutGrammar.PROOF_PRESS -> 20.dp
      ThemeLayoutGrammar.SPECIMEN_FIELD -> 16.dp
      ThemeLayoutGrammar.MUSEUM_CATALOGUE -> 26.dp
    }
    Column(
      modifier =
        Modifier
          .fillMaxWidth()
          .widthIn(max = 960.dp)
          .align(Alignment.Center)
          .then(heroFrame)
          .graphicsLayer {
            // zll.me hero scroll parallax scale-up & fade (zero recompositions)
            val scroll = if (reducedMotion) 0f else scrollPxProvider().coerceIn(0f, 760f)
            val p = scroll / 760f
            val s = 1f + p * 0.07f
            scaleX = s
            scaleY = s
            translationY = -scroll * 0.08f
            alpha = (1f - p * 0.82f).coerceIn(0.18f, 1f)
          },
      verticalArrangement = Arrangement.spacedBy(heroSpacing),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          Box(
            modifier =
              Modifier
                .size(6.dp)
                .clip(CircleShape)
                .background(palette.accent),
          )
          Text(
            text = OrvaShowcaseCopy.homeEyebrow(state.language),
            fontFamily = OrvaShowcaseFonts.mono(state.language),
            fontSize = 10.5.sp,
            letterSpacing = OrvaShowcaseFonts.tracking(1.6.sp),
            color = palette.inkSecondary,
          )
        }
        Text(
          text = OrvaShowcaseCopy.homeHeroSectionIndex(state.language),
          fontFamily = OrvaShowcaseFonts.mono(state.language),
          fontSize = 10.5.sp,
          letterSpacing = OrvaShowcaseFonts.tracking(1.4.sp),
          color = palette.inkMuted,
          modifier = Modifier.testTag("home_hero_section_index"),
        )
      }

      Spacer(Modifier.height(36.dp))

      // Monumental condensed-style display headline
      Column(
        modifier = Modifier.testTag("home_hero_headline"),
        verticalArrangement = Arrangement.spacedBy(2.dp),
      ) {
        Text(
          text = OrvaShowcaseCopy.homeHeadlineTop(state.language),
          onTextLayout = rememberAgenticTextLayoutHandler("home_h1_headline_top"),
          fontFamily = OrvaShowcaseFonts.display(state.language),
          fontWeight = FontWeight.Bold,
          fontSize = heroTitleSize,
          lineHeight = heroTitleSize,
          letterSpacing = OrvaShowcaseFonts.tracking((-1.4).sp),
          color = palette.inkPrimary,
          modifier = Modifier.agenticNode(
            id = "home_h1_headline_top", kind = LayerKind.TEXT,
            parentId = "home_h1_content", textRole = AgenticTextRole.DISPLAY,
          ),
        )
        Text(
          text = OrvaShowcaseCopy.homeHeadlineItalic(state.language),
          onTextLayout = rememberAgenticTextLayoutHandler("home_h1_headline_italic"),
          fontFamily = OrvaShowcaseFonts.display(state.language),
          fontWeight = FontWeight.Bold,
          fontSize = heroTitleSize,
          lineHeight = heroTitleSize,
          letterSpacing = OrvaShowcaseFonts.tracking((-1.4).sp),
          color = palette.accent,
          modifier = Modifier.agenticNode(
            id = "home_h1_headline_italic", kind = LayerKind.TEXT,
            parentId = "home_h1_content", textRole = AgenticTextRole.DISPLAY,
          ),
        )
      }

      Text(
        text = OrvaShowcaseCopy.homeSubtitle(state.language),
        onTextLayout = rememberAgenticTextLayoutHandler("home_h1_subtitle"),
        fontFamily = OrvaShowcaseFonts.body(state.language),
        fontSize = homeBodySize(),
        lineHeight = homeBodyLineHeight(),
        color = palette.inkSecondary,
        modifier = Modifier.widthIn(max = 520.dp).agenticNode(
          id = "home_h1_subtitle", kind = LayerKind.TEXT,
          parentId = "home_h1_content", textRole = AgenticTextRole.READING,
        ),
      )

      Spacer(Modifier.height(6.dp))

      // Primary & secondary actions
      FlowRow(
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        Button(
          onClick = onExploreOrva,
          colors =
            ButtonDefaults.buttonColors(
              containerColor = palette.inkPrimary,
              contentColor = palette.canvasDeep,
            ),
          shape = RoundedCornerShape(2.dp),
          contentPadding = PaddingValues(horizontal = 20.dp, vertical = 14.dp),
          modifier = Modifier.minimumInteractiveComponentSize().testTag("home_start_billing_btn"),
        ) {
          Text(
            text = OrvaShowcaseCopy.startBillingCta(state.language),
            fontFamily = OrvaShowcaseFonts.mono(state.language),
            fontWeight = FontWeight.SemiBold,
            fontSize = 12.sp,
            letterSpacing = OrvaShowcaseFonts.tracking(1.2.sp),
          )
        }

        OutlinedButton(
          onClick = onOpenStudio,
          border = BorderStroke(1.dp, palette.hairline),
          colors =
            ButtonDefaults.outlinedButtonColors(
              containerColor = palette.canvasSecondary.copy(alpha = 0.72f),
              contentColor = palette.inkPrimary,
            ),
          shape = RoundedCornerShape(2.dp),
          contentPadding = PaddingValues(horizontal = 18.dp, vertical = 14.dp),
          modifier = Modifier.minimumInteractiveComponentSize().testTag("home_studio_btn"),
        ) {
          Text(
            text = OrvaShowcaseCopy.studioSecondaryCta(state.language),
            fontFamily = OrvaShowcaseFonts.mono(state.language),
            fontWeight = FontWeight.Medium,
            fontSize = 12.sp,
            letterSpacing = OrvaShowcaseFonts.tracking(1.2.sp),
          )
        }

        OutlinedButton(
          onClick = onAddStock,
          border = BorderStroke(1.dp, palette.hairline),
          colors =
            ButtonDefaults.outlinedButtonColors(
              containerColor = Color.Transparent,
              contentColor = palette.inkSecondary,
            ),
          shape = RoundedCornerShape(2.dp),
          contentPadding = PaddingValues(horizontal = 14.dp, vertical = 14.dp),
          modifier = Modifier.minimumInteractiveComponentSize().testTag("home_add_stock_btn"),
        ) {
          Text(
            text = OrvaShowcaseCopy.addStockCta(state.language),
            fontFamily = OrvaShowcaseFonts.mono(state.language),
            fontSize = 11.5.sp,
            letterSpacing = OrvaShowcaseFonts.tracking(1.sp),
          )
        }
      }

      Spacer(Modifier.height(14.dp))
      HorizontalDivider(thickness = 1.dp, color = palette.hairline)

      // Live local shop readiness strip (real SQLite state — never fake telemetry)
      Text(
        text =
          OrvaShowcaseCopy.readinessStrip(
            shopName = state.shopName,
            usableMedicines = state.usableMedicineCount,
            expiringSoonCount = state.expiringSoonCount,
            backupState = state.backupStatus,
            language = state.language,
          ),
        fontFamily = OrvaShowcaseFonts.mono(state.language),
        fontSize = 11.sp,
        lineHeight = 18.sp,
        letterSpacing = OrvaShowcaseFonts.tracking(0.5.sp),
        color = palette.inkMuted,
        modifier = Modifier.testTag("home_readiness_strip"),
      )
    }
  }
}

/**
 * H2 — Darkness-First Lantern Surface (Master Directive §3.2).
 * Neutral chalk/violet light pool reveals monochrome apothecary shelving without trapping scroll.
 */
@Composable
private fun HomeLanternSurfaceSection(
  language: AppLanguage,
  reducedMotion: Boolean,
) {
  val palette = currentShowcasePalette()
  var lanternPos by remember { mutableStateOf<Offset?>(null) }
  var lanternActive by remember { mutableStateOf(false) }
  val lanternIntensity = remember { Animatable(0.32f) }
  val lanternSweep = remember { Animatable(0f) }
  var lanternSweepPlayed by remember { mutableStateOf(false) }
  val agenticController = LocalAgenticController.current
  val lanternMotion = LocalAgenticThemeMediaMotion.current
  val lanternLayout = currentHomeThemeSpec().layoutGrammar
  val themeId = currentHomeThemeSpec().id
  val activeMorphRegion = agenticController?.themeMorphSnapshot?.activeRegionId
  val activeMorphPhase = agenticController?.themeMorphSnapshot?.activeRegionPhase
  var lastLanternTheme by remember { mutableStateOf(themeId) }

  LaunchedEffect(agenticController?.act, themeId, activeMorphRegion, activeMorphPhase, reducedMotion) {
    val initialBuildFinished = agenticController?.act == BuildAct.COMPLETED && !lanternSweepPlayed
    val h2WasRebuilt = activeMorphRegion == "home-scene-02" &&
      activeMorphPhase == com.rindleworks.orva.ui.about.agentic.MorphRegionPhase.DISPENSING &&
      themeId != lastLanternTheme
    if (initialBuildFinished || h2WasRebuilt) {
      lanternSweepPlayed = true
      lastLanternTheme = themeId
      if (reducedMotion) lanternSweep.snapTo(1f)
      else {
        lanternSweep.snapTo(0f)
        lanternSweep.animateTo(1f, tween(1250, easing = FastOutSlowInEasing))
      }
    }
  }

  LaunchedEffect(lanternActive, reducedMotion) {
    val target =
      when {
        reducedMotion -> 0.48f
        lanternActive -> 1f
        else -> when (currentHomeThemeSpec().layoutGrammar) {
          ThemeLayoutGrammar.PROOF_PRESS -> 0.28f
          ThemeLayoutGrammar.SPECIMEN_FIELD -> 0.36f
          ThemeLayoutGrammar.MUSEUM_CATALOGUE -> 0.24f
        }
      }
    lanternIntensity.animateTo(
      targetValue = target,
      animationSpec = tween(durationMillis = if (lanternActive) 140 else 320),
    )
  }

  Column(
    modifier =
      Modifier
        .fillMaxWidth()
        .widthIn(max = 960.dp)
        .padding(horizontal = 24.dp, vertical = 20.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Text(
        text = OrvaShowcaseCopy.lanternEyebrow(language),
        fontFamily = OrvaShowcaseFonts.mono(language),
        fontSize = 10.5.sp,
        letterSpacing = OrvaShowcaseFonts.tracking(1.5.sp),
        color = palette.inkMuted,
        modifier = Modifier.testTag("home_lantern_eyebrow"),
      )
      Text(
        text = OrvaShowcaseCopy.lanternHint(language),
        fontFamily = OrvaShowcaseFonts.mono(language),
        fontSize = 10.sp,
        letterSpacing = OrvaShowcaseFonts.tracking(1.2.sp),
        color = palette.signal,
      )
    }

    BoxWithConstraints(
      modifier =
        Modifier
          .fillMaxWidth()
          .height(340.dp)
          .border(1.dp, palette.hairline)
          .background(palette.canvasDeep)
          .clipToBounds()
          .pointerInput(reducedMotion) {
            if (reducedMotion) return@pointerInput
            awaitEachGesture {
              val down = awaitFirstDown(requireUnconsumed = false)
              lanternPos = down.position
              lanternActive = true
              try {
                while (true) {
                  val event = awaitPointerEvent()
                  val activeChange = event.changes.firstOrNull { it.pressed }
                  if (activeChange != null) {
                    lanternPos = activeChange.position
                  } else {
                    break
                  }
                }
              } finally {
                lanternActive = false
              }
            }
          },
    ) {
      // The photograph stays on the base layer. Only the dark veil is rendered offscreen, so
      // DstOut clears the veil and reveals the intact image beneath it (never the image itself).
      Image(
        painter = painterResource(id = R.drawable.editorial_apothecary_shelves),
        contentDescription = OrvaShowcaseCopy.lanternImageDescription(language),
        contentScale = ContentScale.Crop,
        modifier = Modifier.fillMaxSize().agenticNode(
          id = "home_h2_shelves_media", kind = LayerKind.MEDIA, parentId = "home_h2_content",
        ),
      )

      Canvas(
        modifier =
          Modifier
            .fillMaxSize()
            .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen },
      ) {
        val intensity = lanternIntensity.value.coerceIn(0f, 1f)
        drawRect(color = palette.canvasDeep.copy(alpha = 0.88f))
        // Neutral chalk/violet feathered spotlight (zero yellow/amber).
        val layout = lanternLayout
        val focus = lanternPos ?: when (layout) {
          ThemeLayoutGrammar.PROOF_PRESS -> Offset(size.width * 0.56f, size.height * 0.44f)
          ThemeLayoutGrammar.SPECIMEN_FIELD -> Offset(size.width * 0.50f, size.height * 0.50f)
          ThemeLayoutGrammar.MUSEUM_CATALOGUE -> Offset(size.width * 0.58f, size.height * 0.46f)
        }
        val radius = (size.minDimension * when (layout) {
          ThemeLayoutGrammar.PROOF_PRESS -> 0.52f
          ThemeLayoutGrammar.SPECIMEN_FIELD -> 0.40f
          ThemeLayoutGrammar.MUSEUM_CATALOGUE -> 0.34f
        }).coerceAtLeast(128f)
        val light = Brush.radialGradient(
          0.0f to Color.White.copy(alpha = 0.94f * intensity),
          0.42f to palette.signal.copy(alpha = 0.55f * intensity),
          0.78f to Color.White.copy(alpha = 0.14f * intensity),
          1.0f to Color.Transparent,
          center = focus,
          radius = radius,
        )
        if (layout == ThemeLayoutGrammar.MUSEUM_CATALOGUE) {
          val beamWidth = size.width * 0.48f
          drawOval(
            brush = light,
            topLeft = Offset(focus.x - beamWidth / 2f, focus.y - radius * 0.72f),
            size = androidx.compose.ui.geometry.Size(beamWidth, radius * 1.44f),
            blendMode = BlendMode.DstOut,
          )
        } else {
          drawCircle(brush = light, radius = radius, center = focus, blendMode = BlendMode.DstOut)
        }
      }

      val wordmarkSize = when {
        maxWidth < 380.dp -> currentHomeThemeSpec().type.heroCompactSp.sp
        maxWidth < 640.dp -> currentHomeThemeSpec().type.heroStandardSp.sp
        else -> currentHomeThemeSpec().type.heroTabletSp.sp
      }
      Box(
        modifier = Modifier.fillMaxWidth().align(Alignment.Center).height(132.dp),
        contentAlignment = Alignment.Center,
      ) {
        Text(
          text = "ORVA",
          fontFamily = OrvaShowcaseFonts.display(language),
          fontWeight = FontWeight.Bold,
          fontSize = wordmarkSize,
          lineHeight = wordmarkSize,
          letterSpacing = OrvaShowcaseFonts.tracking((-2.8).sp),
          color = Color.White.copy(alpha = if (reducedMotion) 0.90f else 0.46f),
          modifier = Modifier.agenticNode(
            id = "home_h2_orva_wordmark", kind = LayerKind.TEXT,
            parentId = "home_h2_content", textRole = AgenticTextRole.DISPLAY,
          ),
        )
        if (!reducedMotion && lanternSweepPlayed) {
          Text(
            text = "ORVA",
            fontFamily = OrvaShowcaseFonts.display(language),
            fontWeight = FontWeight.Bold,
            fontSize = wordmarkSize,
            lineHeight = wordmarkSize,
            letterSpacing = OrvaShowcaseFonts.tracking((-2.8).sp),
            color = Color.White,
            modifier = Modifier.drawWithContent {
              val progress = lanternSweep.value.coerceIn(0f, 1f)
              when (lanternMotion) {
                ThemeMediaMotion.HORIZONTAL_SCAN -> {
                  val edge = size.width * progress
                  clipRect(left = 0f, top = 0f, right = edge, bottom = size.height) { drawContent() }
                }
                ThemeMediaMotion.FOIL_PRESS -> {
                  val halfWidth = size.width * progress * 0.5f
                  val center = size.width * 0.5f
                  clipRect(left = center - halfWidth, right = center + halfWidth) { drawContent() }
                }
                ThemeMediaMotion.CATALOGUE_LIFT -> {
                  val top = size.height * (1f - progress)
                  clipRect(left = 0f, top = top, right = size.width, bottom = size.height) { drawContent() }
                }
              }
            },
          )
        }
      }

      Text(
        text = OrvaShowcaseCopy.lanternCaption(language),
        fontFamily = OrvaShowcaseFonts.mono(language),
        fontSize = 10.sp,
        letterSpacing = OrvaShowcaseFonts.tracking(1.4.sp),
        color = palette.inkPrimary.copy(alpha = 0.72f),
        modifier =
          Modifier
            .testTag("home_lantern_caption")
            .align(Alignment.BottomStart)
            .background(palette.canvasDeep.copy(alpha = 0.72f))
            .padding(horizontal = 10.dp, vertical = 6.dp),
      )
    }
  }
}

/**
 * H3 — Scroll-Linked Cinematic Image & Typography Composition (Master Directive §3.3).
 */
@Composable
private fun HomeCinematicScrollSection(
  language: AppLanguage,
  reducedMotion: Boolean,
  viewportHeightPx: Float,
) {
  val palette = currentShowcasePalette()
  var bandTopInWindow by remember { mutableFloatStateOf(viewportHeightPx) }
  var bandHeightPx by remember { mutableFloatStateOf(520f) }

  val progress =
    if (reducedMotion || viewportHeightPx <= 1f) {
      0.5f
    } else {
      val span = viewportHeightPx + bandHeightPx
      ((viewportHeightPx - bandTopInWindow) / span).coerceIn(0f, 1f)
    }

  Column(
    modifier =
      Modifier
        .fillMaxWidth()
        .padding(vertical = 36.dp)
        .onGloballyPositioned { coords ->
          bandTopInWindow = coords.positionInWindow().y
          bandHeightPx = coords.size.height.toFloat().coerceAtLeast(1f)
        },
    verticalArrangement = Arrangement.spacedBy(20.dp),
  ) {
    HorizontalDivider(thickness = 1.dp, color = palette.hairline)

    Box(
      modifier =
        Modifier
          .fillMaxWidth()
          .height(310.dp)
          .clipToBounds()
          .background(palette.canvasSecondary),
    ) {
      Image(
        painter = painterResource(id = R.drawable.editorial_thermal_counter),
        contentDescription = OrvaShowcaseCopy.precisionImageDescription(language),
        contentScale = ContentScale.Crop,
        modifier =
          Modifier
            .fillMaxSize()
            .testTag("home_precision_image")
            .graphicsLayer {
              val s = 1.18f - progress * 0.14f
              scaleX = s
              scaleY = s
              translationY = (progress - 0.5f) * -36f
              alpha = 0.58f
            }
            .agenticNode(id = "home_h3_precision_media", kind = LayerKind.MEDIA, parentId = "home_h3_content"),
      )

      Box(
        modifier =
          Modifier
            .fillMaxSize()
            .background(
              Brush.horizontalGradient(
                0.0f to palette.canvasDeep.copy(alpha = 0.88f),
                0.65f to palette.canvasDeep.copy(alpha = 0.42f),
                1.0f to palette.canvasDeep.copy(alpha = 0.72f),
              )
            ),
      )

      Column(
        modifier =
          Modifier
            .align(Alignment.CenterStart)
            .padding(horizontal = 24.dp)
            .graphicsLayer {
              translationX = if (reducedMotion) 0f else (progress - 0.5f) * 28f
            },
        verticalArrangement = Arrangement.spacedBy(4.dp),
      ) {
        Text(
          text = OrvaShowcaseCopy.precisionEyebrow(language),
          fontFamily = OrvaShowcaseFonts.mono(language),
          fontSize = 10.5.sp,
          letterSpacing = OrvaShowcaseFonts.tracking(1.6.sp),
          color = palette.accent,
          modifier = Modifier.testTag("home_precision_eyebrow"),
        )
        Text(
          text = OrvaShowcaseCopy.homeIdentityLeftLine1(language),
          fontFamily = OrvaShowcaseFonts.display(language),
          fontWeight = FontWeight.Bold,
          fontSize = homeDisplaySize(38f),
          lineHeight = homeDisplaySize(40f),
          letterSpacing = OrvaShowcaseFonts.tracking((-1).sp),
          color = palette.inkPrimary,
        )
        Text(
          text = OrvaShowcaseCopy.homeIdentityLeftLine2(language),
          fontFamily = OrvaShowcaseFonts.display(language),
          fontWeight = FontWeight.Normal,
          fontSize = homeDisplaySize(34f),
          lineHeight = homeDisplaySize(39f),
          letterSpacing = OrvaShowcaseFonts.tracking((-0.5).sp),
          color = palette.inkSecondary,
        )
      }
    }

    HorizontalDivider(thickness = 1.dp, color = palette.hairline)
  }
}

/**
 * H4 — Flagship ORVA case-study cover. The image is atmospheric editorial artwork,
 * not a representation of the actual application UI.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun HomeFlagshipOrvaSection(
  state: HomeShowcaseUiState,
  onExploreProduct: () -> Unit,
  onOpenStudio: () -> Unit,
) {
  val palette = currentShowcasePalette()
  Column(
    modifier =
      Modifier
        .fillMaxWidth()
        .widthIn(max = 960.dp)
        .padding(horizontal = 24.dp, vertical = 36.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Text(
        text = OrvaShowcaseCopy.flagshipEyebrow(state.language),
        fontFamily = OrvaShowcaseFonts.mono(state.language),
        fontSize = 11.sp,
        letterSpacing = OrvaShowcaseFonts.tracking(1.5.sp),
        color = palette.accent,
      )
      Text(
        text = OrvaShowcaseCopy.flagshipCaseCode(state.language),
        fontFamily = OrvaShowcaseFonts.mono(state.language),
        fontSize = 10.sp,
        letterSpacing = OrvaShowcaseFonts.tracking(1.2.sp),
        color = palette.inkMuted,
        modifier = Modifier.testTag("home_flagship_case_code"),
      )
    }

    // The artwork is deliberately treated as a studio/editorial image, not an ORVA screenshot.
    BoxWithConstraints(
      modifier =
        Modifier
          .fillMaxWidth()
          .height(320.dp)
          .clipToBounds()
          .background(palette.canvasDeep)
          .agenticNode(id = "home_h4_case_media", kind = LayerKind.MEDIA, parentId = "home_h4_content"),
    ) {
      Image(
        painter = painterResource(id = R.drawable.editorial_studio_workbench),
        contentDescription = null,
        contentScale = ContentScale.Crop,
        modifier =
          Modifier
            .fillMaxSize()
            .graphicsLayer {
              scaleX = 1.035f
              scaleY = 1.035f
            },
      )
      Box(
        modifier =
          Modifier
            .fillMaxSize()
            .background(
              Brush.verticalGradient(
                0f to palette.canvasDeep.copy(alpha = 0.66f),
                0.42f to palette.canvasDeep.copy(alpha = 0.18f),
                1f to palette.canvasDeep.copy(alpha = 0.94f),
              )
            ),
      )
      // Quiet registration marks establish an editorial plate without fake telemetry.
      Canvas(modifier = Modifier.fillMaxSize()) {
        val inset = 14.dp.toPx()
        val mark = 13.dp.toPx()
        val stroke = 1.dp.toPx()
        val color = palette.inkPrimary.copy(alpha = 0.48f)
        val corners = listOf(
          Offset(inset, inset),
          Offset(size.width - inset, inset),
          Offset(inset, size.height - inset),
          Offset(size.width - inset, size.height - inset),
        )
        corners.forEachIndexed { index, point ->
          val sx = if (index % 2 == 0) 1f else -1f
          val sy = if (index < 2) 1f else -1f
          drawLine(color, point, point + Offset(mark * sx, 0f), stroke)
          drawLine(color, point, point + Offset(0f, mark * sy), stroke)
        }
      }

      Row(
        modifier = Modifier.align(Alignment.TopStart).fillMaxWidth().padding(22.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = OrvaShowcaseCopy.flagshipStudyLabel(state.language),
          fontFamily = OrvaShowcaseFonts.mono(state.language),
          fontSize = 9.5.sp,
          letterSpacing = OrvaShowcaseFonts.tracking(1.2.sp),
          color = palette.inkPrimary.copy(alpha = 0.9f),
          modifier = Modifier.testTag("home_flagship_study_label"),
        )
        Box(Modifier.size(6.dp).clip(CircleShape).background(palette.accent))
      }

      val flagshipLayout = currentHomeThemeSpec().layoutGrammar
      val wordmarkAlignment = when (flagshipLayout) {
        ThemeLayoutGrammar.PROOF_PRESS -> Alignment.BottomStart
        ThemeLayoutGrammar.SPECIMEN_FIELD -> Alignment.BottomStart
        ThemeLayoutGrammar.MUSEUM_CATALOGUE -> Alignment.CenterEnd
      }
      val wordmarkPlate = when (flagshipLayout) {
        ThemeLayoutGrammar.PROOF_PRESS -> Modifier.padding(horizontal = 22.dp, vertical = 20.dp)
        ThemeLayoutGrammar.SPECIMEN_FIELD -> Modifier
          .padding(start = 16.dp, bottom = 16.dp)
          .background(palette.canvasSecondary)
          .border(1.dp, palette.hairline)
          .padding(horizontal = 16.dp, vertical = 10.dp)
        ThemeLayoutGrammar.MUSEUM_CATALOGUE -> Modifier
          .padding(end = 24.dp)
          .drawBehind {
            val x = size.width - 2.dp.toPx()
            drawLine(palette.accent, Offset(x, 0f), Offset(x, size.height), 1.dp.toPx())
          }
          .padding(end = 12.dp, top = 10.dp, bottom = 10.dp)
      }
      Column(
        modifier = Modifier.align(wordmarkAlignment).then(wordmarkPlate),
        horizontalAlignment = if (flagshipLayout == ThemeLayoutGrammar.MUSEUM_CATALOGUE) Alignment.End else Alignment.Start,
        verticalArrangement = Arrangement.spacedBy(2.dp),
      ) {
        Text(
          text = "ORVA",
          fontFamily = OrvaShowcaseFonts.display(AppLanguage.English),
          fontWeight = FontWeight.Bold,
          fontSize = if (maxWidth < 380.dp) currentHomeThemeSpec().type.heroCompactSp.sp
            else if (maxWidth < 640.dp) currentHomeThemeSpec().type.heroStandardSp.sp
            else currentHomeThemeSpec().type.heroTabletSp.sp,
          lineHeight = if (maxWidth < 380.dp) currentHomeThemeSpec().type.heroCompactSp.sp
            else if (maxWidth < 640.dp) currentHomeThemeSpec().type.heroStandardSp.sp
            else currentHomeThemeSpec().type.heroTabletSp.sp,
          letterSpacing = OrvaShowcaseFonts.tracking(AppLanguage.English, (-3.2).sp),
          color = palette.inkPrimary,
        )
        Text(
          text = OrvaShowcaseCopy.flagshipDescriptor(state.language),
          fontFamily = OrvaShowcaseFonts.mono(state.language),
          fontSize = 9.5.sp,
          letterSpacing = OrvaShowcaseFonts.tracking(1.35.sp),
          color = palette.inkSecondary,
        )
      }
      Text(
        text = OrvaShowcaseCopy.flagshipStateLabel(state.language),
        fontFamily = OrvaShowcaseFonts.mono(state.language),
        fontSize = 9.sp,
        letterSpacing = OrvaShowcaseFonts.tracking(1.1.sp),
        color = palette.inkPrimary,
        modifier =
          Modifier
            .align(Alignment.BottomEnd)
            .padding(22.dp)
            .border(1.dp, palette.inkPrimary.copy(alpha = 0.35f))
            .padding(horizontal = 8.dp, vertical = 5.dp),
      )
    }

    Text(
      text = OrvaShowcaseCopy.flagshipBody(state.language),
      fontFamily = OrvaShowcaseFonts.body(state.language),
      fontSize = homeBodySize(),
      lineHeight = homeBodyLineHeight(),
      color = palette.inkSecondary,
      modifier = Modifier.widthIn(max = 620.dp),
    )

    FlowRow(
      horizontalArrangement = Arrangement.spacedBy(12.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      Button(
        onClick = onExploreProduct,
        colors =
          ButtonDefaults.buttonColors(
            containerColor = palette.accent,
            contentColor = palette.canvasDeep,
          ),
        shape = RoundedCornerShape(2.dp),
        contentPadding = PaddingValues(horizontal = 18.dp, vertical = 12.dp),
        modifier = Modifier.minimumInteractiveComponentSize().testTag("home_flagship_explore"),
      ) {
        Text(
          text = OrvaShowcaseCopy.flagshipAction(state.language),
          fontFamily = OrvaShowcaseFonts.mono(state.language),
          fontWeight = FontWeight.SemiBold,
          fontSize = 11.5.sp,
          letterSpacing = OrvaShowcaseFonts.tracking(1.1.sp),
        )
      }

      OutlinedButton(
        onClick = onOpenStudio,
        border = BorderStroke(1.dp, palette.hairline),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = palette.inkPrimary),
        shape = RoundedCornerShape(2.dp),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        modifier = Modifier.minimumInteractiveComponentSize().testTag("home_flagship_about"),
      ) {
        Text(
          text = OrvaShowcaseCopy.studioSecondaryCta(state.language),
          fontFamily = OrvaShowcaseFonts.mono(state.language),
          fontSize = 11.5.sp,
          letterSpacing = OrvaShowcaseFonts.tracking(1.1.sp),
        )
      }
    }
  }
}

/**
 * H5 — Three Layered Document Panels: PRODUCT / CRAFT / ENGINEERING (Master Directive §3.5).
 */
@Composable
private fun HomeLayeredPanelsSection(
  state: HomeShowcaseUiState,
  reducedMotion: Boolean,
  onPanelAction: (String) -> Unit,
) {
  val palette = currentShowcasePalette()
  val folders =
    remember(state.expiringSoonCount, state.appVersion, state.language) {
      OrvaShowcaseCopy.workspaceFolders(
        expiringSoonCount = state.expiringSoonCount,
        appVersion = state.appVersion,
        language = state.language,
      )
    }
  var expandedId by remember { mutableStateOf<String?>(folders.first().id) }

  Column(
    modifier =
      Modifier
        .fillMaxWidth()
        .widthIn(max = 960.dp)
        .padding(horizontal = 24.dp, vertical = 32.dp),
    verticalArrangement = Arrangement.spacedBy(18.dp),
  ) {
    Text(
      text =
        OrvaShowcaseCopy.homeFoldersSectionPrefix(state.language) +
          OrvaShowcaseCopy.folderSectionHeading(state.language),
      fontFamily = OrvaShowcaseFonts.mono(state.language),
      fontSize = 11.sp,
      letterSpacing = OrvaShowcaseFonts.tracking(1.6.sp),
      color = palette.inkMuted,
      modifier = Modifier.testTag("home_folder_section_heading"),
    )

    BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
      val wide = maxWidth >= 720.dp
      val layout = currentHomeThemeSpec().layoutGrammar
      if (wide && layout == ThemeLayoutGrammar.PROOF_PRESS) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(16.dp),
        ) {
          folders.forEach { folder ->
            LayeredDocumentPanel(
              folder = folder,
              expanded = expandedId == folder.id,
              reducedMotion = reducedMotion,
              language = state.language,
              onToggle = { expandedId = if (expandedId == folder.id) null else folder.id },
              onAction = { onPanelAction(folder.id) },
              modifier = Modifier.weight(1f).agenticNode(
                id = "home_h5_panel_${folder.id}", kind = LayerKind.CONTAINER,
                parentId = "home_h5_content",
              ),
            )
          }
        }
      } else if (wide && layout == ThemeLayoutGrammar.SPECIMEN_FIELD && folders.size >= 3) {
        Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
          Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            folders.take(2).forEach { folder ->
              LayeredDocumentPanel(
                folder = folder,
                expanded = expandedId == folder.id,
                reducedMotion = reducedMotion,
                language = state.language,
                onToggle = { expandedId = if (expandedId == folder.id) null else folder.id },
                onAction = { onPanelAction(folder.id) },
                modifier = Modifier.weight(1f).agenticNode(
                  id = "home_h5_panel_${folder.id}", kind = LayerKind.CONTAINER,
                  parentId = "home_h5_content",
                ),
              )
            }
          }
          val finalFolder = folders.last()
          LayeredDocumentPanel(
            folder = finalFolder,
            expanded = expandedId == finalFolder.id,
            reducedMotion = reducedMotion,
            language = state.language,
            onToggle = { expandedId = if (expandedId == finalFolder.id) null else finalFolder.id },
            onAction = { onPanelAction(finalFolder.id) },
            modifier = Modifier.fillMaxWidth().agenticNode(
              id = "home_h5_panel_${finalFolder.id}", kind = LayerKind.CONTAINER,
              parentId = "home_h5_content",
            ),
          )
        }
      } else {
        Column(verticalArrangement = Arrangement.spacedBy(if (layout == ThemeLayoutGrammar.MUSEUM_CATALOGUE) 0.dp else 14.dp)) {
          folders.forEachIndexed { index, folder ->
            LayeredDocumentPanel(
              folder = folder,
              expanded = expandedId == folder.id,
              reducedMotion = reducedMotion,
              language = state.language,
              onToggle = { expandedId = if (expandedId == folder.id) null else folder.id },
              onAction = { onPanelAction(folder.id) },
              modifier = Modifier.fillMaxWidth().agenticNode(
                id = "home_h5_panel_${folder.id}", kind = LayerKind.CONTAINER,
                parentId = "home_h5_content",
              ),
            )
            if (layout == ThemeLayoutGrammar.MUSEUM_CATALOGUE && index < folders.lastIndex) {
              HorizontalDivider(thickness = 1.dp, color = palette.hairline)
            }
          }
        }
      }
    }
  }
}

@Composable
private fun LayeredDocumentPanel(
  folder: FolderCopy,
  expanded: Boolean,
  reducedMotion: Boolean,
  language: AppLanguage,
  onToggle: () -> Unit,
  onAction: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val palette = currentShowcasePalette()
  val layout = currentHomeThemeSpec().layoutGrammar
  val liftDp by animateDpAsState(
    targetValue = if (expanded && !reducedMotion) 6.dp else 0.dp,
    animationSpec = tween(220, easing = FastOutSlowInEasing),
    label = "panel_lift",
  )
  val borderAlpha by animateFloatAsState(
    targetValue = if (expanded) 1f else 0.45f,
    animationSpec = tween(220),
    label = "panel_border",
  )

  val panelTreatment = when (layout) {
    ThemeLayoutGrammar.PROOF_PRESS -> Modifier
      .border(1.dp, if (expanded) palette.accent.copy(alpha = borderAlpha) else palette.hairline)
      .background(if (expanded) palette.surfaceRaised else palette.canvasSecondary)
    ThemeLayoutGrammar.SPECIMEN_FIELD -> Modifier
      .background(if (expanded) palette.canvasDeep else palette.canvasSecondary)
      .drawBehind {
        val edge = if (expanded) 3.dp.toPx() else 1.dp.toPx()
        drawLine(palette.accent.copy(alpha = if (expanded) 1f else 0.58f), Offset.Zero, Offset(0f, size.height), edge)
        drawLine(palette.hairline, Offset(0f, size.height), Offset(size.width, size.height), 1.dp.toPx())
      }
    ThemeLayoutGrammar.MUSEUM_CATALOGUE -> Modifier.drawBehind {
      drawLine(if (expanded) palette.accent else palette.hairline, Offset.Zero, Offset(size.width, 0f), 1.dp.toPx())
      drawLine(palette.hairline, Offset(0f, 0f), Offset(0f, size.height), 1.dp.toPx())
    }
  }
  Column(
    modifier = modifier.then(panelTreatment)
      .padding(
        top = 18.dp - liftDp.coerceAtMost(4.dp),
        bottom = if (layout == ThemeLayoutGrammar.MUSEUM_CATALOGUE) 14.dp else 18.dp,
        start = if (layout == ThemeLayoutGrammar.MUSEUM_CATALOGUE) 12.dp else 18.dp,
        end = 18.dp,
      ),
    verticalArrangement = Arrangement.spacedBy(if (layout == ThemeLayoutGrammar.MUSEUM_CATALOGUE) 8.dp else 10.dp),
  ) {
    // The disclosure control and its navigation action are siblings, not nested buttons.
    // This gives TalkBack two distinct actions and prevents the card toggle from swallowing the CTA.
    Column(
      modifier =
        Modifier
          .fillMaxWidth()
          .minimumInteractiveComponentSize()
          .clickable(role = Role.Button, onClick = onToggle)
          .semantics {
            stateDescription = OrvaShowcaseCopy.folderExpandedState(expanded, language)
          }
          .testTag("home_folder_toggle_${folder.id}"),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      Text(
        text = folder.tabLabel,
        fontFamily = OrvaShowcaseFonts.mono(language),
        fontSize = 10.sp,
        letterSpacing = OrvaShowcaseFonts.tracking(1.4.sp),
        color = if (expanded) palette.accent else palette.inkMuted,
      )

      Text(
        text = folder.title,
        fontFamily = OrvaShowcaseFonts.display(language),
        fontWeight = FontWeight.Bold,
        fontSize = homeDisplaySize(22f),
        letterSpacing = OrvaShowcaseFonts.tracking((-0.4).sp),
        color = palette.inkPrimary,
      )

      Text(
        text = folder.body,
        fontFamily = OrvaShowcaseFonts.body(language),
        fontSize = homeBodySize(),
        lineHeight = homeBodyLineHeight(),
        color = palette.inkSecondary,
      )
    }

    if (expanded) {
      HorizontalDivider(thickness = 1.dp, color = palette.hairline)
      Column(
        modifier = Modifier.testTag("home_folder_details_${folder.id}"),
        verticalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        folder.sheets.forEach { sheet ->
          Text(
            text = "— $sheet",
            fontFamily = OrvaShowcaseFonts.mono(language),
            fontSize = 11.sp,
            color = palette.inkPrimary.copy(alpha = 0.86f),
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
          )
        }
      }
    }

    Spacer(Modifier.height(4.dp))
    Box(
      modifier =
        Modifier
          .minimumInteractiveComponentSize()
          .clickable(role = Role.Button, onClick = onAction)
          .testTag("home_folder_action_${folder.id}"),
      contentAlignment = Alignment.CenterStart,
    ) {
      Text(
        text = folder.actionLabel,
        fontFamily = OrvaShowcaseFonts.mono(language),
        fontWeight = FontWeight.SemiBold,
        fontSize = 11.5.sp,
        letterSpacing = OrvaShowcaseFonts.tracking(1.sp),
        color = palette.signal,
      )
    }
  }
}
