package com.rindleworks.orva.data.repository

import com.rindleworks.orva.data.local.MedicineWithBatchJoinRow
import com.rindleworks.orva.data.local.OrvaDatabaseProvider
import com.rindleworks.orva.data.local.OrvaTransactionRunner
import com.rindleworks.orva.data.local.entity.AuditLogEntity
import com.rindleworks.orva.domain.common.OrvaFormatters
import com.rindleworks.orva.domain.engine.BillingClock
import com.rindleworks.orva.domain.engine.BillingInstant
import com.rindleworks.orva.domain.engine.CheckedMath
import com.rindleworks.orva.domain.engine.InventoryAlertCalculator
import com.rindleworks.orva.domain.inventory.BatchStatus
import com.rindleworks.orva.domain.inventory.ExpiryAlertItem
import com.rindleworks.orva.domain.inventory.ExpiryAlertLevel
import com.rindleworks.orva.domain.inventory.InventoryFilterMode
import com.rindleworks.orva.domain.inventory.InventoryRepository
import com.rindleworks.orva.domain.inventory.InventoryRow
import com.rindleworks.orva.domain.inventory.LowStockAlertItem
import com.rindleworks.orva.domain.inventory.MedicineDetailsInput
import java.time.temporal.ChronoUnit
import java.util.Locale
import java.util.UUID
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

@OptIn(ExperimentalCoroutinesApi::class)
class RoomInventoryRepository(
  private val databaseProvider: OrvaDatabaseProvider,
  private val transactionRunner: OrvaTransactionRunner,
  private val clock: BillingClock,
  private val snapshotRefresher: (suspend () -> Result<Boolean>)? = null,
) : InventoryRepository {

  private val json = Json { encodeDefaults = true }

  override fun observeInventoryRows(
    searchText: String,
    filterMode: InventoryFilterMode,
  ): Flow<List<InventoryRow>> =
    databaseProvider.databaseGeneration.flatMapLatest {
      val db = databaseProvider.current()
      db.stockBatchDao().observeAllWithMedicine().map { joinedRows ->
        val localDate = BillingInstant.capture(clock).localBusinessDate
        val usableByMedicine = computeUsableTotalsByMedicine(joinedRows, localDate)
        val searchLower = searchText.trim().lowercase(Locale.ROOT)

        joinedRows
          .map { row ->
            val usableTotal = usableByMedicine[row.medicineId] ?: 0L
            val expiryLevel =
              InventoryAlertCalculator.classifyExpiry(row.batchStatus, row.expiryYyyyMm, localDate)
            val isLowStock =
              InventoryAlertCalculator.isLowStock(
                isMedicineActive = row.isActive == 1,
                usableQuantityMilli = usableTotal,
                thresholdMilli = row.lowStockThresholdMilli,
              )
            val (statusLabel, statusColour) =
              InventoryAlertCalculator.resolveDisplayStatus(
                batchStatus = row.batchStatus,
                expiryLevel = expiryLevel,
                quantityMilli = row.quantityMilli,
                isLowStock = isLowStock,
              )
            InventoryRow(
              medicineId = row.medicineId,
              batchId = row.batchId,
              medicineName = row.displayName,
              batchNumber = row.batchNumber,
              expiryText = OrvaFormatters.formatExpiry(row.expiryYyyyMm),
              expiryYearMonth = row.expiryYyyyMm,
              quantityText = OrvaFormatters.formatQuantity(row.quantityMilli),
              quantityMilli = row.quantityMilli,
              unit = row.batchStockUnitName,
              mrpPaise = row.mrpPaise,
              mrpText = "₹${OrvaFormatters.formatRupees(row.mrpPaise)}",
              statusLabel = statusLabel,
              statusColourHex = statusColour,
              batchStatus = BatchStatus.fromDbValue(row.batchStatus) ?: BatchStatus.Active,
              expiryLevel = expiryLevel,
              isLowStock = isLowStock,
              lowStockThresholdMilli = row.lowStockThresholdMilli,
              usableMedicineTotalMilli = usableTotal,
            )
          }
          .filter { item ->
            val matchesSearch =
              searchLower.isEmpty() ||
                item.medicineName.lowercase(Locale.ROOT).contains(searchLower) ||
                item.batchNumber.lowercase(Locale.ROOT).contains(searchLower)
            if (!matchesSearch) return@filter false

            when (filterMode) {
              InventoryFilterMode.All -> true
              InventoryFilterMode.LowStock -> item.isLowStock
              InventoryFilterMode.Expiring ->
                item.quantityMilli > 0L &&
                  (item.expiryLevel == ExpiryAlertLevel.EarlyWarning90Days ||
                    item.expiryLevel == ExpiryAlertLevel.Warning60Days ||
                    item.expiryLevel == ExpiryAlertLevel.UrgentWarning30Days)
              InventoryFilterMode.Expired ->
                item.quantityMilli > 0L && item.expiryLevel == ExpiryAlertLevel.Expired
            }
          }
      }
    }

  override fun observeLowStockAlerts(): Flow<List<LowStockAlertItem>> =
    databaseProvider.databaseGeneration.flatMapLatest {
      val db = databaseProvider.current()
      combine(db.medicineDao().observeAll(), db.stockBatchDao().observeAllWithMedicine()) {
        medicines,
        joinedRows ->
        val localDate = BillingInstant.capture(clock).localBusinessDate
        val usableByMedicine = computeUsableTotalsByMedicine(joinedRows, localDate)
        medicines
          .filter { med ->
            val usable = usableByMedicine[med.medicineId] ?: 0L
            InventoryAlertCalculator.isLowStock(
              isMedicineActive = med.isActive == 1,
              usableQuantityMilli = usable,
              thresholdMilli = med.lowStockThresholdMilli,
            )
          }
          .map { med ->
            LowStockAlertItem(
              medicineId = med.medicineId,
              medicineName = med.displayName,
              stockUnitName = med.stockUnitName,
              usableQuantityMilli = usableByMedicine[med.medicineId] ?: 0L,
              thresholdMilli = med.lowStockThresholdMilli,
            )
          }
          .sortedWith(compareBy<LowStockAlertItem> { it.usableQuantityMilli }.thenBy { it.medicineName.lowercase(Locale.ROOT) })
      }
    }

  override fun observeExpiryAlerts(): Flow<List<ExpiryAlertItem>> =
    databaseProvider.databaseGeneration.flatMapLatest {
      val db = databaseProvider.current()
      db.stockBatchDao().observeAllWithMedicine().map { joinedRows ->
        val localDate = BillingInstant.capture(clock).localBusinessDate
        joinedRows
          .filter { it.quantityMilli > 0L }
          .mapNotNull { row ->
            val level =
              InventoryAlertCalculator.classifyExpiry(row.batchStatus, row.expiryYyyyMm, localDate)
            if (level == ExpiryAlertLevel.None) return@mapNotNull null
            val expiryDate = InventoryAlertCalculator.getMonthEndExpiryDate(row.expiryYyyyMm)
            val daysRemaining = ChronoUnit.DAYS.between(localDate, expiryDate).toInt()
            ExpiryAlertItem(
              medicineId = row.medicineId,
              batchId = row.batchId,
              medicineName = row.displayName,
              batchNumber = row.batchNumber,
              expiryYearMonth = row.expiryYyyyMm,
              expiryDateIso = expiryDate.toString(),
              daysRemaining = daysRemaining,
              quantityMilli = row.quantityMilli,
              stockUnitName = row.batchStockUnitName,
              alertLevel = level,
              alertLabel = level.label,
            )
          }
          .sortedWith(
            compareBy<ExpiryAlertItem> { it.expiryYearMonth }
              .thenBy { it.daysRemaining }
              .thenBy { it.medicineName.lowercase(Locale.ROOT) }
          )
      }
    }

  override suspend fun getMedicineDetails(medicineId: String): MedicineDetailsInput? =
    transactionRunner.runRead { db ->
      db.medicineDao().getById(medicineId)?.let { m ->
        MedicineDetailsInput(
          medicineId = m.medicineId,
          displayName = m.displayName,
          genericName = m.genericName,
          brandName = m.brandName,
          strength = m.strength,
          dosageForm = m.dosageForm,
          stockUnitName = m.stockUnitName,
          lowStockThresholdMilli = m.lowStockThresholdMilli,
          isActive = m.isActive == 1,
        )
      }
    }

  override suspend fun updateMedicineDetails(input: MedicineDetailsInput): Result<Unit> = runCatching {
    val cleanDisplay = input.displayName.trim()
    require(cleanDisplay.isNotEmpty()) { "Medicine display name is required." }
    val cleanUnit = input.stockUnitName.trim()
    require(cleanUnit.isNotEmpty()) { "Stock unit name is required." }
    require(input.lowStockThresholdMilli >= 0L) { "Low-stock threshold cannot be negative." }

    val normalized = cleanDisplay.lowercase(Locale.ROOT)
    val now = BillingInstant.capture(clock)

    transactionRunner.runWriteTransaction { db ->
      val existing =
        db.medicineDao().getById(input.medicineId)
          ?: throw IllegalArgumentException("Medicine '${input.medicineId}' was not found.")

      val conflict = db.medicineDao().getByNormalizedName(normalized)
      if (conflict != null && conflict.medicineId != existing.medicineId) {
        throw IllegalArgumentException(
          "Another medicine named '${conflict.displayName}' already exists."
        )
      }

      // Preserve existing.stockUnitName deliberately (WPF parity: protects historical batch & invoice unit consistency).
      val updated =
        existing.copy(
          displayName = cleanDisplay,
          normalizedName = normalized,
          genericName = input.genericName?.trim()?.ifEmpty { null },
          brandName = input.brandName?.trim()?.ifEmpty { null },
          strength = input.strength?.trim()?.ifEmpty { null },
          dosageForm = input.dosageForm?.trim()?.ifEmpty { null },
          stockUnitName = existing.stockUnitName,
          lowStockThresholdMilli = input.lowStockThresholdMilli,
          isActive = if (input.isActive) 1 else 0,
          updatedAtUtc = now.utcIsoText,
        )
      db.medicineDao().update(updated)
      StockSnapshotState.markDirtyAndIncrementGeneration(db, now.utcIsoText)

      db.ledgerDao()
        .insertAuditLog(
          AuditLogEntity(
            auditId = UUID.randomUUID().toString(),
            actionType = "MEDICINE_UPDATED",
            entityType = "medicine",
            entityId = existing.medicineId,
            summary = "Updated medicine details for '$cleanDisplay'",
            beforeJson =
              json.encodeToString(
                MedicineAuditDto(
                  displayName = existing.displayName,
                  stockUnitName = existing.stockUnitName,
                  lowStockThresholdMilli = existing.lowStockThresholdMilli,
                  isActive = existing.isActive == 1,
                )
              ),
            afterJson =
              json.encodeToString(
                MedicineAuditDto(
                  displayName = updated.displayName,
                  stockUnitName = updated.stockUnitName,
                  lowStockThresholdMilli = updated.lowStockThresholdMilli,
                  isActive = updated.isActive == 1,
                )
              ),
            createdAtUtc = now.utcIsoText,
            createdLocalText = now.localLogText,
          )
        )
    }
    runCatching { snapshotRefresher?.invoke() }
  }

  override suspend fun updateBatchStatus(
    batchId: String,
    newStatus: BatchStatus,
    reason: String,
  ): Result<Unit> = runCatching {
    val cleanReason = reason.trim()
    require(cleanReason.isNotEmpty()) { "A reason is required when changing batch status." }
    val now = BillingInstant.capture(clock)

    transactionRunner.runWriteTransaction { db ->
      val existing =
        db.stockBatchDao().getById(batchId)
          ?: throw IllegalArgumentException("Batch '$batchId' was not found.")

      val rows = db.stockBatchDao().updateStatus(batchId, newStatus.dbValue, now.utcIsoText)
      check(rows == 1) { "Failed to update batch status for '$batchId'." }

      StockSnapshotState.markDirtyAndIncrementGeneration(db, now.utcIsoText)

      db.ledgerDao()
        .insertAuditLog(
          AuditLogEntity(
            auditId = UUID.randomUUID().toString(),
            actionType = "BATCH_STATUS_CHANGED",
            entityType = "stock_batch",
            entityId = batchId,
            summary =
              "Batch '${existing.batchNumber}' status changed from ${existing.batchStatus} to ${newStatus.dbValue}: $cleanReason",
            beforeJson = json.encodeToString(BatchStatusAuditDto(existing.batchStatus)),
            afterJson = json.encodeToString(BatchStatusAuditDto(newStatus.dbValue)),
            createdAtUtc = now.utcIsoText,
            createdLocalText = now.localLogText,
          )
        )
    }
    runCatching { snapshotRefresher?.invoke() }
  }

  override suspend fun getStockUnitForMedicine(medicineName: String): String? =
    transactionRunner.runRead { db ->
      val normalized = medicineName.trim().lowercase(Locale.ROOT)
      if (normalized.isEmpty()) return@runRead null
      db.medicineDao().getByNormalizedName(normalized)?.stockUnitName
    }

  override suspend fun getCounts(): Pair<Int, Int> =
    transactionRunner.runRead { db ->
      db.medicineDao().countAll() to db.stockBatchDao().countAll()
    }

  private fun computeUsableTotalsByMedicine(
    rows: List<MedicineWithBatchJoinRow>,
    localBusinessDate: java.time.LocalDate,
  ): Map<String, Long> {
    val totals = HashMap<String, Long>()
    for (row in rows) {
      if (
        InventoryAlertCalculator.isBatchUsableForSale(
          batchStatus = row.batchStatus,
          expiryYyyyMm = row.expiryYyyyMm,
          quantityMilli = row.quantityMilli,
          localBusinessDate = localBusinessDate,
        )
      ) {
        val current = totals[row.medicineId] ?: 0L
        totals[row.medicineId] = CheckedMath.addExact(current, row.quantityMilli)
      }
    }
    return totals
  }

  @Serializable
  private data class MedicineAuditDto(
    val displayName: String,
    val stockUnitName: String,
    val lowStockThresholdMilli: Long,
    val isActive: Boolean,
  )

  @Serializable
  private data class BatchStatusAuditDto(val batchStatus: String)
}
