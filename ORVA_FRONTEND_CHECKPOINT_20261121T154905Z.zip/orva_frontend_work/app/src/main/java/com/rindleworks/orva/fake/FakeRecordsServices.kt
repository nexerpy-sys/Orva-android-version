package com.rindleworks.orva.fake

import com.rindleworks.orva.domain.billing.BatchAllocationPreview
import com.rindleworks.orva.domain.billing.InvoiceCustomerDraft
import com.rindleworks.orva.domain.billing.InvoiceLinePreview
import com.rindleworks.orva.domain.billing.InvoicePaymentMethod
import com.rindleworks.orva.domain.billing.InvoicePreviewResult
import com.rindleworks.orva.domain.billing.InvoiceResult
import com.rindleworks.orva.domain.billing.PaymentTenderDraft
import com.rindleworks.orva.domain.common.InvoiceStatus
import com.rindleworks.orva.domain.common.OrvaDateTimeFormatters
import com.rindleworks.orva.domain.inventory.PurchaseDocumentType
import com.rindleworks.orva.domain.records.ExpenseInput
import com.rindleworks.orva.domain.records.ExpenseRow
import com.rindleworks.orva.domain.records.ExportFormat
import com.rindleworks.orva.domain.records.GstSummaryRow
import com.rindleworks.orva.domain.records.HistoricalInvoiceRecord
import com.rindleworks.orva.domain.records.InvoiceStatusFilter
import com.rindleworks.orva.domain.records.PurchaseRegisterRow
import com.rindleworks.orva.domain.records.RegisterDateFilter
import com.rindleworks.orva.domain.records.ReportType
import com.rindleworks.orva.domain.records.ReportingService
import com.rindleworks.orva.domain.records.SalesRegisterRow
import com.rindleworks.orva.domain.records.SalesReturnRegisterRow
import com.rindleworks.orva.domain.records.StockValuationRow
import java.io.OutputStream
import java.time.Instant
import java.util.UUID

class FakeReportingService : ReportingService {
  private val expenses =
    mutableListOf(
      ExpenseRow(
        expenseId = "fake-exp-1",
        expenseDateUtc = "2026-04-01T09:00:00.0000000Z",
        expenseDateText = "01 Apr 2026, 02:30 PM",
        category = "Utilities",
        description = "Electricity bill",
        amountPaise = 125_000L,
        paymentMethod = InvoicePaymentMethod.Upi.dbValue,
        documentReference = "EB-2026-04",
      )
    )

  override suspend fun getSalesRegister(
    filter: RegisterDateFilter,
    statusFilter: InvoiceStatusFilter,
    search: String?,
  ): List<SalesRegisterRow> {
    val rows =
      listOf(
        SalesRegisterRow(
          invoiceId = "fake-inv-1",
          invoiceNumber = "INV/26-27/000001",
          issuedAtUtc = "2026-04-01T10:00:00.0000000Z",
          issuedDateText = "01 Apr 2026, 03:30 PM",
          customerName = "Walk-in Customer",
          customerGstin = "",
          taxableValuePaise = 5_714L,
          cgstPaise = 343L,
          sgstPaise = 343L,
          igstPaise = 0L,
          roundOffPaise = 0L,
          grandTotalPaise = 6_400L,
          paidTotalPaise = 6_400L,
          status = InvoiceStatus.Issued.dbValue,
          cancellationReason = "",
        )
      )
    val needle = search?.trim().orEmpty()
    return rows.filter { row ->
      (statusFilter == InvoiceStatusFilter.All || row.status == statusFilter.dbValue) &&
        (needle.isEmpty() ||
          row.invoiceNumber.contains(needle, ignoreCase = true) ||
          row.customerName.contains(needle, ignoreCase = true))
    }
  }

  override suspend fun getPurchaseRegister(
    filter: RegisterDateFilter,
    supplierSearch: String?,
  ): List<PurchaseRegisterRow> =
    listOf(
      PurchaseRegisterRow(
        purchaseId = "fake-pur-1",
        receivedAtUtc = "2026-04-01T08:00:00.0000000Z",
        receivedDateText = "01 Apr 2026, 01:30 PM",
        supplierName = "Bengal Pharma Distributors",
        documentType = PurchaseDocumentType.TaxInvoice.dbValue,
        documentReference = "BPD-991",
        totalPaise = 480_000L,
        isDocumentedForReview = true,
      )
    )

  override suspend fun getGstSummary(filter: RegisterDateFilter): List<GstSummaryRow> =
    listOf(
      GstSummaryRow(
        hsnCode = "3004",
        gstRateBasisPoints = 1_200,
        taxableValuePaise = 5_714L,
        cgstPaise = 343L,
        sgstPaise = 343L,
        igstPaise = 0L,
        totalValuePaise = 6_400L,
      )
    )

  override suspend fun getStockValuation(): List<StockValuationRow> =
    listOf(
      StockValuationRow(
        medicineId = "fake-med-1",
        medicineName = "Paracetamol 500mg",
        stockUnitName = "strip",
        usableQuantityMilli = 24_000L,
        lowStockThresholdMilli = 5_000L,
        isLowStock = false,
        purchaseCostValuePaise = 57_600L,
        mrpValuePaise = 76_800L,
      )
    )

  override suspend fun getSalesReturnsRegister(
    filter: RegisterDateFilter,
    search: String?,
  ): List<SalesReturnRegisterRow> = emptyList()

  override suspend fun getExpenses(filter: RegisterDateFilter): List<ExpenseRow> = expenses.toList()

  override suspend fun addExpense(input: ExpenseInput): Result<Unit> {
    if (input.category.isBlank() || input.amountPaise <= 0L) {
      return Result.failure(IllegalArgumentException("Enter category and positive expense amount."))
    }
    val nowUtc = OrvaDateTimeFormatters.formatUtcRoundTrip(Instant.now())
    expenses +=
      ExpenseRow(
        expenseId = UUID.randomUUID().toString().replace("-", ""),
        expenseDateUtc = nowUtc,
        expenseDateText = OrvaDateTimeFormatters.formatUtcToLocalDisplay(nowUtc),
        category = input.category.trim(),
        description = input.description?.trim().orEmpty(),
        amountPaise = input.amountPaise,
        paymentMethod = input.paymentMethod?.dbValue.orEmpty(),
        documentReference = input.documentReference?.trim().orEmpty(),
      )
    return Result.success(Unit)
  }

  override suspend fun getInvoiceForReprint(invoiceId: String): HistoricalInvoiceRecord? {
    if (invoiceId != "fake-inv-1") return null
    val line =
      InvoiceLinePreview(
        medicineId = "fake-med-1",
        medicineName = "Paracetamol 500mg",
        quantityMilli = 2_000L,
        stockUnitName = "strip",
        batchAllocations =
          listOf(
            BatchAllocationPreview(
              batchNumber = "P26A",
              expiryYyyyMm = 202803,
              quantityMilli = 2_000L,
              unitPricePaise = 3_200L,
              subtotalPaise = 6_400L,
              taxableValuePaise = 5_714L,
              cgstPaise = 343L,
              sgstPaise = 343L,
              igstPaise = 0L,
              lineTotalPaise = 6_400L,
            )
          ),
        subtotalPaise = 6_400L,
        taxableValuePaise = 5_714L,
        cgstPaise = 343L,
        sgstPaise = 343L,
        igstPaise = 0L,
        lineTotalPaise = 6_400L,
      )
    return HistoricalInvoiceRecord(
      committedInvoice =
        InvoiceResult(
          succeeded = true,
          invoiceId = "fake-inv-1",
          invoiceNumber = "INV/26-27/000001",
          issuedAtUtc = "2026-04-01T10:00:00.0000000Z",
          issuedLocalOffsetMinutes = 330,
          grandTotalPaise = 6_400L,
        ),
      preview =
        InvoicePreviewResult(
          isDraftValid = true,
          canFinalize = true,
          lines = listOf(line),
          subtotalPaise = 6_400L,
          taxableValuePaise = 5_714L,
          cgstPaise = 343L,
          sgstPaise = 343L,
          grandTotalPaise = 6_400L,
          tenderTotalPaise = 6_400L,
          amountRemainingPaise = 0L,
          isFullyPaid = true,
        ),
      customer = InvoiceCustomerDraft(name = "Walk-in Customer"),
      tenders = listOf(PaymentTenderDraft(method = InvoicePaymentMethod.Cash, amountPaise = 6_400L)),
    )
  }

  override suspend fun exportReport(
    reportType: ReportType,
    format: ExportFormat,
    output: OutputStream,
    filter: RegisterDateFilter,
    statusFilter: InvoiceStatusFilter,
    search: String?,
    subtitle: String?,
  ): Result<Unit> = runCatching {
    val content = "ORVA Stage 0 Fake Export: $reportType ($format)\n"
    output.write(content.toByteArray(Charsets.UTF_8))
    output.flush()
  }
}
