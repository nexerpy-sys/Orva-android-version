package com.rindleworks.orva.service.inventory

import com.rindleworks.orva.data.local.OrvaTransactionRunner
import com.rindleworks.orva.data.local.entity.AuditLogEntity
import com.rindleworks.orva.data.local.entity.MedicineEntity
import com.rindleworks.orva.data.local.entity.PurchaseLineEntity
import com.rindleworks.orva.data.local.entity.PurchaseReceiptEntity
import com.rindleworks.orva.data.local.entity.StockBatchEntity
import com.rindleworks.orva.data.local.entity.StockMovementEntity
import com.rindleworks.orva.data.repository.StockSnapshotState
import com.rindleworks.orva.domain.common.OrvaFormatters
import com.rindleworks.orva.domain.common.StockMovementType
import com.rindleworks.orva.domain.engine.BillingClock
import com.rindleworks.orva.domain.engine.BillingInstant
import com.rindleworks.orva.domain.engine.CheckedMath
import com.rindleworks.orva.domain.engine.InvoiceCalculator
import com.rindleworks.orva.domain.inventory.BatchStatus
import com.rindleworks.orva.domain.inventory.StockEntryInput
import com.rindleworks.orva.domain.inventory.StockEntryResult
import com.rindleworks.orva.domain.inventory.StockEntryService
import java.util.Locale
import java.util.UUID
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

class DefaultStockEntryService(
  private val transactionRunner: OrvaTransactionRunner,
  private val clock: BillingClock,
  private val snapshotRefresher: (suspend () -> Result<Boolean>)? = null,
) : StockEntryService {

  private val json = Json { encodeDefaults = true }

  override suspend fun receiveStock(input: StockEntryInput): StockEntryResult {
    val cleanMedName = input.medicineName.trim()
    val cleanUnit = input.stockUnitName.trim()
    val cleanBatchNum = input.batchNumber.trim()

    if (cleanMedName.isEmpty()) {
      return StockEntryResult(succeeded = false, errorMessage = "Medicine name is required.")
    }
    if (cleanMedName.length > 180) {
      return StockEntryResult(succeeded = false, errorMessage = "Medicine name is too long (max 180 characters).")
    }
    if (cleanUnit.isEmpty()) {
      return StockEntryResult(succeeded = false, errorMessage = "Stock unit name is required.")
    }
    if (cleanBatchNum.isEmpty()) {
      return StockEntryResult(succeeded = false, errorMessage = "Batch number is required.")
    }
    if (cleanBatchNum.length > 80) {
      return StockEntryResult(succeeded = false, errorMessage = "Batch number is too long (max 80 characters).")
    }
    val expYear = input.expiryYearMonth / 100
    val expMonth = input.expiryYearMonth % 100
    if (expYear !in 2000..2199 || expMonth !in 1..12) {
      return StockEntryResult(
        succeeded = false,
        errorMessage = "Expiry must be a valid YYYYMM between 200001 and 219912.",
      )
    }
    val currentYm = BillingInstant.capture(clock).currentExpiryYearMonth
    if (input.expiryYearMonth < currentYm) {
      return StockEntryResult(
        succeeded = false,
        errorMessage = "This batch has already passed its expiry month. Check the date before receiving it.",
      )
    }
    if (input.quantityMilli <= 0L) {
      return StockEntryResult(
        succeeded = false,
        errorMessage = "Received quantity must be greater than zero.",
      )
    }
    if (input.purchasePricePaise < 0L || input.mrpPaise < 0L) {
      return StockEntryResult(
        succeeded = false,
        errorMessage = "Purchase price and MRP cannot be negative.",
      )
    }

    val committed =
      try {
        transactionRunner.runWriteTransaction { db ->
          val now = BillingInstant.capture(clock)
          val utcIso = now.utcIsoText
          val localText = now.localLogText
          val normalizedName = cleanMedName.lowercase(Locale.ROOT)

          // 1. Find or create medicine (exact WPF parity: enforce unit consistency & reactivate soft-inactivated medicine)
          val existingMed = db.medicineDao().getByNormalizedName(normalizedName)
          val medicine =
            if (existingMed != null) {
              if (!existingMed.stockUnitName.equals(cleanUnit, ignoreCase = true)) {
                throw IllegalStateException(
                  "This medicine is already recorded using the unit '${existingMed.stockUnitName}'. Use that unit for this stock entry."
                )
              }
              if (existingMed.isActive == 0) {
                db.medicineDao().updateActiveFlag(existingMed.medicineId, 1, utcIso)
                existingMed.copy(isActive = 1, updatedAtUtc = utcIso)
              } else {
                existingMed
              }
            } else {
              MedicineEntity(
                medicineId = UUID.randomUUID().toString(),
                displayName = cleanMedName,
                normalizedName = normalizedName,
                stockUnitName = cleanUnit,
                gstRateBasisPoints = 0,
                gstRateConfigured = 0,
                lowStockThresholdMilli = 0L,
                isActive = 1,
                createdAtUtc = utcIso,
                updatedAtUtc = utcIso,
              ).also { db.medicineDao().insert(it) }
            }

          // 2. Find or create batch by normalized identity (medicine_id, UPPER(TRIM(batch_number)), expiry_yyyymm)
          val existingBatch =
            db.stockBatchDao()
              .findByNormalizedIdentity(medicine.medicineId, cleanBatchNum, input.expiryYearMonth)

          val batchId: String
          val previousQty: Long
          val newQty: Long
          val storedBatchNumber: String

          if (existingBatch != null) {
            if (!existingBatch.batchStatus.equals(BatchStatus.Active.dbValue, ignoreCase = true)) {
              throw IllegalStateException(
                "This batch is marked as ${existingBatch.batchStatus.lowercase(Locale.ROOT)}. It must be checked before more stock is added."
              )
            }
            batchId = existingBatch.batchId
            storedBatchNumber = existingBatch.batchNumber
            previousQty = existingBatch.quantityMilli
            newQty = CheckedMath.addExact(previousQty, input.quantityMilli)
            db.stockBatchDao()
              .update(
                existingBatch.copy(
                  mrpPaise = if (input.mrpPaise > 0L) input.mrpPaise else existingBatch.mrpPaise,
                  latestPurchasePricePaise = input.purchasePricePaise,
                  quantityMilli = newQty,
                  updatedAtUtc = utcIso,
                )
              )
          } else {
            batchId = UUID.randomUUID().toString()
            storedBatchNumber = cleanBatchNum
            previousQty = 0L
            newQty = input.quantityMilli
            db.stockBatchDao()
              .insert(
                StockBatchEntity(
                  batchId = batchId,
                  medicineId = medicine.medicineId,
                  batchNumber = cleanBatchNum,
                  expiryYyyyMm = input.expiryYearMonth,
                  stockUnitName = medicine.stockUnitName,
                  mrpPaise = input.mrpPaise,
                  latestPurchasePricePaise = input.purchasePricePaise,
                  quantityMilli = newQty,
                  batchStatus = BatchStatus.Active.dbValue,
                  createdAtUtc = utcIso,
                  updatedAtUtc = utcIso,
                )
              )
          }

          // 3. Insert purchase_receipt & purchase_line
          val lineTotalPaise =
            InvoiceCalculator.calculateGrossPaise(input.quantityMilli, input.purchasePricePaise)
          val purchaseId = UUID.randomUUID().toString()
          db.purchaseDao()
            .insertReceipt(
              PurchaseReceiptEntity(
                purchaseId = purchaseId,
                receivedAtUtc = utcIso,
                supplierNameText = input.supplierName?.trim()?.ifEmpty { null },
                supplierLicenceText = input.supplierLicence?.trim()?.ifEmpty { null },
                documentType = input.documentType.dbValue,
                documentReference = input.documentReference?.trim()?.ifEmpty { null },
                notes = null,
                subtotalPaise = lineTotalPaise,
                totalTaxPaise = 0L,
                totalPaise = lineTotalPaise,
                createdAtUtc = utcIso,
              )
            )
          db.purchaseDao()
            .insertLine(
              PurchaseLineEntity(
                purchaseLineId = UUID.randomUUID().toString(),
                purchaseId = purchaseId,
                batchId = batchId,
                medicineId = medicine.medicineId,
                quantityMilli = input.quantityMilli,
                unitNameSnapshot = medicine.stockUnitName,
                unitPurchasePricePaise = input.purchasePricePaise,
                lineTotalPaise = lineTotalPaise,
                createdAtUtc = utcIso,
              )
            )

          // 4. Insert stock_movement (PURCHASE)
          db.ledgerDao()
            .insertStockMovement(
              StockMovementEntity(
                movementId = UUID.randomUUID().toString(),
                batchId = batchId,
                medicineId = medicine.medicineId,
                movementType = StockMovementType.Purchase.dbValue,
                quantityDeltaMilli = input.quantityMilli,
                referenceType = "PURCHASE",
                referenceId = purchaseId,
                reason = "Purchase received (${input.documentType.dbValue})",
                createdAtUtc = utcIso,
                createdLocalText = localText,
              )
            )

          // 5. Audit log
          db.ledgerDao()
            .insertAuditLog(
              AuditLogEntity(
                auditId = UUID.randomUUID().toString(),
                actionType = "STOCK_ENTRY_RECEIVED",
                entityType = "stock_batch",
                entityId = batchId,
                summary =
                  "Received ${OrvaFormatters.formatQuantity(input.quantityMilli)} ${medicine.stockUnitName} of '${medicine.displayName}' (batch '$storedBatchNumber')",
                beforeJson = json.encodeToString(BatchQtyAuditDto(previousQty)),
                afterJson = json.encodeToString(BatchQtyAuditDto(newQty)),
                createdAtUtc = utcIso,
                createdLocalText = localText,
              )
            )

          // 6. Mark stock snapshot dirty
          StockSnapshotState.markDirtyAndIncrementGeneration(db, utcIso)

          StockEntryResult(
            succeeded = true,
            medicineName = medicine.displayName,
            batchNumber = storedBatchNumber,
            newQuantityMilli = newQty,
          )
        }
      } catch (ex: Exception) {
        return StockEntryResult(
          succeeded = false,
          errorMessage = ex.message ?: "Unable to record stock entry.",
        )
      }

    var snapshotUpdated = false
    var snapshotWarning: String? = null
    val refresher = snapshotRefresher
    if (refresher != null) {
      val res = runCatching { refresher.invoke() }.getOrElse { Result.failure(it) }
      if (res.isSuccess) {
        snapshotUpdated = true
      } else {
        snapshotWarning =
          "Stock saved, but StockData.json refresh failed: ${res.exceptionOrNull()?.message ?: "unknown error"}"
      }
    }

    return committed.copy(snapshotUpdated = snapshotUpdated, snapshotWarning = snapshotWarning)
  }

  @Serializable
  private data class BatchQtyAuditDto(val quantityMilli: Long)
}
