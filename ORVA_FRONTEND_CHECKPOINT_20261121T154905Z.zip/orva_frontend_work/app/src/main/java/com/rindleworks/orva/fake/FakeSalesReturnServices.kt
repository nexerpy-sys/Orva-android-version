package com.rindleworks.orva.fake

import com.rindleworks.orva.domain.common.InvoiceStatus
import com.rindleworks.orva.domain.common.OrvaDateTimeFormatters
import com.rindleworks.orva.domain.inventory.BatchStatus
import com.rindleworks.orva.domain.returns.InvoiceCancellationResult
import com.rindleworks.orva.domain.returns.InvoiceCancellationService
import com.rindleworks.orva.domain.returns.ResaleDisposition
import com.rindleworks.orva.domain.returns.ReturnableInvoiceLine
import com.rindleworks.orva.domain.returns.ReturnableInvoiceSummary
import com.rindleworks.orva.domain.returns.SalesReturnPreviewResult
import com.rindleworks.orva.domain.returns.SalesReturnRequest
import com.rindleworks.orva.domain.returns.SalesReturnResult
import com.rindleworks.orva.domain.returns.SalesReturnService
import java.math.BigDecimal
import java.math.RoundingMode
import java.time.Instant
import java.util.UUID

class FakeSalesReturnService : SalesReturnService {
  internal val cancelledInvoiceIds = mutableSetOf<String>()
  internal val returnedInvoiceIds = mutableSetOf<String>()

  private val sampleInvoices =
    listOf(
      ReturnableInvoiceSummary(
        invoiceId = "fake-inv-1",
        invoiceNumber = "INV/26-27/000001",
        issuedAtUtc = "2026-04-01T10:00:00.0000000Z",
        issuedDateText = "01 Apr 2026, 03:30 PM",
        customerName = "Walk-in Customer",
        grandTotalPaise = 6_400L,
        status = InvoiceStatus.Issued.dbValue,
      )
    )

  private val sampleLines =
    listOf(
      ReturnableInvoiceLine(
        invoiceLineId = "fake-inv-line-1",
        medicineId = "fake-med-1",
        batchId = "fake-batch-1",
        medicineName = "Paracetamol 500mg",
        batchNumber = "P26A",
        expiryYyyyMm = 202803,
        stockUnitName = "strip",
        originalQuantityMilli = 2_000L,
        alreadyReturnedMilli = 0L,
        remainingReturnableMilli = 2_000L,
        unitPricePaise = 3_200L,
        originalLineTotalPaise = 6_400L,
        alreadyRefundedPaise = 0L,
        remainingRefundablePaise = 6_400L,
        batchStatus = BatchStatus.Active,
        gstRateBasisPoints = 1_200,
        hsnCode = "3004",
      )
    )

  private var returnSeq: Long = 1L

  override suspend fun searchReturnableInvoices(
    query: String,
    limit: Int,
  ): List<ReturnableInvoiceSummary> {
    val needle = query.trim()
    return sampleInvoices
      .filter { it.invoiceId !in cancelledInvoiceIds }
      .filter {
        needle.isEmpty() ||
          it.invoiceNumber.contains(needle, ignoreCase = true) ||
          it.customerName.contains(needle, ignoreCase = true)
      }
      .take(limit.coerceAtLeast(1))
  }

  override suspend fun getReturnableLines(invoiceId: String): List<ReturnableInvoiceLine> =
    if (invoiceId == "fake-inv-1") sampleLines else emptyList()

  override suspend fun previewReturn(request: SalesReturnRequest): SalesReturnPreviewResult {
    val errors = mutableListOf<String>()
    if (request.invoiceId.isBlank()) errors += "Select an original invoice first."
    if (request.invoiceId in cancelledInvoiceIds) {
      errors += "Cannot process a sales return against a cancelled invoice."
    }
    if (request.reason.isBlank()) errors += "Enter a reason for the sales return."
    if (request.lines.isEmpty()) errors += "Select at least one medicine line to return."

    var totalRefund = 0L
    var restocked = 0
    var quarantined = 0
    for (req in request.lines) {
      if (req.returnQuantityMilli <= 0L) continue
      val orig = sampleLines.firstOrNull { it.invoiceLineId == req.invoiceLineId }
      if (orig == null) {
        errors += "One of the selected return items does not belong to this invoice."
        continue
      }
      if (req.returnQuantityMilli > orig.remainingReturnableMilli) {
        errors += "Return quantity for ${orig.medicineName} exceeds remaining sold quantity."
        continue
      }
      val refund =
        BigDecimal.valueOf(orig.originalLineTotalPaise)
          .multiply(BigDecimal.valueOf(req.returnQuantityMilli))
          .divide(BigDecimal.valueOf(orig.originalQuantityMilli), 0, RoundingMode.HALF_UP)
          .longValueExact()
      totalRefund += refund
      if (req.resaleDisposition == ResaleDisposition.Restock) restocked++ else quarantined++
    }
    if (errors.isEmpty() && totalRefund <= 0L) {
      errors += "Enter a return quantity greater than zero for at least one medicine."
    }
    return SalesReturnPreviewResult(
      canFinalize = errors.isEmpty() && totalRefund > 0L,
      totalRefundPaise = totalRefund,
      quarantinedLineCount = quarantined,
      restockedLineCount = restocked,
      errors = errors,
    )
  }

  override suspend fun finalizeReturn(request: SalesReturnRequest): SalesReturnResult {
    val preview = previewReturn(request)
    if (!preview.canFinalize) {
      return SalesReturnResult(
        succeeded = false,
        errorMessage = preview.errors.firstOrNull() ?: "Sales return could not be validated.",
      )
    }
    returnedInvoiceIds += request.invoiceId
    val seq = returnSeq++
    return SalesReturnResult(
      succeeded = true,
      returnId = UUID.randomUUID().toString().replace("-", ""),
      returnNumber = "RET/26-27/${seq.toString().padStart(6, '0')}",
      refundAmountPaise = preview.totalRefundPaise,
      returnedAtUtc = OrvaDateTimeFormatters.formatUtcRoundTrip(Instant.now()),
      snapshotRefreshed = preview.restockedLineCount > 0,
    )
  }
}

class FakeInvoiceCancellationService(private val returns: FakeSalesReturnService) :
  InvoiceCancellationService {
  override suspend fun cancelInvoice(
    invoiceId: String,
    reason: String,
    restoreStock: Boolean,
  ): InvoiceCancellationResult {
    val trimmedReason = reason.trim()
    if (invoiceId.isBlank()) {
      return InvoiceCancellationResult(succeeded = false, errorMessage = "Select an invoice to cancel.")
    }
    if (trimmedReason.isEmpty()) {
      return InvoiceCancellationResult(
        succeeded = false,
        errorMessage = "Enter a reason for cancelling this invoice.",
      )
    }
    if (trimmedReason.length > 240) {
      return InvoiceCancellationResult(
        succeeded = false,
        errorMessage = "Cancellation reason is too long (maximum 240 characters).",
      )
    }
    if (invoiceId in returns.cancelledInvoiceIds) {
      return InvoiceCancellationResult(succeeded = false, errorMessage = "Invoice is already cancelled.")
    }
    if (invoiceId in returns.returnedInvoiceIds) {
      return InvoiceCancellationResult(
        succeeded = false,
        errorMessage = "Invoice already has completed sales return(s) and cannot be cancelled.",
      )
    }
    returns.cancelledInvoiceIds += invoiceId
    return InvoiceCancellationResult(
      succeeded = true,
      invoiceNumber = "INV/26-27/000001",
      stockRestored = restoreStock,
      snapshotRefreshed = restoreStock,
    )
  }
}
