package com.rindleworks.orva.service.returns

import com.rindleworks.orva.data.local.OrvaDatabase
import com.rindleworks.orva.data.local.OrvaTransactionRunner
import com.rindleworks.orva.data.local.SqlLikeEscaper
import com.rindleworks.orva.data.local.entity.AuditLogEntity
import com.rindleworks.orva.data.local.entity.InvoiceEntity
import com.rindleworks.orva.data.local.entity.InvoiceLineEntity
import com.rindleworks.orva.data.local.entity.SalesReturnEntity
import com.rindleworks.orva.data.local.entity.SalesReturnLineEntity
import com.rindleworks.orva.data.local.entity.StockMovementEntity
import com.rindleworks.orva.data.repository.StockSnapshotState
import com.rindleworks.orva.domain.common.InvoiceStatus
import com.rindleworks.orva.domain.common.OrvaDateTimeFormatters
import com.rindleworks.orva.domain.common.OrvaFormatters
import com.rindleworks.orva.domain.common.OrvaSettingKeys
import com.rindleworks.orva.domain.common.StockMovementType
import com.rindleworks.orva.domain.engine.BillingClock
import com.rindleworks.orva.domain.engine.BillingInstant
import com.rindleworks.orva.domain.engine.CheckedMath
import com.rindleworks.orva.domain.engine.InventoryAlertCalculator
import com.rindleworks.orva.domain.engine.InvoiceCalculator
import com.rindleworks.orva.domain.inventory.BatchStatus
import com.rindleworks.orva.domain.returns.ResaleDisposition
import com.rindleworks.orva.domain.returns.ReturnableInvoiceLine
import com.rindleworks.orva.domain.returns.ReturnableInvoiceSummary
import com.rindleworks.orva.domain.returns.SalesReturnPreviewResult
import com.rindleworks.orva.domain.returns.SalesReturnRequest
import com.rindleworks.orva.domain.returns.SalesReturnResult
import com.rindleworks.orva.domain.returns.SalesReturnService
import java.math.BigDecimal
import java.util.Locale
import java.util.UUID
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

/**
 * Production sales return engine preserving all ORVA WPF invariants:
 * - Default disposition is QUARANTINE (never silently re-enters sellable FEFO stock).
 * - RESTOCK is strictly rejected for expired or non-ACTIVE batches.
 * - Preview == Header == SUM(Lines) refund parity, including NEAREST_RUPEE round-off reconciliation.
 * - Sequential RET/{FY}/{SEQ:06d} numbering persisted via `return_seq_{FY}`.
 */
class DefaultSalesReturnService(
  private val transactionRunner: OrvaTransactionRunner,
  private val clock: BillingClock,
  private val snapshotRefresher: (suspend () -> Result<Boolean>)? = null,
) : SalesReturnService {

  private val json = Json { encodeDefaults = true }

  override suspend fun searchReturnableInvoices(
    query: String,
    limit: Int,
  ): List<ReturnableInvoiceSummary> =
    transactionRunner.runRead { db ->
      val pattern = SqlLikeEscaper.containsPattern(query)
      db.invoiceDao().searchReturnableInvoices(pattern, limit.coerceIn(1, 200)).map { inv ->
        ReturnableInvoiceSummary(
          invoiceId = inv.invoiceId,
          invoiceNumber = inv.invoiceNumber,
          issuedAtUtc = inv.issuedAtUtc,
          issuedDateText = OrvaDateTimeFormatters.formatUtcToLocalDisplay(inv.issuedAtUtc),
          customerName = inv.customerName?.ifBlank { null } ?: "Walk-in Customer",
          grandTotalPaise = inv.grandTotalPaise,
          status = inv.status,
        )
      }
    }

  override suspend fun getReturnableLines(invoiceId: String): List<ReturnableInvoiceLine> =
    transactionRunner.runRead { db ->
      loadReturnableLines(db, invoiceId)
    }

  override suspend fun previewReturn(request: SalesReturnRequest): SalesReturnPreviewResult =
    transactionRunner.runRead { db ->
      val now = BillingInstant.capture(clock)
      evaluateReturn(db, request, now).preview
    }

  override suspend fun finalizeReturn(request: SalesReturnRequest): SalesReturnResult {
    val outcome =
      try {
        transactionRunner.runWriteTransaction { db ->
          val now = BillingInstant.capture(clock)
          val eval = evaluateReturn(db, request, now)
          if (!eval.preview.canFinalize || eval.invoice == null) {
            return@runWriteTransaction ReturnCommitOutcome.Rejected(
              eval.preview.errors.firstOrNull() ?: "Sales return validation failed."
            )
          }

          val invoice = eval.invoice
          val utcIso = now.utcIsoText
          val localText = now.localLogText
          val shopProfile = db.shopProfileDao().getProfile()
          val fyStartMonth = shopProfile?.financialYearStartMonth ?: 4
          val financialYear = InvoiceCalculator.getFinancialYearLabel(now.localBusinessDate, fyStartMonth)

          val seqKey = OrvaSettingKeys.RETURN_SEQUENCE_PREFIX + financialYear
          val currentSeq = db.appSettingDao().getValue(seqKey)?.trim()?.toLongOrNull() ?: 0L
          val nextSeq = CheckedMath.addExact(currentSeq, 1L)
          StockSnapshotState.upsertSetting(db, seqKey, nextSeq.toString(), utcIso)
          val returnNumber = String.format(Locale.ROOT, "RET/%s/%06d", financialYear, nextSeq)

          val returnId = UUID.randomUUID().toString()
          val headerRefundPaise = eval.computedLines.fold(0L) { acc, line ->
            CheckedMath.addExact(acc, line.lineRefundPaise)
          }
          check(headerRefundPaise == eval.preview.totalRefundPaise) {
            "Internal invariant violation: Preview != Header refund total."
          }

          db.salesReturnDao()
            .insertReturn(
              SalesReturnEntity(
                returnId = returnId,
                returnNumber = returnNumber,
                invoiceId = invoice.invoiceId,
                returnedAtUtc = utcIso,
                reason = request.reason.trim(),
                refundMethod = request.refundMethod.dbValue,
                refundAmountPaise = headerRefundPaise,
                status = "COMPLETED",
                createdAtUtc = utcIso,
              )
            )

          var anyRestocked = false
          for (line in eval.computedLines) {
            db.salesReturnDao()
              .insertReturnLine(
                SalesReturnLineEntity(
                  returnLineId = UUID.randomUUID().toString(),
                  returnId = returnId,
                  invoiceLineId = line.invoiceLine.invoiceLineId,
                  batchId = line.invoiceLine.batchId,
                  quantityMilli = line.returnQuantityMilli,
                  resaleDisposition = line.disposition.dbValue,
                  lineRefundPaise = line.lineRefundPaise,
                )
              )

            // Only explicit RESTOCK on verified active non-expired batch re-enters sellable stock.
            if (line.disposition == ResaleDisposition.Restock) {
              anyRestocked = true
              val rows = db.stockBatchDao().addQuantity(line.invoiceLine.batchId, line.returnQuantityMilli, utcIso)
              check(rows == 1) { "Failed to restock batch '${line.invoiceLine.batchId}'." }

              db.ledgerDao()
                .insertStockMovement(
                  StockMovementEntity(
                    movementId = UUID.randomUUID().toString(),
                    batchId = line.invoiceLine.batchId,
                    medicineId = line.invoiceLine.medicineId,
                    movementType = StockMovementType.SaleReturnRestock.dbValue,
                    quantityDeltaMilli = line.returnQuantityMilli,
                    referenceType = "SALES_RETURN",
                    referenceId = returnId,
                    reason = "Return $returnNumber (${request.reason.trim()})",
                    createdAtUtc = utcIso,
                    createdLocalText = localText,
                  )
                )
            }
          }

          // Mark invoice as CREDIT_NOTE_ISSUED
          db.invoiceDao()
            .updateInvoiceStatus(
              invoiceId = invoice.invoiceId,
              newStatus = InvoiceStatus.CreditNoteIssued.dbValue,
              cancellationReason = invoice.cancellationReason,
            )

          db.ledgerDao()
            .insertAuditLog(
              AuditLogEntity(
                auditId = UUID.randomUUID().toString(),
                actionType = "SALES_RETURN_CREATED",
                entityType = "sales_return",
                entityId = returnId,
                summary =
                  "Recorded return $returnNumber against ${invoice.invoiceNumber} for ₹${OrvaFormatters.formatRupees(headerRefundPaise)}",
                beforeJson = null,
                afterJson =
                  json.encodeToString(
                    ReturnAuditDto(
                      returnNumber = returnNumber,
                      invoiceNumber = invoice.invoiceNumber,
                      refundAmountPaise = headerRefundPaise,
                      refundMethod = request.refundMethod.dbValue,
                      restockedLines = eval.preview.restockedLineCount,
                      quarantinedLines = eval.preview.quarantinedLineCount,
                    )
                  ),
                createdAtUtc = utcIso,
                createdLocalText = localText,
              )
            )

          if (anyRestocked) {
            StockSnapshotState.markDirtyAndIncrementGeneration(db, utcIso)
          }

          ReturnCommitOutcome.Committed(
            result =
              SalesReturnResult(
                succeeded = true,
                returnId = returnId,
                returnNumber = returnNumber,
                refundAmountPaise = headerRefundPaise,
                returnedAtUtc = utcIso,
              ),
            shouldRefreshSnapshot = anyRestocked,
          )
        }
      } catch (ex: Exception) {
        return SalesReturnResult(
          succeeded = false,
          errorMessage = ex.message ?: "Unable to finalize sales return.",
        )
      }

    return when (outcome) {
      is ReturnCommitOutcome.Rejected ->
        SalesReturnResult(succeeded = false, errorMessage = outcome.error)
      is ReturnCommitOutcome.Committed -> {
        var snapshotRefreshed = false
        var snapshotWarning: String? = null
        val refresher = snapshotRefresher
        if (outcome.shouldRefreshSnapshot && refresher != null) {
          val res = runCatching { refresher.invoke() }.getOrElse { Result.failure(it) }
          if (res.isSuccess) {
            snapshotRefreshed = true
          } else {
            snapshotWarning =
              "Sales return saved, but StockData.json refresh failed: ${res.exceptionOrNull()?.message ?: "unknown error"}"
          }
        }
        outcome.result.copy(
          snapshotRefreshed = snapshotRefreshed,
          snapshotWarning = snapshotWarning,
        )
      }
    }
  }

  private fun evaluateReturn(
    db: OrvaDatabase,
    request: SalesReturnRequest,
    now: BillingInstant,
  ): ReturnEvaluation {
    val errors = mutableListOf<String>()
    if (request.reason.trim().isEmpty()) {
      errors += "Return reason is required."
    }
    if (request.lines.isEmpty()) {
      errors += "Select at least one invoice line to return."
    }

    val invoice = db.invoiceDao().getInvoiceById(request.invoiceId)
    if (invoice == null) {
      errors += "Invoice '${request.invoiceId}' was not found."
      return ReturnEvaluation(
        preview = SalesReturnPreviewResult(canFinalize = false, errors = errors),
        invoice = null,
        computedLines = emptyList(),
      )
    }
    if (invoice.status == InvoiceStatus.Cancelled.dbValue) {
      errors += "Cancelled invoice '${invoice.invoiceNumber}' cannot accept sales returns."
    }

    val invoiceLines = db.invoiceDao().getLinesForInvoice(invoice.invoiceId)
    val invoiceLinesById = invoiceLines.associateBy { it.invoiceLineId }
    val aggregatesByLineId =
      db.salesReturnDao().getCompletedReturnAggregatesForInvoice(invoice.invoiceId)
        .associateBy { it.invoiceLineId }
    val alreadyRefundedInvoiceTotal =
      db.salesReturnDao().getTotalCompletedRefundForInvoice(invoice.invoiceId)

    val seenLineIds = HashSet<String>()
    val draftComputed = mutableListOf<ComputedReturnLine>()
    var quarantinedCount = 0
    var restockedCount = 0

    for (reqLine in request.lines) {
      if (!seenLineIds.add(reqLine.invoiceLineId)) {
        errors += "Duplicate return line '${reqLine.invoiceLineId}' in request."
        continue
      }
      if (reqLine.returnQuantityMilli <= 0L) {
        errors += "Return quantity must be greater than zero."
        continue
      }
      val invLine = invoiceLinesById[reqLine.invoiceLineId]
      if (invLine == null) {
        errors += "Invoice line '${reqLine.invoiceLineId}' does not belong to invoice '${invoice.invoiceNumber}'."
        continue
      }

      val agg = aggregatesByLineId[invLine.invoiceLineId]
      val alreadyReturnedQty = agg?.returnedQtyMilli ?: 0L
      val alreadyRefundedLine = agg?.refundedPaise ?: 0L
      val remainingQty = CheckedMath.subtractExact(invLine.quantityMilli, alreadyReturnedQty)
      val remainingRefundableLine =
        maxOf(0L, CheckedMath.subtractExact(invLine.lineTotalPaise, alreadyRefundedLine))

      if (reqLine.returnQuantityMilli > remainingQty) {
        errors +=
          "Return quantity for '${invLine.medicineNameSnapshot}' exceeds remaining returnable quantity (${OrvaFormatters.formatQuantity(remainingQty)} ${invLine.unitNameSnapshot})."
        continue
      }

      // Guard RESTOCK against expired or non-ACTIVE batches
      if (reqLine.resaleDisposition == ResaleDisposition.Restock) {
        val batch = db.stockBatchDao().getById(invLine.batchId)
        val expiryDate = InventoryAlertCalculator.getMonthEndExpiryDate(invLine.expiryYyyyMmSnapshot)
        val isExpired = expiryDate.isBefore(now.localBusinessDate)
        val isActive = batch != null && batch.batchStatus == BatchStatus.Active.dbValue
        if (!isActive || isExpired) {
          errors +=
            "Cannot restock '${invLine.medicineNameSnapshot}' (batch '${invLine.batchNumberSnapshot}'): batch is expired or not ACTIVE. Use QUARANTINE, DAMAGED, or EXPIRED instead."
          continue
        }
        restockedCount++
      } else if (reqLine.resaleDisposition == ResaleDisposition.Quarantine) {
        quarantinedCount++
      }

      val baseLineRefund =
        if (reqLine.returnQuantityMilli == remainingQty) {
          remainingRefundableLine
        } else {
          val proportional =
            CheckedMath.divideRoundHalfAwayFromZero(
              BigDecimal.valueOf(reqLine.returnQuantityMilli)
                .multiply(BigDecimal.valueOf(invLine.lineTotalPaise)),
              BigDecimal.valueOf(invLine.quantityMilli),
            )
          minOf(proportional, remainingRefundableLine)
        }

      draftComputed +=
        ComputedReturnLine(
          invoiceLine = invLine,
          returnQuantityMilli = reqLine.returnQuantityMilli,
          disposition = reqLine.resaleDisposition,
          lineRefundPaise = baseLineRefund,
        )
    }

    // Reconcile NEAREST_RUPEE invoice-level round-off & grandTotal cap so:
    // 1. Preview == Header == SUM(Lines) ALWAYS holds.
    // 2. Full return (single or multi-step) refunds exactly invoice.grandTotalPaise.
    // 3. Cumulative returns never exceed invoice.grandTotalPaise.
    val reconciledLines =
      if (errors.isEmpty() && draftComputed.isNotEmpty()) {
        reconcileLineRefundsWithInvoiceGrandTotal(
          invoice = invoice,
          allInvoiceLines = invoiceLines,
          aggregatesByLineId = aggregatesByLineId,
          alreadyRefundedInvoiceTotal = alreadyRefundedInvoiceTotal,
          computed = draftComputed,
        )
      } else {
        draftComputed
      }

    val totalRefund =
      reconciledLines.fold(0L) { acc, line -> CheckedMath.addExact(acc, line.lineRefundPaise) }

    val preview =
      SalesReturnPreviewResult(
        canFinalize = errors.isEmpty() && reconciledLines.isNotEmpty(),
        totalRefundPaise = totalRefund,
        quarantinedLineCount = quarantinedCount,
        restockedLineCount = restockedCount,
        errors = errors,
      )
    return ReturnEvaluation(preview = preview, invoice = invoice, computedLines = reconciledLines)
  }

  private fun reconcileLineRefundsWithInvoiceGrandTotal(
    invoice: InvoiceEntity,
    allInvoiceLines: List<InvoiceLineEntity>,
    aggregatesByLineId: Map<String, com.rindleworks.orva.data.local.ReturnLineSummaryAggregate>,
    alreadyRefundedInvoiceTotal: Long,
    computed: List<ComputedReturnLine>,
  ): List<ComputedReturnLine> {
    val remainingInvoiceRefundBudget =
      maxOf(0L, CheckedMath.subtractExact(invoice.grandTotalPaise, alreadyRefundedInvoiceTotal))
    val returningByLineId = computed.associate { it.invoiceLine.invoiceLineId to it.returnQuantityMilli }

    val completesEntireInvoice =
      allInvoiceLines.all { invLine ->
        val prevQty = aggregatesByLineId[invLine.invoiceLineId]?.returnedQtyMilli ?: 0L
        val thisQty = returningByLineId[invLine.invoiceLineId] ?: 0L
        CheckedMath.addExact(prevQty, thisQty) == invLine.quantityMilli
      }

    val mutable = computed.toMutableList()
    val rawSum = mutable.fold(0L) { acc, l -> CheckedMath.addExact(acc, l.lineRefundPaise) }

    if (completesEntireInvoice) {
      // Adjust across lines from the end so SUM(lines) == remainingInvoiceRefundBudget exactly.
      var delta = CheckedMath.subtractExact(remainingInvoiceRefundBudget, rawSum)
      if (delta > 0L) {
        val lastIdx = mutable.lastIndex
        mutable[lastIdx] =
          mutable[lastIdx].copy(
            lineRefundPaise = CheckedMath.addExact(mutable[lastIdx].lineRefundPaise, delta)
          )
      } else if (delta < 0L) {
        var toSubtract = -delta
        for (idx in mutable.lastIndex downTo 0) {
          if (toSubtract <= 0L) break
          val reducible = minOf(mutable[idx].lineRefundPaise, toSubtract)
          mutable[idx] =
            mutable[idx].copy(
              lineRefundPaise = CheckedMath.subtractExact(mutable[idx].lineRefundPaise, reducible)
            )
          toSubtract -= reducible
        }
      }
    } else if (rawSum > remainingInvoiceRefundBudget) {
      var excess = CheckedMath.subtractExact(rawSum, remainingInvoiceRefundBudget)
      for (idx in mutable.lastIndex downTo 0) {
        if (excess <= 0L) break
        val reducible = minOf(mutable[idx].lineRefundPaise, excess)
        mutable[idx] =
          mutable[idx].copy(
            lineRefundPaise = CheckedMath.subtractExact(mutable[idx].lineRefundPaise, reducible)
          )
        excess -= reducible
      }
    }

    return mutable
  }

  private fun loadReturnableLines(db: OrvaDatabase, invoiceId: String): List<ReturnableInvoiceLine> {
    val lines = db.invoiceDao().getLinesForInvoice(invoiceId)
    val aggregates =
      db.salesReturnDao().getCompletedReturnAggregatesForInvoice(invoiceId)
        .associateBy { it.invoiceLineId }

    return lines.map { line ->
      val agg = aggregates[line.invoiceLineId]
      val returnedQty = agg?.returnedQtyMilli ?: 0L
      val refundedPaise = agg?.refundedPaise ?: 0L
      val batchStatus =
        BatchStatus.fromDbValue(db.stockBatchDao().getById(line.batchId)?.batchStatus)
          ?: BatchStatus.Active

      ReturnableInvoiceLine(
        invoiceLineId = line.invoiceLineId,
        medicineId = line.medicineId,
        batchId = line.batchId,
        medicineName = line.medicineNameSnapshot,
        batchNumber = line.batchNumberSnapshot,
        expiryYyyyMm = line.expiryYyyyMmSnapshot,
        stockUnitName = line.unitNameSnapshot,
        originalQuantityMilli = line.quantityMilli,
        alreadyReturnedMilli = returnedQty,
        remainingReturnableMilli = maxOf(0L, CheckedMath.subtractExact(line.quantityMilli, returnedQty)),
        unitPricePaise = line.unitPricePaise,
        originalLineTotalPaise = line.lineTotalPaise,
        alreadyRefundedPaise = refundedPaise,
        remainingRefundablePaise = maxOf(0L, CheckedMath.subtractExact(line.lineTotalPaise, refundedPaise)),
        batchStatus = batchStatus,
        gstRateBasisPoints = line.gstRateBasisPoints,
        hsnCode = line.hsnCodeSnapshot,
      )
    }
  }

  private data class ComputedReturnLine(
    val invoiceLine: InvoiceLineEntity,
    val returnQuantityMilli: Long,
    val disposition: ResaleDisposition,
    val lineRefundPaise: Long,
  )

  private data class ReturnEvaluation(
    val preview: SalesReturnPreviewResult,
    val invoice: InvoiceEntity?,
    val computedLines: List<ComputedReturnLine>,
  )

  private sealed interface ReturnCommitOutcome {
    data class Rejected(val error: String) : ReturnCommitOutcome
    data class Committed(val result: SalesReturnResult, val shouldRefreshSnapshot: Boolean) :
      ReturnCommitOutcome
  }

  @Serializable
  private data class ReturnAuditDto(
    val returnNumber: String,
    val invoiceNumber: String,
    val refundAmountPaise: Long,
    val refundMethod: String,
    val restockedLines: Int,
    val quarantinedLines: Int,
  )
}
