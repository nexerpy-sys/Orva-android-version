package com.rindleworks.orva.ui.showcase

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.rindleworks.orva.di.OrvaAppContainer
import com.rindleworks.orva.domain.common.AppVersionInfo
import com.rindleworks.orva.domain.engine.BillingInstant
import com.rindleworks.orva.domain.inventory.ExpiryAlertLevel
import com.rindleworks.orva.domain.inventory.InventoryFilterMode
import com.rindleworks.orva.domain.settings.AppLanguage
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/**
 * UI state contract for ORVA Home showcase screen.
 * Driven exclusively from real local state (zero invented counts, dates, or sample shop names).
 */
data class HomeShowcaseUiState(
  val shopName: String = "ORVA",
  val dateText: String = "",
  val usableMedicineCount: Int = 0,
  val expiringSoonCount: Int = 0,
  val backupStatus: ReadinessBackupState = ReadinessBackupState.NotYetBackedUp,
  val appVersion: String = "1.0",
  val language: AppLanguage = AppLanguage.English,
  val isLoaded: Boolean = false,
)

/**
 * UI state contract for ORVA About Us showcase screen.
 * Support phone and email are nullable — blank settings MUST remain null so UI omits absent rows.
 */
data class AboutShowcaseUiState(
  val appVersion: String = "1.0",
  val buildNumber: String = "1",
  val supportPhone: String? = null,
  val supportEmail: String? = null,
  val language: AppLanguage = AppLanguage.English,
)

/** Navigation & showcase actions emitted by Home and About Us screens. */
sealed interface ShowcaseUiEvent {
  data object StartBilling : ShowcaseUiEvent
  data object AddStock : ShowcaseUiEvent
  data object OpenInventory : ShowcaseUiEvent
  data object OpenAboutUs : ShowcaseUiEvent
  data object BackToHome : ShowcaseUiEvent
  data object OpenSettings : ShowcaseUiEvent
  data object ToggleLanguage : ShowcaseUiEvent
}

/**
 * Shared ViewModel binding Home & About Us directly to [OrvaAppContainer]'s live local data.
 */
class OrvaShowcaseViewModel(
  private val container: OrvaAppContainer,
) : ViewModel() {

  private val versionInfo: AppVersionInfo = container.appVersionInfo

  private val _homeState =
    MutableStateFlow(
      HomeShowcaseUiState(
        dateText = formatLocalDate(),
        appVersion = versionInfo.versionName,
      )
    )
  val homeState: StateFlow<HomeShowcaseUiState> = _homeState.asStateFlow()

  private val _aboutState =
    MutableStateFlow(
      AboutShowcaseUiState(
        appVersion = versionInfo.versionName,
        buildNumber = versionInfo.versionCode.toString(),
      )
    )
  val aboutState: StateFlow<AboutShowcaseUiState> = _aboutState.asStateFlow()

  init {
    observeLocalState()
    refreshOneShotSettings()
  }

  private fun observeLocalState() {
    viewModelScope.launch {
      combine(
        container.shopRepository.observeProfile(),
        container.inventoryRepository.observeInventoryRows("", InventoryFilterMode.All),
        container.inventoryRepository.observeExpiryAlerts(),
      ) { profile, rows, expiryAlerts ->
        val usableMedicines =
          rows
            .asSequence()
            .filter { it.usableMedicineTotalMilli > 0L }
            .map { it.medicineId }
            .distinct()
            .count()
        val expiringWithin30 =
          expiryAlerts.count { it.alertLevel == ExpiryAlertLevel.UrgentWarning30Days }
        Triple(profile?.shopName?.trim()?.ifEmpty { null }, usableMedicines, expiringWithin30)
      }.collect { (shopName, usableCount, expiringCount) ->
        val backupStatus = readBackupState()
        _homeState.update { prev ->
          prev.copy(
            shopName = shopName ?: "ORVA",
            dateText = formatLocalDate(),
            usableMedicineCount = usableCount,
            expiringSoonCount = expiringCount,
            backupStatus = backupStatus,
            isLoaded = true,
          )
        }
      }
    }
  }

  fun refreshOneShotSettings() {
    viewModelScope.launch {
      val lang = runCatching { container.appSettingsRepository.getLanguage() }.getOrDefault(AppLanguage.English)
      val supportPrefs = runCatching { container.appSettingsRepository.getOperationalSupportPrefs() }.getOrNull()
      val backupStatus = readBackupState()

      val cleanPhone = supportPrefs?.supportPhones?.trim()?.ifEmpty { null }
      val cleanEmail = supportPrefs?.supportEmail?.trim()?.ifEmpty { null }

      _homeState.update {
        it.copy(
          language = lang,
          dateText = formatLocalDate(),
          backupStatus = backupStatus,
        )
      }
      _aboutState.update {
        it.copy(
          appVersion = versionInfo.versionName,
          buildNumber = versionInfo.versionCode.toString(),
          supportPhone = cleanPhone,
          supportEmail = cleanEmail,
          language = lang,
        )
      }
    }
  }

  fun toggleLanguage() {
    val next =
      if (_homeState.value.language == AppLanguage.English) {
        AppLanguage.Bengali
      } else {
        AppLanguage.English
      }
    _homeState.update { it.copy(language = next) }
    _aboutState.update { it.copy(language = next) }
    viewModelScope.launch {
      runCatching { container.appSettingsRepository.setLanguage(next) }
    }
  }

  private suspend fun readBackupState(): ReadinessBackupState {
    val summary = runCatching { container.backupRestoreService.getBackupStatus() }.getOrNull()
    return when {
      summary == null || summary.lastSuccessUtc.isNullOrBlank() -> ReadinessBackupState.NotYetBackedUp
      summary.isDueToday -> ReadinessBackupState.DueToday
      else -> ReadinessBackupState.Saved
    }
  }

  private fun formatLocalDate(): String {
    val localDate = BillingInstant.capture(container.clock).localBusinessDate
    return localDate.format(DateTimeFormatter.ofPattern("dd MMM yyyy", Locale.ENGLISH))
  }

  class Factory(private val container: OrvaAppContainer) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T =
      OrvaShowcaseViewModel(container) as T
  }
}
