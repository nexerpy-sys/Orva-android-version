package com.rindleworks.orva.ui.about.agentic

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rindleworks.orva.domain.settings.AppLanguage
import com.rindleworks.orva.ui.showcase.OrvaShowcaseFonts
import com.rindleworks.orva.ui.showcase.currentShowcasePalette
import kotlin.math.sin

/**
 * Single high-efficiency Compose Canvas rendering ORVA's About Us Agentic Build overlay:
 * - Immediate live construction (ZERO opening ORVA text/glow veil)
 * - Architectural `saai.pro`-inspired micro ruler ticks along the left rail during active build
 * - `21st.dev`-inspired traveling luminous Border Beam along active drafting frames + crisp `W × H` badges
 * - `cursor-swarm.js`-inspired role micro-tags (`LAYOUT`, `TYPE`, `CLONE`, `MEDIA`), blinking I-beam
 *   caret, media scan-line wipe, snap ripples, and completion diamond sparks
 * - Electric Royal Purple & Signal Vermilion cursors with tight, optical specular glow (zero muddy
 *   overlapping neon blobs; idle cursors dim cleanly at the viewport margins)
 *
 * Subscribes ONLY the draw phase to [AgenticBuildController.frameTick] -> 0 recompositions/sec.
 */
@Composable
fun AgenticOverlayCanvas(
  controller: AgenticBuildController,
  modifier: Modifier = Modifier,
) {
  val textMeasurer = rememberTextMeasurer()
  val palette = currentShowcasePalette()
  val monoFont = OrvaShowcaseFonts.mono(AppLanguage.English)
  val badgeStyle =
    remember(palette, monoFont) {
      TextStyle(
        color = palette.inkPrimary,
        fontSize = 8.5.sp,
        fontWeight = FontWeight.SemiBold,
        fontFamily = monoFont,
        letterSpacing = 0.6.sp,
      )
    }
  val tagStyle =
    remember(palette, monoFont) {
      TextStyle(
        color = palette.inkPrimary,
        fontSize = 8.sp,
        fontWeight = FontWeight.Medium,
        fontFamily = monoFont,
        letterSpacing = 0.8.sp,
      )
    }
  val rulerStyle =
    remember(palette, monoFont) {
      TextStyle(
        color = palette.inkMuted,
        fontSize = 7.5.sp,
        fontWeight = FontWeight.Normal,
        fontFamily = monoFont,
      )
    }
  val stampStyle =
    remember(palette, monoFont) {
      TextStyle(
        color = palette.inkSecondary,
        fontSize = 8.5.sp,
        fontWeight = FontWeight.Medium,
        fontFamily = monoFont,
        letterSpacing = 0.35.sp,
      )
    }
  Canvas(modifier = modifier.fillMaxSize()) {
    // Subscribe ONLY this draw block to frameTick
    val tick = controller.frameTick
    if (tick < 0L) return@Canvas
    val globalAlpha = controller.overlayAlpha.coerceIn(0f, 1f)
    val scrollY = controller.scrollState.value.toFloat()
    val simTimeMs = controller.currentSimTimeMs

    // 0a. Subtle zll.me architectural square drafting grid during active build
    drawSubtleArchitecturalGrid(
      scrollY = scrollY,
      densityPxPerDp = controller.densityPxPerDp,
      alpha = globalAlpha * 0.45f,
      lineTint = controller.activeThemeTextColor,
    )

    // 0b. Act I Orbital Scan: the real Scene 01 composition remains visible while the swarm inspects its measured geometry.

    // 0c. Subtle architectural edge drafting ruler (saai.pro precision cue, fades out on completion)
    drawPipetteMeasureGauge(
      controller = controller,
      scrollY = scrollY,
      textMeasurer = textMeasurer,
      rulerStyle = rulerStyle,
      inkColor = controller.activeThemeTextColor,
      mutedColor = controller.activeThemeTextColor.copy(alpha = 0.72f),
      hairlineColor = controller.activeThemeHairlineColor,
      accentColor = controller.activeThemeAccentColor,
      signalColor = controller.activeThemeSignalColor,
    )

    // One scene seal per real scene completion; the same scheduler journal also drives rewind.
    for (stamp in controller.sceneStamps.values) {
      val root = controller.scheduler.sceneRootBounds(stamp.sceneIndex) ?: continue
      val sceneTop = root.top - scrollY
      val sceneBottom = root.bottom - scrollY
      if (sceneBottom < -32f || sceneTop > size.height + 32f) continue
      val prefix = "LOT RW-%02d · DISPENSED ".format(stamp.sceneIndex)
      val stampText = buildAnnotatedString {
        append(prefix)
        withStyle(SpanStyle(color = controller.activeThemeSignalColor)) { append("✓") }
      }
      val layout = textMeasurer.measure(
        stampText,
        style = stampStyle.copy(color = controller.activeThemeTextColor.copy(alpha = 0.82f)),
      )
      val entrance = if (stamp.restoredInstantly) 1f else {
        ((simTimeMs - stamp.committedAtMs).toFloat() / 120f).coerceIn(0f, 1f)
      }
      val lift = stamp.liftingStartedAtMs?.let {
        ((simTimeMs - it).toFloat() / 120f).coerceIn(0f, 1f)
      } ?: 0f
      val alpha = entrance * (1f - lift)
      if (alpha <= 0.005f) continue
      val x = (root.right - layout.size.width - 14.dp.toPx()).coerceAtLeast(root.left + 8.dp.toPx())
      val y = sceneTop + 14.dp.toPx()
      val pivot = Offset(x + layout.size.width / 2f, y + layout.size.height / 2f)
      val stampScale = (1.12f - 0.12f * entrance) * (1f - 0.06f * lift)
      withTransform({ scale(stampScale, stampScale, pivot) }) {
        drawText(layout, topLeft = Offset(x, y), alpha = alpha)
      }
    }

    // A single violet verification pass follows the stamp. It is driven by the same frame clock.
    if (!controller.reducedMotion && controller.optionalEffectDegradationLevel == 0) {
      for (sweep in controller.sceneVerifySweeps.values) {
        val root = controller.scheduler.sceneRootBounds(sweep.sceneIndex) ?: continue
        val sceneTop = root.top - scrollY
        val sceneBottom = root.bottom - scrollY
        if (sceneBottom < 0f || sceneTop > size.height) continue
        val elapsed = simTimeMs - sweep.startedAtMs
        if (elapsed !in 0L..400L) continue
        val progress = elapsed / 400f
        val band = 24.dp.toPx()
        val x = root.left - band + (root.right - root.left + band * 2f) * progress
        drawRect(
          brush = Brush.linearGradient(
            colors = listOf(
              Color.Transparent,
              controller.activeThemeSignalColor.copy(alpha = 0.06f),
              Color.Transparent,
            ),
            start = Offset(x, sceneTop),
            end = Offset(x + band, sceneTop),
          ),
          topLeft = Offset(x, sceneTop),
          size = Size(band, (sceneBottom - sceneTop).coerceAtLeast(0f)),
        )
      }
    }

    // 1. Active Drafting Wireframes + 21st.dev Traveling Border Beam + Media Scan Wipe + W × H Badges
    for (wf in controller.activeWireframes.values) {
      val screenRect = wf.currentRect.translate(0f, -scrollY)
      if (screenRect.bottom < -40f || screenRect.top > size.height + 40f) continue
      drawDraftingWireframeWithBeam(
        rect = screenRect,
        accentColor = wf.accentColor,
        isTextSelection = wf.isTextSelection,
        isMediaScan = wf.isMediaScan,
        progress = wf.progress,
        beamPhase = wf.beamPhase,
        widthDp = wf.widthDp,
        heightDp = wf.heightDp,
        textMeasurer = textMeasurer,
        badgeStyle = badgeStyle,
        tagSurfaceColor = palette.agentTagSurface,
        backgroundColor = palette.canvasDeep,
        neutralTextColor = palette.inkPrimary,
        alpha = globalAlpha,
        reducedMotion = controller.reducedMotion,
        degradationLevel = controller.optionalEffectDegradationLevel,
      )
    }

    // 2. Translucent Clone Ghosts gliding along curved Bezier arcs
    for (ghost in controller.cloneGhosts.values) {
      val screenRect = ghost.currentRect.translate(0f, -scrollY)
      if (screenRect.bottom < -80f || screenRect.top > size.height + 80f) continue
      drawRoundRect(
        color = palette.surfaceRaised.copy(alpha = 0.62f * ghost.alpha * globalAlpha),
        topLeft = screenRect.topLeft,
        size = screenRect.size,
        cornerRadius = CornerRadius(4.dp.toPx()),
      )
      drawRoundRect(
        color = ghost.accentColor.copy(alpha = 0.85f * ghost.alpha * globalAlpha),
        topLeft = screenRect.topLeft,
        size = screenRect.size,
        cornerRadius = CornerRadius(4.dp.toPx()),
        style = Stroke(width = 1.dp.toPx()),
      )
    }

    // 3. Real-Snap-Only Smart Guides (#FF3B30) with Precision End Ticks + Spacing Pills
    for (guide in controller.smartGuides) {
      val p1 = Offset(guide.start.x, guide.start.y - scrollY)
      val p2 = Offset(guide.end.x, guide.end.y - scrollY)
      val ageFrac = ((simTimeMs - guide.createdAtMs).toFloat() / guide.durationMs.toFloat()).coerceIn(0f, 1f)
      val fade = (1f - ageFrac * ageFrac).coerceIn(0f, 1f)
      val guideColor = controller.activeThemeAccentColor.copy(alpha = 0.82f * fade * globalAlpha)
      val tickHalf = 3.dp.toPx()
      drawLine(
        color = guideColor,
        start = p1,
        end = p2,
        strokeWidth = 0.9.dp.toPx(),
      )
      val isVertical = kotlin.math.abs(p1.x - p2.x) < 1f
      if (isVertical) {
        drawLine(guideColor, Offset(p1.x - tickHalf, p1.y), Offset(p1.x + tickHalf, p1.y), 0.9.dp.toPx())
        drawLine(guideColor, Offset(p2.x - tickHalf, p2.y), Offset(p2.x + tickHalf, p2.y), 0.9.dp.toPx())
      } else {
        drawLine(guideColor, Offset(p1.x, p1.y - tickHalf), Offset(p1.x, p1.y + tickHalf), 0.9.dp.toPx())
        drawLine(guideColor, Offset(p2.x, p2.y - tickHalf), Offset(p2.x, p2.y + tickHalf), 0.9.dp.toPx())
      }
      if (!guide.label.isNullOrBlank()) {
        val mid = Offset((p1.x + p2.x) * 0.5f, (p1.y + p2.y) * 0.5f)
        drawMeasurementPill(
          text = guide.label,
          center = mid,
          bgColor = controller.activeThemeAccentColor.copy(alpha = 0.92f * fade * globalAlpha),
          textMeasurer = textMeasurer,
          style = badgeStyle,
        )
      }
    }

    // 4. Expanding 1dp Snap Ripples & Completion Micro-Sparks (cursor-swarm.js polish)
    for (ripple in controller.snapRipples) {
      val p = ((simTimeMs - ripple.createdAtMs).toFloat() / ripple.durationMs.toFloat()).coerceIn(0f, 1f)
      val pt = Offset(ripple.center.x, ripple.center.y - scrollY)
      val radius = (3.5f + p * 15f).dp.toPx()
      val ringAlpha = (1f - p) * (1f - p) * 0.65f * globalAlpha
      if (ringAlpha > 0.01f) {
        drawCircle(
          color = ripple.color.copy(alpha = ringAlpha),
          radius = radius,
          center = pt,
          style = Stroke(width = 1.dp.toPx()),
        )
      }
    }

    for (spark in controller.completionSparks) {
      val elapsedSec = ((simTimeMs - spark.createdAtMs).toFloat() / 1000f).coerceAtLeast(0f)
      val p = ((simTimeMs - spark.createdAtMs).toFloat() / spark.durationMs.toFloat()).coerceIn(0f, 1f)
      val ease = 1f - (1f - p) * (1f - p)
      val pos =
        Offset(
          x = spark.origin.x + spark.velocity.x * elapsedSec * (1f - ease * 0.35f),
          y = spark.origin.y - scrollY + spark.velocity.y * elapsedSec * (1f - ease * 0.35f),
        )
      val sparkAlpha = (1f - p) * 0.85f * globalAlpha
      if (sparkAlpha > 0.02f) {
        drawCircle(
          color = spark.color.copy(alpha = sparkAlpha),
          radius = (2.3f * (1f - p * 0.72f)).coerceAtLeast(0.5f).dp.toPx(),
          center = pos,
        )
      }
    }

    // 5. Four-Point Star Media Glints (✦)
    for (glint in controller.mediaGlints) {
      val pt = Offset(glint.center.x, glint.center.y - scrollY)
      val glintScale = sin(glint.progress * Math.PI).toFloat().coerceIn(0f, 1f)
      if (glintScale > 0.05f) {
        drawFourPointStar(
          center = pt,
          radiusPx = 5.5.dp.toPx() * glintScale,
          color = controller.activeThemeSignalColor.copy(alpha = 0.88f * glintScale * globalAlpha),
        )
      }
    }

    // 6. Crisp Visitor Touch Reticle (thin 1dp ring, never a blurry blob)
    controller.visitorTouchContentPos?.let { touchContent ->
      val touchScreen = Offset(touchContent.x, touchContent.y - scrollY)
      drawCircle(
        color = controller.activeThemeAccentColor.copy(alpha = 0.38f * globalAlpha),
        radius = 12.dp.toPx(),
        center = touchScreen,
        style = Stroke(width = 1.dp.toPx()),
      )
    }

    // 7. Sixteen Electric Royal Purple & Signal Vermilion Cursors
    //    Active builders: silky quadratic motion ribbon + tight optical specular glow + crisp role tag
    //    Idle scouts: quietly dimmed at margins with zero glow halo
    for (agent in controller.agents) {
      val screenPos = Offset(agent.pos.x, agent.pos.y - scrollY)
      if (screenPos.y < -48f || screenPos.y > size.height + 48f) continue

      val agentAlpha = (agent.visualAlpha * globalAlpha).coerceIn(0f, 1f)
      if (agentAlpha <= 0.02f) continue
      val energy = agent.glowEnergy.coerceIn(0f, 1.08f)
      val cursorColor = controller.colorForAgent(agent.id)

      // 7a. Silky quadratic motion ribbon (active flights/drags only)
      if (agent.trail.size >= 3 && energy > 0.1f) {
        drawSmoothMotionRibbon(
          trail = agent.trail,
          scrollY = scrollY,
          color = cursorColor,
          alpha = agentAlpha * 0.18f,
        )
      }

      // 7b. Tight, arrow-tip-anchored optical specular glow (Master Directive §5.4: exact tip coordinate)
      if (energy > 0.05f) {
        drawOpticalSpecularGlow(
          center = screenPos,
          cursorColor = cursorColor,
          neutralColor = palette.inkPrimary,
          energy = energy,
          alpha = agentAlpha,
        )
      }

      // 7c. Viewport-spanning dashed crosshair guides (zll.me stroke-dasharray: 4 4) + crisp cursor vector
      when (agent.mode) {
        CursorVisualMode.POINTER -> drawPrecisionPointerCursor(screenPos, cursorColor, palette.inkPrimary, agentAlpha)
        CursorVisualMode.CROSSHAIR -> {
          if (agent.activeNodeId != null && agentAlpha > 0.35f) {
            val dash = PathEffect.dashPathEffect(floatArrayOf(4.dp.toPx(), 4.dp.toPx()), 0f)
            val guideTint = cursorColor.copy(alpha = 0.24f * agentAlpha)
            drawLine(
              color = guideTint,
              start = Offset(0f, screenPos.y),
              end = Offset(size.width, screenPos.y),
              strokeWidth = 0.85.dp.toPx(),
              pathEffect = dash,
            )
            drawLine(
              color = guideTint,
              start = Offset(screenPos.x, 0f),
              end = Offset(screenPos.x, size.height),
              strokeWidth = 0.85.dp.toPx(),
              pathEffect = dash,
            )
          }
          drawCrosshairCursor(screenPos, cursorColor, palette.inkPrimary, agentAlpha)
        }
        CursorVisualMode.I_BEAM -> {
          // 550ms stepped blink (zll.me caret-blink 550ms steps(1) infinite)
          val blinkOn = ((simTimeMs / 550L) % 2L == 0L)
          drawIBeamCursor(screenPos, cursorColor, palette.inkPrimary, if (blinkOn) agentAlpha else agentAlpha * 0.30f)
        }
      }

      // 7d. Sleek cursor-swarm.js micro role tag (active builders only)
      if (agent.activeNodeId != null && agentAlpha > 0.45f) {
        drawAgentRoleTag(
          anchor = Offset(screenPos.x + 12.dp.toPx(), screenPos.y + 11.dp.toPx()),
          label = agent.roleLabel,
          accentColor = cursorColor,
          alpha = agentAlpha,
          textMeasurer = textMeasurer,
          style = tagStyle.copy(color = controller.activeThemeTextColor),
          tagSurfaceColor = palette.agentTagSurface,
          textColor = palette.inkPrimary,
        )
      }
    }
  }
}

/**
 * Scheduler-backed pipette gauge. Scene anchors come from registered root bounds and fill comes
 * from the actual layer state/journal, never raw scroll percentage.
 */
private fun DrawScope.drawPipetteMeasureGauge(
  controller: AgenticBuildController,
  scrollY: Float,
  textMeasurer: TextMeasurer,
  rulerStyle: TextStyle,
  inkColor: Color,
  mutedColor: Color,
  hairlineColor: Color,
  accentColor: Color,
  signalColor: Color,
) {
  val railX = 2.dp.toPx()
  val railBottom = size.height
  val progress = controller.buildProgress.coerceIn(0f, 1f)
  val fillY = railBottom * progress
  val hairline = hairlineColor
  val chalk = inkColor
  val muted = mutedColor

  drawLine(hairline, Offset(railX, 0f), Offset(railX, railBottom), 2.dp.toPx())
  if (fillY > 0f) drawLine(chalk, Offset(railX, 0f), Offset(railX, fillY), 2.dp.toPx())

  // Fine 8dp calibrations remain legible when major scene labels are outside the viewport.
  var y = 0f
  val minorStep = 8.dp.toPx()
  while (y <= railBottom) {
    val active = y <= fillY
    drawLine(
      color = (if (active) chalk else muted).copy(alpha = 0.55f),
      start = Offset(railX, y),
      end = Offset(railX + 5.dp.toPx(), y),
      strokeWidth = 0.75.dp.toPx(),
    )
    y += minorStep
  }

  val sealed = controller.scheduler.sealedSceneIndices()
  val sceneNodes = controller.scheduler.allNodesSnapshot()
  for (sceneIndex in controller.scheduler.sceneIndicesSnapshot().sorted()) {
    val root = controller.scheduler.sceneRootBounds(sceneIndex) ?: continue
    val anchorY = root.top - scrollY
    if (anchorY !in 0f..railBottom) continue
    val isBuilding = sceneNodes.any {
      it.sceneIndex == sceneIndex && (it.phase == LayerPhase.BUILDING || it.phase == LayerPhase.REVERSING)
    }
    val ink = when {
      sceneIndex in sealed -> chalk
      isBuilding -> signalColor
      else -> muted
    }
    drawLine(
      color = ink,
      start = Offset(railX, anchorY),
      end = Offset(railX + 12.dp.toPx(), anchorY),
      strokeWidth = 1.5.dp.toPx(),
    )
    val label = textMeasurer.measure("%02d".format(sceneIndex), style = rulerStyle.copy(color = ink))
    drawText(label, topLeft = Offset(railX + 15.dp.toPx(), anchorY - label.size.height * 0.5f))
  }

  // Liquid meniscus is optional. Under reduced motion/performance pressure it becomes a static line.
  if (progress > 0f && progress < 1f) {
    if (controller.reducedMotion || controller.optionalEffectDegradationLevel >= 3) {
      drawLine(
        accentColor,
        Offset(railX - 1.dp.toPx(), fillY),
        Offset(railX + 9.dp.toPx(), fillY),
        5.dp.toPx(),
        cap = StrokeCap.Round,
      )
    } else {
      val meniscus = Path().apply {
        moveTo(railX - 1.dp.toPx(), fillY)
        quadraticTo(railX + 4.dp.toPx(), fillY - 2.dp.toPx(), railX + 9.dp.toPx(), fillY)
      }
      drawPath(meniscus, accentColor, style = Stroke(width = 6.dp.toPx(), cap = StrokeCap.Round))
    }
  }
}

/**
 * Silky quadratic-interpolated motion ribbon following active cursor flights.
 */
private fun DrawScope.drawSmoothMotionRibbon(
  trail: ArrayDeque<Offset>,
  scrollY: Float,
  color: Color,
  alpha: Float,
) {
  val count = trail.size
  if (count < 3) return
  for (i in 1 until count - 1) {
    val p0 = Offset(trail[i - 1].x, trail[i - 1].y - scrollY)
    val p1 = Offset(trail[i].x, trail[i].y - scrollY)
    val p2 = Offset(trail[i + 1].x, trail[i + 1].y - scrollY)
    val mid1 = Offset((p0.x + p1.x) * 0.5f, (p0.y + p1.y) * 0.5f)
    val mid2 = Offset((p1.x + p2.x) * 0.5f, (p1.y + p2.y) * 0.5f)
    val frac = i.toFloat() / (count - 1).toFloat()
    val segPath =
      Path().apply {
        moveTo(mid1.x, mid1.y)
        quadraticTo(p1.x, p1.y, mid2.x, mid2.y)
      }
    drawPath(
      path = segPath,
      color = color.copy(alpha = alpha * frac * frac),
      style = Stroke(width = (1.5.dp.toPx() * frac).coerceAtLeast(0.5f), cap = StrokeCap.Round),
    )
  }
}

/**
 * Tight, professional optical specular glow anchored 1:1 to an active cursor tip.
 * Controlled falloff with zero muddy wide-radius radial clouds.
 */
private fun DrawScope.drawOpticalSpecularGlow(
  center: Offset,
  cursorColor: Color,
  neutralColor: Color,
  energy: Float,
  alpha: Float,
) {
  // A cursor should look self-illuminated, not surrounded by a detached neon cloud.
  // Keep this bloom deliberately smaller than the pointer's visual footprint.
  val outerRadius = (8.5f + energy * 2.5f).dp.toPx()
  val coreRadius = (2.0f + energy * 0.65f).dp.toPx()

  drawCircle(
    brush =
      Brush.radialGradient(
        colorStops =
          arrayOf(
            0.0f to cursorColor.copy(alpha = (0.15f * energy * alpha).coerceAtMost(0.18f)),
            0.34f to cursorColor.copy(alpha = (0.055f * energy * alpha).coerceAtMost(0.07f)),
            0.72f to cursorColor.copy(alpha = (0.012f * energy * alpha).coerceAtMost(0.02f)),
            1.0f to Color.Transparent,
          ),
        center = center,
        radius = outerRadius,
      ),
    radius = outerRadius,
    center = center,
    blendMode = BlendMode.Screen,
  )

  // Tiny neutral specular centre; the pointer vector is drawn above it in the same pass.
  drawCircle(
    brush =
      Brush.radialGradient(
        colorStops =
          arrayOf(
            0.0f to neutralColor.copy(alpha = (0.15f * energy * alpha).coerceAtMost(0.18f)),
            0.48f to cursorColor.copy(alpha = (0.10f * energy * alpha).coerceAtMost(0.12f)),
            1.0f to Color.Transparent,
          ),
        center = center,
        radius = coreRadius,
      ),
    radius = coreRadius,
    center = center,
    blendMode = BlendMode.Screen,
  )
}

/**
 * Architectural drafting frame featuring a `21st.dev`-inspired traveling luminous Border Beam,
 * media scan-line wipe, crisp corner nodes, and live `W × H` obsidian-glass measurement pill.
 */
private fun DrawScope.drawDraftingWireframeWithBeam(
  rect: Rect,
  accentColor: Color,
  isTextSelection: Boolean,
  isMediaScan: Boolean,
  progress: Float,
  beamPhase: Float,
  widthDp: Int,
  heightDp: Int,
  textMeasurer: TextMeasurer,
  badgeStyle: TextStyle,
  tagSurfaceColor: Color,
  backgroundColor: Color,
  neutralTextColor: Color,
  alpha: Float,
  reducedMotion: Boolean,
  degradationLevel: Int,
) {
  val baseStroke = accentColor.copy(alpha = (if (isTextSelection) 0.52f else 0.42f) * alpha)
  val fillColor =
    if (isTextSelection) accentColor.copy(alpha = 0.06f * alpha)
    else accentColor.copy(alpha = 0.03f * alpha)

  drawRect(color = fillColor, topLeft = rect.topLeft, size = rect.size)
  drawRect(
    color = baseStroke,
    topLeft = rect.topLeft,
    size = rect.size,
    style = Stroke(width = 0.85.dp.toPx()),
  )

  // 21st.dev-style traveling perimeter Border Beam comet on containers & media
  if (!reducedMotion && !isTextSelection && rect.width > 18f && rect.height > 10f) {
    val perimeterPath =
      Path().apply {
        moveTo(rect.left, rect.top)
        lineTo(rect.right, rect.top)
        lineTo(rect.right, rect.bottom)
        lineTo(rect.left, rect.bottom)
        close()
      }
    val pm = PathMeasure()
    pm.setPath(perimeterPath, false)
    val totalLen = pm.length
    if (totalLen > 12f) {
      val beamLen = (totalLen * 0.24f).coerceIn(28f, 160f)
      val headDist = (beamPhase * totalLen) % totalLen
      val tailDist = headDist - beamLen

      val beamPath = Path()
      if (tailDist >= 0f) {
        pm.getSegment(tailDist, headDist, beamPath, true)
      } else {
        pm.getSegment(totalLen + tailDist, totalLen, beamPath, true)
        pm.getSegment(0f, headDist, beamPath, true)
      }

      // Subtle outer beam sheen + crisp 1.6dp luminous core + bright leading tip
      if (degradationLevel < 2) {
        drawPath(
          path = beamPath,
          color = accentColor.copy(alpha = 0.24f * alpha),
          style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round),
          blendMode = BlendMode.Screen,
        )
      }
      drawPath(
        path = beamPath,
        color = accentColor.copy(alpha = 0.92f * alpha),
        style = Stroke(width = 1.5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round),
      )
      val tipPos = pm.getPosition(headDist)
      drawCircle(
        color = neutralTextColor.copy(alpha = 0.90f * alpha),
        radius = 1.8.dp.toPx(),
        center = tipPos,
      )
    }
  }

  // Top-to-bottom media laser scan-line wipe (zll.me 2px laser scan bar)
  if (isMediaScan) {
    val scanY = rect.top + rect.height * progress.coerceIn(0f, 1f)
    val glowH = 18.dp.toPx()
    val trailTop = (scanY - glowH).coerceAtLeast(rect.top)
    drawRect(
      brush =
        Brush.verticalGradient(
          colors = listOf(Color.Transparent, accentColor.copy(alpha = 0.32f * alpha)),
          startY = trailTop,
          endY = scanY,
        ),
      topLeft = Offset(rect.left, trailTop),
      size = Size(rect.width, (scanY - trailTop).coerceAtLeast(0f)),
      blendMode = BlendMode.Screen,
    )
    drawLine(
      color = accentColor.copy(alpha = 0.92f * alpha),
      start = Offset(rect.left, scanY),
      end = Offset(rect.right, scanY),
      strokeWidth = 2.dp.toPx(),
    )
    drawLine(
      color = neutralTextColor.copy(alpha = 0.92f * alpha),
      start = Offset(rect.left, scanY),
      end = Offset(rect.right, scanY),
      strokeWidth = 0.9.dp.toPx(),
    )
  }

  // Four 3dp precision corner nodes (obsidian fill, crisp accent stroke)
  val handle = 3.2.dp.toPx()
  val half = handle * 0.5f
  val corners = listOf(rect.topLeft, rect.topRight, rect.bottomLeft, rect.bottomRight)
  for (corner in corners) {
    val tl = Offset(corner.x - half, corner.y - half)
    drawRect(color = backgroundColor.copy(alpha = alpha), topLeft = tl, size = Size(handle, handle))
    drawRect(
      color = accentColor.copy(alpha = 0.95f * alpha),
      topLeft = tl,
      size = Size(handle, handle),
      style = Stroke(width = 1.dp.toPx()),
    )
  }

  // Live W × H pill badge centered below bottom border
  if (!isTextSelection && rect.width > 42f) {
    val badgeCenter = Offset(rect.center.x, rect.bottom + 10.dp.toPx())
    drawMeasurementPill(
      text = "$widthDp × $heightDp",
      center = badgeCenter,
      bgColor = tagSurfaceColor.copy(alpha = 0.94f * alpha),
      borderColor = accentColor.copy(alpha = 0.72f * alpha),
      textMeasurer = textMeasurer,
      style = badgeStyle,
    )
  }
}

private fun DrawScope.drawAgentRoleTag(
  anchor: Offset,
  label: String,
  accentColor: Color,
  alpha: Float,
  textMeasurer: TextMeasurer,
  style: TextStyle,
  tagSurfaceColor: Color,
  textColor: Color,
) {
  val measured = textMeasurer.measure(label, style = style.copy(color = textColor.copy(alpha = alpha)))
  val dotRadius = 2.dp.toPx()
  val padX = 5.dp.toPx()
  val padY = 2.dp.toPx()
  val dotGap = 4.dp.toPx()
  val w = padX + dotRadius * 2f + dotGap + measured.size.width + padX
  val h = measured.size.height + padY * 2f

  // Keep pill inside right edge of viewport
  val left = anchor.x.coerceAtMost((size.width - w - 6.dp.toPx()).coerceAtLeast(4f))
  val top = anchor.y.coerceAtMost((size.height - h - 6.dp.toPx()).coerceAtLeast(4f))

  drawRoundRect(
    color = tagSurfaceColor.copy(alpha = 0.92f * alpha),
    topLeft = Offset(left, top),
    size = Size(w, h),
    cornerRadius = CornerRadius(4.dp.toPx()),
  )
  drawRoundRect(
    color = accentColor.copy(alpha = 0.65f * alpha),
    topLeft = Offset(left, top),
    size = Size(w, h),
    cornerRadius = CornerRadius(4.dp.toPx()),
    style = Stroke(width = 0.75.dp.toPx()),
  )
  drawCircle(
    color = accentColor.copy(alpha = alpha),
    radius = dotRadius,
    center = Offset(left + padX + dotRadius, top + h * 0.5f),
  )
  drawText(
    textLayoutResult = measured,
    topLeft = Offset(left + padX + dotRadius * 2f + dotGap, top + padY),
  )
}

private fun DrawScope.drawMeasurementPill(
  text: String,
  center: Offset,
  bgColor: Color,
  textMeasurer: TextMeasurer,
  style: TextStyle,
  borderColor: Color? = null,
) {
  val measured = textMeasurer.measure(text, style = style)
  val padX = 5.dp.toPx()
  val padY = 2.dp.toPx()
  val w = measured.size.width + padX * 2f
  val h = measured.size.height + padY * 2f
  val tl = Offset(center.x - w / 2f, center.y - h / 2f)
  drawRoundRect(
    color = bgColor,
    topLeft = tl,
    size = Size(w, h),
    cornerRadius = CornerRadius(3.dp.toPx()),
  )
  if (borderColor != null) {
    drawRoundRect(
      color = borderColor,
      topLeft = tl,
      size = Size(w, h),
      cornerRadius = CornerRadius(3.dp.toPx()),
      style = Stroke(width = 0.75.dp.toPx()),
    )
  }
  drawText(
    textLayoutResult = measured,
    topLeft = Offset(tl.x + padX, tl.y + padY),
  )
}

private fun DrawScope.drawFourPointStar(
  center: Offset,
  radiusPx: Float,
  color: Color,
) {
  val inner = radiusPx * 0.22f
  val path =
    Path().apply {
      moveTo(center.x, center.y - radiusPx)
      lineTo(center.x + inner, center.y - inner)
      lineTo(center.x + radiusPx, center.y)
      lineTo(center.x + inner, center.y + inner)
      lineTo(center.x, center.y + radiusPx)
      lineTo(center.x - inner, center.y + inner)
      lineTo(center.x - radiusPx, center.y)
      lineTo(center.x - inner, center.y - inner)
      close()
    }
  drawPath(path = path, color = color)
}

private fun DrawScope.drawPrecisionPointerCursor(
  tip: Offset,
  fill: Color,
  outline: Color,
  alpha: Float,
) {
  val s = 1.dp.toPx()
  // Sleek Figma-grade cursor arrow with crisp interior notch
  val path =
    Path().apply {
      moveTo(tip.x, tip.y)
      lineTo(tip.x + 1.1f * s, tip.y + 13.4f * s)
      lineTo(tip.x + 4.8f * s, tip.y + 9.8f * s)
      lineTo(tip.x + 11.0f * s, tip.y + 9.0f * s)
      close()
    }
  drawPath(path = path, color = fill.copy(alpha = alpha))
  drawPath(
    path = path,
    color = outline.copy(alpha = alpha),
    style = Stroke(width = 1.15.dp.toPx(), join = StrokeJoin.Round),
  )
}

private fun DrawScope.drawCrosshairCursor(
  center: Offset,
  tint: Color,
  outline: Color,
  alpha: Float,
) {
  val arm = 6.dp.toPx()
  val gap = 1.8.dp.toPx()
  val halo = 2.2.dp.toPx()
  val inner = 1.15.dp.toPx()
  val segments =
    listOf(
      Offset(center.x - arm, center.y) to Offset(center.x - gap, center.y),
      Offset(center.x + gap, center.y) to Offset(center.x + arm, center.y),
      Offset(center.x, center.y - arm) to Offset(center.x, center.y - gap),
      Offset(center.x, center.y + gap) to Offset(center.x, center.y + arm),
    )
  for ((start, end) in segments) {
    drawLine(outline.copy(alpha = alpha), start, end, halo, StrokeCap.Round)
    drawLine(tint.copy(alpha = alpha), start, end, inner, StrokeCap.Round)
  }
  drawCircle(color = outline.copy(alpha = alpha), radius = 1.dp.toPx(), center = center)
}

private fun DrawScope.drawIBeamCursor(
  center: Offset,
  tint: Color,
  outline: Color,
  alpha: Float,
) {
  val halfH = 7.5.dp.toPx()
  val capW = 2.6.dp.toPx()
  val glowStroke = 2.2.dp.toPx()
  val coreStroke = 1.25.dp.toPx()
  drawLine(tint.copy(alpha = 0.72f * alpha), Offset(center.x, center.y - halfH), Offset(center.x, center.y + halfH), glowStroke, StrokeCap.Round)
  drawLine(outline.copy(alpha = alpha), Offset(center.x, center.y - halfH), Offset(center.x, center.y + halfH), coreStroke, StrokeCap.Round)
  drawLine(outline.copy(alpha = alpha), Offset(center.x - capW, center.y - halfH), Offset(center.x + capW, center.y - halfH), coreStroke, StrokeCap.Round)
  drawLine(outline.copy(alpha = alpha), Offset(center.x - capW, center.y + halfH), Offset(center.x + capW, center.y + halfH), coreStroke, StrokeCap.Round)
}

/**
 * Ultra-subtle `zll.me`-inspired square drafting grid rendered across the obsidian stage during build.
 */
private fun DrawScope.drawSubtleArchitecturalGrid(
  scrollY: Float,
  densityPxPerDp: Float,
  alpha: Float,
  lineTint: Color,
) {
  if (alpha <= 0.02f) return
  val cell = 48f * densityPxPerDp
  val gridColor = lineTint.copy(alpha = 0.045f * alpha)
  var x = cell
  while (x < size.width) {
    drawLine(gridColor, Offset(x, 0f), Offset(x, size.height), strokeWidth = 0.75f)
    x += cell
  }
  val offsetY = -(scrollY % cell)
  var y = offsetY
  while (y < size.height) {
    if (y >= 0f) {
      drawLine(gridColor, Offset(0f, y), Offset(size.width, y), strokeWidth = 0.75f)
    }
    y += cell
  }
}
