package com.rindleworks.orva.ui.about.agentic

import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.unit.dp

val LocalAgenticController = compositionLocalOf<AgenticBuildController?> { null }
enum class AgenticTextRole { DISPLAY, READING, UTILITY }

val LocalAgenticThemeMotion = compositionLocalOf { ThemeHeadlineMotion.WORD_BY_WORD_REVEAL }
val LocalAgenticThemeMediaMotion = compositionLocalOf { ThemeMediaMotion.HORIZONTAL_SCAN }
val LocalAgenticMorphRegionId = compositionLocalOf<String?> { null }

/** Attach a Text composable's measured glyph layout to its stable Agentic Build node. */
@Composable
fun rememberAgenticTextLayoutHandler(nodeId: String): (TextLayoutResult) -> Unit {
  val controller = LocalAgenticController.current
  return remember(controller, nodeId) {
    { layout -> controller?.registerTextLayout(nodeId, layout) }
  }
}

/**
 * Attaches an actual Compose About Us composable to the deterministic Agentic Build scene graph.
 *
 * Key guardrails enforced:
 * - Registers bounds in ONE consistent root/content coordinate space (`boundsInRoot - stageRootTop + scrollY`).
 * - Real Compose content stays the single source of truth; full text is always measured up-front.
 * - Display text uses the identity's headline motion; reading text enters as a quiet block;
 *   utility labels retain measured grapheme-safe typing.
 * - Media uses each identity's scan, foil-press or catalogue-lift reveal without reflow.
 * - Reads reveal progress ONLY in draw / `graphicsLayer` phases -> zero recompositions per frame.
 */
fun Modifier.agenticNode(
  id: String,
  kind: LayerKind,
  parentId: String? = null,
  cloneGroupId: String? = null,
  cloneIndex: Int = 0,
  morphRegionId: String? = null,
  textRole: AgenticTextRole = AgenticTextRole.UTILITY,
): Modifier = composed {
  val controller = LocalAgenticController.current ?: return@composed this
  val resolvedMorphRegionId = LocalAgenticMorphRegionId.current ?: morphRegionId
  val themeMotion = LocalAgenticThemeMotion.current
  val mediaMotion = LocalAgenticThemeMediaMotion.current
  val renderState = controller.getOrCreateRenderState(id)

  this
    .onGloballyPositioned { coords ->
      val rootRect = coords.boundsInRoot()
      val contentRect =
        Rect(
          left = rootRect.left,
          top = rootRect.top - controller.stageRootTopInRootPx + controller.scrollState.value.toFloat(),
          right = rootRect.right,
          bottom = rootRect.bottom - controller.stageRootTopInRootPx + controller.scrollState.value.toFloat(),
        )
      controller.registerComposableBounds(
        id = id,
        kind = kind,
        parentId = parentId,
        cloneGroupId = cloneGroupId,
        cloneIndex = cloneIndex,
        contentRect = contentRect,
        morphRegionId = resolvedMorphRegionId,
      )
    }
    .graphicsLayer {
      val fraction = renderState.revealClipFraction.coerceIn(0f, 1f)
      val animating = controller.isThemeMorphActive && kind == LayerKind.TEXT && textRole == AgenticTextRole.DISPLAY
      val readingText = kind == LayerKind.TEXT && textRole == AgenticTextRole.READING
      val morphingMedia = controller.isThemeMorphActive && kind == LayerKind.MEDIA
      alpha =
        if (controller.act == BuildAct.COMPLETED && !controller.isThemeMorphActive) 1f
        else renderState.revealAlpha.coerceIn(0f, 1f)
      if (readingText) {
        translationY = (1f - fraction) * 8.dp.toPx()
      } else if (animating && themeMotion == ThemeHeadlineMotion.SERIF_LINE_MASK) {
        translationY = (1f - fraction) * 8.dp.toPx()
      }
      if (morphingMedia) {
        when (mediaMotion) {
          ThemeMediaMotion.HORIZONTAL_SCAN -> Unit
          ThemeMediaMotion.FOIL_PRESS -> {
            scaleX = 0.975f + 0.025f * fraction
            scaleY = 0.975f + 0.025f * fraction
          }
          ThemeMediaMotion.CATALOGUE_LIFT -> translationY = (1f - fraction) * 12.dp.toPx()
        }
      }
    }
    .drawWithContent {
      if (controller.act == BuildAct.COMPLETED && !controller.isThemeMorphActive) {
        drawContent()
        return@drawWithContent
      }
      val fraction = renderState.revealClipFraction.coerceIn(0f, 1f)
      if (fraction <= 0.001f) return@drawWithContent

      val accentTint = renderState.activeAccentColor.copy(alpha = 0.08f)

      if (kind == LayerKind.TEXT && textRole == AgenticTextRole.READING) {
        drawContent()
      } else if (kind == LayerKind.TEXT && fraction < 0.999f &&
        textRole == AgenticTextRole.DISPLAY && themeMotion == ThemeHeadlineMotion.SERIF_LINE_MASK
      ) {
        clipRect(left = 0f, top = 0f, right = size.width, bottom = size.height * fraction) {
          drawContent()
        }
      } else if (kind == LayerKind.TEXT && fraction < 0.999f) {
        val measuredLines = renderState.textLineMetrics
        val measuredCarets = renderState.textCaretMetrics
        if (measuredLines.isNotEmpty() && measuredCarets.isNotEmpty()) {
          // Reveal by actual UTF-16 offsets and measured glyph caret positions. One compound path
          // clips the full text draw, preserving shaping, wrapping and span styling.
          // Step on extended grapheme boundaries so Indic conjuncts, combining marks and emoji
          // are revealed as complete visible characters rather than split UTF-16 code units.
          val visibleOffset =
            if (textRole == AgenticTextRole.DISPLAY &&
              themeMotion == ThemeHeadlineMotion.WORD_BY_WORD_REVEAL
            ) {
              renderState.textWordOffsetAtProgress(fraction)
            } else {
              renderState.textOffsetAtProgress(fraction)
            }
          val revealPath = Path()
          for (line in measuredLines) {
            val lineStart = line.start.coerceIn(0, renderState.textLength)
            val lineEnd = line.end.coerceIn(lineStart, renderState.textLength)
            if (lineEnd <= lineStart) continue
            when {
              visibleOffset >= lineEnd -> {
                revealPath.addRect(androidx.compose.ui.geometry.Rect(line.left, line.top, line.right, line.bottom))
              }
              visibleOffset > lineStart -> {
                val caret = measuredCarets.getOrNull(visibleOffset)
                if (caret != null) {
                  val revealRect =
                    if (line.isRtl) {
                      androidx.compose.ui.geometry.Rect(caret.left, line.top, line.right, line.bottom)
                    } else {
                      androidx.compose.ui.geometry.Rect(line.left, line.top, caret.left, line.bottom)
                    }
                  if (revealRect.width > 0f && revealRect.height > 0f) revealPath.addRect(revealRect)
                }
              }
            }
          }
          if (renderState.highlightSelectionActive && !revealPath.isEmpty) {
            drawPath(path = revealPath, color = accentTint)
          }
          clipPath(revealPath) { drawContent() }
        } else {
          // Fallback for composite text containers without one owning TextLayoutResult.
          val lines = renderState.estimatedLineCount.coerceAtLeast(1)
          val scaled = (fraction * lines).coerceIn(0f, lines.toFloat())
          val completedLines = scaled.toInt().coerceIn(0, lines)
          val currentLineFrac = (scaled - completedLines).coerceIn(0f, 1f)
          val lineHeight = size.height / lines.toFloat()
          val revealPath = Path()
          if (completedLines > 0) {
            val completedBottom = (completedLines * lineHeight).coerceAtMost(size.height)
            revealPath.addRect(androidx.compose.ui.geometry.Rect(0f, 0f, size.width, completedBottom))
          }
          if (completedLines < lines && currentLineFrac > 0.001f) {
            val lineTop = completedLines * lineHeight
            val lineBottom = ((completedLines + 1) * lineHeight).coerceAtMost(size.height)
            val lineRight = size.width * currentLineFrac
            revealPath.addRect(androidx.compose.ui.geometry.Rect(0f, lineTop, lineRight, lineBottom))
          }
          if (renderState.highlightSelectionActive && !revealPath.isEmpty) {
            drawPath(path = revealPath, color = accentTint)
          }
          clipPath(revealPath) { drawContent() }
        }
      } else if (kind == LayerKind.MEDIA && fraction < 0.999f) {
        when (mediaMotion) {
          ThemeMediaMotion.HORIZONTAL_SCAN -> clipRect(
            left = 0f, top = 0f, right = size.width * fraction, bottom = size.height,
          ) { drawContent() }
          ThemeMediaMotion.FOIL_PRESS -> {
            val edge = size.width * fraction
            clipRect(left = 0f, top = 0f, right = edge, bottom = size.height) { drawContent() }
            if (fraction > 0.02f) {
              drawLine(
                color = accentTint.copy(alpha = 0.75f),
                start = Offset(edge, 0f),
                end = Offset(edge, size.height),
                strokeWidth = 1.dp.toPx(),
              )
            }
          }
          ThemeMediaMotion.CATALOGUE_LIFT -> clipRect(
            left = 0f, top = size.height * (1f - fraction), right = size.width, bottom = size.height,
          ) { drawContent() }
        }
      } else {
        if (renderState.highlightSelectionActive) {
          drawRect(
            color = accentTint,
            topLeft = Offset.Zero,
            size = Size(size.width * fraction, size.height),
          )
        }
        drawContent()
      }
    }
}
