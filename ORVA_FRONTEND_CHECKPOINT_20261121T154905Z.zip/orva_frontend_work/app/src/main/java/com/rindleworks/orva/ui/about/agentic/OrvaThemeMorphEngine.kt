package com.rindleworks.orva.ui.about.agentic

import kotlin.random.Random

/** The three complete visual identities approved for the ORVA showcase. */
enum class OrvaDesignTheme {
  MEASURED_PRESS,
  FIELD_SPECIMEN,
  MUSEUM_INDEX,
  ;

  fun next(): OrvaDesignTheme = when (this) {
    MEASURED_PRESS -> FIELD_SPECIMEN
    FIELD_SPECIMEN -> MUSEUM_INDEX
    MUSEUM_INDEX -> MEASURED_PRESS
  }
}

enum class ThemeLayoutGrammar { PROOF_PRESS, SPECIMEN_FIELD, MUSEUM_CATALOGUE }
enum class ThemeHeadlineMotion { WORD_BY_WORD_REVEAL, GRAPHEME_REVEAL, SERIF_LINE_MASK }
enum class ThemeMediaMotion { HORIZONTAL_SCAN, FOIL_PRESS, CATALOGUE_LIFT }

data class ThemeColourSet(
  val background: String,
  val surface: String,
  val text: String,
  val accent: String,
  val signal: String,
)

data class FontAxisRange(val min: Float, val max: Float) {
  init {
    require(min.isFinite() && max.isFinite() && max > min)
  }

  fun clamp(value: Float): Float =
    if (value.isFinite()) value.coerceIn(min, max) else min
}

data class ThemeDisplayAxisProfile(
  val weight: FontAxisRange,
  val width: FontAxisRange? = null,
  val opticalSize: FontAxisRange? = null,
  val startWeight: Float,
  val endWeight: Float,
  val startWidth: Float? = null,
  val endWidth: Float? = null,
  val startOpticalSize: Float? = null,
  val endOpticalSize: Float? = null,
) {
  init {
    require(weight.clamp(startWeight) == startWeight && weight.clamp(endWeight) == endWeight)
    require((width == null) == (startWidth == null && endWidth == null))
    require((opticalSize == null) == (startOpticalSize == null && endOpticalSize == null))
    if (width != null) {
      require(
        width.clamp(requireNotNull(startWidth)) == startWidth &&
          width.clamp(requireNotNull(endWidth)) == endWidth,
      )
    }
    if (opticalSize != null) {
      require(
        opticalSize.clamp(requireNotNull(startOpticalSize)) == startOpticalSize &&
          opticalSize.clamp(requireNotNull(endOpticalSize)) == endOpticalSize,
      )
    }
  }
}

data class ThemeDisplayAxisValues(
  val weight: Float,
  val width: Float? = null,
  val opticalSize: Float? = null,
)

data class ThemeTypeSet(
  val display: String,
  val reading: String,
  val utility: String,
  val heroCompactSp: Float,
  val heroStandardSp: Float,
  val heroTabletSp: Float,
  val bodySp: Float,
  val bodyLineHeightSp: Float,
  val utilitySp: Float,
  val scaleRatio: Float,
  val displayAxes: ThemeDisplayAxisProfile? = null,
)

data class OrvaThemeSpec(
  val id: OrvaDesignTheme,
  val name: String,
  val idea: String,
  val layoutGrammar: ThemeLayoutGrammar,
  val headlineMotion: ThemeHeadlineMotion,
  val mediaMotion: ThemeMediaMotion,
  val type: ThemeTypeSet,
  val colours: ThemeColourSet,
)

/**
 * Design identities are content-independent. A scene keeps its content and stable node IDs while
 * its visual blueprint changes. Bengali remains rendered through the dedicated script font.
 */
object OrvaThemeCatalog {
  val all: List<OrvaThemeSpec> = listOf(
    OrvaThemeSpec(
      id = OrvaDesignTheme.MEASURED_PRESS,
      name = "The Measured Press",
      idea = "A measured proofing press: wide display type, editorial reading and mechanical indices.",
      layoutGrammar = ThemeLayoutGrammar.PROOF_PRESS,
      headlineMotion = ThemeHeadlineMotion.WORD_BY_WORD_REVEAL,
      mediaMotion = ThemeMediaMotion.HORIZONTAL_SCAN,
      type = ThemeTypeSet(
        display = "Archivo",
        reading = "Newsreader",
        utility = "Space Mono",
        heroCompactSp = 68f,
        heroStandardSp = 80f,
        heroTabletSp = 112f,
        bodySp = 17f,
        bodyLineHeightSp = 26f,
        utilitySp = 10.5f,
        scaleRatio = 1.333f,
        displayAxes = ThemeDisplayAxisProfile(
          weight = FontAxisRange(100f, 900f),
          width = FontAxisRange(62f, 125f),
          startWeight = 680f,
          endWeight = 900f,
          startWidth = 72f,
          endWidth = 125f,
        ),
      ),
      colours = ThemeColourSet(
        background = "#171D19",
        surface = "#28322B",
        text = "#F0EBDD",
        accent = "#D16A4A",
        signal = "#A5BBA8",
      ),
    ),
    OrvaThemeSpec(
      id = OrvaDesignTheme.FIELD_SPECIMEN,
      name = "The Field Specimen",
      idea = "A printed specimen: expressive grotesk, book-like text and precise annotations.",
      layoutGrammar = ThemeLayoutGrammar.SPECIMEN_FIELD,
      headlineMotion = ThemeHeadlineMotion.GRAPHEME_REVEAL,
      mediaMotion = ThemeMediaMotion.FOIL_PRESS,
      type = ThemeTypeSet(
        display = "Bricolage Grotesque",
        reading = "Source Serif 4",
        utility = "Martian Mono",
        heroCompactSp = 64f,
        heroStandardSp = 76f,
        heroTabletSp = 104f,
        bodySp = 18f,
        bodyLineHeightSp = 28f,
        utilitySp = 10.5f,
        scaleRatio = 1.25f,
        displayAxes = ThemeDisplayAxisProfile(
          weight = FontAxisRange(200f, 800f),
          width = FontAxisRange(75f, 100f),
          opticalSize = FontAxisRange(12f, 96f),
          startWeight = 620f,
          endWeight = 800f,
          startWidth = 78f,
          endWidth = 92f,
          startOpticalSize = 64f,
          endOpticalSize = 96f,
        ),
      ),
      colours = ThemeColourSet(
        background = "#EEE8DC",
        surface = "#D8D0C1",
        text = "#282B25",
        accent = "#A9422D",
        signal = "#386A60",
      ),
    ),
    OrvaThemeSpec(
      id = OrvaDesignTheme.MUSEUM_INDEX,
      name = "The Museum Index",
      idea = "A museum catalogue: a display object, quiet digital reading and disciplined index marks.",
      layoutGrammar = ThemeLayoutGrammar.MUSEUM_CATALOGUE,
      headlineMotion = ThemeHeadlineMotion.SERIF_LINE_MASK,
      mediaMotion = ThemeMediaMotion.CATALOGUE_LIFT,
      type = ThemeTypeSet(
        display = "Gloock",
        reading = "Schibsted Grotesk",
        utility = "IBM Plex Mono",
        heroCompactSp = 72f,
        heroStandardSp = 88f,
        heroTabletSp = 120f,
        bodySp = 17f,
        bodyLineHeightSp = 26f,
        utilitySp = 10.5f,
        scaleRatio = 1.333f,
      ),
      colours = ThemeColourSet(
        background = "#E6E2D7",
        surface = "#D4D1C6",
        text = "#282B2D",
        accent = "#1F5965",
        signal = "#9C3F31",
      ),
    ),
  )

  fun get(id: OrvaDesignTheme): OrvaThemeSpec = all.first { it.id == id }
}

/** Archivo stays tighter on narrow phones and uses its true width axis on wider layouts. */
fun archivoWidthForViewport(viewportWidthDp: Int): Float {
  val progress = ((viewportWidthDp - 360f) / (840f - 360f)).coerceIn(0f, 1f)
  return 86f + (125f - 86f) * progress
}

/** Exact variable-font axis values for a headline's build progress. */
fun displayAxesAtProgress(
  theme: OrvaDesignTheme,
  progress: Float,
  viewportWidthDp: Int,
): ThemeDisplayAxisValues? {
  val profile = OrvaThemeCatalog.get(theme).type.displayAxes ?: return null
  val t = if (progress.isFinite()) progress.coerceIn(0f, 1f) else 0f
  fun lerp(start: Float, end: Float) = start + (end - start) * t
  val targetWidth =
    if (theme == OrvaDesignTheme.MEASURED_PRESS) archivoWidthForViewport(viewportWidthDp)
    else requireNotNull(profile.endWidth)
  return ThemeDisplayAxisValues(
    weight = profile.weight.clamp(lerp(profile.startWeight, profile.endWeight)),
    width = profile.width?.clamp(lerp(requireNotNull(profile.startWidth), targetWidth)),
    opticalSize = profile.opticalSize?.clamp(
      lerp(requireNotNull(profile.startOpticalSize), requireNotNull(profile.endOpticalSize)),
    ),
  )
}

data class MorphRegionCandidate(
  val id: String,
  val sceneIndex: Int,
  val documentOrder: Int,
  val bounds: SceneBounds,
  val visibleFraction: Float,
  val isFullyBuilt: Boolean,
  val isMeasured: Boolean = true,
  val isLayoutStable: Boolean = true,
  val hasActiveInteraction: Boolean = false,
  val hasAccessibilityFocus: Boolean = false,
  val isPinnedOrProtected: Boolean = false,
  val isAlreadyMorphing: Boolean = false,
)

data class MorphViewport(
  val topPx: Float,
  val bottomPx: Float,
  val pageIsVisible: Boolean = true,
  val pointerIsDown: Boolean = false,
  val agentWorkIsBusy: Boolean = false,
) {
  val isValid: Boolean get() = topPx.isFinite() && bottomPx.isFinite() && bottomPx > topPx
}

data class ThemeMorphPlan(
  val fromTheme: OrvaDesignTheme,
  val toTheme: OrvaDesignTheme,
  val anchorRegionId: String,
  /** Anchor first, then nearest regions outwards. */
  val regionIds: List<String>,
  val startedAtMs: Long,
)

/**
 * Selects an unexpected but safe starting point. Randomness is injected so the choice can be
 * reproduced in tests and diagnosed from a reported session seed.
 */
class OrvaThemeMorphPolicy(
  private val random: Random = Random.Default,
  private val firstDelayRangeMs: LongRange = 18_000L..32_000L,
  private val repeatDelayRangeMs: LongRange = 24_000L..42_000L,
  private val minVisibleFraction: Float = 0.30f,
) {
  var currentTheme: OrvaDesignTheme = OrvaDesignTheme.MEASURED_PRESS
    private set
  var nextEligibleAtMs: Long = Long.MAX_VALUE
    private set
  var morphCount: Int = 0
    private set
  private var pendingPlan: ThemeMorphPlan? = null

  fun beginSession(nowMs: Long, initialTheme: OrvaDesignTheme = OrvaDesignTheme.MEASURED_PRESS) {
    require(nowMs >= 0L)
    currentTheme = initialTheme
    morphCount = 0
    pendingPlan = null
    nextEligibleAtMs = nowMs + randomDelay(firstDelayRangeMs)
  }

  fun choosePlan(
    nowMs: Long,
    viewport: MorphViewport,
    candidates: List<MorphRegionCandidate>,
  ): ThemeMorphPlan? {
    if (pendingPlan != null || nowMs < nextEligibleAtMs || !viewport.isValid || !viewport.pageIsVisible) return null
    if (viewport.pointerIsDown || viewport.agentWorkIsBusy) return null

    val measuredBuiltRegions = candidates.filter { candidate ->
      candidate.id.isNotBlank() &&
        candidate.bounds.isValid &&
        candidate.isFullyBuilt &&
        candidate.isMeasured &&
        candidate.isLayoutStable &&
        !candidate.isPinnedOrProtected &&
        !candidate.isAlreadyMorphing
    }
    val anchorCandidates = measuredBuiltRegions.filter { candidate ->
      isSafeToStartRegion(candidate, viewport)
    }
    if (anchorCandidates.isEmpty()) return null

    val ordered = measuredBuiltRegions.sortedBy { it.documentOrder }
    val anchor = anchorCandidates[random.nextInt(anchorCandidates.size)]
    val regionOrder = ordered
      .sortedWith(
        compareBy<MorphRegionCandidate> { kotlin.math.abs(it.documentOrder - anchor.documentOrder) }
          .thenBy { it.documentOrder },
      )
      .map { it.id }
      .distinct()
    if (regionOrder.isEmpty() || regionOrder.first() != anchor.id) return null

    return ThemeMorphPlan(
      fromTheme = currentTheme,
      toTheme = currentTheme.next(),
      anchorRegionId = anchor.id,
      regionIds = regionOrder,
      startedAtMs = nowMs,
    ).also { pendingPlan = it }
  }

  /** A new region can start only when it is fully built, measurable and visible. */
  fun isSafeToStartRegion(candidate: MorphRegionCandidate, viewport: MorphViewport): Boolean =
    isSafeVisibleRegion(candidate, viewport) && candidate.isFullyBuilt

  /** A partially transformed region may resume without pretending it is fully built. */
  fun isSafeToResumeRegion(candidate: MorphRegionCandidate, viewport: MorphViewport): Boolean =
    isSafeVisibleRegion(candidate, viewport)

  private fun isSafeVisibleRegion(candidate: MorphRegionCandidate, viewport: MorphViewport): Boolean =
    viewport.isValid && viewport.pageIsVisible && !viewport.pointerIsDown &&
      candidate.id.isNotBlank() && candidate.bounds.isValid &&
      candidate.bounds.intersectsVerticalWindow(viewport.topPx, viewport.bottomPx) &&
      candidate.visibleFraction.isFinite() && candidate.visibleFraction in minVisibleFraction..1f &&
      candidate.isMeasured && candidate.isLayoutStable &&
      !candidate.hasActiveInteraction && !candidate.hasAccessibilityFocus &&
      !candidate.isPinnedOrProtected && !candidate.isAlreadyMorphing

  fun completeMorph(nowMs: Long, completedTheme: OrvaDesignTheme) {
    require(nowMs >= 0L)
    val plan = requireNotNull(pendingPlan) { "There is no pending morph to complete." }
    require(completedTheme == plan.toTheme && completedTheme == currentTheme.next()) {
      "Morph completion must advance exactly one identity in the approved A → B → C cycle."
    }
    currentTheme = completedTheme
    morphCount++
    pendingPlan = null
    nextEligibleAtMs = nowMs + randomDelay(repeatDelayRangeMs)
  }

  /** Releases a plan that could not acquire the Agentic Build scheduler. */
  fun releasePlan(nowMs: Long, retryDelayMs: Long = 4_000L) {
    require(nowMs >= 0L && retryDelayMs >= 0L)
    if (pendingPlan == null) return
    pendingPlan = null
    nextEligibleAtMs = nowMs + retryDelayMs
  }

  fun deferNextAttempt(nowMs: Long, retryDelayMs: Long = 2_000L) {
    require(nowMs >= 0L && retryDelayMs >= 0L)
    if (pendingPlan == null) nextEligibleAtMs = nowMs + retryDelayMs
  }

  private fun randomDelay(range: LongRange): Long {
    require(range.first >= 0L && range.last >= range.first)
    return if (range.first == range.last) range.first else random.nextLong(range.first, range.last + 1L)
  }
}

enum class MorphRegionPhase { RESTOCKING, LAYOUT_SETTLING, DISPENSING }
enum class MorphEnginePhase { IDLE, ACTIVE, PAUSED }

data class ThemeMorphSnapshot(
  val committedTheme: OrvaDesignTheme,
  val targetTheme: OrvaDesignTheme? = null,
  val phase: MorphEnginePhase = MorphEnginePhase.IDLE,
  val activeRegionId: String? = null,
  val activeRegionPhase: MorphRegionPhase? = null,
  val completedRegionIds: Set<String> = emptySet(),
  val regionOrder: List<String> = emptyList(),
  val pauseRequested: Boolean = false,
)

/**
 * Transaction coordinator for the visible reverse-build → rebuild wave. A region changes its
 * visual blueprint only after its old presentation has been fully restocked. The overall theme
 * commits only after every planned region has been dispensed in the target identity.
 */
class OrvaThemeMorphCoordinator(initialTheme: OrvaDesignTheme = OrvaDesignTheme.MEASURED_PRESS) {
  var snapshot: ThemeMorphSnapshot = ThemeMorphSnapshot(committedTheme = initialTheme)
    private set

  fun reset(theme: OrvaDesignTheme = OrvaDesignTheme.MEASURED_PRESS) {
    snapshot = ThemeMorphSnapshot(committedTheme = theme)
  }

  fun begin(plan: ThemeMorphPlan): Boolean {
    if (snapshot.phase != MorphEnginePhase.IDLE) return false
    if (plan.fromTheme != snapshot.committedTheme) return false
    if (plan.toTheme != snapshot.committedTheme.next()) return false
    if (plan.regionIds.isEmpty() || plan.anchorRegionId != plan.regionIds.first()) return false
    if (plan.regionIds.any { it.isBlank() } || plan.regionIds.distinct().size != plan.regionIds.size) return false

    snapshot = snapshot.copy(
      targetTheme = plan.toTheme,
      phase = MorphEnginePhase.ACTIVE,
      activeRegionId = plan.anchorRegionId,
      activeRegionPhase = MorphRegionPhase.RESTOCKING,
      completedRegionIds = emptySet(),
      regionOrder = plan.regionIds,
      pauseRequested = false,
    )
    return true
  }

  /** The old region is gone; only now may Compose present it with the target identity. */
  fun onRegionRestocked(regionId: String): Boolean {
    if (snapshot.phase != MorphEnginePhase.ACTIVE || snapshot.activeRegionId != regionId) return false
    if (snapshot.activeRegionPhase != MorphRegionPhase.RESTOCKING) return false
    snapshot = snapshot.copy(activeRegionPhase = MorphRegionPhase.LAYOUT_SETTLING)
    return true
  }

  /** A target identity can enter the scene graph only after its new Compose geometry settles. */
  fun onRegionLayoutSettled(regionId: String): Boolean {
    if (snapshot.phase != MorphEnginePhase.ACTIVE || snapshot.activeRegionId != regionId) return false
    if (snapshot.activeRegionPhase != MorphRegionPhase.LAYOUT_SETTLING) return false
    snapshot = snapshot.copy(activeRegionPhase = MorphRegionPhase.DISPENSING)
    return true
  }

  /** Commits one rebuilt region and advances the wave, or pauses at this safe boundary. */
  fun onRegionDispensed(regionId: String): Boolean {
    if (snapshot.phase != MorphEnginePhase.ACTIVE || snapshot.activeRegionId != regionId) return false
    if (snapshot.activeRegionPhase != MorphRegionPhase.DISPENSING) return false
    val completed = snapshot.completedRegionIds + regionId
    val nextIndex = snapshot.regionOrder.indexOf(regionId) + 1
    if (nextIndex >= snapshot.regionOrder.size) {
      snapshot = ThemeMorphSnapshot(committedTheme = requireNotNull(snapshot.targetTheme))
      return true
    }
    if (snapshot.pauseRequested) {
      snapshot = snapshot.copy(
        phase = MorphEnginePhase.PAUSED,
        activeRegionId = null,
        activeRegionPhase = null,
        completedRegionIds = completed,
      )
      return true
    }
    snapshot = snapshot.copy(
      activeRegionId = snapshot.regionOrder[nextIndex],
      activeRegionPhase = MorphRegionPhase.RESTOCKING,
      completedRegionIds = completed,
    )
    return true
  }

  /** Scroll/touch input asks the engine to pause, but never interrupts an in-flight region. */
  fun requestPause(): Boolean {
    if (snapshot.phase != MorphEnginePhase.ACTIVE) return false
    snapshot = snapshot.copy(pauseRequested = true)
    return true
  }

  /** Pauses between visible work batches without discarding partial progress in the active region. */
  fun pauseAtRegionBoundary(): Boolean {
    if (snapshot.phase != MorphEnginePhase.ACTIVE || snapshot.activeRegionId == null ||
      snapshot.activeRegionPhase == null
    ) return false
    snapshot = snapshot.copy(phase = MorphEnginePhase.PAUSED, pauseRequested = false)
    return true
  }

  fun resume(): Boolean {
    if (snapshot.phase != MorphEnginePhase.PAUSED) return false
    val nextId = snapshot.activeRegionId
      ?: snapshot.regionOrder.firstOrNull { it !in snapshot.completedRegionIds }
      ?: return false
    val nextPhase = snapshot.activeRegionPhase ?: MorphRegionPhase.RESTOCKING
    snapshot = snapshot.copy(
      phase = MorphEnginePhase.ACTIVE,
      activeRegionId = nextId,
      activeRegionPhase = nextPhase,
      pauseRequested = false,
    )
    return true
  }

  /** Per-region theme lookup permits a deliberate, visible mixed state during the morph wave. */
  fun themeForRegion(regionId: String): OrvaDesignTheme {
    val target = snapshot.targetTheme ?: return snapshot.committedTheme
    return when {
      regionId !in snapshot.regionOrder -> target // new/unbuilt content is born in the target identity
      regionId in snapshot.completedRegionIds -> target
      snapshot.activeRegionId == regionId && snapshot.activeRegionPhase != MorphRegionPhase.RESTOCKING -> target
      else -> snapshot.committedTheme
    }
  }
}

/** WCAG relative-luminance contrast ratio for the exact hex tokens used in a theme. */
fun contrastRatio(foregroundHex: String, backgroundHex: String): Double {
  fun luminance(hex: String): Double {
    require(HEX_COLOUR.matches(hex)) { "Expected #RRGGBB colour, got '$hex'." }
    val channels = (1..3).map { index ->
      val value = hex.substring(index * 2 - 1, index * 2 + 1).toInt(16) / 255.0
      if (value <= 0.04045) value / 12.92 else Math.pow((value + 0.055) / 1.055, 2.4)
    }
    return 0.2126 * channels[0] + 0.7152 * channels[1] + 0.0722 * channels[2]
  }
  val first = luminance(foregroundHex)
  val second = luminance(backgroundHex)
  val lighter = maxOf(first, second)
  val darker = minOf(first, second)
  return (lighter + 0.05) / (darker + 0.05)
}

private val HEX_COLOUR = Regex("^#[0-9A-Fa-f]{6}$")
