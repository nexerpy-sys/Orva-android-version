package com.rindleworks.orva.fake

import com.rindleworks.orva.domain.common.OrvaDateTimeFormatters
import com.rindleworks.orva.domain.common.OrvaSchemaInteropContract
import com.rindleworks.orva.domain.common.OrvaSettingKeys
import com.rindleworks.orva.domain.settings.AppLanguage
import com.rindleworks.orva.domain.settings.AppSettingsRepository
import com.rindleworks.orva.domain.settings.BackupRestoreService
import com.rindleworks.orva.domain.settings.BackupStatusSummary
import com.rindleworks.orva.domain.settings.BillingTaxSettings
import com.rindleworks.orva.domain.settings.IndianGstState
import com.rindleworks.orva.domain.settings.MedicineTaxConfigItem
import com.rindleworks.orva.domain.settings.OperationalSupportPrefs
import com.rindleworks.orva.domain.settings.RoundOffMode
import com.rindleworks.orva.domain.settings.ShopBackupCreateResult
import com.rindleworks.orva.domain.settings.ShopBackupManifest
import com.rindleworks.orva.domain.settings.ShopBackupPreview
import com.rindleworks.orva.domain.settings.ShopProfile
import com.rindleworks.orva.domain.settings.ShopRepository
import com.rindleworks.orva.domain.settings.ShopRestoreResult
import com.rindleworks.orva.domain.settings.SubscriptionService
import com.rindleworks.orva.domain.settings.SubscriptionStatus
import com.rindleworks.orva.domain.settings.SupplyType
import com.rindleworks.orva.domain.settings.TaxPricingMode
import com.rindleworks.orva.domain.settings.TaxSettingsRepository
import java.io.InputStream
import java.io.OutputStream
import java.net.URLEncoder
import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.map

class FakeShopRepository : ShopRepository {
  private val profileState =
    MutableStateFlow<ShopProfile?>(
      ShopProfile(
        shopId = "fake-shop-001",
        shopName = "ORVA Demo Pharmacy",
        legalName = "ORVA Demo Medical Stores",
        address = "12 College Street, Kolkata",
        phone = "",
        email = "",
        stateName = "West Bengal",
        stateCode = "19",
        gstin = null,
        drugLicenceNumber = "WB/KOL/20B/0001",
        invoicePrefix = "INV",
        financialYearStartMonth = 4,
      )
    )

  private val states =
    listOf(
      IndianGstState("07", "Delhi"),
      IndianGstState("19", "West Bengal"),
      IndianGstState("27", "Maharashtra"),
      IndianGstState("29", "Karnataka"),
      IndianGstState("33", "Tamil Nadu"),
    )

  override fun observeProfile(): Flow<ShopProfile?> = profileState

  override suspend fun getProfile(): ShopProfile? = profileState.value

  override suspend fun saveProfileWithAudit(profile: ShopProfile): Result<Unit> {
    if (profile.shopName.isBlank()) {
      return Result.failure(IllegalArgumentException("Shop name is required."))
    }
    profileState.value = profile
    return Result.success(Unit)
  }

  override fun getIndianGstStates(): List<IndianGstState> = states
}

class FakeTaxSettingsRepository : TaxSettingsRepository {
  private val settingsState =
    MutableStateFlow(
      BillingTaxSettings(
        isConfigured = true,
        pricingMode = TaxPricingMode.TaxInclusive,
        defaultSupplyType = SupplyType.IntraState,
        roundOffMode = RoundOffMode.None,
      )
    )

  private val medicines =
    mutableListOf(
      MedicineTaxConfigItem(
        medicineId = "fake-med-1",
        displayName = "Paracetamol 500mg",
        stockUnitName = "strip",
        hsnCode = "3004",
        gstRateBasisPoints = 1_200,
        gstRateConfigured = true,
      ),
      MedicineTaxConfigItem(
        medicineId = "fake-med-2",
        displayName = "Amoxicillin 250mg",
        stockUnitName = "strip",
        hsnCode = "3004",
        gstRateBasisPoints = 1_200,
        gstRateConfigured = true,
      ),
    )

  override fun observeTaxSettings(): Flow<BillingTaxSettings> = settingsState

  override suspend fun getTaxSettings(): BillingTaxSettings = settingsState.value

  override suspend fun saveTaxSettings(
    taxConfigured: Boolean,
    pricingMode: TaxPricingMode,
    defaultSupplyType: SupplyType,
    roundOffMode: RoundOffMode,
  ): Result<Unit> {
    settingsState.value =
      BillingTaxSettings(
        isConfigured = taxConfigured,
        pricingMode = pricingMode,
        defaultSupplyType = defaultSupplyType,
        roundOffMode = roundOffMode,
      )
    return Result.success(Unit)
  }

  override suspend fun getMedicinesForTaxConfig(searchText: String): List<MedicineTaxConfigItem> {
    val needle = searchText.trim()
    return medicines.filter {
      needle.isEmpty() || it.displayName.contains(needle, ignoreCase = true)
    }
  }

  override suspend fun updateMedicineTaxConfig(
    medicineId: String,
    hsnCode: String?,
    gstRateBasisPoints: Int,
    gstRateConfigured: Boolean,
  ): Result<Unit> {
    val idx = medicines.indexOfFirst { it.medicineId == medicineId }
    if (idx < 0) return Result.failure(IllegalArgumentException("Medicine not found."))
    medicines[idx] =
      medicines[idx].copy(
        hsnCode = hsnCode?.trim()?.ifEmpty { null },
        gstRateBasisPoints = gstRateBasisPoints,
        gstRateConfigured = gstRateConfigured,
      )
    return Result.success(Unit)
  }
}

class FakeAppSettingsRepository : AppSettingsRepository {
  private val settingsState =
    MutableStateFlow<Map<String, String>>(
      mapOf(
        OrvaSettingKeys.DISPLAY_LANGUAGE to AppLanguage.English.code,
        OrvaSettingKeys.BACKUP_RETENTION_DAYS to "7",
      )
    )

  override fun observe(key: String, defaultValue: String): Flow<String> =
    settingsState.map { it[key] ?: defaultValue }

  override suspend fun get(key: String, defaultValue: String): String =
    settingsState.value[key] ?: defaultValue

  override suspend fun set(key: String, value: String) {
    settingsState.value = settingsState.value + (key to value)
  }

  override suspend fun getLanguage(): AppLanguage =
    AppLanguage.fromCode(get(OrvaSettingKeys.DISPLAY_LANGUAGE, AppLanguage.English.code))

  override suspend fun setLanguage(language: AppLanguage) {
    set(OrvaSettingKeys.DISPLAY_LANGUAGE, language.code)
  }

  override suspend fun getOperationalSupportPrefs(): OperationalSupportPrefs =
    OperationalSupportPrefs(
      supportPhones = get(OrvaSettingKeys.SUPPORT_PHONES, ""),
      supportWhatsapp = get(OrvaSettingKeys.SUPPORT_WHATSAPP, ""),
      supportEmail = get(OrvaSettingKeys.SUPPORT_EMAIL, ""),
      upiId = get(OrvaSettingKeys.UPI_ID, ""),
      upiPayeeName = get(OrvaSettingKeys.UPI_PAYEE_NAME, ""),
    )
}

class FakeBackupRestoreService(
  private val shopRepository: ShopRepository,
  private val databaseGeneration: MutableStateFlow<Long>,
) : BackupRestoreService {
  private var retentionDays: Int = 7
  private var lastSuccessUtc: String? = null
  private var lastSuccessLocalDate: String? = null
  private var lastPath: String? = null

  override suspend fun createBackupToStream(
    output: OutputStream,
    displayTargetName: String,
  ): ShopBackupCreateResult {
    val manifest = buildManifest()
    output.write("PK-ORVA-STAGE0-FAKE-BACKUP".toByteArray(Charsets.UTF_8))
    output.flush()
    lastSuccessUtc = manifest.backupUtc
    lastSuccessLocalDate = LocalDate.now().toString()
    lastPath = displayTargetName
    return ShopBackupCreateResult(
      succeeded = true,
      backupPathOrUri = displayTargetName,
      manifest = manifest,
    )
  }

  override suspend fun runBackupNow(): ShopBackupCreateResult {
    val manifest = buildManifest()
    lastSuccessUtc = manifest.backupUtc
    lastSuccessLocalDate = LocalDate.now().toString()
    lastPath = "backups/daily/orva_demo_${lastSuccessLocalDate}.shopbackup"
    return ShopBackupCreateResult(
      succeeded = true,
      backupPathOrUri = lastPath,
      manifest = manifest,
    )
  }

  override suspend fun runDailyBackupIfDue(): ShopBackupCreateResult? {
    val today = LocalDate.now().toString()
    return if (lastSuccessLocalDate == today) null else runBackupNow()
  }

  override suspend fun getBackupStatus(): BackupStatusSummary {
    val today = LocalDate.now().toString()
    return BackupStatusSummary(
      lastSuccessUtc = lastSuccessUtc,
      lastSuccessLocalDate = lastSuccessLocalDate,
      lastBackupPath = lastPath,
      lastError = null,
      retentionDays = retentionDays,
      isDueToday = lastSuccessLocalDate != today,
    )
  }

  override suspend fun setRetentionDays(days: Int) {
    retentionDays = days.coerceAtLeast(1)
  }

  override suspend fun previewRestore(input: InputStream, sourceName: String): ShopBackupPreview =
    ShopBackupPreview(
      isValid = true,
      sourceName = sourceName,
      manifest = buildManifest(),
      targetShopId = shopRepository.getProfile()?.shopId,
      targetShopName = shopRepository.getProfile()?.shopName,
      isDifferentShop = false,
    )

  override suspend fun executeRestore(input: InputStream, sourceName: String): ShopRestoreResult {
    databaseGeneration.value += 1L
    return ShopRestoreResult(
      succeeded = true,
      restoredShopName = shopRepository.getProfile()?.shopName ?: "ORVA Demo Pharmacy",
      snapshotRefreshed = true,
    )
  }

  private suspend fun buildManifest(): ShopBackupManifest {
    val shop = shopRepository.getProfile()
    return ShopBackupManifest(
      backupFormat = OrvaSchemaInteropContract.BACKUP_FORMAT_NAME,
      formatVersion = OrvaSchemaInteropContract.BACKUP_FORMAT_VERSION,
      applicationName = "ORVA",
      applicationVersion = "1.0",
      databaseSchemaVersion = OrvaSchemaInteropContract.CURRENT_SCHEMA_VERSION,
      shopId = shop?.shopId,
      shopName = shop?.shopName,
      backupUtc = OrvaDateTimeFormatters.formatUtcRoundTrip(Instant.now()),
      backupLocalText = OrvaDateTimeFormatters.formatLocalLogText(LocalDateTime.now()),
      databaseFileName = "orva.sqlite",
      databaseLengthBytes = 4096L,
      databaseSha256 = "0".repeat(64),
      medicineCount = 2L,
      batchCount = 2L,
      invoiceCount = 1L,
      purchaseCount = 1L,
      returnCount = 0L,
    )
  }
}

class FakeSubscriptionService(private val settings: AppSettingsRepository) : SubscriptionService {
  override suspend fun saveCredentials(
    username: String,
    activationCode: String,
    registryUrl: String,
  ) {
    settings.set(OrvaSettingKeys.SUBSCRIPTION_USERNAME, username.trim())
    settings.set(OrvaSettingKeys.SUBSCRIPTION_ACTIVATION_CODE, activationCode.trim())
    settings.set(OrvaSettingKeys.SUBSCRIPTION_REGISTRY_URL, registryUrl.trim())
  }

  override suspend fun saveSupportAndUpiSettings(prefs: OperationalSupportPrefs) {
    settings.set(OrvaSettingKeys.SUPPORT_PHONES, prefs.supportPhones.trim())
    settings.set(OrvaSettingKeys.SUPPORT_WHATSAPP, prefs.supportWhatsapp.trim())
    settings.set(OrvaSettingKeys.SUPPORT_EMAIL, prefs.supportEmail.trim())
    settings.set(OrvaSettingKeys.UPI_ID, prefs.upiId.trim())
    settings.set(OrvaSettingKeys.UPI_PAYEE_NAME, prefs.upiPayeeName.trim())
  }

  override suspend fun evaluateLocalStatus(): SubscriptionStatus {
    val username = settings.get(OrvaSettingKeys.SUBSCRIPTION_USERNAME, "").ifBlank { null }
    return SubscriptionStatus(
      username = username,
      plan = if (username != null) "Active (Demo)" else null,
      startDateIso = null,
      expiryDateIso = null,
      status = if (username != null) "ACTIVE" else "UNCONFIGURED",
      lastVerifiedUtc = null,
      isConfigured = username != null,
      isActive = true,
      isInGracePeriod = false,
      graceDaysRemaining = 14,
      isRenewalReminderDue = false,
      daysUntilExpiry = null,
      allowNewBilling = true,
      message = "Offline demo subscription active for frontend development.",
    )
  }

  override suspend fun refreshFromRegistry(): SubscriptionStatus = evaluateLocalStatus()

  override fun buildUpiPaymentUri(
    upiId: String,
    payeeName: String,
    amountRupees: String,
    note: String,
  ): String {
    val enc = { value: String -> URLEncoder.encode(value.trim(), "UTF-8") }
    return buildString {
      append("upi://pay?pa=").append(enc(upiId))
      append("&pn=").append(enc(payeeName))
      if (amountRupees.isNotBlank()) append("&am=").append(enc(amountRupees))
      append("&cu=INR")
      if (note.isNotBlank()) append("&tn=").append(enc(note))
    }
  }

  override fun buildWhatsAppClickToChatUrl(phone: String, message: String): String {
    val digits = phone.filter { it.isDigit() }
    val encoded = URLEncoder.encode(message.trim(), "UTF-8")
    return "https://wa.me/$digits?text=$encoded"
  }
}
