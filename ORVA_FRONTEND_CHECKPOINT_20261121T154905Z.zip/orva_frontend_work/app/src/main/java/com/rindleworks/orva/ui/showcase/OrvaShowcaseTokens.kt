package com.rindleworks.orva.ui.showcase

import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.font.FontVariation
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.sp
import android.os.Build
import com.rindleworks.orva.R
import com.rindleworks.orva.domain.settings.AppLanguage
import com.rindleworks.orva.ui.about.agentic.OrvaDesignTheme
import com.rindleworks.orva.ui.about.agentic.OrvaThemeCatalog
import com.rindleworks.orva.ui.about.agentic.displayAxesAtProgress
import kotlin.math.roundToInt

/** Fixed dark editorial surfaces used by the Home and About showcases. */
@Immutable
data class ShowcasePalette(
  val canvasDeep: Color,
  val canvasSecondary: Color,
  val surfaceRaised: Color,
  val inkPrimary: Color,
  val inkSecondary: Color,
  val inkMuted: Color,
  val hairline: Color,
  val agentTagSurface: Color,
  val accent: Color = Color(0xFFF45A43),
  val signal: Color = Color(0xFF9A78F5),
)

val DarkShowcasePalette =
  ShowcasePalette(
    canvasDeep = Color(0xFF08090B),
    canvasSecondary = Color(0xFF111318),
    surfaceRaised = Color(0xFF181B21),
    inkPrimary = Color(0xFFF1EFE9),
    inkSecondary = Color(0xFFA1A3AA),
    inkMuted = Color(0xFF6E727D),
    hairline = Color(0xFF2A2D34),
    agentTagSurface = Color(0xED0C0E13),
    accent = Color(0xFFF45A43),
    signal = Color(0xFF9A78F5),
  )

val LocalShowcasePalette = compositionLocalOf { DarkShowcasePalette }

@Composable
fun currentShowcasePalette(): ShowcasePalette = LocalShowcasePalette.current

/**
 * Authoritative Rindle Works × ORVA Showcase visual tokens
 * (Master Frontend Build Directive §2.1 & §5.4).
 *
 * Dark editorial palette: near-black obsidian (`#08090B`), graphite panels (`#111318`, `#181B21`),
 * warm chalk (`#F1EFE9`), muted slate (`#A1A3AA`), hairline rules (`#2A2D34`), editorial vermilion
 * (`#F45A43`), secondary violet (`#9A78F5`), and strictly dual-tone Violet (`#A78BFA`) + Vermilion
 * (`#FF604A`) Agentic Build cursor identities.
 *
 * Operational billing/inventory theme remains isolated in `ui/theme/`.
 */
object OrvaShowcaseColors {
  val CanvasDeep = Color(0xFF08090B)
  val CanvasSecondary = Color(0xFF111318)
  val SurfaceRaised = Color(0xFF181B21)
  val FolderBackplate = Color(0xFF13161D)
  val FolderPocket = Color(0xFF181B21)

  val PaperSheetRear = Color(0xFFDCDAD2)
  val PaperSheetMid = Color(0xFFE7E5DE)
  val PaperSheetFront = Color(0xFFF1EFE9)
  val PaperInk = Color(0xFF111318)
  val PaperInkMuted = Color(0xFF4F5360)

  val InkPrimary = Color(0xFFF1EFE9)
  val InkSecondary = Color(0xFFA1A3AA)
  val InkMuted = Color(0xFF6E727D)
  val Hairline = Color(0xFF2A2D34)

  // Editorial accents (restrained vermilion primary + violet secondary)
  val AccentVermilion = Color(0xFFF45A43)
  val AccentVermilionWash = Color(0x1AF45A43)
  val AccentViolet = Color(0xFF9A78F5)
  val AccentVioletSoft = Color(0xFFBBA6FF)
  val AccentVioletWash = Color(0x1A9A78F5)

  // Agentic Build visual grammar (About Us construction overlay)
  val FigmaBlue = Color(0xFF0D99FF)
  val FigmaBlueFill = Color(0x1E0D99FF)
  val SmartGuideRed = Color(0xFFF45A43)

  // Strictly two cursor identities: Violet & Vermilion (zero rainbow palette)
  val CursorPurpleCore = Color(0xFFA78BFA)
  val CursorPurpleBright = Color(0xFFC4B5FD)
  val CursorPurpleDeep = Color(0xFF8B5CF6)
  val CursorVermilionCore = Color(0xFFFF604A)
  val CursorVermilionBright = Color(0xFFFF8370)
  val CursorVermilionDeep = Color(0xFFF45A43)

  // Architectural drafting chrome (agent micro-tags & precision ruler ticks)
  val AgentTagSurface = Color(0xED0C0E13)
  val DraftingRulerTick = Color(0x45A1A3AA)

  val AgentCursorPalette: List<Color> =
    listOf(
      CursorPurpleCore,
      CursorVermilionCore,
      CursorPurpleBright,
      CursorVermilionBright,
      CursorPurpleDeep,
      CursorVermilionDeep,
    )
}

/** Theme and script context for every shared showcase typography role. */
val LocalOrvaShowcaseTheme = compositionLocalOf { OrvaDesignTheme.MEASURED_PRESS }
val LocalOrvaShowcaseLanguage = compositionLocalOf { AppLanguage.English }

/** Locally bundled Google Fonts selected by each region's active A/B/C morph identity. */
object OrvaShowcaseFonts {
  private val spaceMono =
    FontFamily(
      Font(R.font.space_mono_regular, FontWeight.Normal),
      Font(R.font.space_mono_bold, FontWeight.Bold),
    )

  private val ibmPlexMono = FontFamily(Font(R.font.ibm_plex_mono, FontWeight.Normal))

  private val gloock = FontFamily(Font(R.font.gloock_regular, FontWeight.Normal))

  private val notoSansBengali = FontFamily(Font(R.font.noto_sans_bengali, FontWeight.Normal))

  private val displayWeights =
    listOf(
      FontWeight.Thin,
      FontWeight.ExtraLight,
      FontWeight.Light,
      FontWeight.Normal,
      FontWeight.Medium,
      FontWeight.SemiBold,
      FontWeight.Bold,
      FontWeight.ExtraBold,
      FontWeight.Black,
    )

  @Composable
  fun display(language: AppLanguage = LocalOrvaShowcaseLanguage.current): FontFamily {
    if (language == AppLanguage.Bengali) return notoSansBengali
    val theme = LocalOrvaShowcaseTheme.current
    val viewportWidthDp = LocalConfiguration.current.screenWidthDp
    return remember(theme, viewportWidthDp) {
      when (theme) {
        OrvaDesignTheme.MEASURED_PRESS -> archivoDisplay(viewportWidthDp)
        OrvaDesignTheme.FIELD_SPECIMEN -> bricolageDisplay(viewportWidthDp)
        OrvaDesignTheme.MUSEUM_INDEX -> gloock
      }
    }
  }

  @Composable
  fun body(language: AppLanguage = LocalOrvaShowcaseLanguage.current): FontFamily {
    if (language == AppLanguage.Bengali) return notoSansBengali
    val theme = LocalOrvaShowcaseTheme.current
    return remember(theme) {
      when (theme) {
        OrvaDesignTheme.MEASURED_PRESS ->
          variableWeightFamily(
            resourceId = R.font.newsreader_variable,
            weights = 200..800 step 100,
            fallbackResourceId = R.font.newsreader_reading_fallback,
          )
        OrvaDesignTheme.FIELD_SPECIMEN ->
          variableWeightFamily(
            resourceId = R.font.source_serif_4_variable,
            weights = 200..900 step 100,
            fallbackResourceId = R.font.source_serif_4_reading_fallback,
          )
        OrvaDesignTheme.MUSEUM_INDEX ->
          variableWeightFamily(
            resourceId = R.font.schibsted_grotesk_variable,
            weights = 400..900 step 100,
            fallbackResourceId = R.font.schibsted_grotesk_reading_fallback,
          )
      }
    }
  }

  @Composable
  fun mono(language: AppLanguage = LocalOrvaShowcaseLanguage.current): FontFamily {
    if (language == AppLanguage.Bengali) return notoSansBengali
    val theme = LocalOrvaShowcaseTheme.current
    return remember(theme) {
      when (theme) {
        OrvaDesignTheme.MEASURED_PRESS -> spaceMono
        OrvaDesignTheme.FIELD_SPECIMEN ->
          variableWeightFamily(
            resourceId = R.font.martian_mono_variable,
            weights = 100..800 step 100,
            fallbackResourceId = R.font.martian_mono_utility_fallback,
          )
        OrvaDesignTheme.MUSEUM_INDEX -> ibmPlexMono
      }
    }
  }

  fun tracking(language: AppLanguage, requested: TextUnit): TextUnit =
    if (language == AppLanguage.Bengali) 0.sp else requested

  @Composable
  fun tracking(requested: TextUnit): TextUnit = tracking(LocalOrvaShowcaseLanguage.current, requested)

  @OptIn(ExperimentalTextApi::class)
  private fun archivoDisplay(viewportWidthDp: Int): FontFamily {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
      return FontFamily(
        Font(R.font.archivo_display_fallback_regular, FontWeight.Normal),
        Font(R.font.archivo_display_fallback_bold, FontWeight.Bold),
      )
    }
    val axes = requireNotNull(
      displayAxesAtProgress(OrvaDesignTheme.MEASURED_PRESS, 1f, viewportWidthDp),
    )
    val width = requireNotNull(axes.width)
    val profile = requireNotNull(OrvaThemeCatalog.get(OrvaDesignTheme.MEASURED_PRESS).type.displayAxes)
    return FontFamily(
      displayWeights.map { fontWeight ->
        val axisWeight = profile.weight.clamp(axes.weight + fontWeight.weight - FontWeight.Bold.weight).roundToInt()
        Font(
          R.font.archivo_variable,
          weight = fontWeight,
          variationSettings = FontVariation.Settings(
            FontVariation.weight(axisWeight),
            FontVariation.width(width),
          ),
        )
      },
    )
  }

  @OptIn(ExperimentalTextApi::class)
  private fun bricolageDisplay(viewportWidthDp: Int): FontFamily {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
      return FontFamily(
        Font(R.font.bricolage_display_fallback_regular, FontWeight.Normal),
        Font(R.font.bricolage_display_fallback_bold, FontWeight.Bold),
      )
    }
    val axes = requireNotNull(
      displayAxesAtProgress(OrvaDesignTheme.FIELD_SPECIMEN, 1f, viewportWidthDp),
    )
    val width = requireNotNull(axes.width)
    val opticalSize = requireNotNull(axes.opticalSize)
    val profile = requireNotNull(OrvaThemeCatalog.get(OrvaDesignTheme.FIELD_SPECIMEN).type.displayAxes)
    return FontFamily(
      displayWeights.map { fontWeight ->
        val axisWeight = profile.weight.clamp(axes.weight + fontWeight.weight - FontWeight.Bold.weight).roundToInt()
        Font(
          R.font.bricolage_grotesque_variable,
          weight = fontWeight,
          variationSettings = FontVariation.Settings(
            FontVariation.weight(axisWeight),
            FontVariation.width(width),
            FontVariation.Setting("opsz", opticalSize),
          ),
        )
      },
    )
  }

  @OptIn(ExperimentalTextApi::class)
  private fun variableWeightFamily(
    resourceId: Int,
    weights: IntProgression,
    fallbackResourceId: Int,
  ): FontFamily {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
      return FontFamily(Font(fallbackResourceId))
    }
    return FontFamily(
      weights.map { weight ->
        Font(
          resourceId,
          weight = FontWeight(weight),
          variationSettings = FontVariation.Settings(FontVariation.weight(weight)),
        )
      },
    )
  }
}
