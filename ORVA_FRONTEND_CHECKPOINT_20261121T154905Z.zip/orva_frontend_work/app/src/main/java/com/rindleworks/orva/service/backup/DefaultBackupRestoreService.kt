package com.rindleworks.orva.service.backup

import com.rindleworks.orva.data.local.OrvaDatabase
import com.rindleworks.orva.data.local.OrvaDatabaseProvider
import com.rindleworks.orva.data.local.OrvaSchemaBootstrapper
import com.rindleworks.orva.data.local.OrvaTransactionRunner
import com.rindleworks.orva.data.repository.StockSnapshotState
import com.rindleworks.orva.domain.common.AppVersionInfo
import com.rindleworks.orva.domain.common.OrvaSchemaInteropContract
import com.rindleworks.orva.domain.common.OrvaSettingKeys
import com.rindleworks.orva.domain.engine.BillingClock
import com.rindleworks.orva.domain.engine.BillingInstant
import com.rindleworks.orva.domain.settings.BackupRestoreService
import com.rindleworks.orva.domain.settings.BackupStatusSummary
import com.rindleworks.orva.domain.settings.ShopBackupCreateResult
import com.rindleworks.orva.domain.settings.ShopBackupManifest
import com.rindleworks.orva.domain.settings.ShopBackupPreview
import com.rindleworks.orva.domain.settings.ShopRestoreResult
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.security.MessageDigest
import java.time.Instant
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import java.util.zip.Deflater
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

// Exact WPF PascalCase manifest.json wire format for bidirectional .shopbackup parity.
@Serializable
internal data class ShopBackupManifestJson(
  @SerialName("BackupFormat") val backupFormat: String = OrvaSchemaInteropContract.BACKUP_FORMAT_NAME,
  @SerialName("FormatVersion") val formatVersion: Int = OrvaSchemaInteropContract.BACKUP_FORMAT_VERSION,
  @SerialName("ApplicationName") val applicationName: String = "ORVA",
  @SerialName("ApplicationVersion") val applicationVersion: String = "1.0.0",
  @SerialName("DatabaseSchemaVersion") val databaseSchemaVersion: Int = OrvaSchemaInteropContract.CURRENT_SCHEMA_VERSION,
  @SerialName("ShopId") val shopId: String? = null,
  @SerialName("ShopName") val shopName: String? = null,
  @SerialName("BackupUtc") val backupUtc: String = "",
  @SerialName("BackupLocalText") val backupLocalText: String = "",
  @SerialName("DatabaseFileName") val databaseFileName: String = OrvaDatabase.DEFAULT_DB_NAME,
  @SerialName("DatabaseLengthBytes") val databaseLengthBytes: Long = 0L,
  @SerialName("DatabaseSha256") val databaseSha256: String = "",
  @SerialName("MedicineCount") val medicineCount: Long = 0L,
  @SerialName("BatchCount") val batchCount: Long = 0L,
  @SerialName("InvoiceCount") val invoiceCount: Long = 0L,
  @SerialName("PurchaseCount") val purchaseCount: Long = 0L,
  @SerialName("ReturnCount") val returnCount: Long = 0L,
)

/**
 * Portable unencrypted `.shopbackup` creation, automatic daily backup coordination,
 * count-based retention management (never deleting the last valid backup), rolling portable
 * `ShopBackup.shopbackup` overwrite, post-write ZIP SHA-256 verification, and safe live Room
 * database restore with automatic rollback recovery.
 */
class DefaultBackupRestoreService(
  private val databaseProvider: OrvaDatabaseProvider,
  private val transactionRunner: OrvaTransactionRunner,
  private val clock: BillingClock,
  private val backupsDirectoryProvider: () -> File,
  private val stagingParentDirectory: File,
  private val appVersionInfo: AppVersionInfo,
  private val snapshotRefresher: (suspend () -> Result<Boolean>)? = null,
  private val portableCopyDirectoryProvider: (() -> File)? = null,
) : BackupRestoreService {

  constructor(
    databaseProvider: OrvaDatabaseProvider,
    transactionRunner: OrvaTransactionRunner,
    clock: BillingClock,
    backupsDirectory: File,
    stagingParentDirectory: File,
    appVersionInfo: AppVersionInfo,
    snapshotRefresher: (suspend () -> Result<Boolean>)? = null,
    portableCopyDirectory: File? = null,
  ) : this(
    databaseProvider = databaseProvider,
    transactionRunner = transactionRunner,
    clock = clock,
    backupsDirectoryProvider = { backupsDirectory },
    stagingParentDirectory = stagingParentDirectory,
    appVersionInfo = appVersionInfo,
    snapshotRefresher = snapshotRefresher,
    portableCopyDirectoryProvider = portableCopyDirectory?.let { dir -> { dir } },
  )

  companion object {
    const val MANIFEST_ENTRY = "manifest.json"
    const val DATABASE_ENTRY = "orva.sqlite"
    const val PORTABLE_BACKUP_FILE_NAME = "ShopBackup.shopbackup"
    const val DEFAULT_RETENTION_DAYS = 7
    private const val MAX_MANIFEST_BYTES = 1L * 1024L * 1024L // 1 MB ceiling
    private const val MAX_DATABASE_BYTES = 512L * 1024L * 1024L // 512 MB ceiling
    private val FILE_TIMESTAMP_FMT = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss", Locale.ROOT)
  }

  private val json = Json {
    encodeDefaults = true
    ignoreUnknownKeys = true
    prettyPrint = true
  }

  private val backupInProgress = AtomicBoolean(false)

  val dailyBackupsDirectory: File
    get() = File(backupsDirectoryProvider(), "Daily")

  val safetyBackupsDirectory: File
    get() = File(backupsDirectoryProvider(), "Safety")

  fun portableShopBackupFile(): File? =
    portableCopyDirectoryProvider?.invoke()?.let { File(it, PORTABLE_BACKUP_FILE_NAME) }

  /** Test-only hook invoked after replacing the active SQLite file during restore, to verify automatic rollback. */
  internal var restoreAfterReplaceFailureHook: (() -> Unit)? = null

  override suspend fun createBackupToStream(
    output: OutputStream,
    displayTargetName: String,
  ): ShopBackupCreateResult {
    val stagingDir = newStagingDir("export")
    return try {
      val (stagedDb, manifest) = createVerifiedStagedSnapshot(stagingDir)
      writeZipToStream(stagedDb, manifest, output)
      ShopBackupCreateResult(
        succeeded = true,
        backupPathOrUri = displayTargetName,
        manifest = manifest,
      )
    } catch (ex: Exception) {
      ShopBackupCreateResult(
        succeeded = false,
        errorMessage = "Backup failed: ${ex.message ?: ex.javaClass.simpleName}",
      )
    } finally {
      stagingDir.deleteRecursively()
    }
  }

  override suspend fun runBackupNow(): ShopBackupCreateResult {
    if (!backupInProgress.compareAndSet(false, true)) {
      return ShopBackupCreateResult(
        succeeded = false,
        errorMessage = "A backup is already in progress.",
      )
    }
    return try {
      createLocalBackup(isSafetyBackup = false)
    } finally {
      backupInProgress.set(false)
    }
  }

  suspend fun createSafetyBackup(): ShopBackupCreateResult =
    createLocalBackup(isSafetyBackup = true)

  override suspend fun runDailyBackupIfDue(): ShopBackupCreateResult? {
    val status = getBackupStatus()
    if (!status.isDueToday) return null
    return runBackupNow()
  }

  override suspend fun getBackupStatus(): BackupStatusSummary =
    transactionRunner.runRead { db ->
      val dao = db.appSettingDao()
      val lastSuccessUtc = dao.getValue(OrvaSettingKeys.BACKUP_LAST_SUCCESS_UTC)
      val lastLocalDate = dao.getValue(OrvaSettingKeys.BACKUP_LAST_SUCCESS_LOCAL_DATE)
      val lastPath = dao.getValue(OrvaSettingKeys.BACKUP_LAST_PATH)
      val lastError = dao.getValue(OrvaSettingKeys.BACKUP_LAST_ERROR)
      val retention =
        dao.getValue(OrvaSettingKeys.BACKUP_RETENTION_DAYS)?.toIntOrNull()?.coerceIn(1, 365)
          ?: DEFAULT_RETENTION_DAYS
      val todayLocal = BillingInstant.capture(clock).localBusinessDate.toString()
      val isDue = lastLocalDate != todayLocal

      BackupStatusSummary(
        lastSuccessUtc = lastSuccessUtc,
        lastSuccessLocalDate = lastLocalDate,
        lastBackupPath = lastPath,
        lastError = lastError,
        retentionDays = retention,
        isDueToday = isDue,
      )
    }

  override suspend fun setRetentionDays(days: Int) {
    val clamped = days.coerceIn(1, 365)
    val nowUtc = BillingInstant.capture(clock).utcIsoText
    transactionRunner.runWriteTransaction { db ->
      StockSnapshotState.upsertSetting(
        db,
        OrvaSettingKeys.BACKUP_RETENTION_DAYS,
        clamped.toString(),
        nowUtc,
      )
    }
  }

  override suspend fun previewRestore(input: InputStream, sourceName: String): ShopBackupPreview {
    val stagingDir = newStagingDir("preview")
    return try {
      val inspected = extractAndValidateBackup(input, sourceName, stagingDir)
      val targetProfile = transactionRunner.runRead { it.shopProfileDao().getProfile() }
      val isDifferentShop =
        inspected.manifest != null &&
          !targetProfile?.shopId.isNullOrBlank() &&
          !inspected.manifest.shopId.isNullOrBlank() &&
          targetProfile.shopId != inspected.manifest.shopId

      ShopBackupPreview(
        isValid = inspected.errors.isEmpty() && inspected.manifest != null,
        sourceName = sourceName,
        manifest = inspected.manifest,
        targetShopId = targetProfile?.shopId,
        targetShopName = targetProfile?.shopName,
        isDifferentShop = isDifferentShop,
        errors = inspected.errors,
      )
    } finally {
      stagingDir.deleteRecursively()
    }
  }

  override suspend fun executeRestore(input: InputStream, sourceName: String): ShopRestoreResult {
    val stagingDir = newStagingDir("restore")
    return try {
      // 1. Extract and strictly verify the backup archive BEFORE touching live DB.
      val inspected = extractAndValidateBackup(input, sourceName, stagingDir)
      if (inspected.errors.isNotEmpty() || inspected.manifest == null || inspected.extractedDb == null) {
        return ShopRestoreResult(
          succeeded = false,
          errorMessage = inspected.errors.firstOrNull() ?: "Backup validation failed.",
        )
      }

      // 2. Create a permanent pre-restore safety backup while the existing DB is still live.
      val safetyResult = createSafetyBackup()
      if (!safetyResult.succeeded || safetyResult.backupPathOrUri.isNullOrBlank()) {
        return ShopRestoreResult(
          succeeded = false,
          errorMessage =
            "Restore aborted: could not create pre-restore safety backup (${safetyResult.errorMessage}).",
        )
      }
      val safetyPath = safetyResult.backupPathOrUri

      // 3. Exclusively swap the SQLite file under maintenance lock with automatic rollback recovery.
      var restoredShopName: String? = null
      var originalRecovered = false
      var restoreError: String? = null

      transactionRunner.withMaintenanceLock {
        val activeFile = databaseProvider.databaseFile
        val rollbackFile = File(stagingDir, "rollback_original.sqlite")

        // Take an atomic clean snapshot of current live DB into rollbackFile before closing.
        snapshotActiveDatabaseTo(rollbackFile)

        databaseProvider.closeCurrent()
        deleteSidecars(activeFile)

        try {
          inspected.extractedDb.copyTo(activeFile, overwrite = true)
          deleteSidecars(activeFile)

          // Optional test hook to simulate mid-restore failure and verify automatic rollback!
          restoreAfterReplaceFailureHook?.invoke()

          // Reopen Room (runs non-destructive v1/v2->v3 migration if needed, verifies v3 schema, bumps databaseGeneration).
          val reopened = databaseProvider.reopen()
          val sqlite = reopened.openHelper.writableDatabase
          sqlite.query("PRAGMA integrity_check;").use { c ->
            check(c.moveToFirst() && c.getString(0).equals("ok", ignoreCase = true)) {
              "Restored database failed integrity_check."
            }
          }
          sqlite.query("PRAGMA foreign_key_check;").use { c ->
            check(!c.moveToNext()) { "Restored database failed foreign_key_check." }
          }
          restoredShopName = reopened.shopProfileDao().getProfile()?.shopName ?: inspected.manifest.shopName
        } catch (ex: Exception) {
          restoreError = ex.message ?: ex.javaClass.simpleName
          // Automatic rollback recovery: restore previous database and reopen Room!
          runCatching {
            databaseProvider.closeCurrent()
            deleteSidecars(activeFile)
            rollbackFile.copyTo(activeFile, overwrite = true)
            deleteSidecars(activeFile)
            databaseProvider.reopen()
            originalRecovered = true
          }
        }
      }

      if (restoreError != null) {
        return ShopRestoreResult(
          succeeded = false,
          safetyBackupPath = safetyPath,
          originalDatabaseRecovered = originalRecovered,
          errorMessage =
            "Restore failed ($restoreError). ${if (originalRecovered) "Your previous database was automatically recovered." else "Use the safety backup at $safetyPath to recover."}",
        )
      }

      // 4. Refresh local StockData.json best-effort from the newly restored DB.
      var snapshotRefreshed = false
      var snapshotWarning: String? = null
      val refresher = snapshotRefresher
      if (refresher != null) {
        val res = runCatching { refresher.invoke() }.getOrElse { Result.failure(it) }
        if (res.isSuccess) snapshotRefreshed = true
        else snapshotWarning = "Database restored, but StockData.json refresh failed: ${res.exceptionOrNull()?.message}"
      }

      ShopRestoreResult(
        succeeded = true,
        restoredShopName = restoredShopName,
        safetyBackupPath = safetyPath,
        snapshotRefreshed = snapshotRefreshed,
        snapshotWarning = snapshotWarning,
      )
    } finally {
      stagingDir.deleteRecursively()
    }
  }

  private suspend fun createLocalBackup(isSafetyBackup: Boolean): ShopBackupCreateResult {
    val stagingDir = newStagingDir(if (isSafetyBackup) "safety" else "backup")
    return try {
      val targetDir = if (isSafetyBackup) safetyBackupsDirectory else dailyBackupsDirectory
      targetDir.mkdirs()
      val (stagedDb, manifest) = createVerifiedStagedSnapshot(stagingDir)

      val now = BillingInstant.capture(clock)
      val prefix = if (isSafetyBackup) "ORVA_Safety_" else "ORVA_Daily_"
      val stamp = FILE_TIMESTAMP_FMT.format(now.localNow)
      val targetFile = File(targetDir, "${prefix}${stamp}_${System.nanoTime() % 10000}.shopbackup")
      val tmpZip = File(targetDir, "${targetFile.name}.tmp")

      try {
        FileOutputStream(tmpZip).use { fos ->
          writeZipToStream(stagedDb, manifest, fos)
          fos.flush()
          runCatching { fos.fd.sync() }
        }
        // Verify completed ZIP package (manifest + SHA-256 + SQLite integrity) BEFORE atomic replace (WPF parity).
        val verifyDir = File(stagingDir, "verify").apply { mkdirs() }
        val verifyResult = FileInputStream(tmpZip).use { fis ->
          extractAndValidateBackup(fis, tmpZip.name, verifyDir)
        }
        check(verifyResult.errors.isEmpty() && verifyResult.manifest != null) {
          "Generated backup failed post-write verification: ${verifyResult.errors.joinToString("; ")}"
        }
        atomicReplaceFile(tmpZip, targetFile)
      } finally {
        if (tmpZip.exists()) tmpZip.delete()
      }

      if (!isSafetyBackup) {
        // Also maintain rolling portable ShopBackup.shopbackup copy alongside StockData.json (WPF parity).
        portableShopBackupFile()?.let { portableTarget ->
          portableTarget.parentFile?.mkdirs()
          val portableTmp = File(portableTarget.parentFile, "${portableTarget.name}.tmp")
          try {
            targetFile.copyTo(portableTmp, overwrite = true)
            atomicReplaceFile(portableTmp, portableTarget)
          } finally {
            if (portableTmp.exists()) portableTmp.delete()
          }
        }

        val retentionDays =
          transactionRunner.runRead { db ->
            db.appSettingDao().getValue(OrvaSettingKeys.BACKUP_RETENTION_DAYS)?.toIntOrNull()
              ?.coerceIn(1, 365) ?: DEFAULT_RETENTION_DAYS
          }
        pruneOldBackupsNeverDeletingLastValid(retentionDays, now.utcNow)

        transactionRunner.runWriteTransaction { db ->
          StockSnapshotState.upsertSetting(db, OrvaSettingKeys.BACKUP_LAST_SUCCESS_UTC, now.utcIsoText, now.utcIsoText)
          StockSnapshotState.upsertSetting(
            db,
            OrvaSettingKeys.BACKUP_LAST_SUCCESS_LOCAL_DATE,
            now.localBusinessDate.toString(),
            now.utcIsoText,
          )
          StockSnapshotState.upsertSetting(db, OrvaSettingKeys.BACKUP_LAST_PATH, targetFile.absolutePath, now.utcIsoText)
          StockSnapshotState.upsertSetting(db, OrvaSettingKeys.BACKUP_LAST_ERROR, "", now.utcIsoText)
        }
      }

      ShopBackupCreateResult(
        succeeded = true,
        backupPathOrUri = targetFile.absolutePath,
        manifest = manifest,
      )
    } catch (ex: Exception) {
      val msg = ex.message ?: ex.javaClass.simpleName
      if (!isSafetyBackup) {
        runCatching {
          val nowUtc = BillingInstant.capture(clock).utcIsoText
          transactionRunner.runWriteTransaction { db ->
            StockSnapshotState.upsertSetting(db, OrvaSettingKeys.BACKUP_LAST_ERROR, msg, nowUtc)
          }
        }
      }
      ShopBackupCreateResult(succeeded = false, errorMessage = "Backup failed: $msg")
    } finally {
      stagingDir.deleteRecursively()
    }
  }

  private fun atomicReplaceFile(sourceTemp: File, destination: File) {
    if (!sourceTemp.renameTo(destination)) {
      sourceTemp.copyTo(destination, overwrite = true)
      sourceTemp.delete()
    }
  }

  private suspend fun createVerifiedStagedSnapshot(stagingDir: File): Pair<File, ShopBackupManifest> {
    val stagedDb = File(stagingDir, DATABASE_ENTRY)

    // Snapshot active DB under exclusive maintenance lock so WAL data is 100% consistent.
    transactionRunner.withMaintenanceLock {
      snapshotActiveDatabaseTo(stagedDb)
    }

    // Strip Room metadata & switch journal_mode=DELETE on the STAGED copy ONLY for pure WPF parity.
    OrvaSchemaBootstrapper.prepareStagedCopyForPortableExport(stagedDb)

    val report = OrvaSchemaBootstrapper.validateStandaloneSqliteFile(stagedDb)
    check(report.isValid) {
      "Staged backup database failed validation: ${report.errors.joinToString("; ")}"
    }

    val sha256 = computeSha256Hex(stagedDb)
    val now = BillingInstant.capture(clock)
    val manifest =
      ShopBackupManifest(
        backupFormat = OrvaSchemaInteropContract.BACKUP_FORMAT_NAME,
        formatVersion = OrvaSchemaInteropContract.BACKUP_FORMAT_VERSION,
        applicationName = appVersionInfo.applicationName,
        applicationVersion = appVersionInfo.versionName,
        databaseSchemaVersion = report.schemaVersion,
        shopId = report.shopId,
        shopName = report.shopName,
        backupUtc = now.utcIsoText,
        backupLocalText = now.localLogText,
        databaseFileName = DATABASE_ENTRY,
        databaseLengthBytes = stagedDb.length(),
        databaseSha256 = sha256,
        medicineCount = report.medicineCount,
        batchCount = report.batchCount,
        invoiceCount = report.invoiceCount,
        purchaseCount = report.purchaseCount,
        returnCount = report.returnCount,
      )
    return stagedDb to manifest
  }

  /**
   * Produces a consistent snapshot of the live WAL SQLite database into [destinationFile].
   * Prefers SQLite `VACUUM INTO` (SQLite >= 3.27.0 / API 30+); falls back cleanly to
   * `PRAGMA wal_checkpoint(TRUNCATE)` + file copy on API 24-29 while holding the write lock.
   */
  private fun snapshotActiveDatabaseTo(destinationFile: File) {
    destinationFile.parentFile?.mkdirs()
    if (destinationFile.exists()) destinationFile.delete()

    val db = databaseProvider.current()
    val sqlite = db.openHelper.writableDatabase
    val escapedPath = destinationFile.absolutePath.replace("'", "''")

    val vacuumSucceeded =
      try {
        sqlite.execSQL("VACUUM INTO '$escapedPath';")
        destinationFile.exists() && destinationFile.length() > 0L
      } catch (_: Exception) {
        false
      }

    if (!vacuumSucceeded) {
      // Fallback for older SQLite (< 3.27.0): checkpoint WAL cleanly while holding maintenanceMutex.
      sqlite.query("PRAGMA wal_checkpoint(TRUNCATE);").use { c ->
        if (c.moveToFirst()) {
          val busy = c.getInt(0)
          check(busy == 0) { "SQLite WAL checkpoint reported busy ($busy); cannot copy safely." }
        }
      }
      databaseProvider.databaseFile.copyTo(destinationFile, overwrite = true)
    }
  }

  private fun writeZipToStream(stagedDb: File, manifest: ShopBackupManifest, output: OutputStream) {
    val manifestDto =
      ShopBackupManifestJson(
        backupFormat = manifest.backupFormat,
        formatVersion = manifest.formatVersion,
        applicationName = manifest.applicationName,
        applicationVersion = manifest.applicationVersion,
        databaseSchemaVersion = manifest.databaseSchemaVersion,
        shopId = manifest.shopId,
        shopName = manifest.shopName,
        backupUtc = manifest.backupUtc,
        backupLocalText = manifest.backupLocalText,
        databaseFileName = manifest.databaseFileName,
        databaseLengthBytes = manifest.databaseLengthBytes,
        databaseSha256 = manifest.databaseSha256,
        medicineCount = manifest.medicineCount,
        batchCount = manifest.batchCount,
        invoiceCount = manifest.invoiceCount,
        purchaseCount = manifest.purchaseCount,
        returnCount = manifest.returnCount,
      )
    val manifestBytes = json.encodeToString(manifestDto).toByteArray(Charsets.UTF_8)

    ZipOutputStream(output).use { zos ->
      zos.setLevel(Deflater.DEFAULT_COMPRESSION)
      zos.putNextEntry(ZipEntry(MANIFEST_ENTRY))
      zos.write(manifestBytes)
      zos.closeEntry()

      zos.putNextEntry(ZipEntry(DATABASE_ENTRY))
      FileInputStream(stagedDb).use { fis ->
        fis.copyTo(zos, bufferSize = 32 * 1024)
      }
      zos.closeEntry()
      zos.finish()
    }
  }

  private fun extractAndValidateBackup(
    input: InputStream,
    sourceName: String,
    stagingDir: File,
  ): ExtractedBackup {
    val errors = mutableListOf<String>()
    var manifestBytes: ByteArray? = null
    val extractedDb = File(stagingDir, DATABASE_ENTRY)
    var foundDb = false

    try {
      ZipInputStream(input).use { zis ->
        var entry = zis.nextEntry
        while (entry != null) {
          val name = entry.name.replace('\\', '/')
          if (name.contains("..") || name.startsWith("/")) {
            errors += "Backup archive '$sourceName' contains an unsafe entry path '$name'."
            return ExtractedBackup(null, null, errors)
          }
          when (name) {
            MANIFEST_ENTRY -> {
              manifestBytes = readBounded(zis, MAX_MANIFEST_BYTES, MANIFEST_ENTRY)
            }
            DATABASE_ENTRY -> {
              copyBoundedToFile(zis, extractedDb, MAX_DATABASE_BYTES, DATABASE_ENTRY)
              foundDb = true
            }
          }
          entry = zis.nextEntry
        }
      }
    } catch (ex: Exception) {
      errors += "Unable to open '$sourceName' as a valid .shopbackup archive: ${ex.message}"
      return ExtractedBackup(null, null, errors)
    }

    if (manifestBytes == null) {
      errors += "Backup archive is missing '$MANIFEST_ENTRY'."
    }
    if (!foundDb || !extractedDb.exists()) {
      errors += "Backup archive is missing '$DATABASE_ENTRY'."
    }
    if (errors.isNotEmpty()) {
      return ExtractedBackup(null, null, errors)
    }

    val manifestDto =
      try {
        json.decodeFromString<ShopBackupManifestJson>(
          String(manifestBytes!!, Charsets.UTF_8).trimStart('\uFEFF')
        )
      } catch (ex: Exception) {
        errors += "Invalid manifest.json: ${ex.message}"
        return ExtractedBackup(null, null, errors)
      }

    if (manifestDto.backupFormat != OrvaSchemaInteropContract.BACKUP_FORMAT_NAME) {
      errors += "Unsupported backup format '${manifestDto.backupFormat}'."
    }
    if (manifestDto.formatVersion != OrvaSchemaInteropContract.BACKUP_FORMAT_VERSION) {
      errors += "Unsupported backup format version ${manifestDto.formatVersion}."
    }
    if (manifestDto.databaseSchemaVersion > OrvaSchemaInteropContract.CURRENT_SCHEMA_VERSION) {
      errors +=
        "Backup requires newer database schema version ${manifestDto.databaseSchemaVersion} (this app supports up to version ${OrvaSchemaInteropContract.CURRENT_SCHEMA_VERSION})."
    }

    val actualLength = extractedDb.length()
    if (manifestDto.databaseLengthBytes != actualLength) {
      errors +=
        "Database file size mismatch: manifest declares ${manifestDto.databaseLengthBytes} bytes, archive contains $actualLength bytes."
    }

    val actualSha256 = computeSha256Hex(extractedDb)
    if (!actualSha256.equals(manifestDto.databaseSha256.trim(), ignoreCase = true)) {
      errors += "Backup checksum verification failed (SHA-256 mismatch). The backup file may be corrupted or modified."
    }

    val dbValidation = OrvaSchemaBootstrapper.validateStandaloneSqliteFile(extractedDb)
    if (!dbValidation.isValid) {
      errors += dbValidation.errors
    }

    val manifest =
      ShopBackupManifest(
        backupFormat = manifestDto.backupFormat,
        formatVersion = manifestDto.formatVersion,
        applicationName = manifestDto.applicationName,
        applicationVersion = manifestDto.applicationVersion,
        databaseSchemaVersion = manifestDto.databaseSchemaVersion,
        shopId = manifestDto.shopId ?: dbValidation.shopId,
        shopName = manifestDto.shopName ?: dbValidation.shopName,
        backupUtc = manifestDto.backupUtc,
        backupLocalText = manifestDto.backupLocalText,
        databaseFileName = manifestDto.databaseFileName,
        databaseLengthBytes = manifestDto.databaseLengthBytes,
        databaseSha256 = manifestDto.databaseSha256,
        medicineCount = manifestDto.medicineCount,
        batchCount = manifestDto.batchCount,
        invoiceCount = manifestDto.invoiceCount,
        purchaseCount = manifestDto.purchaseCount,
        returnCount = manifestDto.returnCount,
      )

    return ExtractedBackup(manifest, extractedDb, errors)
  }

  /**
   * Keeps the newest [retentionDays] daily `.shopbackup` files (minimum 1), matching WPF
   * `AutomaticBackupCoordinator.PruneOldDailyBackups`, and NEVER deletes the last valid backup.
   */
  internal fun pruneOldBackupsNeverDeletingLastValid(retentionDays: Int, @Suppress("UNUSED_PARAMETER") nowUtc: Instant) {
    val keepCount = retentionDays.coerceAtLeast(1)
    val dailyDir = dailyBackupsDirectory
    if (!dailyDir.exists()) return
    val dailyBackups =
      dailyDir
        .listFiles { f ->
          f.isFile && f.name.startsWith("ORVA_Daily_") && f.name.endsWith(".shopbackup")
        }
        ?.sortedWith(compareByDescending<File> { it.lastModified() }.thenByDescending { it.name })
        .orEmpty()

    if (dailyBackups.size <= keepCount) return

    for (file in dailyBackups.drop(keepCount)) {
      runCatching { file.delete() }
    }
  }

  private fun computeSha256Hex(file: File): String {
    val digest = MessageDigest.getInstance("SHA-256")
    FileInputStream(file).use { fis ->
      val buf = ByteArray(32 * 1024)
      while (true) {
        val read = fis.read(buf)
        if (read <= 0) break
        digest.update(buf, 0, read)
      }
    }
    return digest.digest().joinToString("") { "%02x".format(it) }
  }

  private fun readBounded(input: InputStream, maxBytes: Long, entryName: String): ByteArray {
    val out = java.io.ByteArrayOutputStream()
    val buf = ByteArray(8192)
    var total = 0L
    while (true) {
      val read = input.read(buf)
      if (read <= 0) break
      total += read
      if (total > maxBytes) {
        throw IllegalStateException("Entry '$entryName' exceeds maximum allowed size ($maxBytes bytes).")
      }
      out.write(buf, 0, read)
    }
    return out.toByteArray()
  }

  private fun copyBoundedToFile(
    input: InputStream,
    target: File,
    maxBytes: Long,
    entryName: String,
  ) {
    FileOutputStream(target).use { fos ->
      val buf = ByteArray(32 * 1024)
      var total = 0L
      while (true) {
        val read = input.read(buf)
        if (read <= 0) break
        total += read
        if (total > maxBytes) {
          throw IllegalStateException("Entry '$entryName' exceeds maximum allowed size ($maxBytes bytes).")
        }
        fos.write(buf, 0, read)
      }
    }
  }

  private fun deleteSidecars(dbFile: File) {
    File(dbFile.absolutePath + "-wal").delete()
    File(dbFile.absolutePath + "-shm").delete()
  }

  private fun newStagingDir(prefix: String): File =
    File(stagingParentDirectory, "orva_${prefix}_${System.nanoTime()}").apply { mkdirs() }

  private data class ExtractedBackup(
    val manifest: ShopBackupManifest?,
    val extractedDb: File?,
    val errors: List<String>,
  )
}
