package com.rindleworks.orva.fake

import com.rindleworks.orva.domain.common.OrvaFormatters
import com.rindleworks.orva.domain.inventory.BatchStatus
import com.rindleworks.orva.domain.inventory.CatalogueImportPreview
import com.rindleworks.orva.domain.inventory.CatalogueImportResult
import com.rindleworks.orva.domain.inventory.ExpiryAlertItem
import com.rindleworks.orva.domain.inventory.ExpiryAlertLevel
import com.rindleworks.orva.domain.inventory.InventoryFilterMode
import com.rindleworks.orva.domain.inventory.InventoryRepository
import com.rindleworks.orva.domain.inventory.InventoryRow
import com.rindleworks.orva.domain.inventory.LowStockAlertItem
import com.rindleworks.orva.domain.inventory.MedicineCatalogueImportService
import com.rindleworks.orva.domain.inventory.MedicineDetailsInput
import com.rindleworks.orva.domain.inventory.StockAdjustmentInput
import com.rindleworks.orva.domain.inventory.StockAdjustmentResult
import com.rindleworks.orva.domain.inventory.StockAdjustmentService
import com.rindleworks.orva.domain.inventory.StockEntryInput
import com.rindleworks.orva.domain.inventory.StockEntryResult
import com.rindleworks.orva.domain.inventory.StockEntryService
import com.rindleworks.orva.domain.inventory.StockImportPreview
import com.rindleworks.orva.domain.inventory.StockImportResult
import com.rindleworks.orva.domain.inventory.StockSnapshotService
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.map

class FakeInventoryRepository : InventoryRepository {
  internal val rowsState =
    MutableStateFlow(
      listOf(
        InventoryRow(
          medicineId = "fake-med-1",
          batchId = "fake-batch-1",
          medicineName = "Paracetamol 500mg",
          batchNumber = "P26A",
          expiryText = OrvaFormatters.formatExpiry(202803),
          expiryYearMonth = 202803,
          quantityText = OrvaFormatters.formatQuantity(24_000L),
          quantityMilli = 24_000L,
          unit = "strip",
          mrpPaise = 3_200L,
          mrpText = OrvaFormatters.formatRupees(3_200L),
          statusLabel = ExpiryAlertLevel.None.label,
          statusColourHex = ExpiryAlertLevel.None.colourHex,
          batchStatus = BatchStatus.Active,
          expiryLevel = ExpiryAlertLevel.None,
          isLowStock = false,
          lowStockThresholdMilli = 5_000L,
          usableMedicineTotalMilli = 24_000L,
        ),
        InventoryRow(
          medicineId = "fake-med-2",
          batchId = "fake-batch-2",
          medicineName = "Amoxicillin 250mg",
          batchNumber = "AMX09",
          expiryText = OrvaFormatters.formatExpiry(202706),
          expiryYearMonth = 202706,
          quantityText = OrvaFormatters.formatQuantity(3_000L),
          quantityMilli = 3_000L,
          unit = "strip",
          mrpPaise = 8_500L,
          mrpText = OrvaFormatters.formatRupees(8_500L),
          statusLabel = ExpiryAlertLevel.UrgentWarning30Days.label,
          statusColourHex = ExpiryAlertLevel.UrgentWarning30Days.colourHex,
          batchStatus = BatchStatus.Active,
          expiryLevel = ExpiryAlertLevel.UrgentWarning30Days,
          isLowStock = true,
          lowStockThresholdMilli = 5_000L,
          usableMedicineTotalMilli = 3_000L,
        ),
      )
    )

  override fun observeInventoryRows(
    searchText: String,
    filterMode: InventoryFilterMode,
  ): Flow<List<InventoryRow>> =
    rowsState.map { rows ->
      val query = searchText.trim()
      rows.filter { row ->
        val matchesSearch =
          query.isEmpty() ||
            row.medicineName.contains(query, ignoreCase = true) ||
            row.batchNumber.contains(query, ignoreCase = true)
        val matchesFilter =
          when (filterMode) {
            InventoryFilterMode.All -> true
            InventoryFilterMode.LowStock -> row.isLowStock
            InventoryFilterMode.Expiring ->
              row.expiryLevel != ExpiryAlertLevel.None &&
                row.expiryLevel != ExpiryAlertLevel.Expired &&
                row.quantityMilli > 0L
            InventoryFilterMode.Expired -> row.expiryLevel == ExpiryAlertLevel.Expired
          }
        matchesSearch && matchesFilter
      }
    }

  override fun observeLowStockAlerts(): Flow<List<LowStockAlertItem>> =
    rowsState.map { rows ->
      rows
        .filter { it.isLowStock }
        .distinctBy { it.medicineId }
        .map {
          LowStockAlertItem(
            medicineId = it.medicineId,
            medicineName = it.medicineName,
            stockUnitName = it.unit,
            usableQuantityMilli = it.usableMedicineTotalMilli,
            thresholdMilli = it.lowStockThresholdMilli,
          )
        }
    }

  override fun observeExpiryAlerts(): Flow<List<ExpiryAlertItem>> =
    rowsState.map { rows ->
      rows
        .filter { it.expiryLevel != ExpiryAlertLevel.None }
        .map {
          ExpiryAlertItem(
            medicineId = it.medicineId,
            batchId = it.batchId,
            medicineName = it.medicineName,
            batchNumber = it.batchNumber,
            expiryYearMonth = it.expiryYearMonth,
            expiryDateIso = "${it.expiryText}-28",
            daysRemaining = if (it.expiryLevel == ExpiryAlertLevel.Expired) -1 else 25,
            quantityMilli = it.quantityMilli,
            stockUnitName = it.unit,
            alertLevel = it.expiryLevel,
            alertLabel = it.expiryLevel.label,
          )
        }
    }

  override suspend fun getMedicineDetails(medicineId: String): MedicineDetailsInput? {
    val row = rowsState.value.firstOrNull { it.medicineId == medicineId } ?: return null
    return MedicineDetailsInput(
      medicineId = row.medicineId,
      displayName = row.medicineName,
      genericName = null,
      brandName = null,
      strength = null,
      dosageForm = null,
      stockUnitName = row.unit,
      lowStockThresholdMilli = row.lowStockThresholdMilli,
      isActive = true,
    )
  }

  override suspend fun updateMedicineDetails(input: MedicineDetailsInput): Result<Unit> {
    rowsState.value =
      rowsState.value.map { row ->
        if (row.medicineId == input.medicineId) {
          row.copy(
            medicineName = input.displayName.trim(),
            unit = input.stockUnitName.trim(),
            lowStockThresholdMilli = input.lowStockThresholdMilli,
          )
        } else {
          row
        }
      }
    return Result.success(Unit)
  }

  override suspend fun updateBatchStatus(
    batchId: String,
    newStatus: BatchStatus,
    reason: String,
  ): Result<Unit> {
    rowsState.value =
      rowsState.value.map { row ->
        if (row.batchId == batchId) row.copy(batchStatus = newStatus) else row
      }
    return Result.success(Unit)
  }

  override suspend fun getStockUnitForMedicine(medicineName: String): String? =
    rowsState.value.firstOrNull { it.medicineName.equals(medicineName.trim(), ignoreCase = true) }?.unit

  override suspend fun getCounts(): Pair<Int, Int> {
    val rows = rowsState.value
    return rows.map { it.medicineId }.distinct().size to rows.size
  }
}

class FakeStockEntryService(private val inventory: FakeInventoryRepository) : StockEntryService {
  override suspend fun receiveStock(input: StockEntryInput): StockEntryResult {
    if (input.medicineName.isBlank() || input.batchNumber.isBlank() || input.quantityMilli <= 0L) {
      return StockEntryResult(
        succeeded = false,
        errorMessage = "Enter medicine name, batch number, and quantity greater than zero.",
      )
    }
    val newRow =
      InventoryRow(
        medicineId = UUID.randomUUID().toString().replace("-", ""),
        batchId = UUID.randomUUID().toString().replace("-", ""),
        medicineName = input.medicineName.trim(),
        batchNumber = input.batchNumber.trim(),
        expiryText = OrvaFormatters.formatExpiry(input.expiryYearMonth),
        expiryYearMonth = input.expiryYearMonth,
        quantityText = OrvaFormatters.formatQuantity(input.quantityMilli),
        quantityMilli = input.quantityMilli,
        unit = input.stockUnitName.trim().ifEmpty { "unit" },
        mrpPaise = input.mrpPaise,
        mrpText = OrvaFormatters.formatRupees(input.mrpPaise),
        statusLabel = ExpiryAlertLevel.None.label,
        statusColourHex = ExpiryAlertLevel.None.colourHex,
        batchStatus = BatchStatus.Active,
        expiryLevel = ExpiryAlertLevel.None,
        isLowStock = false,
        lowStockThresholdMilli = 0L,
        usableMedicineTotalMilli = input.quantityMilli,
      )
    inventory.rowsState.value = inventory.rowsState.value + newRow
    return StockEntryResult(
      succeeded = true,
      medicineName = newRow.medicineName,
      batchNumber = newRow.batchNumber,
      newQuantityMilli = newRow.quantityMilli,
      snapshotUpdated = true,
    )
  }
}

class FakeStockAdjustmentService(private val inventory: FakeInventoryRepository) :
  StockAdjustmentService {
  override suspend fun adjustBatchQuantity(input: StockAdjustmentInput): StockAdjustmentResult {
    val target = inventory.rowsState.value.firstOrNull { it.batchId == input.batchId }
      ?: return StockAdjustmentResult(succeeded = false, errorMessage = "Batch not found.")
    if (input.countedQuantityMilli < 0L || input.reason.isBlank()) {
      return StockAdjustmentResult(
        succeeded = false,
        errorMessage = "Enter a valid non-negative quantity and adjustment reason.",
      )
    }
    val diff = input.countedQuantityMilli - target.quantityMilli
    inventory.rowsState.value =
      inventory.rowsState.value.map { row ->
        if (row.batchId == target.batchId) {
          row.copy(
            quantityMilli = input.countedQuantityMilli,
            quantityText = OrvaFormatters.formatQuantity(input.countedQuantityMilli),
            usableMedicineTotalMilli = input.countedQuantityMilli,
          )
        } else {
          row
        }
      }
    return StockAdjustmentResult(
      succeeded = true,
      medicineName = target.medicineName,
      batchNumber = target.batchNumber,
      previousQuantityMilli = target.quantityMilli,
      newQuantityMilli = input.countedQuantityMilli,
      differenceMilli = diff,
      snapshotUpdated = true,
    )
  }
}

class FakeStockSnapshotService : StockSnapshotService {
  override suspend fun refreshSnapshot(): Result<Boolean> = Result.success(true)

  override suspend fun exportSnapshotTo(output: OutputStream): Result<Unit> = runCatching {
    output.write("""{"Format":"ORVA_STOCK_DATA","FormatVersion":2,"Medicines":[]}""".toByteArray())
    output.flush()
  }

  override suspend fun previewStockDataImport(
    input: InputStream,
    sourceName: String,
  ): StockImportPreview =
    StockImportPreview(
      isValid = true,
      sourceName = sourceName,
      formatVersion = 2,
      medicineCount = 2,
      batchCount = 2,
      totalImportedQuantityMilli = 27_000L,
    )

  override suspend fun executeStockDataImport(
    input: InputStream,
    sourceName: String,
    confirmDifferentShop: Boolean,
  ): StockImportResult =
    StockImportResult(
      succeeded = true,
      medicinesImported = 2,
      batchesImported = 2,
      stockMovementsRecorded = 2,
      snapshotUpdated = true,
    )
}

class FakeMedicineCatalogueImportService : MedicineCatalogueImportService {
  override suspend fun writeTemplateCsv(output: OutputStream) {
    val header =
      "MedicineName,GenericName,BrandName,Strength,DosageForm,StockUnit,HsnCode,GstRatePercent,LowStockThreshold,Barcode,BatchNumber,ExpiryYyyyMm,OpeningQuantity,PurchasePrice,Mrp\n"
    output.write(header.toByteArray(Charsets.UTF_8))
    output.flush()
  }

  override suspend fun previewCatalogueImport(
    input: InputStream,
    fileName: String,
  ): CatalogueImportPreview =
    CatalogueImportPreview(
      isValid = true,
      sourceName = fileName,
      newMedicineCount = 1,
      openingBatchRowCount = 1,
    )

  override suspend fun executeCatalogueImport(
    input: InputStream,
    fileName: String,
    markProvidedGstRatesAsConfigured: Boolean,
  ): CatalogueImportResult =
    CatalogueImportResult(
      succeeded = true,
      medicinesCreated = 1,
      batchesUpdatedOrCreated = 1,
      snapshotRefreshed = true,
    )
}
