package com.rindleworks.orva.ui.about.agentic

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rindleworks.orva.domain.settings.AppLanguage
import com.rindleworks.orva.ui.showcase.OrvaShowcaseFonts
import com.rindleworks.orva.ui.showcase.currentShowcasePalette

/**
 * Compact reader-facing HUD. Progress and pause stay visible; advanced controls are tucked
 * behind one expansion affordance. Appearance selection is deliberately absent from this HUD.
 */
@Composable
fun AgenticHudBar(
  controller: AgenticBuildController,
  language: AppLanguage,
  modifier: Modifier = Modifier,
) {
  val palette = currentShowcasePalette()
  var advancedExpanded by remember(controller) { mutableStateOf(false) }
  val completed = controller.completedCount
  val total = controller.totalCount.coerceAtLeast(1)
  // Use the same per-layer animation journal as the pipette gauge so RESTOCK drains smoothly.
  val isDone = controller.act == BuildAct.COMPLETED && !controller.isThemeMorphActive
  val morphTheme = controller.themeMorphSnapshot.targetTheme
    ?.let(OrvaThemeCatalog::get)
    ?.name
  val morphStatus = when (controller.themeMorphSnapshot.phase) {
    MorphEnginePhase.IDLE -> null
    MorphEnginePhase.PAUSED -> morphTheme?.let { "PAUSED · $it" } ?: "PAUSED"
    MorphEnginePhase.ACTIVE -> when (controller.themeMorphSnapshot.activeRegionPhase) {
      MorphRegionPhase.RESTOCKING -> morphTheme?.let { "RESTOCK · $it" } ?: "RESTOCK"
      MorphRegionPhase.LAYOUT_SETTLING -> morphTheme?.let { "RE-LAY · $it" } ?: "RE-LAY"
      MorphRegionPhase.DISPENSING -> morphTheme?.let { "DISPENSE · $it" } ?: "DISPENSE"
      null -> morphTheme ?: "REDESIGN"
    }
  }

  val compactStatus = morphStatus ?: when (controller.act) {
      BuildAct.ORBITAL_SCAN -> if (language == AppLanguage.Bengali) "ইন্ট্রো" else "INTRO"
      BuildAct.STRUCTURAL_BUILD, BuildAct.SCROLL_ASSEMBLY -> when (controller.agentActivity) {
        AgentActivity.BUILD -> "DISPENSE · ${controller.sealedSceneCount}/${controller.totalSceneCount} · $completed/$total"
        AgentActivity.REWIND -> "RESTOCK · ${controller.sealedSceneCount}/${controller.totalSceneCount} · $completed/$total"
        AgentActivity.IDLE -> "IDLE · ${controller.sealedSceneCount}/${controller.totalSceneCount} · $completed/$total"
      }
      BuildAct.CONVERGENCE -> if (language == AppLanguage.Bengali) "সমাপ্তি" else "SETTLING"
      BuildAct.COMPLETED -> if (language == AppLanguage.Bengali) "সম্পন্ন" else "BUILT · $completed/$total"
    }

  val progressBrush =
    Brush.horizontalGradient(
      colors = listOf(palette.accent, palette.signal),
    )

  Box(
    modifier =
      modifier
        .fillMaxWidth()
        .navigationBarsPadding()
        .padding(horizontal = 14.dp, vertical = 10.dp),
    contentAlignment = Alignment.Center,
  ) {
    Column(
      modifier =
        Modifier
          .widthIn(max = 580.dp)
          .clip(RoundedCornerShape(999.dp))
          .background(palette.agentTagSurface)
          .border(1.dp, palette.hairline, RoundedCornerShape(999.dp))
          .testTag("agentic_hud_bar"),
    ) {
      Row(
        modifier =
          Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp),
      ) {
        Box(
          modifier =
            Modifier
              .size(6.dp)
              .clip(CircleShape)
              .background(
                if (isDone) palette.signal else palette.accent,
              ),
        )
        Text(
          text = compactStatus,
          fontFamily = OrvaShowcaseFonts.mono(language),
          fontSize = 10.sp,
          letterSpacing = OrvaShowcaseFonts.tracking(0.6.sp),
          color = palette.inkPrimary,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
          modifier = Modifier
            .weight(1f)
            .padding(start = 4.dp)
            .semantics {
              contentDescription = "Agentic Build: $compactStatus"
              stateDescription = when (controller.agentActivity) {
                AgentActivity.BUILD -> "Dispensing layers"
                AgentActivity.REWIND -> "Restocking lower completed layers"
                AgentActivity.IDLE -> "Build idle"
              }
            }
            .testTag("agentic_hud_status"),
        )

        CapsuleIconAction(
          icon = if (controller.paused) Icons.Filled.PlayArrow else Icons.Filled.Pause,
          contentDescription = if (controller.paused) "Resume build" else "Pause build",
          active = controller.paused,
          testTag = "hud_pause_btn",
          onClick = { controller.togglePause() },
        )
        CapsuleIconAction(
          icon = Icons.Filled.MoreHoriz,
          contentDescription = if (advancedExpanded) "Hide advanced build controls" else "Show advanced build controls",
          active = advancedExpanded,
          testTag = "hud_advanced_btn",
          onClick = { advancedExpanded = !advancedExpanded },
        )
      }

      if (advancedExpanded) {
        Row(
          modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
          if (!isDone) {
            CapsuleTextAction(
              label = if (controller.touringEnabled) "TOUR" else "FREE",
              active = controller.touringEnabled,
              testTag = "hud_tour_btn",
              onClick = { controller.toggleTouring() },
            )
            CapsuleTextAction(
              label = "${controller.speedMultiplier.toString().removeSuffix(".0")}×",
              active = controller.speedMultiplier > 1f,
              testTag = "hud_speed_btn",
              onClick = { controller.cycleSpeed() },
            )
            CapsuleTextAction(
              label = if (language == AppLanguage.Bengali) "সম্পূর্ণ" else "FINISH",
              active = false,
              accentColor = palette.accent,
              testTag = "hud_skip_btn",
              onClick = { controller.skipToFinish() },
            )
          } else {
            CapsuleTextAction(
              label = if (language == AppLanguage.Bengali) "পুনরায়" else "REPLAY",
              active = true,
              leadingIcon = Icons.Filled.Replay,
              testTag = "hud_replay_btn",
              onClick = { controller.replay() },
            )
          }
        }
      }

      // Draw-phase subscription to the shared Agentic clock; the HUD itself does not recompose
      // at frame cadence just to keep this thin progress line in sync with RESTOCK.
      Canvas(Modifier.fillMaxWidth().height(2.dp)) {
        val tick = controller.frameTick
        if (tick >= 0L) {
          val p = controller.buildProgress.coerceIn(0f, 1f)
          if (p > 0f) drawRect(brush = progressBrush, size = Size(size.width * p, size.height))
        }
      }
    }
  }
}

@Composable
private fun CapsuleTextAction(
  label: String,
  active: Boolean,
  testTag: String,
  onClick: () -> Unit,
  accentColor: Color? = null,
  leadingIcon: androidx.compose.ui.graphics.vector.ImageVector? = null,
) {
  val palette = currentShowcasePalette()
  val tint =
    when {
      accentColor != null -> accentColor
      active -> palette.signal
      else -> palette.inkSecondary
    }
  Row(
    modifier =
      Modifier
        .minimumInteractiveComponentSize()
        .clickable(role = Role.Button, onClick = onClick)
        .padding(horizontal = 6.dp)
        .testTag(testTag),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.spacedBy(4.dp),
  ) {
    if (leadingIcon != null) {
      Icon(imageVector = leadingIcon, contentDescription = null, tint = tint, modifier = Modifier.size(13.dp))
    }
    Text(
      text = label,
      fontFamily = OrvaShowcaseFonts.mono(),
      fontWeight = FontWeight.SemiBold,
      fontSize = 10.sp,
      letterSpacing = OrvaShowcaseFonts.tracking(0.8.sp),
      color = tint,
    )
  }
}

@Composable
private fun CapsuleIconAction(
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  contentDescription: String,
  active: Boolean,
  testTag: String,
  onClick: () -> Unit,
) {
  val palette = currentShowcasePalette()
  Box(
    modifier =
      Modifier
        .minimumInteractiveComponentSize()
        .clickable(role = Role.Button, onClick = onClick)
        .padding(horizontal = 4.dp)
        .testTag(testTag),
    contentAlignment = Alignment.Center,
  ) {
    Icon(
      imageVector = icon,
      contentDescription = contentDescription,
      tint =
        if (active) {
          palette.signal
        } else {
          palette.inkSecondary
        },
      modifier = Modifier.size(15.dp),
    )
  }
}
