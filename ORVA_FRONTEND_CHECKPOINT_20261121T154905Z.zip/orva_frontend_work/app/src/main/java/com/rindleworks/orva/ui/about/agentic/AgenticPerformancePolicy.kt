package com.rindleworks.orva.ui.about.agentic

/**
 * Pure hysteresis for the optional Agentic Build effects. Recovery is only committed at a
 * completed scene boundary so effects never reappear halfway through a gesture or node animation.
 */
class AgenticPerformancePolicy(
  private val slowFrameThresholdMs: Float = 12f,
  private val slowFramesToDegrade: Int = 3,
  private val healthyFrameThresholdMs: Float = 10f,
  private val healthyFramesToRecover: Int = 90,
  private val maximumLevel: Int = 3,
) {
  var level: Int = 0
    private set

  private var slowFrameStreak = 0
  private var healthyFrameStreak = 0
  private var recoveryPending = false

  fun onFrame(frameDurationMs: Float): Int {
    if (!frameDurationMs.isFinite() || frameDurationMs < 0f) return level

    when {
      frameDurationMs > slowFrameThresholdMs -> {
        recoveryPending = false
        slowFrameStreak++
        healthyFrameStreak = 0
        if (slowFrameStreak >= slowFramesToDegrade) {
          if (level < maximumLevel) level++
          slowFrameStreak = 0
        }
      }
      frameDurationMs < healthyFrameThresholdMs -> {
        healthyFrameStreak++
        slowFrameStreak = 0
        if (healthyFrameStreak >= healthyFramesToRecover) {
          if (level > 0) recoveryPending = true
          healthyFrameStreak = 0
        }
      }
      else -> {
        recoveryPending = false
        slowFrameStreak = 0
        healthyFrameStreak = 0
      }
    }
    return level
  }

  fun onSceneSealed(): Int {
    if (recoveryPending && level > 0) level--
    recoveryPending = false
    return level
  }

  fun reset(): Int {
    level = 0
    slowFrameStreak = 0
    healthyFrameStreak = 0
    recoveryPending = false
    return level
  }
}
