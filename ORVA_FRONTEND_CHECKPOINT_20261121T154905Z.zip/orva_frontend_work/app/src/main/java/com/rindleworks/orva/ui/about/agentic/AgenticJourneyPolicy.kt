package com.rindleworks.orva.ui.about.agentic

import kotlin.math.abs

/** Scroll ownership is independent from the kind of layer work agents perform. */
enum class ScrollOwner { AUTO, MANUAL }

enum class AgentActivity { BUILD, REWIND, IDLE }

enum class ManualScrollDirection { DOWN, UP }

data class JourneyDirectionChange(
  val direction: ManualScrollDirection,
  val previousActivity: AgentActivity,
  val nextActivity: AgentActivity,
)

/**
 * Small deterministic policy for the About journey. It never moves the viewport; it only
 * classifies manual ScrollState deltas and enforces the legal ownership/activity combinations.
 * Positive ScrollState deltas mean the reader moved down the document.
 */
class AgenticJourneyPolicy(
  private val directionThresholdPx: Float = 18f,
) {
  var scrollOwner: ScrollOwner = ScrollOwner.AUTO
    private set

  var activity: AgentActivity = AgentActivity.BUILD
    private set

  private var accumulatedDeltaPx = 0f
  private var previousDeltaSign = 0

  fun onManualVerticalGesture() {
    scrollOwner = ScrollOwner.MANUAL
    accumulatedDeltaPx = 0f
    previousDeltaSign = 0
    if (activity == AgentActivity.REWIND) activity = AgentActivity.IDLE
  }

  fun enableTour() {
    // AUTO + REWIND is intentionally not a valid state.
    scrollOwner = ScrollOwner.AUTO
    activity = AgentActivity.BUILD
    accumulatedDeltaPx = 0f
    previousDeltaSign = 0
  }

  fun disableTour() {
    scrollOwner = ScrollOwner.MANUAL
    if (activity == AgentActivity.REWIND) activity = AgentActivity.IDLE
    accumulatedDeltaPx = 0f
    previousDeltaSign = 0
  }

  fun observeManualScrollDelta(deltaPx: Float): JourneyDirectionChange? {
    if (scrollOwner != ScrollOwner.MANUAL || !deltaPx.isFinite() || abs(deltaPx) < 0.5f) return null
    val sign = if (deltaPx > 0f) 1 else -1
    if (previousDeltaSign != 0 && sign != previousDeltaSign) accumulatedDeltaPx = 0f
    previousDeltaSign = sign
    accumulatedDeltaPx += deltaPx
    if (abs(accumulatedDeltaPx) < directionThresholdPx) return null

    val direction = if (accumulatedDeltaPx > 0f) ManualScrollDirection.DOWN else ManualScrollDirection.UP
    accumulatedDeltaPx = 0f
    val next = if (direction == ManualScrollDirection.UP) AgentActivity.REWIND else AgentActivity.BUILD
    val previous = activity
    if (previous == next) return null
    activity = next
    return JourneyDirectionChange(direction, previous, next)
  }

  fun markIdle() {
    if (scrollOwner == ScrollOwner.MANUAL) {
      activity = AgentActivity.IDLE
      accumulatedDeltaPx = 0f
      previousDeltaSign = 0
    }
  }

  fun markBuild() {
    activity = AgentActivity.BUILD
  }

  fun markRewind() {
    // REWIND is only legal while the user owns the scroll position.
    if (scrollOwner == ScrollOwner.MANUAL) activity = AgentActivity.REWIND
  }

  fun resetForReplay() {
    scrollOwner = ScrollOwner.AUTO
    activity = AgentActivity.BUILD
    accumulatedDeltaPx = 0f
    previousDeltaSign = 0
  }
}
