package com.rindleworks.orva.service.subscription

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.io.File
import java.io.FileOutputStream
import java.security.KeyFactory
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.MessageDigest
import java.security.PrivateKey
import java.security.PublicKey
import java.security.SecureRandom
import java.security.Signature
import java.security.spec.ECGenParameterSpec
import java.security.spec.X509EncodedKeySpec
import java.util.Locale
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

/**
 * Plaintext payload stored encrypted + authenticated inside `ORVA/license.orvalic`.
 */
@Serializable
data class SealedLicensePayload(
  val username: String,
  val plan: String,
  val startDateRaw: String,
  val expiryDateRaw: String,
  val status: String,
  val activationCodeSha256: String,
  val vendorSignatureBase64: String? = null,
  val deviceInstallId: String,
  val verifiedAtUtc: String,
  val lastSeenUtc: String,
  val lastSeenElapsedMs: Long? = null,
)

data class SealedLicenseWriteResult(
  val file: File,
  val envelopeSha256: String,
)

@Serializable
internal data class OrvaSealedLicenseEnvelope(
  @SerialName("Format") val format: String = OrvaLicenseVault.ENVELOPE_FORMAT,
  @SerialName("Version") val version: Int = OrvaLicenseVault.ENVELOPE_VERSION,
  @SerialName("KeyAlias") val keyAlias: String = OrvaLicenseVault.KEYSTORE_ALIAS,
  @SerialName("IvBase64") val ivBase64: String,
  @SerialName("CiphertextBase64") val ciphertextBase64: String,
)

sealed interface LicenseVaultReadResult {
  /** No licence has ever been sealed on this device (fresh / unconfigured install). */
  data object NotPresent : LicenseVaultReadResult

  /** Sealed licence file decrypted, authenticated, and matched internal anti-delete anchor. */
  data class Valid(val payload: SealedLicensePayload) : LicenseVaultReadResult

  /** An activation anchor exists, proving `ORVA/license.orvalic` was deleted or moved. */
  data class MissingAfterActivation(val expectedUsername: String) : LicenseVaultReadResult

  /** File bytes were edited, corrupted, copied from another device, or failed signature/anchor check. */
  data class Tampered(val reason: String) : LicenseVaultReadResult
}

/**
 * Pluggable AES-256-GCM cipher engine backed by hardware `AndroidKeyStore` in production
 * and deterministic JVM keys in Robolectric unit tests.
 */
interface LicenseCipherEngine {
  val keyAlias: String
  fun encrypt(plaintext: ByteArray, aad: ByteArray): Pair<ByteArray, ByteArray>
  fun decrypt(iv: ByteArray, ciphertext: ByteArray, aad: ByteArray): ByteArray
}

/**
 * Hardware-backed AndroidKeyStore AES-256-GCM engine (TEE/StrongBox on Android devices).
 * The secret key is non-exportable and bound to this device's hardware keystore.
 */
class AndroidKeyStoreCipherEngine(
  override val keyAlias: String = OrvaLicenseVault.KEYSTORE_ALIAS,
) : LicenseCipherEngine {

  private fun getOrCreateKey(): SecretKey {
    val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
    val existing = ks.getKey(keyAlias, null) as? SecretKey
    if (existing != null) return existing

    val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
    val spec =
      KeyGenParameterSpec.Builder(
        keyAlias,
        KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT,
      )
        .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
        .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
        .setKeySize(256)
        .setRandomizedEncryptionRequired(true)
        .build()
    generator.init(spec)
    return generator.generateKey()
  }

  override fun encrypt(plaintext: ByteArray, aad: ByteArray): Pair<ByteArray, ByteArray> {
    val cipher = Cipher.getInstance("AES/GCM/NoPadding")
    cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
    cipher.updateAAD(aad)
    val ciphertext = cipher.doFinal(plaintext)
    return cipher.iv to ciphertext
  }

  override fun decrypt(iv: ByteArray, ciphertext: ByteArray, aad: ByteArray): ByteArray {
    val cipher = Cipher.getInstance("AES/GCM/NoPadding")
    cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), GCMParameterSpec(128, iv))
    cipher.updateAAD(aad)
    return cipher.doFinal(ciphertext)
  }
}

/**
 * Software AES-256-GCM fallback used automatically only if `AndroidKeyStore` is unavailable
 * (e.g., Robolectric JVM tests), or injected directly in unit tests to simulate cross-device key mismatch.
 */
class SoftwareAesGcmCipherEngine(
  private val rawKey32Bytes: ByteArray,
  override val keyAlias: String = "orva_software_aes256_gcm_v1",
) : LicenseCipherEngine {

  private val random = SecureRandom()
  private val secretKey = SecretKeySpec(rawKey32Bytes.copyOf(32), "AES")

  override fun encrypt(plaintext: ByteArray, aad: ByteArray): Pair<ByteArray, ByteArray> {
    val iv = ByteArray(12).also { random.nextBytes(it) }
    val cipher = Cipher.getInstance("AES/GCM/NoPadding")
    cipher.init(Cipher.ENCRYPT_MODE, secretKey, GCMParameterSpec(128, iv))
    cipher.updateAAD(aad)
    return iv to cipher.doFinal(plaintext)
  }

  override fun decrypt(iv: ByteArray, ciphertext: ByteArray, aad: ByteArray): ByteArray {
    val cipher = Cipher.getInstance("AES/GCM/NoPadding")
    cipher.init(Cipher.DECRYPT_MODE, secretKey, GCMParameterSpec(128, iv))
    cipher.updateAAD(aad)
    return cipher.doFinal(ciphertext)
  }
}

/**
 * Optional asymmetric vendor signature verifier (ECDSA P-256 / SHA256withECDSA) for `licenses.csv`.
 *
 * When Rindle Works configures [publicKeySpkiBase64], every CSV row and sealed local licence MUST
 * carry a valid ECDSA signature generated by Rindle Works' offline private key over:
 *   `username|plan|startDate|expiryDate|status|activationCodeSha256`
 *
 * When [publicKeySpkiBase64] is null/blank, verification stays backward-compatible with existing
 * 6-column WPF `licenses.csv` files while hardware Keystore AES-256-GCM still blocks all local tampering.
 */
class VendorSignatureVerifier(
  publicKeySpkiBase64: String? = null,
) {
  val isEnforced: Boolean = !publicKeySpkiBase64.isNullOrBlank()

  private val publicKey: PublicKey? =
    publicKeySpkiBase64?.trim()?.takeIf { it.isNotEmpty() }?.let { b64 ->
      val der = Base64.decode(b64, Base64.DEFAULT)
      KeyFactory.getInstance("EC").generatePublic(X509EncodedKeySpec(der))
    }

  fun verifyRowSignature(
    username: String,
    plan: String,
    startDateRaw: String,
    expiryDateRaw: String,
    status: String,
    activationCodeSha256: String,
    signatureBase64: String?,
  ): Boolean {
    val key = publicKey ?: return true
    val cleanSig = signatureBase64?.trim().orEmpty()
    if (cleanSig.isEmpty()) return false
    return runCatching {
      val sigBytes = Base64.decode(cleanSig, Base64.DEFAULT)
      val verifier = Signature.getInstance("SHA256withECDSA")
      verifier.initVerify(key)
      verifier.update(
        canonicalMessage(username, plan, startDateRaw, expiryDateRaw, status, activationCodeSha256)
          .toByteArray(Charsets.UTF_8)
      )
      verifier.verify(sigBytes)
    }.getOrDefault(false)
  }

  companion object {
    fun canonicalMessage(
      username: String,
      plan: String,
      startDateRaw: String,
      expiryDateRaw: String,
      status: String,
      activationCodeSha256: String,
    ): String =
      listOf(
        username.trim().lowercase(Locale.ROOT),
        plan.trim(),
        startDateRaw.trim(),
        expiryDateRaw.trim(),
        status.trim().lowercase(Locale.ROOT),
        activationCodeSha256.trim().lowercase(Locale.ROOT),
      ).joinToString("|")

    /** Generates a fresh ECDSA P-256 key pair for Rindle Works offline licence CSV signing. */
    fun generateP256KeyPair(): KeyPair {
      val gen = KeyPairGenerator.getInstance("EC")
      gen.initialize(ECGenParameterSpec("secp256r1"), SecureRandom())
      return gen.generateKeyPair()
    }

    /** Signs a canonical licence CSV row with Rindle Works' private key (Base64 DER signature). */
    fun signRow(
      privateKey: PrivateKey,
      username: String,
      plan: String,
      startDateRaw: String,
      expiryDateRaw: String,
      status: String,
      activationCodeSha256: String,
    ): String {
      val signer = Signature.getInstance("SHA256withECDSA")
      signer.initSign(privateKey)
      signer.update(
        canonicalMessage(username, plan, startDateRaw, expiryDateRaw, status, activationCodeSha256)
          .toByteArray(Charsets.UTF_8)
      )
      return Base64.encodeToString(signer.sign(), Base64.NO_WRAP)
    }

    fun encodePublicKeySpkiBase64(publicKey: PublicKey): String =
      Base64.encodeToString(publicKey.encoded, Base64.NO_WRAP)
  }
}

/**
 * Hardware-Keystore-sealed local licence store saved inside the auto-created `ORVA/license.orvalic`
 * file, paired with an app-private anti-delete anchor (`filesDir/orva/.license_anchor`).
 *
 * Security guarantees:
 * 1. Editing even 1 byte of `ORVA/license.orvalic` fails AES-256-GCM authentication (`Tampered`).
 * 2. Copying `ORVA/license.orvalic` to another phone fails both Keystore key & `deviceInstallId` AAD (`Tampered`).
 * 3. Deleting `ORVA/license.orvalic` after activation is detected by `.license_anchor` (`MissingAfterActivation`).
 * 4. Optional ECDSA P-256 vendor signature prevents forgery even on rooted/decompiled environments.
 */
class OrvaLicenseVault(
  private val licenseFileProvider: () -> File,
  private val anchorFile: File,
  private val deviceInstallIdProvider: () -> String,
  cipherEngine: LicenseCipherEngine? = null,
  val vendorSignatureVerifier: VendorSignatureVerifier = VendorSignatureVerifier(),
  private val fallbackLicenseFileProvider: (() -> File)? = null,
) {
  companion object {
    const val ENVELOPE_FORMAT = "ORVA_LICENSE_V1"
    const val ENVELOPE_VERSION = 1
    const val KEYSTORE_ALIAS = "orva_license_aes256_gcm_v1"

    private fun createDefaultCipherEngine(deviceInstallIdProvider: () -> String): LicenseCipherEngine {
      val hwEngine = AndroidKeyStoreCipherEngine(KEYSTORE_ALIAS)
      return try {
        // Probe AndroidKeyStore availability (succeeds on real Android devices; throws in Robolectric JVM).
        val probeKs = KeyStore.getInstance("AndroidKeyStore")
        probeKs.load(null)
        hwEngine
      } catch (_: Throwable) {
        val derived =
          MessageDigest.getInstance("SHA-256")
            .digest(("ORVA_LOCAL_FALLBACK|" + deviceInstallIdProvider()).toByteArray(Charsets.UTF_8))
        SoftwareAesGcmCipherEngine(derived)
      }
    }
  }

  private val cipher: LicenseCipherEngine =
    cipherEngine ?: createDefaultCipherEngine(deviceInstallIdProvider)

  private val json = Json {
    encodeDefaults = true
    ignoreUnknownKeys = true
    prettyPrint = false
  }

  fun licenseFile(): File = licenseFileProvider()

  fun hasAnchor(): Boolean = anchorFile.exists() && anchorFile.length() > 0L

  /**
   * Atomically writes the hardware-sealed `ORVA/license.orvalic` (auto-creating `ORVA/` on first write),
   * updates the app-private anti-delete anchor, and returns the envelope file + SHA-256 digest so
   * callers can mirror the anchor digest inside SQLite `app_setting`.
   */
  @Synchronized
  fun sealAndSaveWithAnchor(payload: SealedLicensePayload): SealedLicenseWriteResult {
    val deviceId = deviceInstallIdProvider()
    val boundPayload = payload.copy(deviceInstallId = deviceId)
    val plaintext = json.encodeToString(boundPayload).toByteArray(Charsets.UTF_8)
    val aad = buildAad(deviceId, boundPayload.username)

    val (iv, ciphertext) = cipher.encrypt(plaintext, aad)
    val envelope =
      OrvaSealedLicenseEnvelope(
        format = ENVELOPE_FORMAT,
        version = ENVELOPE_VERSION,
        keyAlias = cipher.keyAlias,
        ivBase64 = Base64.encodeToString(iv, Base64.NO_WRAP),
        ciphertextBase64 = Base64.encodeToString(ciphertext, Base64.NO_WRAP),
      )
    val envelopeBytes = json.encodeToString(envelope).toByteArray(Charsets.UTF_8)
    val envelopeDigest = sha256Hex(envelopeBytes)

    val targetFile = licenseFileProvider()
    targetFile.parentFile?.mkdirs()
    val tmpFile = File(targetFile.parentFile, "${targetFile.name}.tmp")
    try {
      FileOutputStream(tmpFile).use { fos ->
        fos.write(envelopeBytes)
        fos.flush()
        runCatching { fos.fd.sync() }
      }
      if (!tmpFile.renameTo(targetFile)) {
        tmpFile.copyTo(targetFile, overwrite = true)
        tmpFile.delete()
      }
    } finally {
      if (tmpFile.exists()) tmpFile.delete()
    }

    // Remove any superseded fallback copy at a different path so only one active licence file exists.
    val fallbackFile = fallbackLicenseFileProvider?.invoke()
    if (fallbackFile != null &&
      fallbackFile.absolutePath != targetFile.absolutePath &&
      fallbackFile.exists()
    ) {
      runCatching { fallbackFile.delete() }
    }

    writeAnchor(boundPayload.username, envelopeDigest)
    return SealedLicenseWriteResult(file = targetFile, envelopeSha256 = envelopeDigest)
  }

  /**
   * Atomically writes the hardware-sealed `ORVA/license.orvalic` (auto-creating `ORVA/` on first write)
   * and updates the app-private anti-delete anchor.
   */
  @Synchronized
  fun sealAndSave(payload: SealedLicensePayload): File = sealAndSaveWithAnchor(payload).file

  /**
   * Reads, decrypts, and authenticates `ORVA/license.orvalic`, cross-checking:
   * - dual anti-delete / anti-swap anchors (app-private `.license_anchor` AND SQLite `externalAnchorSha256`),
   * - envelope format & version,
   * - AES-256-GCM auth tag & device+username AAD,
   * - `deviceInstallId` binding, and
   * - optional ECDSA P-256 vendor signature.
   */
  @Synchronized
  fun readAndVerify(
    expectedUsername: String?,
    externalAnchorSha256: String? = null,
  ): LicenseVaultReadResult {
    val targetFile = licenseFileProvider()
    val anchor = readAnchor()
    val cleanExternalAnchor = externalAnchorSha256?.trim()?.takeIf { it.isNotEmpty() }
    val hasAnyAnchor = anchor != null || cleanExternalAnchor != null

    if (!targetFile.exists()) {
      // Seamless one-time migration if user granted All Files Access after activating in fallback storage.
      val fallbackFile = fallbackLicenseFileProvider?.invoke()
      if (hasAnyAnchor &&
        fallbackFile != null &&
        fallbackFile.absolutePath != targetFile.absolutePath &&
        fallbackFile.exists()
      ) {
        val fallbackBytes = runCatching { fallbackFile.readBytes() }.getOrNull()
        val fallbackDigest = fallbackBytes?.let { sha256Hex(it) }
        val matchesAnchor =
          fallbackDigest != null &&
            (anchor == null || fallbackDigest.equals(anchor.envelopeSha256, ignoreCase = true)) &&
            (cleanExternalAnchor == null || fallbackDigest.equals(cleanExternalAnchor, ignoreCase = true))
        if (matchesAnchor && fallbackBytes != null) {
          runCatching {
            targetFile.parentFile?.mkdirs()
            val tmp = File(targetFile.parentFile, "${targetFile.name}.tmp")
            FileOutputStream(tmp).use { fos ->
              fos.write(fallbackBytes)
              fos.flush()
              runCatching { fos.fd.sync() }
            }
            if (!tmp.renameTo(targetFile)) {
              tmp.copyTo(targetFile, overwrite = true)
              tmp.delete()
            }
            fallbackFile.delete()
          }
        }
      }
      if (!targetFile.exists()) {
        return if (hasAnyAnchor) {
          LicenseVaultReadResult.MissingAfterActivation(
            anchor?.username ?: expectedUsername?.trim().orEmpty()
          )
        } else {
          LicenseVaultReadResult.NotPresent
        }
      }
    }

    val rawBytes =
      try {
        targetFile.readBytes()
      } catch (ex: Exception) {
        return LicenseVaultReadResult.Tampered("Unable to read licence file: ${ex.message}")
      }

    // Verify BOTH internal `.license_anchor` AND SQLite anchor digest (blocks file edits, swaps, and replay).
    val actualDigest = sha256Hex(rawBytes)
    if (anchor != null && !actualDigest.equals(anchor.envelopeSha256, ignoreCase = true)) {
      return LicenseVaultReadResult.Tampered(
        "Licence file digest does not match this device's sealed activation record."
      )
    }
    if (cleanExternalAnchor != null && !actualDigest.equals(cleanExternalAnchor, ignoreCase = true)) {
      return LicenseVaultReadResult.Tampered(
        "Licence file digest does not match SQLite activation anchor."
      )
    }

    val envelope =
      try {
        json.decodeFromString<OrvaSealedLicenseEnvelope>(String(rawBytes, Charsets.UTF_8))
      } catch (_: Exception) {
        return LicenseVaultReadResult.Tampered("Licence file format is corrupted or modified.")
      }

    if (envelope.format != ENVELOPE_FORMAT || envelope.version != ENVELOPE_VERSION) {
      return LicenseVaultReadResult.Tampered("Unsupported or modified licence file format.")
    }

    val candidateUsername =
      expectedUsername?.trim()?.takeIf { it.isNotEmpty() }
        ?: anchor?.username
        ?: return LicenseVaultReadResult.Tampered("Licence username binding is missing.")

    val deviceId = deviceInstallIdProvider()
    val aad = buildAad(deviceId, candidateUsername)

    val payload =
      try {
        val iv = Base64.decode(envelope.ivBase64, Base64.DEFAULT)
        val ciphertext = Base64.decode(envelope.ciphertextBase64, Base64.DEFAULT)
        val plaintext = cipher.decrypt(iv, ciphertext, aad)
        json.decodeFromString<SealedLicensePayload>(String(plaintext, Charsets.UTF_8))
      } catch (_: Exception) {
        return LicenseVaultReadResult.Tampered(
          "Licence file authentication failed (edited or copied from another device)."
        )
      }

    if (payload.deviceInstallId != deviceId) {
      return LicenseVaultReadResult.Tampered("Licence file belongs to a different device installation.")
    }
    if (!payload.username.equals(candidateUsername, ignoreCase = true)) {
      return LicenseVaultReadResult.Tampered("Licence file username does not match this account.")
    }

    if (vendorSignatureVerifier.isEnforced) {
      val sigOk =
        vendorSignatureVerifier.verifyRowSignature(
          username = payload.username,
          plan = payload.plan,
          startDateRaw = payload.startDateRaw,
          expiryDateRaw = payload.expiryDateRaw,
          status = payload.status,
          activationCodeSha256 = payload.activationCodeSha256,
          signatureBase64 = payload.vendorSignatureBase64,
        )
      if (!sigOk) {
        return LicenseVaultReadResult.Tampered("Vendor licence signature verification failed.")
      }
    }

    return LicenseVaultReadResult.Valid(payload)
  }

  private fun buildAad(deviceInstallId: String, username: String): ByteArray =
    "$ENVELOPE_FORMAT|$deviceInstallId|${username.trim().lowercase(Locale.ROOT)}"
      .toByteArray(Charsets.UTF_8)

  private fun writeAnchor(username: String, envelopeSha256: String) {
    anchorFile.parentFile?.mkdirs()
    val line = "${username.trim()}|$envelopeSha256"
    val tmp = File(anchorFile.parentFile, "${anchorFile.name}.tmp")
    try {
      FileOutputStream(tmp).use { fos ->
        fos.write(line.toByteArray(Charsets.UTF_8))
        fos.flush()
        runCatching { fos.fd.sync() }
      }
      if (!tmp.renameTo(anchorFile)) {
        tmp.copyTo(anchorFile, overwrite = true)
        tmp.delete()
      }
    } finally {
      if (tmp.exists()) tmp.delete()
    }
  }

  private fun readAnchor(): AnchorRecord? {
    if (!anchorFile.exists()) return null
    val text = runCatching { anchorFile.readText(Charsets.UTF_8).trim() }.getOrDefault("")
    val sep = text.lastIndexOf('|')
    if (sep <= 0 || sep >= text.lastIndex) return null
    return AnchorRecord(
      username = text.substring(0, sep),
      envelopeSha256 = text.substring(sep + 1),
    )
  }

  private fun sha256Hex(bytes: ByteArray): String =
    MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }

  private data class AnchorRecord(val username: String, val envelopeSha256: String)
}
