package com.rindleworks.orva.ui.showcase

import com.rindleworks.orva.R
import com.rindleworks.orva.domain.settings.AppLanguage

enum class ReadinessBackupState {
  Saved,
  DueToday,
  NotYetBackedUp,
}

data class FolderCopy(
  val id: String,
  val tabLabel: String,
  val title: String,
  val actionLabel: String,
  val body: String,
  val sheets: List<String>,
)

data class PrincipleCopy(
  val number: String,
  val title: String,
  val description: String,
)

data class OrvaCaseRailItem(
  val code: String,
  val index: String,
  val title: String,
  val summary: String,
  val tags: List<String>,
  /** Local editorial artwork for the case-study cover; never a claimed product screenshot. */
  val imageResId: Int,
)

/**
 * Authoritative bilingual (English / Bengali) display copy implementing
 * `RINDLE_WORKS_ORVA_FRONTEND_MASTER_DIRECTIVE.md` (§3 & §4).
 *
 * Guardrails enforced:
 * - Zero hardcoded fallback phone numbers or emails.
 * - Zero invented founding year, team bio, office address, customer counts, awards, or fake projects.
 * - Honest development status: ORVA Android edition is in active development.
 * - Preserves Rindle Works as studio identity and ORVA as flagship product.
 */
object OrvaShowcaseCopy {
  fun toBengaliDigits(value: Int): String = toBengaliDigits(value.toString())

  fun toBengaliDigits(raw: String): String {
    val map = charArrayOf('০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯')
    return buildString(raw.length) {
      for (ch in raw) {
        if (ch in '0'..'9') append(map[ch - '0']) else append(ch)
      }
    }
  }

  fun backupStatusLabel(state: ReadinessBackupState, language: AppLanguage): String =
    when (language) {
      AppLanguage.English ->
        when (state) {
          ReadinessBackupState.Saved -> "Saved"
          ReadinessBackupState.DueToday -> "Due today"
          ReadinessBackupState.NotYetBackedUp -> "Not yet backed up"
        }
      AppLanguage.Bengali ->
        when (state) {
          ReadinessBackupState.Saved -> "সুরক্ষিত"
          ReadinessBackupState.DueToday -> "বকেয়া"
          ReadinessBackupState.NotYetBackedUp -> "এখনো ব্যাকআপ হয়নি"
        }
    }

  // ---- Home H1 (Master Directive §3.1) ----
  fun homeEyebrow(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "RINDLE WORKS — উদ্দেশ্যমূলক সফটওয়্যার"
    else "RINDLE WORKS — SOFTWARE, WITH INTENTION"

  fun homeHeroSectionIndex(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "০১ / ০৫" else "01 / 05"

  fun homeFoldersSectionPrefix(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "০৫ / " else "05 / "

  fun folderExpandedState(expanded: Boolean, language: AppLanguage): String =
    when (language) {
      AppLanguage.English -> if (expanded) "Details expanded" else "Details collapsed"
      AppLanguage.Bengali -> if (expanded) "বিস্তারিত খোলা হয়েছে" else "বিস্তারিত বন্ধ রয়েছে"
    }

  fun homeHeadlineTop(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "কাজের ছন্দেই" else "BUILT AROUND"

  fun homeHeadlineItalic(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "তৈরি।" else "THE WORK."

  fun homeSubtitle(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) {
      "গুরুত্বপূর্ণ কাজ, সিদ্ধান্ত ও খুঁটিনাটির জন্য যত্নশীল সফটওয়্যার।"
    } else {
      "Thoughtful software for the tasks, decisions and details that matter."
    }

  fun startBillingCta(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "ORVA দেখুন →" else "EXPLORE ORVA →"

  fun studioSecondaryCta(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "স্টুডিও পরিচিতি" else "THE STUDIO"

  fun addStockCta(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "+ স্টক যোগ" else "+ ADD STOCK"

  fun readinessStrip(
    shopName: String,
    usableMedicines: Int,
    expiringSoonCount: Int,
    backupState: ReadinessBackupState,
    language: AppLanguage,
  ): String {
    val backupText = backupStatusLabel(backupState, language)
    return if (language == AppLanguage.Bengali) {
      "$shopName · ${toBengaliDigits(usableMedicines)}টি ওষুধ প্রস্তুত · ৩০ দিনের মধ্যে মেয়াদ শেষ: ${toBengaliDigits(expiringSoonCount)} · ব্যাকআপ: $backupText"
    } else {
      "$shopName · $usableMedicines medicines ready · $expiringSoonCount expiring within 30 days · Backup: $backupText"
    }
  }

  fun lanternHint(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "আলো ফেলতে স্পর্শ করে টানুন" else "TOUCH & DRAG TO ILLUMINATE"

  fun lanternEyebrow(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "০২ / আলোর অধ্যয়ন" else "02 / ILLUMINATION STUDY"

  fun lanternImageDescription(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) {
      "ফার্মেসির কাচের তাক ও সাজানো পণ্যের একরঙা দৃশ্য"
    } else {
      "Monochrome apothecary glass shelving"
    }

  fun lanternCaption(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "ঔষধালয় / বিস্তারিত ০১" else "APOTHECARY / DETAIL 01"

  fun precisionEyebrow(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "০৩ / নির্ভুলতা" else "03 / PRECISION"

  fun precisionImageDescription(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) {
      "থার্মাল কাগজের রোল ও ধাতব যন্ত্রাংশের কাছের দৃশ্য"
    } else {
      "Macro detail of thermal counter paper roll and aluminum hardware"
    }

  fun flagshipCaseCode(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "কেস / ০০১" else "CASE / 001"

  fun flagshipStudyLabel(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "RINDLE WORKS / পণ্য-সমীক্ষা" else "RINDLE WORKS / PRODUCT STUDY"

  // ---- Home H2/H3 (Cinematic Image/Typography & Flagship ORVA §3.3–3.4) ----
  fun homeIdentityLeftLine1(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "পরিষ্কার বিল।" else "CLEAR BILLS."

  fun homeIdentityLeftLine2(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "সতর্ক স্টক।" else "CAREFUL STOCK."

  fun flagshipEyebrow(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "প্রধান পণ্য / ০১" else "FLAGSHIP PRODUCT / 01"

  fun flagshipDescriptor(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "ফার্মেসি বিলিং ও ইনভেন্টরি" else "PHARMACY BILLING & INVENTORY"

  fun flagshipBody(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) {
      "ফার্মেসির প্রতিদিনের বাস্তব কাজের জন্য একটি নিবিড় পণ্য: বিলিং, ব্যাচ-ভিত্তিক স্টক, মেয়াদ তদারকি এবং নির্ভরযোগ্য রেকর্ড।"
    } else {
      "A focused product for the daily reality of pharmacy work: billing, batch-aware stock, expiry visibility and dependable records."
    }

  fun flagshipStateLabel(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "সক্রিয় নির্মাণে" else "IN ACTIVE DEVELOPMENT"

  fun flagshipAction(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "পণ্যটি দেখুন →" else "EXPLORE THE PRODUCT →"

  // ---- Home H5 (Three Physical Layered Panels §3.5: PRODUCT / CRAFT / ENGINEERING) ----
  fun folderSectionHeading(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "তিনটি স্তম্ভ।" else "THREE PILLARS OF THE WORK."

  fun workspaceFolders(
    expiringSoonCount: Int,
    appVersion: String,
    language: AppLanguage,
  ): List<FolderCopy> =
    if (language == AppLanguage.Bengali) {
      listOf(
        FolderCopy(
          id = "quick_billing",
          tabLabel = "০১ · PRODUCT",
          title = "PRODUCT",
          actionLabel = "কাউন্টার বিলিং খুলুন →",
          body = "দ্রুত বিলিং, ব্যাচ বাছাই এবং পরিষ্কার গ্রাহক রসিদ—সবকিছু স্থানীয়ভাবে।",
          sheets =
            listOf(
              "দ্রুত কাউন্টার বিলিং ও রসিদ",
              "ব্যাচ ও মেয়াদ সুরক্ষা",
              "৩০ দিনের মধ্যে মেয়াদ শেষ: ${toBengaliDigits(expiringSoonCount)}",
            ),
        ),
        FolderCopy(
          id = "expiry_stock",
          tabLabel = "০২ · CRAFT",
          title = "CRAFT",
          actionLabel = "ইনভেন্টরি দেখুন →",
          body = "কম ঘর্ষণ, স্পষ্ট সিদ্ধান্ত এবং প্রতিদিনের কাজের জন্য শান্ত ইন্টারফেস।",
          sheets =
            listOf(
              "অপ্রয়োজনীয় জটিলতাহীন বিন্যাস",
              "স্পষ্ট অগ্রাধিকার ও পরবর্তী ধাপ",
              "বাংলা ও ইংরেজি উভয় ভাষায় স্পষ্টতা",
            ),
        ),
        FolderCopy(
          id = "about_orva",
          tabLabel = "০৩ · ENGINEERING",
          title = "ENGINEERING",
          actionLabel = "স্টুডিও পোর্টফোলিও পড়ুন →",
          body = "পূর্ণ পয়সার হিসাব, আগে মেয়াদ শেষ হওয়া ব্যাচ বাছাই ও স্থানীয় ব্যাকআপ।",
          sheets =
            listOf(
              "Rindle Works · ORVA v$appVersion",
              "অ্যাটমিক ইনভয়েস ও স্টক লেনদেন",
              "স্থানীয় স্টোরেজ ও ব্যাকআপ নিয়ন্ত্রণ",
            ),
        ),
      )
    } else {
      listOf(
        FolderCopy(
          id = "quick_billing",
          tabLabel = "01 · PRODUCT",
          title = "PRODUCT",
          actionLabel = "OPEN COUNTER BILLING →",
          body = "Fast billing, batch-aware stock and clear receipts—kept local on your device.",
          sheets =
            listOf(
              "Counter Billing & GST Receipts",
              "Batch & Expiry Visibility",
              "$expiringSoonCount Expiring ≤ 30 Days",
            ),
        ),
        FolderCopy(
          id = "expiry_stock",
          tabLabel = "02 · CRAFT",
          title = "CRAFT",
          actionLabel = "INSPECT INVENTORY →",
          body = "Less friction, clearer decisions and calm interfaces built for ordinary days.",
          sheets =
            listOf(
              "Every Element Earns Its Place",
              "Readable Under Counter Pressure",
              "English & Bengali Native Clarity",
            ),
        ),
        FolderCopy(
          id = "about_orva",
          tabLabel = "03 · ENGINEERING",
          title = "ENGINEERING",
          actionLabel = "ENTER THE STUDIO →",
          body = "Integer-paise math, earliest-expiry allocation and local-first dependability.",
          sheets =
            listOf(
              "Rindle Works · ORVA v$appVersion",
              "Atomic Invoice & Stock Ledger",
              "Local-First Backup & Recovery",
            ),
        ),
      )
    }

  // ---- Shared Closing / Footer ----
  fun closingLine(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "উদ্দেশ্যমূলক সফটওয়্যার।" else "Software, with intention."

  fun linkStartBilling(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "ORVA দেখুন" else "Explore ORVA"

  fun linkAboutUs(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "স্টুডিও পরিচিতি" else "The Studio"

  fun linkBackToHome(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "হোমে ফিরে যান" else "Back to Home"

  fun linkBackToTop(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "উপরে যান ↑" else "Back to top ↑"

  // ---- About Us 9-Scene Portfolio (Master Directive §4.1) ----
  fun aboutMetaLeft(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "RINDLE WORKS / স্টুডিও" else "RINDLE WORKS / THE STUDIO"

  fun aboutHeroSceneIndex(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "দৃশ্য ০১ / ০৯" else "SCENE 01 / 09"

  fun aboutHeroArtworkDescription(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) {
      "ধারণামূলক একরঙা স্টুডিও ওয়ার্কবেঞ্চের চিত্র"
    } else {
      "Conceptual monochrome studio workbench artwork"
    }

  fun aboutHeroVersionLabel(version: String, language: AppLanguage): String =
    if (language == AppLanguage.Bengali) {
      "RINDLE WORKS · সংস্করণ V${toBengaliDigits(version)}"
    } else {
      "RINDLE WORKS · V$version"
    }

  fun aboutPovImageDescription(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) {
      "ধারণামূলক একরঙা ঔষধালয়ের কাচের তাকের চিত্র"
    } else {
      "Conceptual monochrome apothecary glass-shelving artwork"
    }

  fun aboutPovFigureCaption(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "চিত্র ০১ — কাজের প্রেক্ষাপট" else "FIG. 01 — WORKING CONTEXT"

  fun aboutMarqueePrimary(language: AppLanguage): String {
    val cycle =
      if (language == AppLanguage.Bengali) {
        "স্থানীয়-প্রথম · পূর্ণ পয়সার হিসাব · FEFO বরাদ্দ · অ্যাটমিক লেজার · GST প্রস্তুত · অফলাইন SQLite · "
      } else {
        "LOCAL-FIRST · INTEGER PAISE · FEFO ALLOCATION · ATOMIC LEDGER · GST READY · OFFLINE SQLITE · "
      }
    return cycle + cycle
  }

  fun aboutMarqueeSecondary(language: AppLanguage): String {
    val cycle =
      if (language == AppLanguage.Bengali) {
        "RINDLE WORKS · ORVA · ব্যাচ সুরক্ষা · বহনযোগ্য ব্যাকআপ · Compose নেটিভ · ক্লাউড-নির্ভরতা নেই · "
      } else {
        "RINDLE WORKS · ORVA · BATCH SAFETY · PORTABLE BACKUPS · COMPOSE NATIVE · ZERO CLOUD LOCK-IN · "
      }
    return cycle + cycle
  }

  fun philosophyBackdrop(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "ভাবনা" else "INTENTION"

  fun philosophyEyebrow(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "০৩ / দর্শন" else "03 / PHILOSOPHY"

  fun principleProgress(index: Int, total: Int, language: AppLanguage): String =
    if (language == AppLanguage.Bengali) {
      "${toBengaliDigits(index.toString().padStart(2, '0'))} / ${toBengaliDigits(total.toString().padStart(2, '0'))}"
    } else {
      "${index.toString().padStart(2, '0')} / ${total.toString().padStart(2, '0')}"
    }

  fun principleLabel(number: String, language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "(${number}) মূলনীতি" else "($number) PRINCIPLE"

  fun commitmentRowIndex(index: Int, language: AppLanguage): String =
    if (language == AppLanguage.Bengali) toBengaliDigits(index.toString().padStart(2, '0'))
    else index.toString().padStart(2, '0')

  fun caseCardCode(code: String, language: AppLanguage): String =
    if (language == AppLanguage.Bengali && code.startsWith("ORVA_")) {
      "ORVA_${toBengaliDigits(code.substringAfterLast('_'))}"
    } else {
      code
    }

  fun caseCardDisplayIndex(index: String, language: AppLanguage): String =
    if (language == AppLanguage.Bengali) toBengaliDigits(index) else index

  fun aboutHeadline(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "কাজের পরিধি পর্দার চেয়েও বড়।" else "THE WORK DOESN'T FIT IN A SCREEN."

  fun aboutLead(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) {
      "দৃশ্যমান কাজের আড়ালে থাকে হস্তান্তর, ব্যতিক্রম, নথি আর পরের সিদ্ধান্ত—আমাদের নকশা সেখানেও পৌঁছায়।"
    } else {
      "We build for everything behind the visible task: the hand-off, the exception, the record and the next decision."
    }

  fun aboutStoryLabel(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "০২ / মূল ভাবনা" else "02 / THE THESIS"

  fun aboutStoryParagraph1(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) {
      "অনেক সফটওয়্যার শুধু নিখুঁত পরিস্থিতির পথ দেখায়। বাস্তব কাজ চলে তার চারপাশে—বিরতি, ব্যতিক্রম, কাগজের হিসাব আর এমন সিদ্ধান্তে, যা পরের মানুষের কাছেও টিকে থাকতে হয়।"
    } else {
      "Most tools show the happy path. Real work lives around it—in interruptions, edge cases, paper trails and decisions that have to survive the next person."
    }

  fun aboutStoryParagraph2(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) {
      "Rindle Works-এ পণ্যের ভাবনা ও প্রকৌশল একই আলোচনায় থাকে। পুরো কর্মপ্রবাহ বুঝে আমরা এমন সরঞ্জাম গড়ি, যা জটিলতা কমায় কিন্তু জরুরি সত্য আড়াল করে না। ORVA সেই দৃষ্টিভঙ্গিকে ফার্মেসির কাজে নিয়ে আসে।"
    } else {
      "At Rindle Works, product thinking and engineering share the same table. We study the whole operation, then shape tools that remove friction without hiding important detail. ORVA brings that approach to pharmacy work."
    }

  fun philosophyLead(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "পর্দা ছোট।" else "THE SCREEN IS SMALL."

  fun philosophyAccent(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "কাজটা নয়।" else "THE WORK ISN'T."

  fun philosophySupport(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) {
      "কাজ যখন ঠিকমতো চলে, সফটওয়্যার সামনে আসে না। কিন্তু কঠিন মুহূর্তে তার প্রতিটি খুঁটিনাটি গুরুত্বপূর্ণ হয়ে ওঠে।"
    } else {
      "When the work flows, the software gets out of the way. When the moment gets difficult, every detail starts to matter."
    }

  fun aboutPrinciplesLabel(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "০৪ / পাঁচটি মূলনীতি" else "04 / PRINCIPLES"

  fun aboutPrinciples(language: AppLanguage): List<PrincipleCopy> =
    if (language == AppLanguage.Bengali) {
      listOf(
        PrincipleCopy("০১", "পুরো কাজটা বুঝুন", "প্রথম ইনপুট থেকে পরের মানুষের হাতে যাওয়া পর্যন্ত—বিরতি ও ব্যতিক্রমসহ—কাজকে অনুসরণ করুন।"),
        PrincipleCopy("০২", "পরের পদক্ষেপ স্পষ্ট করুন", "সিদ্ধান্তের ঠিক জায়গায় সঠিক তথ্য দিন; প্রেক্ষাপট নয়, অপ্রয়োজনীয় শব্দ সরান।"),
        PrincipleCopy("০৩", "প্রতিটি রেকর্ডের মর্যাদা রাখুন", "নির্ভুলতা, অনুসরণযোগ্যতা ও নিরাপদ পরিবর্তন পণ্যের ভিতরেই তৈরি থাকতে হবে।"),
        PrincipleCopy("০৪", "দীর্ঘ কর্মদিবসের জন্য বানান", "পুনরাবৃত্তি, বাধা ও অসম্পূর্ণ পরিস্থিতিতেও কর্মপ্রবাহকে টিকে থাকতে হবে—শুধু ডেমোতে নয়।"),
        PrincipleCopy("০৫", "সমস্যার পথও তৈরি রাখুন", "ফাঁকা অবস্থা, ভুল সংশোধন, পুনরুদ্ধার ও প্রতিক্রিয়াও শুরু থেকেই নকশার অংশ।"),
      )
    } else {
      listOf(
        PrincipleCopy(
          number = "01",
          title = "STUDY THE WHOLE TASK",
          description = "Follow the work from first input to hand-off, including interruptions and exceptions.",
        ),
        PrincipleCopy(
          number = "02",
          title = "MAKE THE NEXT MOVE CLEAR",
          description = "Put the right information at the point of decision. Remove noise, not context.",
        ),
        PrincipleCopy(
          number = "03",
          title = "TREAT RECORDS AS PROMISES",
          description = "Accuracy, traceability and safe state changes must be built into the product.",
        ),
        PrincipleCopy(
          number = "04",
          title = "BUILD FOR THE LONG SHIFT",
          description = "A workflow must hold up under repetition, interruptions and imperfect conditions—not only in a polished demo.",
        ),
        PrincipleCopy(
          number = "05",
          title = "PLAN FOR WHAT GOES WRONG",
          description = "Empty states, reversals, recovery and feedback belong in the design from day one.",
        ),
      )
    }

  // ---- Scene 05: Selected Work / ORVA ----
  fun selectedWorkEyebrow(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "নির্বাচিত কাজ / কেস ০০১" else "SELECTED WORK / CASE 001"

  fun selectedWorkStatement(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "কাউন্টারের প্রতিটি সিদ্ধান্তের হিসাব আছে।" else "A COUNTER IS A THOUSAND SMALL DECISIONS."

  fun selectedWorkBody1(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) {
      "ওষুধ খোঁজা থেকে ব্যাচ ও মেয়াদ দেখা, বিল তৈরি, রিটার্ন এবং রেকর্ড রাখা—ORVA ফার্মেসির দৈনন্দিন কাজকে একটি সুসংহত কর্মক্ষেত্রে আনার জন্য তৈরি হচ্ছে।"
    } else {
      "Medicine lookup, batches and expiry, billing, returns and records: ORVA is being shaped to bring the everyday work of a pharmacy into one considered workspace."
    }

  fun selectedWorkBody2(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) {
      "এখানে নির্ভুল হিসাব, মেয়াদ-সচেতন স্টক, অ্যাটমিক লেনদেন এবং স্থানীয়ভাবে সংরক্ষিত তথ্য—সবকিছু একই কর্মপ্রবাহের অংশ।"
    } else {
      "Its foundations are deliberate: integer-paise calculations, expiry-aware stock, atomic transactions and locally held records. Each part supports the same working day."
    }

  fun orvaCaseRail(language: AppLanguage): List<OrvaCaseRailItem> =
    listOf(
      OrvaCaseRailItem(
        code = "ORVA_01",
        index = "01",
        title = if (language == AppLanguage.Bengali) "কাউন্টার বিলিং" else "Counter Billing",
        summary =
          if (language == AppLanguage.Bengali) "দ্রুত ওষুধ বাছাই, পূর্ণ পয়সার GST হিসাব এবং অ্যাটমিক ইনভয়েস চূড়ান্তকরণ।"
          else "Fast lookup, integer-paise GST calculation and atomic invoice finalisation.",
        tags = if (language == AppLanguage.Bengali) listOf("বিলিং", "GST", "পয়সা") else listOf("BILLING", "GST", "PAISE"),
        imageResId = R.drawable.editorial_thermal_counter,
      ),
      OrvaCaseRailItem(
        code = "ORVA_02",
        index = "02",
        title = if (language == AppLanguage.Bengali) "ব্যাচ ও মেয়াদ (FEFO)" else "Batch & FEFO Stock",
        summary =
          if (language == AppLanguage.Bengali) "আগে মেয়াদ শেষ হওয়া ব্যাচ অগ্রাধিকার এবং মেয়াদোত্তীর্ণ স্টক আলাদা রাখা।"
          else "Earliest-expiry-first allocation keeping expired stock out of regular sales.",
        tags = if (language == AppLanguage.Bengali) listOf("FEFO", "ব্যাচ", "মেয়াদ") else listOf("FEFO", "BATCHES", "EXPIRY"),
        imageResId = R.drawable.editorial_apothecary_shelves,
      ),
      OrvaCaseRailItem(
        code = "ORVA_03",
        index = "03",
        title = if (language == AppLanguage.Bengali) "রিটার্ন ও সংশোধন" else "Returns & Ledger",
        summary =
          if (language == AppLanguage.Bengali) "সেলস রিটার্ন, বাতিলকরণ এবং প্রতিটি স্টক পরিবর্তনের নির্ভরযোগ্য রেকর্ড।"
          else "Traceable sales returns, cancellations and auditable stock movement records.",
        tags = if (language == AppLanguage.Bengali) listOf("রিটার্ন", "লেজার", "অডিট") else listOf("RETURNS", "LEDGER", "AUDIT"),
        imageResId = R.drawable.editorial_studio_workbench,
      ),
      OrvaCaseRailItem(
        code = "ORVA_04",
        index = "04",
        title = if (language == AppLanguage.Bengali) "স্থানীয় ব্যাকআপ" else "Local-First Vault",
        summary =
          if (language == AppLanguage.Bengali) "ইন্টারনেট ছাড়াই সম্পূর্ণ পরিচালনা এবং দোকানের নিজস্ব ব্যাকআপ ও পুনরুদ্ধার।"
          else "Zero cloud lock-in with local SQLite persistence and portable shop backups.",
        tags = if (language == AppLanguage.Bengali) listOf("SQLite", "অফলাইন", "ব্যাকআপ") else listOf("SQLITE", "OFFLINE", "BACKUP"),
        imageResId = R.drawable.editorial_architecture_light,
      ),
    )

  // ---- Scene 06: Product Concerns & Engineering Commitments ----
  fun architectureEyebrow(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "০৬ / সিস্টেমের ভিত্তি" else "06 / SYSTEM CONTRACT"

  fun architectureMeta(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "পণ্য × প্রকৌশল" else "PRODUCT × ENGINEERING"

  fun architectureHeadline(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "প্রতিটি প্রতিশ্রুতির পেছনে নিয়ম থাকতে হয়।"
    else "EVERY PROMISE NEEDS A RULE."

  fun architectureBody(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) {
      "কাউন্টারের কাজ সহজ দেখালেই যথেষ্ট নয়। হিসাব, স্টক ও রেকর্ডের ভিতরে যে নিয়মগুলো কাজ করে, সেগুলোকেও নির্ভরযোগ্য হতে হয়।"
    } else {
      "A smoother counter means little if the numbers drift. The rules beneath billing, stock and records have to hold up under real use."
    }

  fun productConcernsCaption(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "যে বিষয়গুলো অটুট থাকতে হবে" else "WHAT THE WORK REQUIRES"

  fun engineeringCommitmentsCaption(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "যে নিয়মগুলো তা রক্ষা করে" else "WHAT THE SYSTEM MUST HONOUR"

  fun productConcerns(language: AppLanguage): List<String> =
    if (language == AppLanguage.Bengali) {
      listOf(
        "বিলিংয়ের নির্ভুলতা",
        "ইনভেন্টরি ও ব্যাচ ব্যবস্থাপনা",
        "মেয়াদ-সচেতন স্টক",
        "রিটার্ন ও বাতিলকরণ",
        "স্থানীয়-প্রথম পরিচালনা",
        "ব্যাকআপ ও পুনরুদ্ধার",
      )
    } else {
      listOf(
        "Billing integrity",
        "Inventory and batches",
        "Expiry-aware stock",
        "Returns and cancellation",
        "Local-first operation",
        "Backup and recovery",
      )
    }

  fun engineeringCommitments(language: AppLanguage): List<String> =
    if (language == AppLanguage.Bengali) {
      listOf(
        "পূর্ণ পয়সার এককে আর্থিক হিসাব",
        "সহস্রাংশ পূর্ণসংখ্যায় পরিমাণের হিসাব",
        "FEFO বরাদ্দ (আগে মেয়াদ শেষ হওয়া ব্যাচ আগে)",
        "অ্যাটমিক ইনভয়েস চূড়ান্তকরণ ও স্টক পরিবর্তন",
        "Compose UI থেকে ডোমেইন নিয়ম পৃথক রাখা",
        "সুস্পষ্ট স্কিমা মাইগ্রেশন ও যাচাইকরণ",
      )
    } else {
      listOf(
        "Money represented as integer paise",
        "Quantities represented in thousandths",
        "FEFO allocation (earliest expiry first)",
        "Atomic invoice finalisation and stock movements",
        "Domain rules separated from Compose UI",
        "Explicit migrations and validation",
      )
    }

  // ---- Scene 07: Field Notes / Visual Studies ----
  fun fieldNotesEyebrow(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "০৭ / কাজের নোট" else "07 / FIELD NOTES"

  fun fieldNotesMeta(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "ধারণামূলক চিত্র" else "CONCEPTUAL IMAGE STUDIES"

  fun fieldNotesHeadline(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "ফার্মেসি শুধু একটি কাউন্টার নয়।"
    else "A PHARMACY IS MORE THAN A COUNTER."

  fun fieldNotesBody(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) {
      "স্টক, ব্যাচের মেয়াদ, রসিদ ও রেকর্ড—সবই একই কর্মদিবসের সংযুক্ত অংশ।"
    } else {
      "Batches, expiry dates, receipts and records are connected parts of one working day."
    }

  fun fieldNotesBatchCaption(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "ব্যাচ / ইনভেন্টরি" else "BATCH / INVENTORY"

  fun fieldNotesBillingCaption(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "বিলিং / কর্মপ্রবাহ" else "BILLING / WORKFLOW"

  fun fieldNotesDetailCaption(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "সিস্টেম / খুঁটিনাটি" else "SYSTEM / DETAIL"

  fun fieldNotesStructureCaption(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "সিস্টেম / কাঠামো" else "SYSTEM / STRUCTURE"

  // ---- Scene 08: Deep Dive / ORVA ----
  fun deepDiveEyebrow(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "গভীর পর্যবেক্ষণ / ORVA" else "DEEP DIVE / ORVA"

  fun deepDiveEyebrowWithScene(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "০৮ / ${deepDiveEyebrow(language)}" else "08 / ${deepDiveEyebrow(language)}"

  fun deepDiveTitle(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "খুঁটিনাটিই আসল পণ্য।"
    else "THE DETAILS ARE THE PRODUCT."

  fun deepDiveBody(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) {
      "বিলের প্রতিটি পয়সা থেকে ব্যাচের মেয়াদ, স্টক পরিবর্তন ও পুনরুদ্ধার—একটি ফার্মেসি পণ্যের ভিতরে নিয়মগুলো কীভাবে জুড়ে থাকে তা দেখুন।"
    } else {
      "Look beneath the interface: how paise-level totals, batch expiry, stock movements and recovery fit into one pharmacy workflow."
    }

  fun deepDivePlateMeta(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "ধারণা / ডোমেইন নিয়ম" else "CONCEPT / DOMAIN RULES"

  fun deepDivePlateSection(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "মূল নিয়ন্ত্রণ" else "CORE CONTROLS"

  fun deepDivePerspectiveHint(
    language: AppLanguage,
    flattened: Boolean,
    reducedMotion: Boolean,
  ): String =
    if (reducedMotion) {
      if (language == AppLanguage.Bengali) "স্থির দৃশ্য / কম গতি" else "STATIC VIEW / REDUCED MOTION"
    } else if (language == AppLanguage.Bengali) {
      if (flattened) "দৃষ্টিকোণ ফিরিয়ে আনুন" else "সমতলভাবে দেখতে চাপ দিন"
    } else {
      if (flattened) "TAP TO RESTORE ANGLE" else "TAP TO FLATTEN"
    }

  fun deepDiveArtworkDescription(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) {
      "ORVA-র ডোমেইন নিয়মের একটি ধারণামূলক সম্পাদকীয় চিত্র"
    } else {
      "Conceptual editorial artwork accompanying the ORVA domain-rule study"
    }

  fun deepDiveRules(language: AppLanguage): List<Pair<String, String>> =
    if (language == AppLanguage.Bengali) {
      listOf(
        "অর্থ" to "পূর্ণ পয়সা",
        "পরিমাণ" to "সহস্রাংশ পূর্ণসংখ্যা",
        "স্টক" to "FEFO বরাদ্দ",
        "ইনভয়েস" to "অ্যাটমিক চূড়ান্তকরণ",
      )
    } else {
      listOf(
        "MONEY" to "INTEGER PAISE",
        "QUANTITY" to "INTEGER THOUSANDTHS",
        "STOCK" to "FEFO ALLOCATION",
        "INVOICE" to "ATOMIC FINALISATION",
      )
    }

  // ---- Scene 09: Contact & Closing ----
  fun supportSectionLabel(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "০৯ / যোগাযোগ" else "09 / CONTACT"

  fun supportHeading(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "কঠিন অংশটা দিয়ে শুরু হোক।" else "START WITH THE HARD PART."

  fun supportSubline(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "জটিল কর্মপ্রবাহ, কাগজের হিসাব বা অনির্ধারিত ব্যতিক্রম—এসব নিয়েই কথা শুরু করা যায়।"
    else "The awkward workflow, the paper trail, the exception no one planned for—those are worth understanding."

  fun supportPhoneLabel(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "ফোন" else "Phone"

  fun supportEmailLabel(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "ইমেইল" else "Email"

  fun supportEmptyState(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) {
      "সহায়তার যোগাযোগের তথ্য এখনো সেটিংসে যুক্ত করা হয়নি।"
    } else {
      "Support contact details are not configured yet. Add them in Settings."
    }

  fun ownershipSectionLabel(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "পণ্য ও পরিচিতি" else "PRODUCT & OWNERSHIP"

  fun productLabel(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "পণ্য" else "Product"

  fun productValue(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "ORVA — ফার্মেসি বিলিং ও ইনভেন্টরি" else "ORVA — Pharmacy Billing & Inventory"

  fun developedByLabel(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "নির্মাতা" else "Developed by"

  fun studioStatusNote(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) {
      "স্টুডিওর নাম: আপাতত ব্যবহৃত; ভারতে ট্রেডমার্ক যাচাই ও অনুমোদন বাকি।"
    } else {
      "Studio name: Provisional; Indian trademark clearance pending."
    }

  fun versionLabel(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "সংস্করণ" else "Version"

  fun buildLabel(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "বিল্ড" else "Build"

  fun ownershipReassurance(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) {
      "আপনার দোকানের ব্যবসায়িক রেকর্ড স্থানীয় স্টোরেজে আপনার নিয়ন্ত্রণেই সুরক্ষিত থাকে।"
    } else {
      "Your shop's business records remain in local storage under your control."
    }

  fun filmEndTagline(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "উদ্দেশ্য নিয়ে তৈরি সফটওয়্যার।"
    else "SOFTWARE, WITH INTENTION."
}
