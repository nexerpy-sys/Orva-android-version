package com.rindleworks.orva.service.subscription

import android.os.SystemClock
import com.rindleworks.orva.domain.common.OrvaDateTimeFormatters
import com.rindleworks.orva.domain.common.OrvaSettingKeys
import com.rindleworks.orva.domain.engine.BillingClock
import com.rindleworks.orva.domain.engine.BillingInstant
import com.rindleworks.orva.domain.settings.AppSettingsRepository
import com.rindleworks.orva.domain.settings.OperationalSupportPrefs
import com.rindleworks.orva.domain.settings.SubscriptionService
import com.rindleworks.orva.domain.settings.SubscriptionStatus
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest
import java.time.Duration
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.Locale
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Offline-resilient license & subscription service with exact ORVA WPF SubscriptionService.cs parity:
 * - Zero hardcoded commercial prices.
 * - One-Time licenses with blank expiry stay active permanently without offline timeout.
 * - 14-day post-expiry grace period AND 14-day offline verification grace period.
 * - Monotonic clock-rollback detection (`ClockMismatch`) combining `last_seen_utc` across SQLite +
 *   sealed `ORVA/license.orvalic` AND Android's kernel-monotonic `SystemClock.elapsedRealtime()`.
 * - Dual anti-delete/anti-swap anchor stored in app-private `.license_anchor` AND SQLite `app_setting`.
 * - HTTPS-only header-mapped RFC 4180 `licenses.csv` verification with strict SHA-256 + optional ECDSA P-256.
 * - Grace expiry pauses ONLY new billing; historical invoices, reports, and backups stay unlocked.
 */
class DefaultSubscriptionService(
  private val settings: AppSettingsRepository,
  private val clock: BillingClock,
  private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO,
  private val registryCsvFetcher: suspend (String) -> String = { url -> defaultHttpsFetch(url, ioDispatcher) },
  private val licenseVault: OrvaLicenseVault? = null,
  private val monotonicElapsedMsProvider: () -> Long = {
    runCatching { SystemClock.elapsedRealtime() }.getOrDefault(-1L)
  },
) : SubscriptionService {

  companion object {
    const val OFFLINE_GRACE_DAYS = 14
    const val REFRESH_INTERVAL_HOURS = 12L
    const val RENEWAL_REMINDER_WINDOW_DAYS = 7
    const val URGENT_RENEWAL_WINDOW_DAYS = 3
    private const val CLOCK_ROLLBACK_TOLERANCE_HOURS = 24L
    private const val UPTIME_CLOCK_DRIFT_TOLERANCE_MS = 2L * 60L * 60L * 1000L // 2 hours
    internal const val SETTING_LAST_SEEN_ELAPSED_MS = "subscription.last_seen_elapsed_ms"
    internal const val SETTING_LICENSE_ANCHOR_SHA256 = "subscription.license_anchor_sha256"

    private val SUPPORTED_DATE_FORMATS =
      listOf(
        DateTimeFormatter.ofPattern("dd-MM-yyyy", Locale.ROOT),
        DateTimeFormatter.ofPattern("yyyy-MM-dd", Locale.ROOT),
        DateTimeFormatter.ofPattern("dd/MM/yyyy", Locale.ROOT),
      )

    fun sha256Hex(raw: String): String {
      val digest = MessageDigest.getInstance("SHA-256").digest(raw.trim().toByteArray(Charsets.UTF_8))
      return digest.joinToString("") { "%02x".format(it) }
    }

    private suspend fun defaultHttpsFetch(urlString: String, ioDispatcher: CoroutineDispatcher): String =
      withContext(ioDispatcher) {
        val trimmed = urlString.trim()
        require(trimmed.startsWith("https://", ignoreCase = true)) {
          "License registry URL must use HTTPS."
        }
        val conn = (URL(trimmed).openConnection() as HttpURLConnection).apply {
          requestMethod = "GET"
          connectTimeout = 10_000
          readTimeout = 10_000
          useCaches = false
        }
        try {
          val code = conn.responseCode
          check(code in 200..299) { "License registry returned HTTP $code." }
          conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally {
          conn.disconnect()
        }
      }
  }

  override suspend fun saveCredentials(
    username: String,
    activationCode: String,
    registryUrl: String,
  ) {
    settings.set(OrvaSettingKeys.SUBSCRIPTION_USERNAME, username.trim())
    settings.set(OrvaSettingKeys.SUBSCRIPTION_ACTIVATION_CODE, activationCode.trim())
    val cleanUrl = registryUrl.trim()
    if (cleanUrl.isNotEmpty()) {
      settings.set(OrvaSettingKeys.SUBSCRIPTION_REGISTRY_URL, cleanUrl)
    }
  }

  override suspend fun saveSupportAndUpiSettings(prefs: OperationalSupportPrefs) {
    settings.set(OrvaSettingKeys.SUPPORT_PHONES, prefs.supportPhones.trim())
    settings.set(OrvaSettingKeys.SUPPORT_WHATSAPP, prefs.supportWhatsapp.trim())
    settings.set(OrvaSettingKeys.SUPPORT_EMAIL, prefs.supportEmail.trim())
    settings.set(OrvaSettingKeys.UPI_ID, prefs.upiId.trim())
    settings.set(OrvaSettingKeys.UPI_PAYEE_NAME, prefs.upiPayeeName.trim())
  }

  override suspend fun evaluateLocalStatus(): SubscriptionStatus {
    val now = BillingInstant.capture(clock)
    val currentElapsedMs = monotonicElapsedMsProvider()
    val dbUsername = settings.get(OrvaSettingKeys.SUBSCRIPTION_USERNAME).trim()
    val registryUrl = settings.get(OrvaSettingKeys.SUBSCRIPTION_REGISTRY_URL).trim()
    val sqliteAnchorSha256 = settings.get(SETTING_LICENSE_ANCHOR_SHA256).trim().ifEmpty { null }

    // 0. Check hardware-Keystore-sealed ORVA/license.orvalic vault + dual anchors (file + SQLite).
    val vaultResult =
      licenseVault?.readAndVerify(
        expectedUsername = dbUsername.ifEmpty { null },
        externalAnchorSha256 = sqliteAnchorSha256,
      )
    when (vaultResult) {
      is LicenseVaultReadResult.MissingAfterActivation -> {
        return SubscriptionStatus(
          username = dbUsername.ifEmpty { vaultResult.expectedUsername },
          plan = settings.get(OrvaSettingKeys.SUBSCRIPTION_CACHED_PLAN).trim().ifEmpty { null },
          startDateIso = null,
          expiryDateIso = null,
          status = "LicenseFileMissing",
          lastVerifiedUtc = settings.get(OrvaSettingKeys.SUBSCRIPTION_LAST_VERIFIED_UTC).trim().ifEmpty { null },
          isConfigured = true,
          isActive = false,
          isInGracePeriod = false,
          graceDaysRemaining = 0,
          isRenewalReminderDue = false,
          daysUntilExpiry = null,
          allowNewBilling = false,
          message =
            "Local licence file (ORVA/license.orvalic) is missing. Connect to the internet and tap Refresh Subscription. Historical invoices and backups remain accessible.",
        )
      }
      is LicenseVaultReadResult.Tampered -> {
        return SubscriptionStatus(
          username = dbUsername.ifEmpty { null },
          plan = settings.get(OrvaSettingKeys.SUBSCRIPTION_CACHED_PLAN).trim().ifEmpty { null },
          startDateIso = null,
          expiryDateIso = null,
          status = "TamperedLicense",
          lastVerifiedUtc = settings.get(OrvaSettingKeys.SUBSCRIPTION_LAST_VERIFIED_UTC).trim().ifEmpty { null },
          isConfigured = true,
          isActive = false,
          isInGracePeriod = false,
          graceDaysRemaining = 0,
          isRenewalReminderDue = false,
          daysUntilExpiry = null,
          allowNewBilling = false,
          message =
            "Local licence verification failed (${vaultResult.reason}). Connect to the internet and tap Refresh Subscription. Historical invoices and backups remain accessible.",
        )
      }
      else -> Unit
    }

    val sealed = (vaultResult as? LicenseVaultReadResult.Valid)?.payload
    val username = dbUsername.ifEmpty { sealed?.username.orEmpty() }

    if (username.isEmpty() && registryUrl.isEmpty() && sealed == null) {
      return SubscriptionStatus(
        username = null,
        plan = null,
        startDateIso = null,
        expiryDateIso = null,
        status = "Not configured",
        lastVerifiedUtc = null,
        isConfigured = false,
        isActive = false,
        isInGracePeriod = false,
        graceDaysRemaining = 0,
        isRenewalReminderDue = false,
        daysUntilExpiry = null,
        allowNewBilling = true,
        message = "Subscription check is not configured on this installation.",
      )
    }

    val dbCachedPlan = settings.get(OrvaSettingKeys.SUBSCRIPTION_CACHED_PLAN).trim()
    val dbCachedStatus = settings.get(OrvaSettingKeys.SUBSCRIPTION_CACHED_STATUS).trim()
    val dbCachedExpiry = settings.get(OrvaSettingKeys.SUBSCRIPTION_CACHED_EXPIRY).trim()

    // Cross-check SQLite app_setting against the hardware-sealed vault to defeat direct SQLite edits.
    if (sealed != null &&
      dbCachedStatus.isNotEmpty() &&
      (!dbCachedStatus.equals(sealed.status, ignoreCase = true) ||
        !dbCachedExpiry.equals(sealed.expiryDateRaw, ignoreCase = true) ||
        !dbCachedPlan.equals(sealed.plan, ignoreCase = true))
    ) {
      // Allow legitimate failed online refresh statuses (InvalidActivationCode / NotFound / InvalidSignature)
      // to remain visible, while blocking any attempt to fabricate Active / extend expiry in SQLite.
      val isKnownFailureStatus =
        dbCachedStatus.equals("InvalidActivationCode", ignoreCase = true) ||
          dbCachedStatus.equals("NotFound", ignoreCase = true) ||
          dbCachedStatus.equals("InvalidSignature", ignoreCase = true)
      if (!isKnownFailureStatus) {
        return SubscriptionStatus(
          username = username.ifEmpty { null },
          plan = sealed.plan.ifEmpty { null },
          startDateIso = parseFlexibleDate(sealed.startDateRaw)?.toString() ?: sealed.startDateRaw.ifEmpty { null },
          expiryDateIso = parseFlexibleDate(sealed.expiryDateRaw)?.toString() ?: sealed.expiryDateRaw.ifEmpty { null },
          status = "TamperedLicense",
          lastVerifiedUtc = sealed.verifiedAtUtc.ifEmpty { null },
          isConfigured = true,
          isActive = false,
          isInGracePeriod = false,
          graceDaysRemaining = 0,
          isRenewalReminderDue = false,
          daysUntilExpiry = null,
          allowNewBilling = false,
          message =
            "Local licence state does not match the sealed licence file (possible database edit). Connect online and tap Refresh Subscription. Historical invoices and backups remain accessible.",
        )
      }
    }

    // Monotonic clock-rollback check combining:
    // (a) 24-hour wall-clock rollback check across BOTH SQLite and sealed ORVA/license.orvalic, AND
    // (b) Android kernel-monotonic `SystemClock.elapsedRealtime()` same-boot uptime drift check
    //     (catches repeated small clock rollbacks within a single boot session).
    val dbLastSeen = OrvaDateTimeFormatters.parseUtcInstant(settings.get(OrvaSettingKeys.SUBSCRIPTION_LAST_SEEN_UTC))
    val dbLastSeenElapsedMs = settings.get(SETTING_LAST_SEEN_ELAPSED_MS).trim().toLongOrNull()
    val vaultLastSeen = OrvaDateTimeFormatters.parseUtcInstant(sealed?.lastSeenUtc)
    val vaultLastSeenElapsedMs = sealed?.lastSeenElapsedMs
    val lastSeenInstant =
      when {
        dbLastSeen != null && vaultLastSeen != null -> if (dbLastSeen.isAfter(vaultLastSeen)) dbLastSeen else vaultLastSeen
        else -> dbLastSeen ?: vaultLastSeen
      }

    val wallClockRolledBack =
      lastSeenInstant != null &&
        Duration.between(now.utcNow, lastSeenInstant).toHours() > CLOCK_ROLLBACK_TOLERANCE_HOURS
    val uptimeRolledBack =
      isSameBootUptimeRollback(now.utcNow, currentElapsedMs, dbLastSeen, dbLastSeenElapsedMs) ||
        isSameBootUptimeRollback(now.utcNow, currentElapsedMs, vaultLastSeen, vaultLastSeenElapsedMs)

    if (wallClockRolledBack || uptimeRolledBack) {
      return SubscriptionStatus(
        username = username.ifEmpty { null },
        plan = (sealed?.plan ?: dbCachedPlan).ifEmpty { null },
        startDateIso = (sealed?.startDateRaw ?: settings.get(OrvaSettingKeys.SUBSCRIPTION_CACHED_START).trim()).ifEmpty { null },
        expiryDateIso = (sealed?.expiryDateRaw ?: dbCachedExpiry).ifEmpty { null },
        status = "ClockMismatch",
        lastVerifiedUtc = (sealed?.verifiedAtUtc ?: settings.get(OrvaSettingKeys.SUBSCRIPTION_LAST_VERIFIED_UTC).trim()).ifEmpty { null },
        isConfigured = true,
        isActive = false,
        isInGracePeriod = false,
        graceDaysRemaining = 0,
        isRenewalReminderDue = false,
        daysUntilExpiry = null,
        allowNewBilling = false,
        message =
          "Device date appears to have been moved backwards. Check system date/time and click Refresh Subscription. Historical invoices and backups remain accessible.",
      )
    }

    val dbRebooted = currentElapsedMs >= 0L && dbLastSeenElapsedMs != null && currentElapsedMs < dbLastSeenElapsedMs
    if (lastSeenInstant == null || now.utcNow.isAfter(lastSeenInstant) || dbRebooted) {
      val effectiveUtc = if (lastSeenInstant == null || now.utcNow.isAfter(lastSeenInstant)) now.utcIsoText else OrvaDateTimeFormatters.formatUtcRoundTrip(lastSeenInstant)
      settings.set(OrvaSettingKeys.SUBSCRIPTION_LAST_SEEN_UTC, effectiveUtc)
      if (currentElapsedMs >= 0L) {
        settings.set(SETTING_LAST_SEEN_ELAPSED_MS, currentElapsedMs.toString())
      }
      // Also advance monotonic lastSeenUtc + lastSeenElapsedMs inside sealed ORVA/license.orvalic
      // (throttled to >= 1h wall or uptime advance, or on reboot reset) and mirror new anchor to SQLite.
      val vault = licenseVault
      val vaultRebooted =
        currentElapsedMs >= 0L && vaultLastSeenElapsedMs != null && currentElapsedMs < vaultLastSeenElapsedMs
      val uptimeAdvancedAnHour =
        currentElapsedMs >= 0L &&
          (vaultLastSeenElapsedMs == null || (currentElapsedMs - vaultLastSeenElapsedMs) >= 3_600_000L)
      val wallAdvancedAnHour =
        vaultLastSeen == null || Duration.between(vaultLastSeen, now.utcNow).toHours() >= 1L
      if (sealed != null && vault != null && (wallAdvancedAnHour || uptimeAdvancedAnHour || vaultRebooted)) {
        runCatching {
          val written =
            vault.sealAndSaveWithAnchor(
              sealed.copy(
                lastSeenUtc = effectiveUtc,
                lastSeenElapsedMs = if (currentElapsedMs >= 0L) currentElapsedMs else sealed.lastSeenElapsedMs,
              )
            )
          settings.set(SETTING_LICENSE_ANCHOR_SHA256, written.envelopeSha256)
        }
      }
    }

    val isKnownFailureStatus =
      dbCachedStatus.equals("InvalidActivationCode", ignoreCase = true) ||
        dbCachedStatus.equals("NotFound", ignoreCase = true) ||
        dbCachedStatus.equals("InvalidSignature", ignoreCase = true)

    val cachedPlan = (if (isKnownFailureStatus) dbCachedPlan else sealed?.plan ?: dbCachedPlan).ifEmpty { null }
    val cachedStatus =
      when {
        isKnownFailureStatus -> dbCachedStatus
        sealed != null -> sealed.status.trim().ifEmpty { "Unverified" }
        dbCachedStatus.isNotEmpty() -> dbCachedStatus
        else -> "Unverified"
      }
    val rawStart = sealed?.startDateRaw ?: settings.get(OrvaSettingKeys.SUBSCRIPTION_CACHED_START).trim()
    val rawExpiry = sealed?.expiryDateRaw ?: dbCachedExpiry
    val parsedStart = parseFlexibleDate(rawStart)
    val parsedExpiry = parseFlexibleDate(rawExpiry)
    val startIso = parsedStart?.toString() ?: rawStart.ifEmpty { null }
    val expiryIso = parsedExpiry?.toString() ?: rawExpiry.ifEmpty { null }
    val lastVerifiedUtcStr =
      (sealed?.verifiedAtUtc ?: settings.get(OrvaSettingKeys.SUBSCRIPTION_LAST_VERIFIED_UTC).trim()).ifEmpty { null }
    val lastVerified = OrvaDateTimeFormatters.parseUtcInstant(lastVerifiedUtcStr)

    if (!cachedStatus.equals("Active", ignoreCase = true)) {
      return SubscriptionStatus(
        username = username.ifEmpty { null },
        plan = cachedPlan,
        startDateIso = startIso,
        expiryDateIso = expiryIso,
        status = cachedStatus,
        lastVerifiedUtc = lastVerifiedUtcStr,
        isConfigured = true,
        isActive = false,
        isInGracePeriod = false,
        graceDaysRemaining = 0,
        isRenewalReminderDue = false,
        daysUntilExpiry = null,
        allowNewBilling = false,
        message =
          "Subscription is not active ($cachedStatus). Renew or refresh in Subscription & Support. Historical invoices and backups remain accessible.",
      )
    }

    // One-Time license with no expiry date remains permanently active offline (WPF parity)
    if (cachedPlan.equals("One-Time", ignoreCase = true) && parsedExpiry == null) {
      return SubscriptionStatus(
        username = username.ifEmpty { null },
        plan = cachedPlan,
        startDateIso = startIso,
        expiryDateIso = null,
        status = cachedStatus,
        lastVerifiedUtc = lastVerifiedUtcStr,
        isConfigured = true,
        isActive = true,
        isInGracePeriod = false,
        graceDaysRemaining = 0,
        isRenewalReminderDue = false,
        daysUntilExpiry = null,
        allowNewBilling = true,
        message = "One-Time licence active.",
      )
    }

    val todayUtc = now.utcNow.atZone(ZoneOffset.UTC).toLocalDate()
    val daysUntilExpiry = parsedExpiry?.let { ChronoUnit.DAYS.between(todayUtc, it).toInt() }

    // 1. Post-expiry 14-day grace window (exact WPF parity)
    if (parsedExpiry != null && todayUtc.isAfter(parsedExpiry)) {
      val daysPast = ChronoUnit.DAYS.between(parsedExpiry, todayUtc).toInt()
      if (daysPast <= OFFLINE_GRACE_DAYS) {
        val remaining = OFFLINE_GRACE_DAYS - daysPast
        return SubscriptionStatus(
          username = username.ifEmpty { null },
          plan = cachedPlan,
          startDateIso = startIso,
          expiryDateIso = expiryIso,
          status = cachedStatus,
          lastVerifiedUtc = lastVerifiedUtcStr,
          isConfigured = true,
          isActive = false,
          isInGracePeriod = true,
          graceDaysRemaining = remaining,
          isRenewalReminderDue = true,
          daysUntilExpiry = daysUntilExpiry,
          allowNewBilling = true,
          message = "Subscription expired. $remaining day(s) of grace period remaining. Please renew soon.",
        )
      }
      return SubscriptionStatus(
        username = username.ifEmpty { null },
        plan = cachedPlan,
        startDateIso = startIso,
        expiryDateIso = expiryIso,
        status = cachedStatus,
        lastVerifiedUtc = lastVerifiedUtcStr,
        isConfigured = true,
        isActive = false,
        isInGracePeriod = false,
        graceDaysRemaining = 0,
        isRenewalReminderDue = true,
        daysUntilExpiry = daysUntilExpiry,
        allowNewBilling = false,
        message =
          "Subscription grace period has ended. New invoice creation is paused until renewal. Historical invoices, records, and backups remain accessible.",
      )
    }

    // 2. Offline verification staleness (1..14 days -> offline grace; >14 days -> pause new billing)
    if (lastVerified != null) {
      val daysSinceVerified = ChronoUnit.DAYS.between(lastVerified, now.utcNow).toInt().coerceAtLeast(0)
      if (daysSinceVerified > OFFLINE_GRACE_DAYS) {
        return SubscriptionStatus(
          username = username.ifEmpty { null },
          plan = cachedPlan,
          startDateIso = startIso,
          expiryDateIso = expiryIso,
          status = cachedStatus,
          lastVerifiedUtc = lastVerifiedUtcStr,
          isConfigured = true,
          isActive = false,
          isInGracePeriod = false,
          graceDaysRemaining = 0,
          isRenewalReminderDue = daysUntilExpiry != null && daysUntilExpiry <= RENEWAL_REMINDER_WINDOW_DAYS,
          daysUntilExpiry = daysUntilExpiry,
          allowNewBilling = false,
          message =
            "Connect briefly to the internet and click Refresh Subscription (offline grace period of 14 days exceeded). Historical invoices and backups remain accessible.",
        )
      }
      if (daysSinceVerified >= 1) {
        val graceRemaining = OFFLINE_GRACE_DAYS - daysSinceVerified
        val reminderDue = daysUntilExpiry != null && daysUntilExpiry <= RENEWAL_REMINDER_WINDOW_DAYS
        return SubscriptionStatus(
          username = username.ifEmpty { null },
          plan = cachedPlan,
          startDateIso = startIso,
          expiryDateIso = expiryIso,
          status = cachedStatus,
          lastVerifiedUtc = lastVerifiedUtcStr,
          isConfigured = true,
          isActive = true,
          isInGracePeriod = true,
          graceDaysRemaining = graceRemaining,
          isRenewalReminderDue = reminderDue,
          daysUntilExpiry = daysUntilExpiry,
          allowNewBilling = true,
          message =
            "Active (${cachedPlan ?: "Standard"}) — offline mode ($graceRemaining day(s) left before online check is needed).",
        )
      }
    }

    val reminderDue = daysUntilExpiry != null && daysUntilExpiry <= RENEWAL_REMINDER_WINDOW_DAYS
    val msg =
      when {
        daysUntilExpiry != null && daysUntilExpiry <= URGENT_RENEWAL_WINDOW_DAYS ->
          "Urgent renewal reminder: Active (${cachedPlan ?: "Standard"}), expires in $daysUntilExpiry day(s)."
        daysUntilExpiry != null && daysUntilExpiry <= RENEWAL_REMINDER_WINDOW_DAYS ->
          "Renewal reminder: Active (${cachedPlan ?: "Standard"}), expires in $daysUntilExpiry day(s)."
        expiryIso != null ->
          "Active (${cachedPlan ?: "Standard"}), valid until $expiryIso."
        else ->
          "Active (${cachedPlan ?: "Standard"})."
      }

    return SubscriptionStatus(
      username = username.ifEmpty { null },
      plan = cachedPlan,
      startDateIso = startIso,
      expiryDateIso = expiryIso,
      status = cachedStatus,
      lastVerifiedUtc = lastVerifiedUtcStr,
      isConfigured = true,
      isActive = true,
      isInGracePeriod = false,
      graceDaysRemaining = 0,
      isRenewalReminderDue = reminderDue,
      daysUntilExpiry = daysUntilExpiry,
      allowNewBilling = true,
      message = msg,
    )
  }

  override suspend fun refreshFromRegistry(): SubscriptionStatus {
    val registryUrl = settings.get(OrvaSettingKeys.SUBSCRIPTION_REGISTRY_URL).trim()
    val username = settings.get(OrvaSettingKeys.SUBSCRIPTION_USERNAME).trim()
    val activationCode = settings.get(OrvaSettingKeys.SUBSCRIPTION_ACTIVATION_CODE).trim()

    if (registryUrl.isEmpty() || !registryUrl.startsWith("https://", ignoreCase = true)) {
      return evaluateLocalStatus().copy(
        message = "Configure a valid HTTPS licenses.csv URL to refresh subscription."
      )
    }
    if (username.isEmpty() || activationCode.isEmpty()) {
      return evaluateLocalStatus().copy(
        message = "Enter your licence Username and Activation Code first."
      )
    }

    val csvText =
      try {
        registryCsvFetcher(registryUrl)
      } catch (_: Exception) {
        val cached = evaluateLocalStatus()
        return cached.copy(
          message = "Could not reach licence registry (offline). ${cached.message}"
        )
      }

    return applyRegistryCsv(csvText, username, activationCode)
  }

  /**
   * Mirrors WPF `App.xaml.cs` startup check: if subscription is configured and either never
   * verified or at least [REFRESH_INTERVAL_HOURS] (12h) have elapsed since last verification,
   * refreshes silently from the raw HTTPS `licenses.csv` registry.
   */
  suspend fun refreshIfStaleOrNeeded(): SubscriptionStatus {
    val local = evaluateLocalStatus()
    if (!local.isConfigured) return local
    val lastVerified = OrvaDateTimeFormatters.parseUtcInstant(local.lastVerifiedUtc)
    val now = BillingInstant.capture(clock).utcNow
    val isStale =
      lastVerified == null || Duration.between(lastVerified, now).toHours() >= REFRESH_INTERVAL_HOURS
    return if (isStale) refreshFromRegistry() else local
  }

  suspend fun applyRegistryCsv(
    csvContent: String,
    username: String,
    activationCode: String,
  ): SubscriptionStatus {
    val now = BillingInstant.capture(clock)
    val expectedHash = sha256Hex(activationCode)
    val lines = csvContent.trimStart('\uFEFF').split('\r', '\n').filter { it.isNotBlank() }
    if (lines.size < 2) {
      settings.set(OrvaSettingKeys.SUBSCRIPTION_CACHED_STATUS, "NotFound")
      return evaluateLocalStatus()
    }

    val headerMap = HashMap<String, Int>()
    val headers = splitCsvLine(lines.first())
    headers.forEachIndexed { idx, raw ->
      val key = raw.trim().trim('\uFEFF').lowercase(Locale.ROOT).replace(" ", "_")
      if (!headerMap.containsKey(key)) headerMap[key] = idx
    }

    val idxUser = findCol(headerMap, listOf("username", "user", "licence_id"), 0)
    val idxPlan = findCol(headerMap, listOf("plan", "subscription_plan"), 1)
    val idxStart = findCol(headerMap, listOf("start_date", "start"), 2)
    val idxExpiry = findCol(headerMap, listOf("expiry_date", "expiry", "end_date"), 3)
    val idxStatus = findCol(headerMap, listOf("status"), 4)
    val idxHash =
      findCol(
        headerMap,
        listOf("activation_code_sha256", "activation_code_sha256_hash", "activation_hash", "hash"),
        5,
      )
    val idxSignature =
      findCol(
        headerMap,
        listOf("signature", "sig", "ecdsa_signature", "vendor_signature"),
        -1,
      )

    for (line in lines.drop(1)) {
      val cols = splitCsvLine(line)
      if (cols.size < 6) continue
      val rowUser = safeGet(cols, idxUser)
      if (!rowUser.equals(username.trim(), ignoreCase = true)) continue

      val rowPlan = safeGet(cols, idxPlan)
      val rowStart = safeGet(cols, idxStart)
      val rowExpiry = safeGet(cols, idxExpiry)
      val rowStatus = safeGet(cols, idxStatus)
      val rowHash = safeGet(cols, idxHash)
      val rowSig = if (idxSignature >= 0) safeGet(cols, idxSignature).ifEmpty { null } else null

      if (!rowHash.equals(expectedHash, ignoreCase = true)) {
        settings.set(OrvaSettingKeys.SUBSCRIPTION_CACHED_STATUS, "InvalidActivationCode")
        return evaluateLocalStatus()
      }

      val verifier = licenseVault?.vendorSignatureVerifier
      if (verifier != null && verifier.isEnforced) {
        val sigOk =
          verifier.verifyRowSignature(
            username = rowUser,
            plan = rowPlan,
            startDateRaw = rowStart,
            expiryDateRaw = rowExpiry,
            status = rowStatus,
            activationCodeSha256 = rowHash,
            signatureBase64 = rowSig,
          )
        if (!sigOk) {
          settings.set(OrvaSettingKeys.SUBSCRIPTION_CACHED_STATUS, "InvalidSignature")
          return evaluateLocalStatus()
        }
      }

      val currentElapsedMs = monotonicElapsedMsProvider()
      settings.set(OrvaSettingKeys.SUBSCRIPTION_CACHED_PLAN, rowPlan)
      settings.set(OrvaSettingKeys.SUBSCRIPTION_CACHED_START, rowStart)
      settings.set(OrvaSettingKeys.SUBSCRIPTION_CACHED_EXPIRY, rowExpiry)
      settings.set(OrvaSettingKeys.SUBSCRIPTION_CACHED_STATUS, rowStatus)
      settings.set(OrvaSettingKeys.SUBSCRIPTION_LAST_VERIFIED_UTC, now.utcIsoText)
      settings.set(OrvaSettingKeys.SUBSCRIPTION_LAST_SEEN_UTC, now.utcIsoText)
      if (currentElapsedMs >= 0L) {
        settings.set(SETTING_LAST_SEEN_ELAPSED_MS, currentElapsedMs.toString())
      }

      // Seal tamper-proof ORVA/license.orvalic (auto-creates ORVA/ folder on first write)
      // and mirror its SHA-256 anchor digest into SQLite app_setting.
      val written =
        licenseVault?.sealAndSaveWithAnchor(
          SealedLicensePayload(
            username = rowUser,
            plan = rowPlan,
            startDateRaw = rowStart,
            expiryDateRaw = rowExpiry,
            status = rowStatus,
            activationCodeSha256 = rowHash,
            vendorSignatureBase64 = rowSig,
            deviceInstallId = "",
            verifiedAtUtc = now.utcIsoText,
            lastSeenUtc = now.utcIsoText,
            lastSeenElapsedMs = if (currentElapsedMs >= 0L) currentElapsedMs else null,
          )
        )
      if (written != null) {
        settings.set(SETTING_LICENSE_ANCHOR_SHA256, written.envelopeSha256)
      }
      return evaluateLocalStatus()
    }

    settings.set(OrvaSettingKeys.SUBSCRIPTION_CACHED_STATUS, "NotFound")
    return evaluateLocalStatus()
  }

  override fun buildUpiPaymentUri(
    upiId: String,
    payeeName: String,
    amountRupees: String,
    note: String,
  ): String {
    val cleanUpi = upiId.trim()
    if (cleanUpi.isEmpty()) return ""
    val sb = StringBuilder("upi://pay?pa=").append(encodeQuery(cleanUpi))
    if (payeeName.isNotBlank()) sb.append("&pn=").append(encodeQuery(payeeName.trim()))
    if (amountRupees.isNotBlank()) sb.append("&am=").append(encodeQuery(amountRupees.trim()))
    sb.append("&cu=INR")
    if (note.isNotBlank()) sb.append("&tn=").append(encodeQuery(note.trim()))
    return sb.toString()
  }

  override fun buildWhatsAppClickToChatUrl(phone: String, message: String): String {
    val digits = phone.filter { it.isDigit() }
    val encodedMsg = encodeQuery(message.trim())
    return if (digits.isEmpty()) {
      "https://wa.me/?text=$encodedMsg"
    } else {
      "https://wa.me/$digits?text=$encodedMsg"
    }
  }

  private fun parseFlexibleDate(raw: String): LocalDate? {
    val trimmed = raw.trim()
    if (trimmed.isEmpty()) return null
    for (fmt in SUPPORTED_DATE_FORMATS) {
      val parsed = runCatching { LocalDate.parse(trimmed, fmt) }.getOrNull()
      if (parsed != null) return parsed
    }
    return null
  }

  private fun findCol(map: Map<String, Int>, aliases: List<String>, fallback: Int): Int {
    for (name in aliases) {
      map[name]?.let { return it }
    }
    return fallback
  }

  private fun safeGet(cols: List<String>, index: Int): String =
    if (index in cols.indices) cols[index].trim().trim('"') else ""

  private fun splitCsvLine(line: String): List<String> {
    val result = mutableListOf<String>()
    val sb = StringBuilder()
    var inQuotes = false
    var i = 0
    while (i < line.length) {
      val ch = line[i]
      if (ch == '"') {
        if (inQuotes && i + 1 < line.length && line[i + 1] == '"') {
          sb.append('"')
          i += 2
          continue
        }
        inQuotes = !inQuotes
      } else if (ch == ',' && !inQuotes) {
        result += sb.toString()
        sb.setLength(0)
      } else {
        sb.append(ch)
      }
      i++
    }
    result += sb.toString()
    return result
  }

  /**
   * Detects same-boot wall-clock rollback using Android's kernel-monotonic uptime
   * (`SystemClock.elapsedRealtime()`). If the device stayed booted (`currentElapsedMs >= baselineElapsedMs`)
   * and real monotonic uptime advanced significantly faster than the device wall clock
   * (`deltaRealMs - deltaWallMs > 2 hours`), the user moved the device clock backwards.
   */
  private fun isSameBootUptimeRollback(
    nowUtc: Instant,
    currentElapsedMs: Long,
    baselineUtc: Instant?,
    baselineElapsedMs: Long?,
  ): Boolean {
    if (baselineUtc == null || baselineElapsedMs == null || currentElapsedMs < 0L || baselineElapsedMs < 0L) {
      return false
    }
    if (currentElapsedMs < baselineElapsedMs) {
      // Device rebooted (elapsedRealtime reset to 0) — handled by the 24h wall-clock check instead.
      return false
    }
    val deltaRealMs = currentElapsedMs - baselineElapsedMs
    val deltaWallMs = Duration.between(baselineUtc, nowUtc).toMillis()
    return (deltaRealMs - deltaWallMs) > UPTIME_CLOCK_DRIFT_TOLERANCE_MS
  }

  private fun encodeQuery(value: String): String =
    URLEncoder.encode(value, "UTF-8").replace("+", "%20")
}
