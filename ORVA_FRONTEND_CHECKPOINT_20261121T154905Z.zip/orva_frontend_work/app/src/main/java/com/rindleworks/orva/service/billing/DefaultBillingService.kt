package com.rindleworks.orva.service.billing

import com.rindleworks.orva.data.local.OrvaDatabase
import com.rindleworks.orva.data.local.OrvaTransactionRunner
import com.rindleworks.orva.data.local.SqlLikeEscaper
import com.rindleworks.orva.data.local.entity.AuditLogEntity
import com.rindleworks.orva.data.local.entity.InvoiceEntity
import com.rindleworks.orva.data.local.entity.InvoiceLineEntity
import com.rindleworks.orva.data.local.entity.InvoiceSequenceEntity
import com.rindleworks.orva.data.local.entity.PaymentEntity
import com.rindleworks.orva.data.local.entity.ShopProfileEntity
import com.rindleworks.orva.data.local.entity.StockMovementEntity
import com.rindleworks.orva.data.repository.StockSnapshotState
import com.rindleworks.orva.domain.billing.BatchAllocationPreview
import com.rindleworks.orva.domain.billing.BillingIssue
import com.rindleworks.orva.domain.billing.BillingIssueCodes
import com.rindleworks.orva.domain.billing.BillingIssueSeverity
import com.rindleworks.orva.domain.billing.BillingService
import com.rindleworks.orva.domain.billing.InvoiceDraft
import com.rindleworks.orva.domain.billing.InvoiceLinePreview
import com.rindleworks.orva.domain.billing.InvoicePreviewResult
import com.rindleworks.orva.domain.billing.InvoiceResult
import com.rindleworks.orva.domain.billing.MedicineLookupResult
import com.rindleworks.orva.domain.common.InvoiceStatus
import com.rindleworks.orva.domain.common.OrvaDateTimeFormatters
import com.rindleworks.orva.domain.common.OrvaFormatters
import com.rindleworks.orva.domain.common.OrvaSettingKeys
import com.rindleworks.orva.domain.common.StockMovementType
import com.rindleworks.orva.domain.engine.BillingBatchRecord
import com.rindleworks.orva.domain.engine.BillingClock
import com.rindleworks.orva.domain.engine.BillingInstant
import com.rindleworks.orva.domain.engine.BillingMedicineRecord
import com.rindleworks.orva.domain.engine.CalculatedInvoice
import com.rindleworks.orva.domain.engine.CheckedMath
import com.rindleworks.orva.domain.engine.FefoAllocator
import com.rindleworks.orva.domain.engine.GstinValidator
import com.rindleworks.orva.domain.engine.IndianGstStateCatalog
import com.rindleworks.orva.domain.engine.InventoryAlertCalculator
import com.rindleworks.orva.domain.engine.InvoiceCalculator
import com.rindleworks.orva.domain.engine.InvoiceLineCalculationInput
import com.rindleworks.orva.domain.engine.ResolvedTaxPolicy
import com.rindleworks.orva.domain.settings.BillingTaxSettings
import com.rindleworks.orva.domain.settings.RoundOffMode
import com.rindleworks.orva.domain.settings.SupplyType
import com.rindleworks.orva.domain.settings.TaxPricingMode
import java.util.Locale
import java.util.UUID
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

/**
 * All 8 transactional failure-injection checkpoints matching ORVA WPF T19 rollback tests.
 */
enum class BillingCommitCheckpoint {
  AFTER_SEQUENCE_INCREMENT,
  AFTER_INVOICE_INSERT,
  AFTER_INVOICE_LINE_INSERT,
  AFTER_BATCH_DEDUCTION,
  AFTER_STOCK_MOVEMENT_INSERT,
  AFTER_PAYMENT_INSERT,
  AFTER_AUDIT_LOG_INSERT,
  AFTER_SNAPSHOT_DIRTY_UPDATE,
}

/**
 * Production transactional billing engine with exact parity to ORVA WPF BillingService.cs
 * and BillingRepository.cs.
 */
class DefaultBillingService(
  private val transactionRunner: OrvaTransactionRunner,
  private val clock: BillingClock,
  private val fefoAllocator: FefoAllocator = FefoAllocator(),
  private val invoiceCalculator: InvoiceCalculator = InvoiceCalculator(),
  private val snapshotRefresher: (suspend () -> Result<Boolean>)? = null,
  private val subscriptionService: com.rindleworks.orva.domain.settings.SubscriptionService? = null,
) : BillingService {

  private val json = Json { encodeDefaults = true }

  /** Test-only hook for deterministic T19 rollback verification across all 8 checkpoints. */
  internal var failureInjectionHook: ((BillingCommitCheckpoint) -> Unit)? = null

  override suspend fun searchMedicines(
    query: String,
    maximumResults: Int,
  ): List<MedicineLookupResult> =
    transactionRunner.runRead { db ->
      val limit = maximumResults.coerceIn(1, 200)
      val trimmed = query.trim().lowercase(Locale.ROOT)
      val now = BillingInstant.capture(clock)
      val currentYm = now.currentExpiryYearMonth

      val medicines =
        if (trimmed.isEmpty()) {
          db.medicineDao().getActiveMedicines().take(limit)
        } else {
          db.medicineDao()
            .searchActiveMedicines(
              likePattern = SqlLikeEscaper.containsPattern(trimmed),
              prefixPattern = SqlLikeEscaper.prefixPattern(trimmed),
              exactLower = trimmed,
              limit = limit,
            )
        }

      medicines.map { med ->
        val batches = db.stockBatchDao().getByMedicineId(med.medicineId)
        var usableTotal = 0L
        var expiredPositiveTotal = 0L
        var blockedOrQuarantinedTotal = 0L
        for (b in batches) {
          if (b.quantityMilli <= 0L) continue
          when {
            b.batchStatus == "ACTIVE" && b.expiryYyyyMm >= currentYm ->
              usableTotal = CheckedMath.addExact(usableTotal, b.quantityMilli)
            b.batchStatus == "EXPIRED" || b.expiryYyyyMm < currentYm ->
              expiredPositiveTotal = CheckedMath.addExact(expiredPositiveTotal, b.quantityMilli)
            else ->
              blockedOrQuarantinedTotal = CheckedMath.addExact(blockedOrQuarantinedTotal, b.quantityMilli)
          }
        }

        val isLowStock =
          InventoryAlertCalculator.isLowStock(
            isMedicineActive = med.isActive == 1,
            usableQuantityMilli = usableTotal,
            thresholdMilli = med.lowStockThresholdMilli,
          )
        val canSell = usableTotal > 0L
        val availabilityMessage =
          when {
            usableTotal > 0L ->
              "Available: ${OrvaFormatters.formatQuantity(usableTotal)} ${med.stockUnitName}"
            expiredPositiveTotal > 0L -> "Expired stock only — cannot sell"
            blockedOrQuarantinedTotal > 0L -> "Quarantined/blocked stock only — cannot sell"
            else -> "Out of stock"
          }

        MedicineLookupResult(
          medicineId = med.medicineId,
          displayName = med.displayName,
          genericName = med.genericName,
          brandName = med.brandName,
          strength = med.strength,
          dosageForm = med.dosageForm,
          stockUnitName = med.stockUnitName,
          availableQuantityMilli = usableTotal,
          lowStockThresholdMilli = med.lowStockThresholdMilli,
          isLowStock = isLowStock,
          canSell = canSell,
          availabilityMessage = availabilityMessage,
        )
      }
    }

  override suspend fun previewInvoice(draft: InvoiceDraft): InvoicePreviewResult {
    val subBlock = checkSubscriptionBillingGate()
    val preview =
      transactionRunner.runRead { db ->
        val now = BillingInstant.capture(clock)
        evaluateDraft(db, draft, now).preview
      }
    return if (subBlock != null) {
      preview.copy(canFinalize = false, issues = listOf(subBlock) + preview.issues)
    } else {
      preview
    }
  }

  override suspend fun finalizeInvoice(draft: InvoiceDraft): InvoiceResult {
    val subBlock = checkSubscriptionBillingGate()
    if (subBlock != null) {
      return InvoiceResult(succeeded = false, issues = listOf(subBlock))
    }

    val commitOutcome =
      transactionRunner.runWriteTransaction { db ->
        val now = BillingInstant.capture(clock)
        val evaluation = evaluateDraft(db, draft, now)
        if (!evaluation.preview.canFinalize ||
          evaluation.calculated == null ||
          evaluation.shopProfile == null ||
          evaluation.resolvedTaxPolicy == null
        ) {
          return@runWriteTransaction CommitOutcome.Rejected(evaluation.preview.issues)
        }

        val profile = evaluation.shopProfile
        val calc = evaluation.calculated
        val taxPolicy = evaluation.resolvedTaxPolicy
        val utcIso = now.utcIsoText
        val localText = now.localLogText
        val financialYear =
          InvoiceCalculator.getFinancialYearLabel(now.localBusinessDate, profile.financialYearStartMonth)

        // Checkpoint 1: Sequence increment
        val currentSeq = db.invoiceDao().getSequence(financialYear)?.lastNumber ?: 0L
        val nextSeq = CheckedMath.addExact(currentSeq, 1L)
        val invoiceNumber =
          InvoiceCalculator.formatInvoiceNumber(profile.invoicePrefix, financialYear, nextSeq)
        db.invoiceDao().upsertSequence(InvoiceSequenceEntity(financialYear, nextSeq))
        failureInjectionHook?.invoke(BillingCommitCheckpoint.AFTER_SEQUENCE_INCREMENT)

        // Checkpoint 2: Invoice header insert
        val invoiceId = UUID.randomUUID().toString()
        val cleanCustomerName = draft.customer.name?.trim()?.ifEmpty { null }
        val cleanCustomerPhone = draft.customer.phone?.trim()?.ifEmpty { null }
        val cleanCustomerAddress = draft.customer.address?.trim()?.ifEmpty { null }
        val invoiceEntity =
          InvoiceEntity(
            invoiceId = invoiceId,
            invoiceNumber = invoiceNumber,
            financialYear = financialYear,
            issuedAtUtc = utcIso,
            issuedLocalOffsetMinutes = now.localOffsetMinutes,
            customerName = cleanCustomerName,
            customerPhone = cleanCustomerPhone,
            customerAddress = cleanCustomerAddress,
            customerGstin = evaluation.normalizedCustomerGstin,
            placeOfSupplyStateCode = taxPolicy.placeOfSupplyStateCode.ifEmpty { null },
            subtotalPaise = calc.subtotalPaise,
            discountPaise = calc.discountPaise,
            taxableValuePaise = calc.taxableValuePaise,
            cgstPaise = calc.cgstPaise,
            sgstPaise = calc.sgstPaise,
            igstPaise = calc.igstPaise,
            roundOffPaise = calc.roundOffPaise,
            grandTotalPaise = calc.grandTotalPaise,
            status = InvoiceStatus.Issued.dbValue,
            cancellationReason = null,
            createdAtUtc = utcIso,
          )
        db.invoiceDao().insertInvoice(invoiceEntity)
        failureInjectionHook?.invoke(BillingCommitCheckpoint.AFTER_INVOICE_INSERT)

        // Checkpoint 3, 4, 5: Invoice lines, guarded batch deductions, stock movements
        val batchAfterSnapshots = mutableListOf<BatchAuditSnapshot>()
        val batchBeforeSnapshots = mutableListOf<BatchAuditSnapshot>()

        for (medLine in calc.lines) {
          for (batchLine in medLine.batchLines) {
            val invoiceLineId = UUID.randomUUID().toString()
            db.invoiceDao()
              .insertInvoiceLine(
                InvoiceLineEntity(
                  invoiceLineId = invoiceLineId,
                  invoiceId = invoiceId,
                  lineGroupId = medLine.lineGroupId,
                  medicineId = medLine.medicineId,
                  batchId = batchLine.batchId,
                  medicineNameSnapshot = medLine.medicineName,
                  batchNumberSnapshot = batchLine.batchNumber,
                  expiryYyyyMmSnapshot = batchLine.expiryYyyyMm,
                  quantityMilli = batchLine.quantityMilli,
                  unitNameSnapshot = batchLine.stockUnitName,
                  unitPricePaise = batchLine.unitPricePaise,
                  discountPaise = batchLine.discountPaise,
                  taxableValuePaise = batchLine.taxableValuePaise,
                  gstRateBasisPoints = batchLine.gstRateBasisPoints,
                  hsnCodeSnapshot = batchLine.hsnCode,
                  cgstPaise = batchLine.cgstPaise,
                  sgstPaise = batchLine.sgstPaise,
                  igstPaise = batchLine.igstPaise,
                  lineTotalPaise = batchLine.lineTotalPaise,
                  createdAtUtc = utcIso,
                )
              )
            failureInjectionHook?.invoke(BillingCommitCheckpoint.AFTER_INVOICE_LINE_INSERT)

            // Guarded deduction: requires ACTIVE and quantity_milli >= deductMilli
            val rowsAffected =
              db.stockBatchDao()
                .deductQuantityGuarded(
                  batchId = batchLine.batchId,
                  deductMilli = batchLine.quantityMilli,
                  updatedAtUtc = utcIso,
                )
            if (rowsAffected != 1) {
              throw IllegalStateException(
                "Guarded stock deduction failed for batch '${batchLine.batchNumber}' (${batchLine.batchId}); insufficient active stock."
              )
            }
            failureInjectionHook?.invoke(BillingCommitCheckpoint.AFTER_BATCH_DEDUCTION)

            val newQty = CheckedMath.subtractExact(batchLine.previousQuantityMilli, batchLine.quantityMilli)
            batchBeforeSnapshots += BatchAuditSnapshot(batchLine.batchId, batchLine.previousQuantityMilli)
            batchAfterSnapshots += BatchAuditSnapshot(batchLine.batchId, newQty)

            db.ledgerDao()
              .insertStockMovement(
                StockMovementEntity(
                  movementId = UUID.randomUUID().toString(),
                  batchId = batchLine.batchId,
                  medicineId = medLine.medicineId,
                  movementType = StockMovementType.Sale.dbValue,
                  quantityDeltaMilli = CheckedMath.negateExact(batchLine.quantityMilli),
                  referenceType = "INVOICE",
                  referenceId = invoiceId,
                  reason = "Sale invoice $invoiceNumber",
                  createdAtUtc = utcIso,
                  createdLocalText = localText,
                )
              )
            failureInjectionHook?.invoke(BillingCommitCheckpoint.AFTER_STOCK_MOVEMENT_INSERT)
          }
        }

        // Checkpoint 6: Payments insert
        for (tender in draft.tenders) {
          db.invoiceDao()
            .insertPayment(
              PaymentEntity(
                paymentId = UUID.randomUUID().toString(),
                invoiceId = invoiceId,
                method = tender.method.dbValue,
                amountPaise = tender.amountPaise,
                referenceText = tender.referenceText?.trim()?.ifEmpty { null },
                paidAtUtc = utcIso,
              )
            )
          failureInjectionHook?.invoke(BillingCommitCheckpoint.AFTER_PAYMENT_INSERT)
        }

        // Checkpoint 7: Audit log insert
        db.ledgerDao()
          .insertAuditLog(
            AuditLogEntity(
              auditId = UUID.randomUUID().toString(),
              actionType = "INVOICE_ISSUED",
              entityType = "invoice",
              entityId = invoiceId,
              summary =
                "Issued invoice $invoiceNumber for ₹${OrvaFormatters.formatRupees(calc.grandTotalPaise)}",
              beforeJson = json.encodeToString(InvoiceBeforeAudit(batchBeforeSnapshots)),
              afterJson =
                json.encodeToString(
                  InvoiceAfterAudit(
                    invoiceNumber = invoiceNumber,
                    grandTotalPaise = calc.grandTotalPaise,
                    batches = batchAfterSnapshots,
                  )
                ),
              createdAtUtc = utcIso,
              createdLocalText = localText,
            )
          )
        failureInjectionHook?.invoke(BillingCommitCheckpoint.AFTER_AUDIT_LOG_INSERT)

        // Checkpoint 8: Stock snapshot dirty + generation increment
        StockSnapshotState.markDirtyAndIncrementGeneration(db, utcIso)
        failureInjectionHook?.invoke(BillingCommitCheckpoint.AFTER_SNAPSHOT_DIRTY_UPDATE)

        CommitOutcome.Committed(
          InvoiceResult(
            succeeded = true,
            invoiceId = invoiceId,
            invoiceNumber = invoiceNumber,
            issuedAtUtc = utcIso,
            issuedLocalOffsetMinutes = now.localOffsetMinutes,
            grandTotalPaise = calc.grandTotalPaise,
          )
        )
      }

    return when (commitOutcome) {
      is CommitOutcome.Rejected ->
        InvoiceResult(succeeded = false, issues = commitOutcome.issues)
      is CommitOutcome.Committed -> {
        val warnings = mutableListOf<String>()
        val refresher = snapshotRefresher
        if (refresher != null) {
          val refreshResult = runCatching { refresher.invoke() }.getOrElse { Result.failure(it) }
          if (refreshResult.isFailure) {
            warnings +=
              "Invoice saved, but StockData.json refresh failed: ${refreshResult.exceptionOrNull()?.message ?: "unknown error"}"
          }
        }
        commitOutcome.result.copy(warnings = warnings)
      }
    }
  }

  private suspend fun checkSubscriptionBillingGate(): BillingIssue? {
    val service = subscriptionService ?: return null
    val status = service.evaluateLocalStatus()
    return if (!status.allowNewBilling) {
      BillingIssue(
        code = "SUBSCRIPTION_BILLING_PAUSED",
        severity = BillingIssueSeverity.Blocking,
        message = status.message,
      )
    } else {
      null
    }
  }

  private fun evaluateDraft(
    db: OrvaDatabase,
    draft: InvoiceDraft,
    now: BillingInstant,
  ): DraftEvaluation {
    val issues = mutableListOf<BillingIssue>()

    // 1. Validate shop profile
    val shopProfile = db.shopProfileDao().getProfile()
    if (shopProfile == null || shopProfile.shopName.isBlank()) {
      issues +=
        blocking(
          BillingIssueCodes.SHOP_PROFILE_MISSING,
          "Shop profile must be configured in Settings before billing.",
        )
    } else if (!InvoiceCalculator.isValidInvoicePrefix(shopProfile.invoicePrefix)) {
      issues +=
        blocking(
          BillingIssueCodes.INVOICE_PREFIX_INVALID,
          "Invoice prefix '${shopProfile.invoicePrefix}' is invalid. Update it in Settings (1-3 characters).",
        )
    }

    // 2. Validate billing tax settings
    val taxSettings = readTaxSettings(db)
    if (!taxSettings.isConfigured ||
      taxSettings.pricingMode == null ||
      taxSettings.defaultSupplyType == null ||
      taxSettings.roundOffMode == null
    ) {
      issues +=
        blocking(
          BillingIssueCodes.TAX_CONFIG_MISSING,
          "Billing tax settings (pricing mode, supply type, and round-off) must be configured in Settings before billing.",
        )
    }

    // 3. Validate customer GSTIN & resolve supply type + place of supply
    var normalizedCustomerGstin: String? = null
    var customerGstinStateCode: String? = null
    val rawCustomerGstin = draft.customer.gstin?.trim().orEmpty()
    if (rawCustomerGstin.isNotEmpty()) {
      val gstinCheck = GstinValidator.validate(rawCustomerGstin)
      if (!gstinCheck.isValid) {
        issues +=
          blocking(
            BillingIssueCodes.CUSTOMER_GSTIN_INVALID,
            gstinCheck.errorMessage ?: "Customer GSTIN is invalid.",
          )
      } else {
        normalizedCustomerGstin = gstinCheck.normalizedGstin
        customerGstinStateCode = gstinCheck.stateCode
      }
    }

    // Always require a valid shop GST state code (matches WPF BillingService.cs)
    val shopStateCode = shopProfile?.stateCode?.trim()?.ifEmpty { null }
    val validShopState =
      shopStateCode != null && IndianGstStateCatalog.isValidShopStateCode(shopStateCode)
    if (shopProfile != null && !validShopState) {
      issues +=
        blocking(
          BillingIssueCodes.SHOP_STATE_CODE_MISSING,
          "Shop GST state code must be selected in Settings before billing.",
        )
    }

    var resolvedTaxPolicy: ResolvedTaxPolicy? = null
    if (taxSettings.isConfigured &&
      taxSettings.pricingMode != null &&
      taxSettings.defaultSupplyType != null &&
      taxSettings.roundOffMode != null &&
      validShopState &&
      shopStateCode != null
    ) {
      if (customerGstinStateCode != null) {
        if (customerGstinStateCode == shopStateCode) {
          resolvedTaxPolicy =
            ResolvedTaxPolicy(
              pricingMode = taxSettings.pricingMode,
              supplyType = SupplyType.IntraState,
              roundOffMode = taxSettings.roundOffMode,
              placeOfSupplyStateCode = shopStateCode,
            )
        } else {
          // Exact WPF parity: never silently assume inter-state IGST from an out-of-state customer GSTIN.
          issues +=
            blocking(
              BillingIssueCodes.PLACE_OF_SUPPLY_REQUIRES_REVIEW,
              "Customer GSTIN is registered in another state ($customerGstinStateCode). Inter-state place of supply cannot be assumed automatically; confirm tax treatment with your CA.",
            )
        }
      } else if (rawCustomerGstin.isEmpty()) {
        resolvedTaxPolicy =
          ResolvedTaxPolicy(
            pricingMode = taxSettings.pricingMode,
            supplyType = taxSettings.defaultSupplyType,
            roundOffMode = taxSettings.roundOffMode,
            placeOfSupplyStateCode = shopStateCode,
          )
      }
    }

    // 4. Validate & merge draft items
    if (draft.items.isEmpty()) {
      issues += blocking(BillingIssueCodes.DRAFT_EMPTY, "Add at least one medicine to create an invoice.")
    }

    val mergedQuantities = LinkedHashMap<String, Long>()
    for (item in draft.items) {
      val medId = item.medicineId.trim()
      if (medId.isEmpty()) {
        issues += blocking(BillingIssueCodes.INVALID_ITEM, "Invoice contains an item with no medicine selected.")
        continue
      }
      if (item.quantityMilli <= 0L) {
        issues +=
          blocking(
            BillingIssueCodes.INVALID_QUANTITY,
            "Quantity must be greater than zero.",
            medicineId = medId,
          )
        continue
      }
      val existing = mergedQuantities[medId] ?: 0L
      try {
        mergedQuantities[medId] = CheckedMath.addExact(existing, item.quantityMilli)
      } catch (_: ArithmeticException) {
        issues +=
          blocking(
            BillingIssueCodes.QUANTITY_OVERFLOW,
            "Combined quantity exceeds supported numeric limits.",
            medicineId = medId,
          )
      }
    }

    // 5. Lookup medicines & allocate FEFO batches
    val calculationInputs = mutableListOf<InvoiceLineCalculationInput>()
    val currentYm = now.currentExpiryYearMonth

    for ((medId, requestedQty) in mergedQuantities) {
      val med = db.medicineDao().getById(medId)
      if (med == null) {
        issues +=
          blocking(
            BillingIssueCodes.MEDICINE_NOT_FOUND,
            "Medicine '$medId' was not found in inventory.",
            medicineId = medId,
          )
        continue
      }
      if (med.isActive != 1) {
        issues +=
          blocking(
            BillingIssueCodes.MEDICINE_INACTIVE,
            "'${med.displayName}' is inactive and cannot be billed.",
            medicineId = medId,
          )
        continue
      }
      if (med.gstRateConfigured != 1) {
        issues +=
          blocking(
            BillingIssueCodes.MEDICINE_TAX_NOT_CONFIGURED,
            "GST rate for '${med.displayName}' is not configured yet. Configure it in Settings > Tax.",
            medicineId = medId,
          )
        continue
      }

      val batches =
        db.stockBatchDao().getByMedicineId(medId).map { b ->
          BillingBatchRecord(
            batchId = b.batchId,
            medicineId = b.medicineId,
            batchNumber = b.batchNumber,
            expiryYyyyMm = b.expiryYyyyMm,
            stockUnitName = b.stockUnitName,
            mrpPaise = b.mrpPaise,
            quantityMilli = b.quantityMilli,
            batchStatus = b.batchStatus,
          )
        }

      val outcome =
        try {
          fefoAllocator.allocate(batches, requestedQty, currentYm)
        } catch (_: ArithmeticException) {
          issues +=
            blocking(
              BillingIssueCodes.CALCULATION_OVERFLOW,
              "Stock quantity calculation overflowed for '${med.displayName}'.",
              medicineId = medId,
            )
          continue
        }

      if (!outcome.succeeded) {
        issues +=
          blocking(
            BillingIssueCodes.INSUFFICIENT_STOCK,
            "Insufficient usable stock for '${med.displayName}': requested ${OrvaFormatters.formatQuantity(requestedQty)} ${med.stockUnitName}, available ${OrvaFormatters.formatQuantity(outcome.availableQuantityMilli)} ${med.stockUnitName}.",
            medicineId = medId,
          )
        continue
      }

      calculationInputs +=
        InvoiceLineCalculationInput(
          medicine =
            BillingMedicineRecord(
              medicineId = med.medicineId,
              displayName = med.displayName,
              genericName = med.genericName,
              brandName = med.brandName,
              strength = med.strength,
              dosageForm = med.dosageForm,
              stockUnitName = med.stockUnitName,
              hsnCode = med.hsnCode,
              gstRateBasisPoints = med.gstRateBasisPoints,
              gstRateConfigured = true,
              lowStockThresholdMilli = med.lowStockThresholdMilli,
              isActive = true,
            ),
          requestedQuantityMilli = requestedQty,
          allocations = outcome.allocations,
        )
    }

    // Check if draft items/config are valid before payment checks
    val hasDraftBlockingIssues = issues.any { it.severity == BillingIssueSeverity.Blocking }

    // 6. Calculate line & invoice totals when possible
    var calculated: CalculatedInvoice? = null
    if (!hasDraftBlockingIssues && resolvedTaxPolicy != null && calculationInputs.isNotEmpty()) {
      try {
        calculated = invoiceCalculator.calculate(calculationInputs, resolvedTaxPolicy)
      } catch (_: ArithmeticException) {
        issues +=
          blocking(
            BillingIssueCodes.CALCULATION_OVERFLOW,
            "Invoice totals exceeded maximum supported integer paise limits.",
          )
      }
    }

    val isDraftValid =
      calculated != null && issues.none { it.severity == BillingIssueSeverity.Blocking }

    // 7. Validate payment tenders (exact reconciliation)
    var tenderTotal = 0L
    var paymentOverflow = false
    for (tender in draft.tenders) {
      if (tender.amountPaise <= 0L) {
        issues +=
          blocking(
            BillingIssueCodes.INVALID_PAYMENT_AMOUNT,
            "Payment tender amount for ${tender.method.dbValue} must be greater than zero.",
          )
        continue
      }
      try {
        tenderTotal = CheckedMath.addExact(tenderTotal, tender.amountPaise)
      } catch (_: ArithmeticException) {
        paymentOverflow = true
      }
    }
    if (paymentOverflow) {
      issues +=
        blocking(
          BillingIssueCodes.CALCULATION_OVERFLOW,
          "Combined tender total exceeded supported numeric limits.",
        )
    }

    val grandTotal = calculated?.grandTotalPaise ?: 0L
    val amountRemaining =
      if (paymentOverflow) {
        0L
      } else {
        try {
          CheckedMath.subtractExact(grandTotal, tenderTotal)
        } catch (_: ArithmeticException) {
          issues +=
            blocking(
              BillingIssueCodes.CALCULATION_OVERFLOW,
              "Remaining balance calculation overflowed.",
            )
          0L
        }
      }

    var isFullyPaid = false
    if (isDraftValid && !paymentOverflow) {
      when {
        tenderTotal < grandTotal -> {
          issues +=
            blocking(
              BillingIssueCodes.PAYMENT_SHORT,
              "Tender total ₹${OrvaFormatters.formatRupees(tenderTotal)} is short of grand total ₹${OrvaFormatters.formatRupees(grandTotal)} by ₹${OrvaFormatters.formatRupees(amountRemaining)}.",
            )
        }
        tenderTotal > grandTotal -> {
          issues +=
            blocking(
              BillingIssueCodes.PAYMENT_OVERPAID,
              "Tender total ₹${OrvaFormatters.formatRupees(tenderTotal)} exceeds grand total ₹${OrvaFormatters.formatRupees(grandTotal)}. Exact tender reconciliation is required.",
            )
        }
        else -> {
          isFullyPaid = true
        }
      }
    }

    val linePreviews =
      calculated?.lines?.map { line ->
        InvoiceLinePreview(
          medicineId = line.medicineId,
          medicineName = line.medicineName,
          quantityMilli = line.quantityMilli,
          stockUnitName = line.stockUnitName,
          batchAllocations =
            line.batchLines.map { b ->
              BatchAllocationPreview(
                batchNumber = b.batchNumber,
                expiryYyyyMm = b.expiryYyyyMm,
                quantityMilli = b.quantityMilli,
                unitPricePaise = b.unitPricePaise,
                subtotalPaise = b.subtotalPaise,
                taxableValuePaise = b.taxableValuePaise,
                cgstPaise = b.cgstPaise,
                sgstPaise = b.sgstPaise,
                igstPaise = b.igstPaise,
                lineTotalPaise = b.lineTotalPaise,
              )
            },
          subtotalPaise = line.subtotalPaise,
          taxableValuePaise = line.taxableValuePaise,
          cgstPaise = line.cgstPaise,
          sgstPaise = line.sgstPaise,
          igstPaise = line.igstPaise,
          lineTotalPaise = line.lineTotalPaise,
        )
      }.orEmpty()

    val canFinalize =
      isDraftValid &&
        isFullyPaid &&
        issues.none { it.severity == BillingIssueSeverity.Blocking }

    val preview =
      InvoicePreviewResult(
        isDraftValid = isDraftValid,
        canFinalize = canFinalize,
        lines = linePreviews,
        issues = issues,
        subtotalPaise = calculated?.subtotalPaise ?: 0L,
        discountPaise = 0L,
        taxableValuePaise = calculated?.taxableValuePaise ?: 0L,
        cgstPaise = calculated?.cgstPaise ?: 0L,
        sgstPaise = calculated?.sgstPaise ?: 0L,
        igstPaise = calculated?.igstPaise ?: 0L,
        roundOffPaise = calculated?.roundOffPaise ?: 0L,
        grandTotalPaise = grandTotal,
        tenderTotalPaise = tenderTotal,
        amountRemainingPaise = amountRemaining,
        isFullyPaid = isFullyPaid,
      )

    return DraftEvaluation(
      preview = preview,
      calculated = calculated,
      shopProfile = shopProfile,
      resolvedTaxPolicy = resolvedTaxPolicy,
      normalizedCustomerGstin = normalizedCustomerGstin,
    )
  }

  private fun readTaxSettings(db: OrvaDatabase): BillingTaxSettings {
    val map = db.appSettingDao().getAll().associate { it.settingKey to it.settingValue }
    val configured = map[OrvaSettingKeys.TAX_CONFIGURED]?.trim() == "1"
    val pricing = TaxPricingMode.fromDbValue(map[OrvaSettingKeys.TAX_PRICING_MODE])
    val supply = SupplyType.fromDbValue(map[OrvaSettingKeys.DEFAULT_SUPPLY_TYPE])
    val roundOff = RoundOffMode.fromDbValue(map[OrvaSettingKeys.ROUND_OFF_MODE])
    return BillingTaxSettings(
      isConfigured = configured && pricing != null && supply != null && roundOff != null,
      pricingMode = pricing,
      defaultSupplyType = supply,
      roundOffMode = roundOff,
    )
  }

  private fun blocking(code: String, message: String, medicineId: String? = null): BillingIssue =
    BillingIssue(
      severity = BillingIssueSeverity.Blocking,
      code = code,
      message = message,
      medicineId = medicineId,
    )

  private data class DraftEvaluation(
    val preview: InvoicePreviewResult,
    val calculated: CalculatedInvoice?,
    val shopProfile: ShopProfileEntity?,
    val resolvedTaxPolicy: ResolvedTaxPolicy?,
    val normalizedCustomerGstin: String?,
  )

  private sealed interface CommitOutcome {
    data class Rejected(val issues: List<BillingIssue>) : CommitOutcome
    data class Committed(val result: InvoiceResult) : CommitOutcome
  }

  @Serializable
  private data class BatchAuditSnapshot(val batchId: String, val quantityMilli: Long)

  @Serializable
  private data class InvoiceBeforeAudit(val batches: List<BatchAuditSnapshot>)

  @Serializable
  private data class InvoiceAfterAudit(
    val invoiceNumber: String,
    val grandTotalPaise: Long,
    val batches: List<BatchAuditSnapshot>,
  )
}
