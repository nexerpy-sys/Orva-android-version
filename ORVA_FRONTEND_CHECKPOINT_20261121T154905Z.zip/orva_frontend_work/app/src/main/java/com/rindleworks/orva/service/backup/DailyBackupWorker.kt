package com.rindleworks.orva.service.backup

import android.content.Context
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.rindleworks.orva.domain.settings.BackupRestoreService
import java.util.concurrent.TimeUnit

/**
 * Provides the active [BackupRestoreService] to [DailyBackupWorker] without forcing heavy DI
 * frameworks. Wired automatically in [com.rindleworks.orva.OrvaApplication].
 */
interface BackupServiceHolder {
  val backupRestoreService: BackupRestoreService
}

/**
 * WorkManager background worker that executes ORVA's daily local `.shopbackup` when due.
 */
class DailyBackupWorker(
  appContext: Context,
  workerParams: WorkerParameters,
) : CoroutineWorker(appContext, workerParams) {

  override suspend fun doWork(): Result {
    val holder = applicationContext as? BackupServiceHolder ?: return Result.success()
    val outcome = runCatching { holder.backupRestoreService.runDailyBackupIfDue() }
    return outcome.fold(
      onSuccess = { res ->
        if (res == null || res.succeeded) Result.success() else Result.retry()
      },
      onFailure = { Result.retry() },
    )
  }
}

object DailyBackupScheduler {
  const val UNIQUE_WORK_NAME = "orva_automatic_daily_backup"

  fun schedulePeriodic(context: Context) {
    val constraints =
      Constraints.Builder()
        .setRequiresStorageNotLow(true)
        .build()

    val request =
      PeriodicWorkRequestBuilder<DailyBackupWorker>(24, TimeUnit.HOURS)
        .setConstraints(constraints)
        .build()

    WorkManager.getInstance(context.applicationContext)
      .enqueueUniquePeriodicWork(
        UNIQUE_WORK_NAME,
        ExistingPeriodicWorkPolicy.KEEP,
        request,
      )
  }
}
