# ORVA theme morph engine — 21 November 2026

## Approved direction

All three design systems are approved together as dynamic identities:

- **A — The Measured Press:** Archivo / Newsreader / Space Mono; Vessel `#171D19`, Glass Shelf `#28322B`, Label Stock `#F0EBDD`, Proof Oxide `#D16A4A`, Assay Sage `#A5BBA8`; proof-press composition; variable-word compile entrance; hero 68/80/112sp, body 17/26sp, utility 10.5sp, scale ratio 1.333.
- **B — The Field Specimen:** Bricolage Grotesque / Source Serif 4 / Martian Mono; Proof Paper `#EEE8DC`, Pressed Stock `#D8D0C1`, Carbon Ink `#282B25`, Correction Red `#A9422D`, Verified Green `#386A60`; specimen-field composition; axis-settle entrance; hero 64/76/104sp, body 18/28sp, utility 10.5sp, scale ratio 1.25.
- **C — The Museum Index:** Gloock / Schibsted Grotesk / IBM Plex Mono; Catalogue Card `#E6E2D7`, Mount Board `#D4D1C6`, Graphite Ink `#282B2D`, Index Petrol `#1F5965`, Oxide Seal `#9C3F31`; museum-catalogue composition; serif line-mask entrance; hero 72/88/120sp, body 17/26sp, utility 10.5sp, scale ratio 1.333.

Noto Sans Bengali remains the Bengali script face. Do not use fonts banned by the user's latest ORVA design manual. All proposals A/B/C are accepted; do not ask the user to choose one.

## User's intended experience

Home and About retain the Agentic Build. A visitor first sees A being built. At a randomized but suitable moment and starting section, the same agent cursors reverse-build the affected region, visibly remove its old presentation, and rebuild it in the next design identity. Fonts, font sizes, palette, composition, spacing and motion change. The redesign spreads section by section. It is not a theme toggle or a cross-fade. Keep content, stable IDs, scroll position, interaction state and navigation intact. Manual scrolling stays responsive; pause morph work at safe boundaries and resume without losing partial work.

The random anchor must be visible, built, measured, layout-stable, and free from active interaction, accessibility focus, pinning/protection or another morph. Nearby regions are queued by proximity and wait until safe.

## Implemented in current source milestone

- `OrvaThemeMorphEngine.kt`: A/B/C catalog, random-delay policy, safe-anchor selection, outward region ordering, transaction coordinator, pause/resume and per-region theme lookup.
- `AgentTaskScheduler.kt`: morph-region ownership/inheritance, region-filtered build claims, scoped reverse claims and morph completion checks. Independent leaves can reverse concurrently under the existing eight-builder cap; dependency ordering remains enforced. Normal visitor rewind remains separately serialized and retains its 1.5-screen boundary.
- `AgenticBuildController.kt`: morph policy/coordinator connected to the existing single `withFrameNanos` loop and real scheduler task lifecycle. It waits for completed initial build, selects a safe anchor, reverses the old region, waits for stable new geometry, and dispenses the region in the new identity. Manual scrolling pauses; automatic scrolling can move to remaining visible work.
- `AgenticModifiers.kt`: morph-region inheritance and separate DISPLAY / READING / UTILITY reveal roles. Reading text enters as a quiet block; utility text retains grapheme-safe typing; display headings use A/B/C motion.
- `AboutUsScreen.kt`: all nine scenes have morph regions. A/B/C palette, layout grammar, hero/body sizing and tracking change per region; display/media entrances differ by theme. Existing content and actions remain.
- `AgenticHudBar.kt` and `AgenticOverlayCanvas.kt`: active-theme colours flow into HUD, gauge, cursor labels, outlines, wireframes, stamps and effects.
- The 16-agent roster and eight concurrent forward workers remain; no new dependency was added.

## Verification

- `./tools/run_pure_kotlin_tests.sh`: **85 passed, 0 failed**.
- `git diff --check`: passed.
- Android Gradle/Compose compilation, Robolectric suite, APK build and device/emulator visuals: **NOT RUN**. The available workspace has no Gradle executable, no Gradle wrapper JAR/script and no Android SDK/dependency cache.

## Pending work

1. **Fonts:** bundle exact A/B/C families and licences: Archivo, Newsreader, Space Mono Regular/Bold; Bricolage Grotesque, Source Serif 4, Martian Mono; Gloock; Schibsted Grotesk; IBM Plex Mono already exists. Keep Noto Sans Bengali. True font-axis animation is not implemented: A currently uses grapheme-safe progressive reveal; B's scale settle is only a temporary visual approximation until its variable font and axis controls are available.
2. **Home:** add the three identity compositions and morph regions to Home, while preserving the current Home content and implementing the approved H2 lantern wordmark sweep.
3. **Device verification:** Compose/Robolectric/Gradle build, visual checks at 360dp/390dp/412dp/tablet, Bengali glyph coverage, accessibility, reduced motion, touch takeover, scroll stability, performance and haptic behaviour.
4. **Timing:** the initial 18–32s and repeat 24–42s delays are provisional implementation defaults; validate and tune on device.

## Current milestone checkpoint

Latest source commit and archive are recorded in the corresponding checkpoint manifest. Never replace the previous archive. Pending work above must be carried into every future checkpoint.

## Home morph integration — WIP checkpoint, 21 November 2026

### Current work in source
- Reused the existing `AgenticBuildController`, frame clock, scheduler, 16-agent overlay and HUD for Home; no second animation engine was introduced.
- Divided Home into six independent morph regions (H1–H6) with stable region IDs and explicit region ownership for registered content.
- Added theme-aware layout grammar, palette, spacing and responsive headline/body sizing for A/B/C. H2's ORVA wordmark now has the one-shot lantern sweep tied to initial Agentic Build completion; reduced motion skips the travel animation.
- Connected Home scroll observation, manual takeover, lifecycle pause/resume and per-scene haptic feedback to the shared controller.
- Added H1–H6 theme providers and agentic registrations for the relevant content/media nodes. Existing navigation callbacks and business actions remain the same.
- Current implementation is an integration WIP, not a verified Android UI release. No Home-specific Compose/Robolectric test has been run.

### WIP verification
- `./tools/run_pure_kotlin_tests.sh`: **86 passed, 0 failed**.
- `git diff --check`: passed.
- Android/Compose compilation, Robolectric, APK, emulator and physical-device verification: **NOT RUN**. This workspace still lacks the full Android build toolchain.

### Pending before Home morph can be called complete
1. Review Home Composables under the actual Android/Compose compiler; correct any compile or runtime issues revealed there.
2. Add and run Home-specific Compose/Robolectric tests for region registration, initial A theme, A→B→C morph, scroll/takeover, navigation, reduced motion and H2 lantern sweep.
3. Inspect real captures at 360dp, 390dp, 412dp and tablet widths, in English and Bengali. Check that layout changes remain legible and no content/action disappears during a morph.
4. Tune the Home H2 lantern sweep so it reads as the wordmark's one signature light pass and does not compete with theme morph motion.
5. Bundle and register the exact A/B/C font files and OFL notices; implement true variable-axis animation where supported. Do not claim font integration complete yet.
6. Run full Android Gradle, Compose/Robolectric, APK and device checks once the Android toolchain is available.

This is a WIP checkpoint. Preserve it as the current recovery point until the Home topic is completed and separately checkpointed.

## Home visual composition pass — 21 November 2026

### Implemented in source
- H1 now has three distinct compositions: proof-press baseline (A), framed specimen sheet (B), and catalogue margin ruler (C).
- Home scene wrappers now add theme-specific sheet treatment and catalogue indexing rather than relying only on a palette swap.
- H2 lantern geometry changes by identity. A uses a broad horizontal light pass; B uses a tighter specimen press; C uses a narrow catalogue beam. The wordmark reveal follows the active theme's media motion and replays when H2 itself is rebuilt into a new identity. Reduced motion settles without travel.
- H3 no longer uses the explicitly prohibited Instrument Serif face for its secondary display line.
- H4 flagship wordmark placement and plate treatment vary by identity.
- H5 composition now differs by identity: A is a three-column press grid, B is a two-up sheet plus full-width sheet, and C is a ruled catalogue list.
- Added a pure test that all three identities have distinct layout grammars.

### Verification
- `./tools/run_pure_kotlin_tests.sh`: **87 passed, 0 failed**.
- `git diff --check`: passed.
- Android/Compose compilation, Home Compose/Robolectric tests, APK and device verification: **NOT RUN**. The current environment has no Gradle executable, wrapper JAR/script or Android SDK/dependency cache.

### Remaining work
1. Obtain and bundle the exact A/B/C font files and verified OFL notices; connect the real families to DISPLAY / READING / UTILITY roles. The theme catalog currently names the approved faces, but the font resources have not been replaced or wired. True variable-axis interpolation remains pending.
2. Compile with the Android/Compose toolchain and fix any issues found. Run Home-specific UI tests for initial build, A→B→C transitions, region ownership, scroll/takeover, navigation, reduced motion and H2 sweep.
3. Inspect EN/BN at 360dp, 390dp, 412dp and tablet widths. Confirm no content, focus, scroll position or actions are lost during region replacement.
4. Tune timing, haptics and performance on physical devices.

This is a source-level visual composition milestone, not a verified Android release. The Home morph engine remains WIP until the pending checks pass.
