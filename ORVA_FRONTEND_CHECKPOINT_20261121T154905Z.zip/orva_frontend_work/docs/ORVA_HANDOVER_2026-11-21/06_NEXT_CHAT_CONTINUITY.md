# ORVA — Context handover / 21 November 2026

## Authority and purpose
This handover prevents context loss. It preserves user instructions verbatim and preserves the assistant's previous audit/proposals verbatim. Do not treat an unselected proposal as an approved design system.

## Latest user design direction
The latest user-provided ORVA Design Direction and detailed Design Manual in `03_USER_ORVA_DESIGN_DIRECTION_VERBATIM.txt` is the current design-method authority. It defines ORVA as the portfolio of Rindle Works, a showcase of hand-built interfaces, and demands a distinctive, demonstrably crafted result rather than a template. The manual requires exactly three Latin type roles (display, reading, utility), no more than two families plus one mono, named/mixed colours, measured contrast, one dominant colour and one sharp accent, one hero motion sequence per page, type-appropriate animation, and a strict list of banned fonts, colours, looks and motion conventions.

The latest banned list explicitly includes Space Grotesk, Plus Jakarta Sans, Instrument Serif, JetBrains Mono and many common alternatives. Do not reuse them. Noto Sans Bengali remains needed for Bengali script support; treat it as a script-specific fallback rather than an additional Latin type role.

## Unresolved authority conflict — do not silently reconcile
Earlier user input in `01_USER_IDENTITY_AMENDMENTS_VERBATIM.txt` defines ORVA as THE DISPENSARY, a pharmacy product identity, with scored-tablet O, pipette gauge, stamps, blister cells and DISPENSE / MEASURE / STAMP / VERIFY language. The newest design direction defines ORVA as the Rindle Works portfolio and front-end craft showcase. Both user messages are preserved. The newest direction should guide the next design pass, but clarify whether any of the older pharmacy/dispensary metaphor is still wanted in the portfolio. Do not force that metaphor into every screen without resolving this.

## Approved three-theme morph system
The user explicitly chose **all three** directions in the latest conversation. They are not alternatives and not a manual theme picker. They are three complete visual identities through which the Home and About showcase can transform:
- A — The Measured Press: Archivo / Newsreader / Space Mono; proof-press layout; Vessel / Glass Shelf / Label Stock / Proof Oxide / Assay Sage palette.
- B — The Field Specimen: Bricolage Grotesque / Source Serif 4 / Martian Mono; specimen-field layout; Proof Paper / Pressed Stock / Carbon Ink / Correction Red / Verified Green palette.
- C — The Museum Index: Gloock / Schibsted Grotesk / IBM Plex Mono; museum-catalogue layout; Catalogue Card / Mount Board / Graphite Ink / Index Petrol / Oxide Seal palette.

The visitor first sees A being constructed. At an unexpected but suitable moment, Agentic Build cursors visibly reverse-build the affected region, then rebuild it in the next theme: typography, type sizes, colour, spacing, composition/layout and entrance motion all change. The wave begins at a randomly selected safe section and spreads to nearby regions. This is live agent-operated redesign, not a skin switch or cross-fade. Preserve the original Agentic Build; it is mandatory and must be improved, never removed.

See `10_USER_THEME_MORPH_CONFIRMATION_VERBATIM.txt` for the user's exact confirmation and `11_THEME_MORPH_ENGINE_STATUS_AND_PENDING.md` for the current implementation boundary, verified tests, provisional timing defaults and pending work.

## What the audit identified
The previous Home/About presentation was judged AI slop. The assistant's preserved critique is in file 05. The core identified problems were: conceptual stock-style images instead of real interface evidence; too many competing hero effects; too many type voices and overused technical labels; too many colour accents; abstract agency copy; generic composition patterns. The remedy is not adding more decoration or more lengthy specifications. It is showing actual crafted interfaces, using a clear hierarchy, fewer stronger compositions, authored asymmetry, evidence-rich case studies, and a restrained but unmistakable Agentic Build.

**Agentic Build is explicitly the user's favourite and must never be removed.** It may be improved, but its real construction process and cursor-agent work remain a defining experience.

## Source checkpoint
- Repository snapshot: `/mnt/data/orva_inspect`
- Branch: `master`
- HEAD at start of this handover: `e54f83498be2d0ee99ff7fdef2d7c4520e414523`
- Commit subject: `Frontend checkpoint 20261121T094711Z`
- Working tree was clean before handover documents were added.
- No Git remote is configured; keep handoff local / File Library / Dropbox, not a GitHub remote.
- Existing files include `HomeScreen.kt`, `AboutUsScreen.kt`, Agentic scheduler/controller/Canvas files and pure Kotlin tests.
- Current bundled font resources inspected: `space_grotesk.ttf`, `ibm_plex_mono.ttf`, `instrument_serif.ttf`, `plus_jakarta_sans.ttf`, `noto_sans_bengali.ttf`. This does NOT comply with the newest banned-font list. No new font binaries have been added by this handover.
- Existing source code was not intentionally changed in this handover; only documentation/context files were added.

## Verification
The pure Kotlin test script `./tools/run_pure_kotlin_tests.sh` was executed during this handover:
- 60 passed; 0 failed.
- Scope: JVM pure Kotlin only.
- Android Gradle build, Compose/Robolectric, emulator and physical device checks were not run. Do not claim them.

## Next actions
1. Confirm whether the earlier THE DISPENSARY metaphor still belongs in ORVA's showcase or whether the latest craft-portfolio definition replaces it.
2. Select one of A/B/C, or reject all three and request a new exploration.
3. For the selected type system, inspect and test actual binaries; verify licences/axes and rendering; do not rely on unverified remembered font facts.
4. Only then lock the ORVA signature.
5. Rebuild screen composition around real ORVA interface evidence. Preserve Agentic Build.
6. Have Gemini handle Phase B font files, axes, local bundling and license notices if that remains the agreed division of work.

## Current implementation checkpoint
The current worktree contains an initial pure-Kotlin morph engine and scheduler support. It defines the approved A/B/C theme catalog, random safe-anchor planning, near-neighbour wave order, per-region reverse/rebuild transaction state, region-scoped scheduler claims, and concurrent reversal of independent leaf nodes under the existing eight-builder limit. Ordinary reader rewind remains serialized and retains its separate 1.5-screen boundary.

This is **engine and scheduler foundation only**. It is not yet connected to the live controller or visible Compose theme providers, so the installed app does not yet perform the morph. See `11_THEME_MORPH_ENGINE_STATUS_AND_PENDING.md` for exact pending work. At this checkpoint, 76 pure JVM tests pass; Android/Compose/device testing has not been run.

## Exact records
- User inputs: files 01–04.
- Assistant audit, proposals and prior status messages: file 05.
- This file is a continuity guide, not a substitute for the verbatim records.

## Latest update — Home morph WIP, 21 November 2026
The user has approved A, B and C together as live identities, not choices. Current source reuses the existing Agentic Build controller/frame clock on Home and has H1–H6 morph regions, theme-aware palette/layout/type sizing, manual-scroll and lifecycle wiring, per-scene haptics and an H2 wordmark lantern sweep. This Home work is a WIP checkpoint: 86 pure Kotlin tests pass, but Android/Compose compilation and Home UI tests have not run. See `09_CHECKPOINT_STATUS.txt` and `11_THEME_MORPH_ENGINE_STATUS_AND_PENDING.md` for the precise pending work. Continue from the newest checkpoint ZIP in the File Library; do not assume the Home milestone is complete.
